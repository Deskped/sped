public class ModelBarrelPowder<T extends Entity> extends EntityModel<T> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "barrelpowder"), "main");
	private final ModelPart big;
	private final ModelPart powder;
	private final ModelPart pw;
	private final ModelPart wq;

	public ModelBarrelPowder(ModelPart root) {
		this.big = root.getChild("big");
		this.powder = this.big.getChild("powder");
		this.pw = this.powder.getChild("pw");
		this.wq = this.powder.getChild("wq");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition big = partdefinition.addOrReplaceChild("big", CubeListBuilder.create(),
				PartPose.offset(7.0F, 24.0F, -7.0F));

		PartDefinition powder = big.addOrReplaceChild("powder", CubeListBuilder.create(),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition pw = powder.addOrReplaceChild("pw", CubeListBuilder.create().texOffs(0, 0).addBox(-15.0F, -16.0F,
				-1.0F, 16.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition wq = powder.addOrReplaceChild("wq", CubeListBuilder.create().texOffs(0, 32).addBox(-15.0F,
				-16.0F, -1.0F, 16.0F, 16.0F, 16.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		big.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}