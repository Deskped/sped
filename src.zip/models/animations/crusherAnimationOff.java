public class crusherAnimationOff {
	public static final AnimationDefinition off = AnimationDefinition.Builder.withLength(0.0F).looping()
			.addAnimation("konchik",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F,
							KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}