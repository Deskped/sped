public class ezonetAnimationIdleClose {
	public static final AnimationDefinition EzonetIdleclose = AnimationDefinition.Builder.withLength(0.0417F)
			.addAnimation("onetotwo",
					new AnimationChannel(AnimationChannel.Targets.SCALE,
							new Keyframe(0.0F, KeyframeAnimations.scaleVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("twototwo",
					new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(0.0F,
							KeyframeAnimations.scaleVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.build();
}