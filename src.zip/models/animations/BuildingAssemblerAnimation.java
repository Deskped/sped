public class BuildingAssemblerAnimation {
	public static final AnimationDefinition start = AnimationDefinition.Builder.withLength(1.0F)
			.addAnimation("lever",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.LINEAR),
							new Keyframe(1.0F, KeyframeAnimations.degreeVec(0.0F, -360.0F, 0.0F),
									AnimationChannel.Interpolations.LINEAR)))
			.build();
}