public class AnimationRotate {
	public static final AnimationDefinition rotate = AnimationDefinition.Builder.withLength(1.5F).looping()
			.addAnimation("val",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.LINEAR),
							new Keyframe(1.5F, KeyframeAnimations.degreeVec(0.0F, 360.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}