#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    vec2 centered = texCoord - vec2(0.5);
    float r2 = dot(centered, centered);
    float k = 0.28;
    vec2 uv = centered * (1.0 - k * r2) + vec2(0.5);
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
    } else {
        fragColor = vec4(texture(DiffuseSampler, uv).rgb, 1.0);
    }
}
