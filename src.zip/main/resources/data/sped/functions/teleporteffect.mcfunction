particle minecraft:falling_obsidian_tear ~ ~ ~ 1 1 1 0.3 100
particle minecraft:dragon_breath ~ ~ ~ 1 1 1 0.3 100
particle minecraft:flash ~ ~ ~ 0.1 0.1 0.1 0.3 1