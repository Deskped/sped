package deskped.sped.deco;

import deskped.sped.SpedMod;
import deskped.sped.init.SpedModTabs;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class DecoReg {

	private static boolean attached;

	public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SpedMod.MODID);
	public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SpedMod.MODID);

	public static final List<DecoSet> MACHINES = new ArrayList<>();
	public static final List<DecoSet> GOLD = new ArrayList<>();

	public static final class DecoSet {
		public final RegistryObject<Block> base;
		public final RegistryObject<Block> stairs;
		public final RegistryObject<Block> slab;
		public final RegistryObject<Block> wall;

		DecoSet(RegistryObject<Block> base, RegistryObject<Block> stairs, RegistryObject<Block> slab, RegistryObject<Block> wall) {
			this.base = base;
			this.stairs = stairs;
			this.slab = slab;
			this.wall = wall;
		}
	}

	private static BlockBehaviour.Properties props(boolean metal) {
		return BlockBehaviour.Properties.of().sound(metal ? SoundType.METAL : SoundType.STONE).strength(metal ? 3.0f : 2.0f, 6.0f)
				.requiresCorrectToolForDrops();
	}

	private static void set(List<DecoSet> group, String id, boolean metal) {
		RegistryObject<Block> base = BLOCKS.register(id, () -> new Block(props(metal)));
		RegistryObject<Block> stairs = BLOCKS.register(id + "_stairs", () -> new StairBlock(() -> base.get().defaultBlockState(), props(metal)));
		RegistryObject<Block> slab = BLOCKS.register(id + "_slab", () -> new SlabBlock(props(metal)));
		RegistryObject<Block> wall = BLOCKS.register(id + "_wall", () -> new WallBlock(props(metal)));
		ITEMS.register(id, () -> new BlockItem(base.get(), new Item.Properties()));
		ITEMS.register(id + "_stairs", () -> new BlockItem(stairs.get(), new Item.Properties()));
		ITEMS.register(id + "_slab", () -> new BlockItem(slab.get(), new Item.Properties()));
		ITEMS.register(id + "_wall", () -> new BlockItem(wall.get(), new Item.Properties()));
		group.add(new DecoSet(base, stairs, slab, wall));
	}

	static {
		set(MACHINES, "iron_bricks", true);
		set(MACHINES, "cut_iron", true);
		set(MACHINES, "chiseled_iron", true);
		set(MACHINES, "iron_tiles", true);
		set(MACHINES, "rusty_iron", true);
		set(MACHINES, "copper_bricks", true);
		set(MACHINES, "copper_tiles", true);
		set(MACHINES, "chiseled_copper", true);
		set(MACHINES, "patinated_copper", true);
		set(MACHINES, "polished_tuff", false);
		set(MACHINES, "tuff_bricks", false);
		set(MACHINES, "chiseled_tuff", false);
		set(MACHINES, "polished_calcite", false);
		set(MACHINES, "calcite_bricks", false);
		set(MACHINES, "polished_dripstone", false);
		set(MACHINES, "dripstone_bricks", false);
		set(MACHINES, "smooth_blackstone", false);
		set(MACHINES, "blackstone_tiles", false);
		set(MACHINES, "stone_tiles", false);
		set(MACHINES, "cracked_stone_tiles", false);
		set(MACHINES, "mossy_stone_tiles", false);
		set(MACHINES, "andesite_bricks", false);
		set(MACHINES, "diorite_bricks", false);
		set(MACHINES, "granite_bricks", false);
		set(MACHINES, "basalt_bricks", false);
		set(MACHINES, "slag_brick", false);
		set(MACHINES, "charred_bricks", false);
		set(MACHINES, "clay_tiles", false);
		set(MACHINES, "terracotta_bricks", false);
		set(MACHINES, "quartz_tiles", false);
		set(MACHINES, "weathered_stone", false);
		set(MACHINES, "polished_prismarine", false);
		set(MACHINES, "iron_lattice", true);
		set(GOLD, "gilded_stone", false);
		set(GOLD, "gold_brick", false);
		set(GOLD, "gold_tile", false);
		set(GOLD, "polished_gold", true);
		set(GOLD, "chiseled_gold", true);
		set(GOLD, "gold_mosaic", false);
		set(GOLD, "dirty_gold_brick", false);
		set(GOLD, "slag_tile", false);
		set(GOLD, "glimmering_brick", false);
		set(GOLD, "glittering_tile", false);
		set(GOLD, "desert_brick", false);
		set(GOLD, "sandstone_tile", false);
		set(GOLD, "pale_sandstone", false);
		set(GOLD, "gilded_iron", true);
		set(GOLD, "gilded_tiles", false);
		set(GOLD, "cracked_gold_brick", false);
		set(GOLD, "golden_sandstone", false);
		set(GOLD, "gilded_sandstone", false);
		set(GOLD, "amber_block", false);
		set(GOLD, "gilded_basalt", false);
		set(GOLD, "royal_gold", true);
		set(GOLD, "ornate_gold", true);
		set(GOLD, "gold_filigree", true);
		set(GOLD, "antique_gold", false);
		set(GOLD, "tarnished_gold", false);
		set(GOLD, "mossy_sandstone_brick", false);
		set(GOLD, "quarry_stone", false);
		set(GOLD, "quarry_brick", false);
		set(GOLD, "coarse_gold", false);
		set(GOLD, "molten_gold", false);
		set(GOLD, "gold_vein_stone", false);
		set(GOLD, "ornate_sandstone", false);
		set(GOLD, "cut_gold", true);
		selfAttach();
	}

	public static synchronized void register(IEventBus bus) {
		if (attached || bus == null)
			return;
		attached = true;
		BLOCKS.register(bus);
		ITEMS.register(bus);
	}

	private static void selfAttach() {
		try {
			register(FMLJavaModLoadingContext.get().getModEventBus());
		} catch (Throwable ignored) {
		}
	}

	public static List<Item> items(List<DecoSet> group) {
		List<Item> out = new ArrayList<>();
		for (DecoSet s : group) {
			add(out, s.base);
			add(out, s.stairs);
			add(out, s.slab);
			add(out, s.wall);
		}
		return out;
	}

	private static void add(List<Item> out, RegistryObject<Block> block) {
		if (block.isPresent())
			out.add(block.get().asItem());
	}

	@SubscribeEvent
	public static void tabContents(BuildCreativeModeTabContentsEvent event) {
		if (event.getTab() != SpedModTabs.RPED.get())
			return;
		for (Item item : items(MACHINES))
			event.accept(item);
		for (Item item : items(GOLD))
			event.accept(item);
	}
}
