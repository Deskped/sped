package deskped.sped.redstring;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import deskped.sped.block.BoltBlock;
import deskped.sped.init.SpedModItems;
import deskped.sped.privat.ClaimData;

public final class StringManager {

    private static final double MAX_SPAN = 32.0D;
    private static final boolean CONSUME_ON_CREATE = true;
    private static final boolean RETURN_ON_REMOVE = true;

    private static final Map<UUID, BlockPos> PENDING = new ConcurrentHashMap<>();

    private StringManager() {
    }

    public static void tryConnect(ServerPlayer player, ServerLevel level, BlockPos pos) {
        if (protectedFor(level, pos, player)) {
            deny(player);
            return;
        }
        UUID uuid = player.getUUID();
        BlockPos anchor = PENDING.get(uuid);
        if (anchor == null) {
            PENDING.put(uuid, pos.immutable());
            sendToPlayer(player, StringDeltaPacket.setAnchor(pos));
            msg(player, "\u041f\u0435\u0440\u0432\u044b\u0439 \u0433\u0432\u043e\u0437\u0434\u044c \u0432\u044b\u0431\u0440\u0430\u043d", "First nail selected");
            return;
        }
        if (anchor.equals(pos)) {
            PENDING.remove(uuid);
            sendToPlayer(player, StringDeltaPacket.clearAnchor());
            msg(player, "\u0412\u044b\u0431\u043e\u0440 \u043e\u0442\u043c\u0435\u043d\u0451\u043d", "Selection cleared");
            return;
        }
        BlockState anchorState = level.getBlockState(anchor);
        if (!(anchorState.getBlock() instanceof BoltBlock)) {
            PENDING.remove(uuid);
            sendToPlayer(player, StringDeltaPacket.clearAnchor());
            msg(player, "\u0413\u0432\u043e\u0437\u0434\u044c \u043f\u0440\u043e\u043f\u0430\u043b", "Nail is gone");
            return;
        }
        if (protectedFor(level, anchor, player)) {
            PENDING.remove(uuid);
            sendToPlayer(player, StringDeltaPacket.clearAnchor());
            deny(player);
            return;
        }
        if (Math.sqrt(anchor.distSqr(pos)) > MAX_SPAN) {
            msg(player, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u0430\u043b\u0435\u043a\u043e", "Too far");
            return;
        }
        StringSavedData data = StringSavedData.get(level);
        StringConnection conn = StringConnection.of(anchor, pos);
        if (data.contains(conn)) {
            msg(player, "\u0423\u0436\u0435 \u0441\u043e\u0435\u0434\u0438\u043d\u0435\u043d\u043e", "Already connected");
            return;
        }
        ItemStack held = player.getMainHandItem();
        if (CONSUME_ON_CREATE && !player.getAbilities().instabuild) {
            if (held.getItem() != SpedModItems.RED_STRING.get() || held.isEmpty()) {
                return;
            }
            held.shrink(1);
        }
        data.add(conn);
        broadcast(level, StringDeltaPacket.add(conn));
        PENDING.remove(uuid);
        sendToPlayer(player, StringDeltaPacket.clearAnchor());
        level.playSound(null, pos, SoundEvents.LEASH_KNOT_PLACE, SoundSource.BLOCKS, 0.7F, 1.2F);
        msg(player, "\u041d\u0438\u0442\u044c \u043d\u0430\u0442\u044f\u043d\u0443\u0442\u0430", "String tied");
    }

    public static boolean tryRemoveAt(ServerPlayer player, ServerLevel level, BlockPos pos) {
        StringSavedData data = StringSavedData.get(level);
        List<StringConnection> touching = data.at(pos);
        if (touching.isEmpty()) {
            return false;
        }
        if (protectedFor(level, pos, player)) {
            deny(player);
            return false;
        }
        for (StringConnection c : touching) {
            data.remove(c);
            broadcast(level, StringDeltaPacket.remove(c));
        }
        if (RETURN_ON_REMOVE && !player.getAbilities().instabuild) {
            popStrings(level, pos, touching.size());
        }
        level.playSound(null, pos, SoundEvents.LEASH_KNOT_BREAK, SoundSource.BLOCKS, 0.7F, 0.9F);
        msg(player, "\u041d\u0438\u0442\u044c \u0441\u043d\u044f\u0442\u0430", "String removed");
        return true;
    }

    public static boolean hasStringAt(ServerLevel level, BlockPos pos) {
        return !StringSavedData.get(level).at(pos).isEmpty();
    }

    public static void onNailRemoved(ServerLevel level, BlockPos pos) {
        MinecraftServer server = level.getServer();
        Iterator<Map.Entry<UUID, BlockPos>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, BlockPos> e = it.next();
            if (e.getValue().equals(pos)) {
                it.remove();
                if (server != null) {
                    ServerPlayer sp = server.getPlayerList().getPlayer(e.getKey());
                    if (sp != null) {
                        sendToPlayer(sp, StringDeltaPacket.clearAnchor());
                    }
                }
            }
        }
        StringSavedData data = StringSavedData.get(level);
        for (StringConnection c : data.at(pos)) {
            data.remove(c);
            broadcast(level, StringDeltaPacket.remove(c));
        }
    }

    public static void sendFullSync(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        List<StringConnection> list = new ArrayList<>(StringSavedData.get(level).all());
        BlockPos anchor = PENDING.get(player.getUUID());
        StringNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new StringSyncPacket(list, anchor));
    }

    public static void clearAnchor(ServerPlayer player) {
        if (PENDING.remove(player.getUUID()) != null) {
            sendToPlayer(player, StringDeltaPacket.clearAnchor());
        }
    }

    private static void popStrings(ServerLevel level, BlockPos pos, int count) {
        int remaining = count;
        while (remaining > 0) {
            int stack = Math.min(remaining, 64);
            Block.popResource(level, pos, new ItemStack(SpedModItems.RED_STRING.get(), stack));
            remaining -= stack;
        }
    }

    private static void broadcast(ServerLevel level, StringDeltaPacket pkt) {
        StringNetwork.CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), pkt);
    }

    private static void sendToPlayer(ServerPlayer player, StringDeltaPacket pkt) {
        StringNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), pkt);
    }

    private static boolean protectedFor(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!level.dimension().equals(Level.OVERWORLD)) {
            return false;
        }
        if (player.hasPermissions(2)) {
            return false;
        }
        MinecraftServer server = level.getServer();
        if (server == null) {
            return false;
        }
        ClaimData data = ClaimData.get(server);
        Optional<UUID> owner = data.getOwner(pos.getX() >> 4, pos.getZ() >> 4);
        if (owner.isEmpty()) {
            return false;
        }
        if (owner.get().equals(player.getUUID())) {
            return false;
        }
        return !data.isTrusted(owner.get(), player.getUUID());
    }

    private static void deny(ServerPlayer player) {
        msg(player, "\u042d\u0442\u043e \u043f\u0440\u0438\u0432\u0430\u0442", "Protected claim");
    }

    private static void msg(ServerPlayer player, String ru, String en) {
        boolean isRu = player.getLanguage() != null && player.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
        player.displayClientMessage(Component.literal(isRu ? ru : en), true);
    }
}
