package deskped.sped.redstring;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class StringDeltaPacket {

    public static final byte ADD = 0;
    public static final byte REMOVE = 1;
    public static final byte SET_ANCHOR = 2;
    public static final byte CLEAR_ANCHOR = 3;

    public final byte op;
    public final StringConnection connection;
    public final BlockPos anchor;

    public StringDeltaPacket(byte op, StringConnection connection, BlockPos anchor) {
        this.op = op;
        this.connection = connection;
        this.anchor = anchor;
    }

    public static StringDeltaPacket add(StringConnection c) {
        return new StringDeltaPacket(ADD, c, null);
    }

    public static StringDeltaPacket remove(StringConnection c) {
        return new StringDeltaPacket(REMOVE, c, null);
    }

    public static StringDeltaPacket setAnchor(BlockPos pos) {
        return new StringDeltaPacket(SET_ANCHOR, null, pos);
    }

    public static StringDeltaPacket clearAnchor() {
        return new StringDeltaPacket(CLEAR_ANCHOR, null, null);
    }

    public static void encode(StringDeltaPacket pkt, FriendlyByteBuf buf) {
        buf.writeByte(pkt.op);
        if (pkt.op == ADD || pkt.op == REMOVE) {
            pkt.connection.write(buf);
        } else if (pkt.op == SET_ANCHOR) {
            buf.writeBlockPos(pkt.anchor);
        }
    }

    public static StringDeltaPacket decode(FriendlyByteBuf buf) {
        byte op = buf.readByte();
        if (op == ADD || op == REMOVE) {
            return new StringDeltaPacket(op, StringConnection.read(buf), null);
        }
        if (op == SET_ANCHOR) {
            return new StringDeltaPacket(op, null, buf.readBlockPos());
        }
        return new StringDeltaPacket(op, null, null);
    }

    public static void handle(StringDeltaPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        deskped.sped.redstring.client.ClientStringCache.applyDelta(pkt)));
        ctx.get().setPacketHandled(true);
    }
}
