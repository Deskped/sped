package deskped.sped.redstring;

import deskped.sped.block.BoltBlock;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public final class NailAnchor {

    private static final double NEAR = 3.0D / 16.0D;
    private static final double FAR = 13.0D / 16.0D;
    private static final double MID = 8.0D / 16.0D;
    private static final double HEIGHT = 15.0D / 16.0D;

    private NailAnchor() {
    }

    public static boolean isNail(BlockState state) {
        return state.getBlock() instanceof BoltBlock;
    }

    public static Vec3 point(BlockState state, BlockPos pos) {
        double x;
        double z;
        switch (state.getValue(BoltBlock.FACING)) {
            case NORTH -> {
                x = MID;
                z = FAR;
            }
            case EAST -> {
                x = NEAR;
                z = MID;
            }
            case WEST -> {
                x = FAR;
                z = MID;
            }
            default -> {
                x = MID;
                z = NEAR;
            }
        }
        return new Vec3(pos.getX() + x, pos.getY() + HEIGHT, pos.getZ() + z);
    }
}
