package deskped.sped.redstring;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class StringSyncPacket {

    public final List<StringConnection> connections;
    public final BlockPos anchor;

    public StringSyncPacket(List<StringConnection> connections, BlockPos anchor) {
        this.connections = connections;
        this.anchor = anchor;
    }

    public static void encode(StringSyncPacket pkt, FriendlyByteBuf buf) {
        buf.writeInt(pkt.connections.size());
        for (StringConnection c : pkt.connections) {
            c.write(buf);
        }
        buf.writeBoolean(pkt.anchor != null);
        if (pkt.anchor != null) {
            buf.writeBlockPos(pkt.anchor);
        }
    }

    public static StringSyncPacket decode(FriendlyByteBuf buf) {
        int size = buf.readInt();
        List<StringConnection> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add(StringConnection.read(buf));
        }
        BlockPos anchor = buf.readBoolean() ? buf.readBlockPos() : null;
        return new StringSyncPacket(list, anchor);
    }

    public static void handle(StringSyncPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        deskped.sped.redstring.client.ClientStringCache.replace(pkt.connections, pkt.anchor)));
        ctx.get().setPacketHandled(true);
    }
}
