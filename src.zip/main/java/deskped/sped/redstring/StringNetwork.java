package deskped.sped.redstring;

import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class StringNetwork {

    private static final String VERSION = "1";
    public static SimpleChannel CHANNEL;

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        if (CHANNEL != null) {
            return;
        }
        CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SpedMod.MODID, "red_string"),
                () -> VERSION, VERSION::equals, VERSION::equals);
        int id = 0;
        CHANNEL.registerMessage(id++, StringSyncPacket.class, StringSyncPacket::encode, StringSyncPacket::decode, StringSyncPacket::handle);
        CHANNEL.registerMessage(id++, StringDeltaPacket.class, StringDeltaPacket::encode, StringDeltaPacket::decode, StringDeltaPacket::handle);
    }
}
