package deskped.sped.redstring.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

import java.util.Set;

import deskped.sped.SpedMod;
import deskped.sped.redstring.NailAnchor;
import deskped.sped.redstring.StringConnection;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class StringRenderer {

    private static final float HALF_WIDTH = 0.02F;
    private static final float R = 0.52F;
    private static final float G = 0.06F;
    private static final float B = 0.07F;
    private static final float LIGHT_FLOOR = 0.45F;
    private static final double MAX_RENDER_DIST = 128.0D;
    private static final double MAX_SPAN = 32.0D;

    @SubscribeEvent
    public static void onRenderWorld(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }
        Set<StringConnection> connections = ClientStringCache.all();
        BlockPos anchor = ClientStringCache.anchor();
        if (connections.isEmpty() && anchor == null) {
            return;
        }
        Level level = mc.level;
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        float time = (float) level.getGameTime() + event.getPartialTick();

        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ps.last().pose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(true);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder bb = tess.getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        for (StringConnection c : connections) {
            if (!level.hasChunkAt(c.a()) || !level.hasChunkAt(c.b())) {
                continue;
            }
            BlockState sa = level.getBlockState(c.a());
            BlockState sb = level.getBlockState(c.b());
            if (!NailAnchor.isNail(sa) || !NailAnchor.isNail(sb)) {
                continue;
            }
            Vec3 a = NailAnchor.point(sa, c.a());
            Vec3 b = NailAnchor.point(sb, c.b());
            if (cam.distanceTo(a) > MAX_RENDER_DIST && cam.distanceTo(b) > MAX_RENDER_DIST) {
                continue;
            }
            float lm = lightScale(level, c.a(), c.b());
            emit(bb, mat, cam, a, b, time, c.seed(), R * lm, G * lm, B * lm, 1.0F);
        }

        if (anchor != null && level.hasChunkAt(anchor)) {
            BlockState sa = level.getBlockState(anchor);
            if (NailAnchor.isNail(sa)) {
                Vec3 a = NailAnchor.point(sa, anchor);
                float pulse = 0.5F + 0.5F * (float) Math.sin(time * 0.25F);
                marker(bb, mat, cam, a, 0.05F + 0.03F * pulse, 0.95F, 0.30F, 0.30F, 0.45F + 0.4F * pulse);
                BlockPos looked = lookedBlock(mc);
                if (looked != null && !looked.equals(anchor) && level.hasChunkAt(looked)) {
                    BlockState sl = level.getBlockState(looked);
                    if (NailAnchor.isNail(sl) && Math.sqrt(anchor.distSqr(looked)) <= MAX_SPAN) {
                        Vec3 target = NailAnchor.point(sl, looked);
                        float lm = lightScale(level, anchor, looked);
                        emit(bb, mat, cam, a, target, time, previewSeed(anchor, looked), R * lm, G * lm, B * lm, 0.45F);
                    }
                }
            }
        }

        tess.end();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ps.popPose();
    }

    private static float lightScale(Level level, BlockPos a, BlockPos b) {
        int la = level.getMaxLocalRawBrightness(a);
        int lb = level.getMaxLocalRawBrightness(b);
        float avg = (la + lb) * 0.5F / 15.0F;
        return LIGHT_FLOOR + (1.0F - LIGHT_FLOOR) * Math.min(1.0F, Math.max(0.0F, avg));
    }

    private static long previewSeed(BlockPos a, BlockPos b) {
        return a.asLong() * 31L + b.asLong();
    }

    private static BlockPos lookedBlock(Minecraft mc) {
        if (mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK) {
            return null;
        }
        return ((BlockHitResult) mc.hitResult).getBlockPos();
    }

    private static void emit(BufferBuilder bb, Matrix4f mat, Vec3 cam, Vec3 a, Vec3 b, float time, long seed, float r, float g, float bl, float alpha) {
        double length = a.distanceTo(b);
        int n = (int) Math.max(12.0D, Math.min(48.0D, length * 4.0D));
        Vec3 d = b.subtract(a);
        Vec3 dir = d.lengthSqr() > 1.0E-6D ? d.normalize() : new Vec3(1, 0, 0);
        Vec3 perp = dir.cross(new Vec3(0, 1, 0));
        perp = perp.lengthSqr() > 1.0E-6D ? perp.normalize() : new Vec3(1, 0, 0);
        double sag = Math.min(0.10D * length + 0.06D, 2.0D);
        double swayMag = Math.min(0.03D + 0.006D * length, 0.10D);
        double phase = time * 0.08D + (Math.floorMod(seed, 6283L) / 1000.0D);

        Vec3[] pts = new Vec3[n + 1];
        for (int i = 0; i <= n; i++) {
            double t = (double) i / (double) n;
            double env = Math.sin(Math.PI * t);
            double droop = -sag * 4.0D * t * (1.0D - t);
            double lat = swayMag * env * Math.sin(phase + t * 3.0D);
            double vert = swayMag * 0.5D * env * Math.sin(phase * 1.3D + t * 2.0D + 1.7D);
            Vec3 base = a.add(d.scale(t));
            pts[i] = base.add(perp.scale(lat)).add(0.0D, droop + vert, 0.0D);
        }

        for (int i = 0; i < n; i++) {
            Vec3 p0 = pts[i];
            Vec3 p1 = pts[i + 1];
            Vec3 seg = p1.subtract(p0);
            if (seg.lengthSqr() < 1.0E-9D) {
                continue;
            }
            Vec3 mid = p0.add(p1).scale(0.5D);
            Vec3 view = cam.subtract(mid);
            Vec3 side = seg.cross(view);
            side = side.lengthSqr() > 1.0E-9D ? side.normalize().scale(HALF_WIDTH) : perp.scale(HALF_WIDTH);
            vertex(bb, mat, p0.subtract(side), r, g, bl, alpha);
            vertex(bb, mat, p1.subtract(side), r, g, bl, alpha);
            vertex(bb, mat, p1.add(side), r, g, bl, alpha);
            vertex(bb, mat, p0.add(side), r, g, bl, alpha);
        }
    }

    private static void marker(BufferBuilder bb, Matrix4f mat, Vec3 cam, Vec3 c, float size, float r, float g, float bl, float alpha) {
        Vec3 view = cam.subtract(c);
        view = view.lengthSqr() > 1.0E-9D ? view.normalize() : new Vec3(0, 0, 1);
        Vec3 right = view.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() > 1.0E-9D ? right.normalize() : new Vec3(1, 0, 0);
        Vec3 up = right.cross(view).normalize();
        Vec3 rx = right.scale(size);
        Vec3 uy = up.scale(size);
        vertex(bb, mat, c.subtract(rx).subtract(uy), r, g, bl, alpha);
        vertex(bb, mat, c.add(rx).subtract(uy), r, g, bl, alpha);
        vertex(bb, mat, c.add(rx).add(uy), r, g, bl, alpha);
        vertex(bb, mat, c.subtract(rx).add(uy), r, g, bl, alpha);
    }

    private static void vertex(BufferBuilder bb, Matrix4f mat, Vec3 p, float r, float g, float b, float a) {
        bb.vertex(mat, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, a).endVertex();
    }
}
