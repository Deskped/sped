package deskped.sped.redstring.client;

import net.minecraft.core.BlockPos;

import deskped.sped.redstring.StringConnection;
import deskped.sped.redstring.StringDeltaPacket;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class ClientStringCache {

    private static final Set<StringConnection> CONNECTIONS = Collections.synchronizedSet(new HashSet<>());
    private static volatile BlockPos anchor;

    private ClientStringCache() {
    }

    public static void replace(Collection<StringConnection> connections, BlockPos newAnchor) {
        synchronized (CONNECTIONS) {
            CONNECTIONS.clear();
            CONNECTIONS.addAll(connections);
        }
        anchor = newAnchor;
    }

    public static void applyDelta(StringDeltaPacket pkt) {
        switch (pkt.op) {
            case StringDeltaPacket.ADD -> CONNECTIONS.add(pkt.connection);
            case StringDeltaPacket.REMOVE -> CONNECTIONS.remove(pkt.connection);
            case StringDeltaPacket.SET_ANCHOR -> anchor = pkt.anchor;
            case StringDeltaPacket.CLEAR_ANCHOR -> anchor = null;
            default -> {
            }
        }
    }

    public static boolean hasAt(BlockPos pos) {
        synchronized (CONNECTIONS) {
            for (StringConnection c : CONNECTIONS) {
                if (c.touches(pos)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void clear() {
        CONNECTIONS.clear();
        anchor = null;
    }

    public static Set<StringConnection> all() {
        synchronized (CONNECTIONS) {
            return new HashSet<>(CONNECTIONS);
        }
    }

    public static BlockPos anchor() {
        return anchor;
    }
}
