package deskped.sped.redstring;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StringSavedData extends SavedData {

    private static final String NAME = "sped_strings";

    private final Set<StringConnection> connections = new HashSet<>();

    public static StringSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(StringSavedData::load, StringSavedData::new, NAME);
    }

    private static StringSavedData load(CompoundTag tag) {
        StringSavedData data = new StringSavedData();
        ListTag list = tag.getList("connections", Tag.TAG_COMPOUND);
        for (Tag t : list) {
            data.connections.add(StringConnection.fromNbt((CompoundTag) t));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (StringConnection c : connections) {
            list.add(c.toNbt());
        }
        tag.put("connections", list);
        return tag;
    }

    public boolean add(StringConnection c) {
        boolean added = connections.add(c);
        if (added) {
            setDirty();
        }
        return added;
    }

    public boolean remove(StringConnection c) {
        boolean removed = connections.remove(c);
        if (removed) {
            setDirty();
        }
        return removed;
    }

    public boolean contains(StringConnection c) {
        return connections.contains(c);
    }

    public List<StringConnection> at(BlockPos pos) {
        List<StringConnection> result = new ArrayList<>();
        for (StringConnection c : connections) {
            if (c.touches(pos)) {
                result.add(c);
            }
        }
        return result;
    }

    public Set<StringConnection> all() {
        return Collections.unmodifiableSet(connections);
    }
}
