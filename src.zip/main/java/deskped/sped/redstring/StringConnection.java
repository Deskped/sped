package deskped.sped.redstring;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;

public final class StringConnection {

    private final BlockPos a;
    private final BlockPos b;

    private StringConnection(BlockPos a, BlockPos b) {
        this.a = a;
        this.b = b;
    }

    public static StringConnection of(BlockPos first, BlockPos second) {
        if (compare(first, second) <= 0) {
            return new StringConnection(first.immutable(), second.immutable());
        }
        return new StringConnection(second.immutable(), first.immutable());
    }

    private static int compare(BlockPos p, BlockPos q) {
        if (p.getX() != q.getX()) {
            return Integer.compare(p.getX(), q.getX());
        }
        if (p.getY() != q.getY()) {
            return Integer.compare(p.getY(), q.getY());
        }
        return Integer.compare(p.getZ(), q.getZ());
    }

    public BlockPos a() {
        return a;
    }

    public BlockPos b() {
        return b;
    }

    public boolean touches(BlockPos pos) {
        return a.equals(pos) || b.equals(pos);
    }

    public long seed() {
        return a.asLong() * 31L + b.asLong();
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeBlockPos(a);
        buf.writeBlockPos(b);
    }

    public static StringConnection read(FriendlyByteBuf buf) {
        return of(buf.readBlockPos(), buf.readBlockPos());
    }

    public CompoundTag toNbt() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("ax", a.getX());
        tag.putInt("ay", a.getY());
        tag.putInt("az", a.getZ());
        tag.putInt("bx", b.getX());
        tag.putInt("by", b.getY());
        tag.putInt("bz", b.getZ());
        return tag;
    }

    public static StringConnection fromNbt(CompoundTag tag) {
        return of(new BlockPos(tag.getInt("ax"), tag.getInt("ay"), tag.getInt("az")),
                new BlockPos(tag.getInt("bx"), tag.getInt("by"), tag.getInt("bz")));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof StringConnection other)) {
            return false;
        }
        return a.equals(other.a) && b.equals(other.b);
    }

    @Override
    public int hashCode() {
        return a.hashCode() * 31 + b.hashCode();
    }
}
