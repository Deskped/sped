package deskped.sped.event;

import deskped.sped.init.SpedBlocks;
import deskped.sped.init.SpedItems;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped")
public class CameraUseHandler {

	private static boolean isCamera(ItemStack stack) {
		if (stack.isEmpty())
			return false;
		return stack.getItem() == SpedItems.CAMERA.get() || stack.getItem() == SpedBlocks.CAMERA.get().asItem();
	}

	@SubscribeEvent(priority = EventPriority.HIGH)
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if (event.getHand() != InteractionHand.MAIN_HAND || event.getEntity().isShiftKeyDown())
			return;
		if (!isCamera(event.getItemStack()))
			return;
		event.setCanceled(true);
		event.setCancellationResult(InteractionResult.SUCCESS);
		snap(event);
	}

	@SubscribeEvent(priority = EventPriority.HIGH)
	public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
		if (event.getHand() != InteractionHand.MAIN_HAND || event.getEntity().isShiftKeyDown())
			return;
		if (!isCamera(event.getItemStack()))
			return;
		event.setCanceled(true);
		event.setCancellationResult(InteractionResult.SUCCESS);
		snap(event);
	}

	private static void snap(PlayerInteractEvent event) {
		event.getEntity().getCooldowns().addCooldown(event.getItemStack().getItem(), 40);
		if (event.getLevel().isClientSide)
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.client.PhotoClientCapture.begin());
	}
}
