package deskped.sped.event;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.PistonEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = "sped")
public class PistonNBTHandler {

    private static final Map<BlockPos, CompoundTag> savedNbt = new HashMap<>();

    private static boolean isRpedBlock(BlockState state) {
        var key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        return key != null && "sped".equals(key.getNamespace());
    }

    @SubscribeEvent
    public static void onPistonPre(PistonEvent.Pre event) {
        if (event.getLevel().isClientSide()) return;
        Level level = (Level) event.getLevel();

        event.getStructureHelper().getToPush().forEach(pos -> {
            BlockState state = level.getBlockState(pos);
            if (isRpedBlock(state)) {
                BlockEntity be = level.getBlockEntity(pos);
                if (be != null) {
                    BlockPos target = pos.relative(event.getDirection());
                    savedNbt.put(target, be.saveWithoutMetadata());
                }
            }
        });
    }

    @SubscribeEvent
    public static void onPistonPost(PistonEvent.Post event) {
        if (event.getLevel().isClientSide()) return;
        Level level = (Level) event.getLevel();

        savedNbt.forEach((pos, tag) -> {
            BlockEntity be = level.getBlockEntity(pos);
            if (be != null) {
                be.load(tag);
                be.setChanged();
                level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), 3);
            }
        });

        savedNbt.clear();
    }
}