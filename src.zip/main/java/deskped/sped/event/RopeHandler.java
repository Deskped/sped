package deskped.sped.event;

import deskped.sped.SpedMod;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RopeHandler {

    private static Block rope() {
        return ForgeRegistries.BLOCKS.getValue(new ResourceLocation("sped", "rope"));
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        Block rope = rope();
        if (rope == null)
            return;
        if (event.getPlacedBlock().getBlock() != rope)
            return;
        if (!(event.getLevel() instanceof Level level) || level.isClientSide)
            return;
        BlockPos cursor = event.getPos().below();
        int limit = 256;
        while (limit-- > 0 && level.getBlockState(cursor).isAir() && cursor.getY() > level.getMinBuildHeight()) {
            level.setBlock(cursor, rope.defaultBlockState(), 3);
            cursor = cursor.below();
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END)
            return;
        Player player = event.player;
        if (!player.onClimbable())
            return;
        Block rope = rope();
        if (rope == null)
            return;
        Level level = player.level();
        BlockPos feet = player.blockPosition();
        boolean onRope = level.getBlockState(feet).getBlock() == rope
                || level.getBlockState(feet.above()).getBlock() == rope;
        if (!onRope)
            return;
        Vec3 motion = player.getDeltaMovement();
        player.fallDistance = 0;
        if (player.isShiftKeyDown()) {
            player.setDeltaMovement(motion.x, 0.0, motion.z);
            return;
        }
        double y = motion.y;
        if (y > 0) {
            y = Math.min(y, 0.08);
        } else {
            y = y * 2.2;
            if (y < -0.45)
                y = -0.45;
        }
        player.setDeltaMovement(motion.x, y, motion.z);
    }
}
