package deskped.sped.event;

import deskped.sped.SpedMod;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import org.joml.Vector3f;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RedstoneEyeHandler {

    private static final double RANGE = 28.0;

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        ItemStack stack = event.getItemStack();
        Item eye = ForgeRegistries.ITEMS.getValue(new ResourceLocation("sped", "redstone_eye"));
        if (eye == null || stack.getItem() != eye)
            return;
        if (event.getLevel() instanceof ServerLevel level) {
            fireLaser(level, player);
            if (!player.isCreative() && stack.isDamageableItem())
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(event.getHand()));
            player.getCooldowns().addCooldown(eye, 4);
        }
        player.swing(event.getHand());
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
    }

    private static void fireLaser(ServerLevel level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 reach = eye.add(look.scale(RANGE));
        BlockHitResult blockHit = level.clip(new ClipContext(eye, reach, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = blockHit.getType() == HitResult.Type.BLOCK ? blockHit.getLocation() : reach;
        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult ehr = ProjectileUtil.getEntityHitResult(level, player, eye, end, box, e -> e != player && e.isPickable() && !e.isSpectator());
        if (ehr != null) {
            end = ehr.getLocation();
            if (ehr.getEntity() instanceof LivingEntity t) {
                t.hurt(level.damageSources().indirectMagic(player, player), 6.0f);
                t.setSecondsOnFire(2);
            }
        }
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(1.0f, 0.05f, 0.05f), 1.0f);
        double dist = eye.distanceTo(end);
        int pts = (int) (dist * 4);
        Vec3 step = end.subtract(eye).normalize().scale(0.25);
        Vec3 cur = eye;
        for (int i = 0; i < pts; i++) {
            level.sendParticles(dust, cur.x, cur.y, cur.z, 1, 0.0, 0.0, 0.0, 0.0);
            cur = cur.add(step);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.7f, 1.7f);
    }
}
