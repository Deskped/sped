package deskped.sped.event;

import deskped.sped.SpedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class NetherCorruptionEvent {

    private static final Map<String, Integer> ACTIVE       = new HashMap<>();
    private static final Map<String, Integer> TIMERS       = new HashMap<>();
    private static final Set<String>          SEEN         = new HashSet<>();
    private static final Map<String, Integer> REVERTING    = new HashMap<>();
    private static final Map<String, Integer> REVERT_TIMERS = new HashMap<>();
    private static final Map<String, Integer> CHECK_TIMERS = new HashMap<>();
    private static final Map<String, Map<BlockPos, BlockState[]>> SAVED = new HashMap<>();
    private static final Map<String, Integer> REVERT_SOUND_TIMER = new HashMap<>();

    private static final int MAX_RADIUS      = 14;
    private static final int TICKS_PER_WAVE  = 30;
    private static final int TICKS_PER_REVERT = 50;
    private static final int CHECK_MIN       = 20 * 60;
    private static final int CHECK_MAX       = 20 * 180;

    private static final net.minecraft.world.level.block.Block[] SURFACE_BLOCKS = {
        Blocks.NETHERRACK, Blocks.NETHERRACK, Blocks.NETHERRACK,
        Blocks.SOUL_SAND, Blocks.SOUL_SOIL,
        Blocks.CRIMSON_NYLIUM, Blocks.WARPED_NYLIUM,
        Blocks.BASALT, Blocks.BLACKSTONE, Blocks.MAGMA_BLOCK
    };
    private static final net.minecraft.world.level.block.Block[] DEEP_BLOCKS = {
        Blocks.NETHERRACK, Blocks.NETHERRACK,
        Blocks.BLACKSTONE, Blocks.BASALT,
        Blocks.MAGMA_BLOCK, Blocks.SOUL_SOIL
    };
    private static final net.minecraft.world.level.block.Block[] PLANTS = {
        Blocks.CRIMSON_FUNGUS, Blocks.WARPED_FUNGUS,
        Blocks.CRIMSON_ROOTS, Blocks.WARPED_ROOTS,
        Blocks.NETHER_SPROUTS
    };

    private static String key(ServerLevel level, BlockPos pos) {
        return level.dimension().location() + "|" + pos.getX() + "|" + pos.getZ();
    }

    private static boolean playerNear(ServerLevel level, int cx, int cz) {
        for (Player p : level.players())
            if (Math.abs(p.getX()-cx) <= 6 && Math.abs(p.getZ()-cz) <= 6) return true;
        return false;
    }

    private static boolean portalExists(ServerLevel level, int kx, int ky, int kz) {
        for (int dx = -3; dx <= 3; dx++)
            for (int dy = -1; dy <= 5; dy++)
                for (int dz = -3; dz <= 3; dz++)
                    if (level.getBlockState(new BlockPos(kx+dx, ky+dy, kz+dz)).is(Blocks.NETHER_PORTAL))
                        return true;
        return false;
    }

    @SubscribeEvent
    public static void onPortalSpawn(BlockEvent.PortalSpawnEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!level.dimension().equals(net.minecraft.world.level.Level.OVERWORLD)) return;

        BlockPos pos = event.getPos();
        String k = key(level, pos);
        if (SEEN.contains(k)) return;
        SEEN.add(k);
        ACTIVE.put(k, 0);
        TIMERS.put(k, 0);
        SAVED.put(k, new HashMap<>());
        Random rand = new Random();
        CHECK_TIMERS.put(k, CHECK_MIN + rand.nextInt(CHECK_MAX - CHECK_MIN));

        level.playSound(null, pos, SoundEvents.PORTAL_TRIGGER,         SoundSource.BLOCKS, 1.0f, 0.3f);
        level.playSound(null, pos, SoundEvents.RESPAWN_ANCHOR_CHARGE,  SoundSource.BLOCKS, 1.0f, 0.4f);
        level.playSound(null, pos, SoundEvents.WITHER_SPAWN,           SoundSource.BLOCKS, 1.0f, 0.5f);

        level.sendParticles(ParticleTypes.PORTAL,       pos.getX()+0.5, pos.getY()+1.5, pos.getZ()+0.5, 500, 5.0, 3.0, 5.0, 0.9);
        level.sendParticles(ParticleTypes.LARGE_SMOKE,  pos.getX()+0.5, pos.getY()+1.5, pos.getZ()+0.5, 120, 4.0, 2.0, 4.0, 0.1);
        level.sendParticles(ParticleTypes.FLAME,        pos.getX()+0.5, pos.getY()+1.5, pos.getZ()+0.5, 200, 4.0, 2.5, 4.0, 0.4);
        level.sendParticles(ParticleTypes.LAVA,         pos.getX()+0.5, pos.getY()+1.5, pos.getZ()+0.5,  80, 3.0, 1.5, 3.0, 0.6);
        level.sendParticles(ParticleTypes.CRIMSON_SPORE,pos.getX()+0.5, pos.getY()+2.0, pos.getZ()+0.5, 200, 5.0, 3.0, 5.0, 0.5);
        level.sendParticles(ParticleTypes.EXPLOSION,    pos.getX()+0.5, pos.getY()+1.0, pos.getZ()+0.5,   8, 2.0, 1.0, 2.0, 0.1);

        corruptRing(level, pos, 1, k);
        corruptRing(level, pos, 2, k);
        corruptRing(level, pos, 3, k);
        ACTIVE.put(k, 3);
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        List<String> toRemove = new ArrayList<>();

        for (String k : new ArrayList<>(ACTIVE.keySet())) {
            String[] p = k.split("\\|");
            if (p.length < 3) { toRemove.add(k); continue; }
            int cx = Integer.parseInt(p[1]);
            int cz = Integer.parseInt(p[2]);

            int radius = ACTIVE.get(k);
            int timer  = TIMERS.getOrDefault(k, 0) + 1;
            TIMERS.put(k, timer);

            for (ServerLevel level : net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer().getAllLevels()) {
                if (!level.dimension().location().toString().equals(p[0])) continue;

                int ct = CHECK_TIMERS.getOrDefault(k, CHECK_MIN) - 1;
                CHECK_TIMERS.put(k, ct);
                if (ct <= 0) {
                    Random rand = new Random();
                    CHECK_TIMERS.put(k, CHECK_MIN + rand.nextInt(CHECK_MAX - CHECK_MIN));
                    int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, cx, cz);
                    if (playerNear(level, cx, cz) && !portalExists(level, cx, sy, cz)) {
                        beginRevert(level, k, cx, cz, sy, radius);
                        break;
                    }
                }

                if (timer % TICKS_PER_WAVE != 0) continue;
                if (radius >= MAX_RADIUS) continue;
                radius++;
                ACTIVE.put(k, radius);

                BlockPos center = new BlockPos(cx, 64, cz);
                corruptRing(level, center, radius, k);

                level.playSound(null, center, SoundEvents.PORTAL_AMBIENT, SoundSource.BLOCKS, 1.0f, 0.4f + radius * 0.04f);
                if (radius % 2 == 0)
                    level.playSound(null, center, SoundEvents.BLAZE_SHOOT, SoundSource.BLOCKS, 1.0f, 0.5f);
                if (radius % 4 == 0)
                    level.playSound(null, center, SoundEvents.GHAST_SCREAM, SoundSource.BLOCKS, 1.0f, 0.6f);
                if (radius == MAX_RADIUS / 2)
                    level.playSound(null, center, SoundEvents.WITHER_DEATH, SoundSource.BLOCKS, 1.0f, 0.4f);
                if (radius >= MAX_RADIUS) {
                    level.playSound(null, center, SoundEvents.PORTAL_TRAVEL,          SoundSource.BLOCKS,  1.0f, 0.3f);
                    level.playSound(null, center, SoundEvents.LIGHTNING_BOLT_IMPACT,  SoundSource.WEATHER, 1.0f, 0.5f);
                    level.sendParticles(ParticleTypes.PORTAL,       center.getX()+0.5, center.getY()+1.5, center.getZ()+0.5, 1000, MAX_RADIUS, 5.0, MAX_RADIUS, 0.9);
                    level.sendParticles(ParticleTypes.FLAME,        center.getX()+0.5, center.getY()+1.5, center.getZ()+0.5,  500, MAX_RADIUS, 4.0, MAX_RADIUS, 0.5);
                }

                for (BlockPos rp : getRing(cx, cz, radius)) {
                    if (Math.random() > 0.6) continue;
                    int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, rp.getX(), rp.getZ());
                    level.sendParticles(ParticleTypes.FLAME,        rp.getX()+0.5, sy+0.5, rp.getZ()+0.5,  6, 0.2, 0.8, 0.2, 0.05);
                    level.sendParticles(ParticleTypes.CRIMSON_SPORE,rp.getX()+0.5, sy+1.0, rp.getZ()+0.5, 10, 0.4, 1.0, 0.4, 0.10);
                    level.sendParticles(ParticleTypes.PORTAL,       rp.getX()+0.5, sy+0.5, rp.getZ()+0.5,  8, 0.3, 0.5, 0.3, 0.15);
                }
            }
        }

        for (String k : new ArrayList<>(REVERTING.keySet())) {
            String[] p = k.split("\\|");
            if (p.length < 3) continue;
            int cx = Integer.parseInt(p[1]);
            int cz = Integer.parseInt(p[2]);

            int radius = REVERTING.get(k);
            int timer  = REVERT_TIMERS.getOrDefault(k, 0) + 1;
            REVERT_TIMERS.put(k, timer);

            int rst = REVERT_SOUND_TIMER.getOrDefault(k, 0) - 1;
            REVERT_SOUND_TIMER.put(k, rst);

            for (ServerLevel level : net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer().getAllLevels()) {
                if (!level.dimension().location().toString().equals(p[0])) continue;

                BlockPos center = new BlockPos(cx, 64, cz);

                if (rst <= 0) {
                    Random rand = new Random();
                    REVERT_SOUND_TIMER.put(k, 40 + rand.nextInt(60));
                    level.playSound(null, center, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 1.0f, 0.8f + rand.nextFloat()*0.4f);
                }

                if (radius <= 0) {
                    finishRevert(level, center, k);
                    toRemove.add(k);
                    break;
                }

                if (timer % TICKS_PER_REVERT != 0) continue;

                revertRing(level, center, radius, k);
                REVERTING.put(k, radius - 1);

                for (BlockPos rp : getRing(cx, cz, radius)) {
                    if (Math.random() > 0.5) continue;
                    int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, rp.getX(), rp.getZ());
                    level.sendParticles(ParticleTypes.SMOKE,        rp.getX()+0.5, sy+0.5, rp.getZ()+0.5,  8, 0.3, 0.6, 0.3, 0.02);
                    level.sendParticles(ParticleTypes.ASH,          rp.getX()+0.5, sy+1.0, rp.getZ()+0.5, 10, 0.4, 0.8, 0.4, 0.05);
                    level.sendParticles(ParticleTypes.HAPPY_VILLAGER,rp.getX()+0.5, sy+0.8, rp.getZ()+0.5,  4, 0.3, 0.4, 0.3, 0.05);
                    level.sendParticles(ParticleTypes.END_ROD,      rp.getX()+0.5, sy+1.0, rp.getZ()+0.5,  4, 0.2, 0.5, 0.2, 0.10);
                }
            }
        }

        for (String k : toRemove) {
            ACTIVE.remove(k); TIMERS.remove(k);
            REVERTING.remove(k); REVERT_TIMERS.remove(k);
            REVERT_SOUND_TIMER.remove(k);
            CHECK_TIMERS.remove(k);
            SEEN.remove(k); SAVED.remove(k);
        }
    }

    static void beginRevert(ServerLevel level, String k, int cx, int cz, int sy, int radius) {
        ACTIVE.remove(k);
        TIMERS.remove(k);
        REVERTING.put(k, radius);
        REVERT_TIMERS.put(k, 0);
        REVERT_SOUND_TIMER.put(k, 0);

        BlockPos c = new BlockPos(cx, sy, cz);
        level.playSound(null, c, SoundEvents.PORTAL_TRAVEL,    SoundSource.BLOCKS,  1.0f, 1.2f);
        level.playSound(null, c, SoundEvents.FIRE_EXTINGUISH,  SoundSource.BLOCKS,  1.0f, 0.8f);
        level.playSound(null, c, SoundEvents.WITHER_AMBIENT,   SoundSource.BLOCKS,  1.0f, 0.6f);

        level.sendParticles(ParticleTypes.SMOKE,  cx+0.5, sy+1.5, cz+0.5, 200, 4.0, 2.0, 4.0, 0.05);
        level.sendParticles(ParticleTypes.ASH,    cx+0.5, sy+2.0, cz+0.5, 300, 5.0, 3.0, 5.0, 0.10);
        level.sendParticles(ParticleTypes.PORTAL, cx+0.5, sy+1.5, cz+0.5, 300, 4.0, 2.0, 4.0, 0.50);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, cx+0.5, sy+1.0, cz+0.5, 80, 3.0, 1.5, 3.0, 0.05);
    }

    static void finishRevert(ServerLevel level, BlockPos center, String k) {
        int cx = center.getX();
        int cz = center.getZ();
        int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, cx, cz);

        level.playSound(null, center, SoundEvents.AMETHYST_BLOCK_CHIME,  SoundSource.BLOCKS, 1.0f, 0.6f);
        level.playSound(null, center, SoundEvents.CHERRY_LEAVES_PLACE,   SoundSource.BLOCKS, 1.0f, 1.0f);
        level.playSound(null, center, SoundEvents.GRASS_PLACE,           SoundSource.BLOCKS, 1.0f, 0.9f);

        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, cx+0.5, sy+2.0, cz+0.5, 150, 5.0, 3.0, 5.0, 0.20);
        level.sendParticles(ParticleTypes.END_ROD,        cx+0.5, sy+1.5, cz+0.5, 200, 6.0, 3.0, 6.0, 0.30);
        level.sendParticles(ParticleTypes.COMPOSTER,      cx+0.5, sy+1.0, cz+0.5, 100, 3.0, 1.0, 3.0, 0.10);

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                int bx = cx + dx;
                int bz = cz + dz;
                int bsy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz) - 1;
                BlockPos sp = new BlockPos(bx, bsy, bz);
                BlockPos ap = sp.above();
                if (!level.getBlockState(sp).is(Blocks.OBSIDIAN))
                    level.setBlock(sp, Blocks.GRASS_BLOCK.defaultBlockState(), 3);
                if (!level.getBlockState(ap).isAir())
                    level.setBlock(ap, Blocks.AIR.defaultBlockState(), 3);
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, bx+0.5, bsy+1.0, bz+0.5, 3, 0.2, 0.3, 0.2, 0.05);
            }
        }

        int ssy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, cx, cz);
        BlockPos saplingPos = new BlockPos(cx, ssy, cz);
        if (level.getBlockState(saplingPos).isAir())
            level.setBlock(saplingPos, Blocks.OAK_SAPLING.defaultBlockState(), 3);
    }

    static void corruptRing(ServerLevel level, BlockPos center, int radius, String k) {
        Random rand = new Random();
        Map<BlockPos, BlockState[]> saved = SAVED.computeIfAbsent(k, x -> new HashMap<>());

        for (BlockPos rp : getChaoticRing(center.getX(), center.getZ(), radius, rand)) {
            int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, rp.getX(), rp.getZ()) - 1;

            boolean hasObsidian = false;
            for (int dy = -2; dy <= 1; dy++)
                if (level.getBlockState(new BlockPos(rp.getX(), sy+dy, rp.getZ())).is(Blocks.OBSIDIAN)) { hasObsidian = true; break; }
            if (hasObsidian) continue;

            BlockPos sp = new BlockPos(rp.getX(), sy,   rp.getZ());
            BlockPos ap = new BlockPos(rp.getX(), sy+1, rp.getZ());

            if (!saved.containsKey(sp)) {
                BlockState[] snap = new BlockState[6];
                snap[0] = level.getBlockState(sp);
                snap[1] = level.getBlockState(ap);
                for (int dy = 1; dy <= 4; dy++)
                    snap[1+dy] = level.getBlockState(new BlockPos(rp.getX(), sy-dy, rp.getZ()));
                saved.put(sp, snap);
            }

            level.setBlock(sp, SURFACE_BLOCKS[rand.nextInt(SURFACE_BLOCKS.length)].defaultBlockState(), 3);

            int depth = 2 + rand.nextInt(4);
            for (int dy = 1; dy <= depth; dy++) {
                BlockPos under = new BlockPos(rp.getX(), sy-dy, rp.getZ());
                if (!level.getBlockState(under).is(Blocks.BEDROCK) && !level.getBlockState(under).is(Blocks.OBSIDIAN))
                    level.setBlock(under, DEEP_BLOCKS[rand.nextInt(DEEP_BLOCKS.length)].defaultBlockState(), 3);
            }

            if (!level.getBlockState(ap).is(Blocks.OBSIDIAN))
                level.setBlock(ap, Blocks.AIR.defaultBlockState(), 3);
            if (rand.nextInt(3) == 0 && level.getBlockState(ap).isAir())
                level.setBlock(ap, PLANTS[rand.nextInt(PLANTS.length)].defaultBlockState(), 3);

            level.sendParticles(ParticleTypes.PORTAL,       rp.getX()+0.5, sy+1.0, rp.getZ()+0.5, 20, 0.5, 0.8, 0.5, 0.20);
            level.sendParticles(ParticleTypes.LARGE_SMOKE,  rp.getX()+0.5, sy+0.5, rp.getZ()+0.5,  8, 0.3, 0.4, 0.3, 0.03);
            level.sendParticles(ParticleTypes.FLAME,        rp.getX()+0.5, sy+0.3, rp.getZ()+0.5,  6, 0.3, 0.5, 0.3, 0.06);
            level.sendParticles(ParticleTypes.CRIMSON_SPORE,rp.getX()+0.5, sy+1.2, rp.getZ()+0.5, 10, 0.4, 0.6, 0.4, 0.08);
            if (rand.nextInt(5) == 0)
                level.sendParticles(ParticleTypes.LAVA,     rp.getX()+0.5, sy+0.5, rp.getZ()+0.5,  3, 0.1, 0.2, 0.1, 0.30);
            if (rand.nextInt(10) == 0)
                level.playSound(null, sp, SoundEvents.NETHER_BRICKS_BREAK, SoundSource.BLOCKS, 0.6f, 0.7f + rand.nextFloat()*0.5f);
        }
    }

    static void revertRing(ServerLevel level, BlockPos center, int radius, String k) {
        Random rand = new Random();
        Map<BlockPos, BlockState[]> saved = SAVED.getOrDefault(k, new HashMap<>());

        for (BlockPos rp : getRing(center.getX(), center.getZ(), radius)) {
            int sy = level.getHeight(Heightmap.Types.MOTION_BLOCKING, rp.getX(), rp.getZ()) - 1;
            BlockPos sp = new BlockPos(rp.getX(), sy,   rp.getZ());
            BlockPos ap = sp.above();

            if (level.getBlockState(sp).is(Blocks.OBSIDIAN)) continue;

            BlockState[] snap = saved.get(sp);
            if (snap != null) {
                level.setBlock(sp, snap[0], 3);
                level.setBlock(ap, snap[1], 3);
                for (int dy = 1; dy <= 4; dy++) {
                    BlockPos under = sp.below(dy);
                    if (!level.getBlockState(under).is(Blocks.BEDROCK) && !level.getBlockState(under).is(Blocks.OBSIDIAN))
                        if (snap[1+dy] != null)
                            level.setBlock(under, snap[1+dy], 3);
                }
                saved.remove(sp);
            }

            level.sendParticles(ParticleTypes.SMOKE,         rp.getX()+0.5, sy+1.0, rp.getZ()+0.5, 15, 0.4, 0.6, 0.4, 0.02);
            level.sendParticles(ParticleTypes.ASH,           rp.getX()+0.5, sy+1.5, rp.getZ()+0.5, 10, 0.5, 0.8, 0.5, 0.04);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER,rp.getX()+0.5, sy+0.8, rp.getZ()+0.5,  6, 0.3, 0.4, 0.3, 0.05);
            level.sendParticles(ParticleTypes.END_ROD,       rp.getX()+0.5, sy+1.0, rp.getZ()+0.5,  4, 0.2, 0.5, 0.2, 0.10);

            if (rand.nextInt(6) == 0)
                level.playSound(null, sp, SoundEvents.GRASS_BREAK, SoundSource.BLOCKS, 0.5f, 0.8f + rand.nextFloat()*0.4f);
        }
    }

    static List<BlockPos> getRing(int cx, int cz, int r) {
        List<BlockPos> list = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
                if (Math.abs(dx) == r || Math.abs(dz) == r)
                    list.add(new BlockPos(cx+dx, 64, cz+dz));
        return list;
    }

    static List<BlockPos> getChaoticRing(int cx, int cz, int r, Random rand) {
        List<BlockPos> list = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
                if (Math.max(Math.abs(dx), Math.abs(dz)) == r) {
                    list.add(new BlockPos(cx+dx+rand.nextInt(3)-1, 64, cz+dz+rand.nextInt(3)-1));
                    if (rand.nextInt(3) == 0)
                        list.add(new BlockPos(cx+dx, 64, cz+dz));
                }
        Collections.shuffle(list, rand);
        return list;
    }
}