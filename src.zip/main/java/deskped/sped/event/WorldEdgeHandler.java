package deskped.sped.event;

import deskped.sped.SpedMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class WorldEdgeHandler {

    private static final int BORDER = 10000;

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        ChunkAccess chunk = event.getChunk();
        ChunkPos pos = chunk.getPos();
        boolean outside = pos.getMinBlockX() > BORDER + 32
                       || pos.getMaxBlockX() < -(BORDER + 32)
                       || pos.getMinBlockZ() > BORDER + 32
                       || pos.getMaxBlockZ() < -(BORDER + 32);
        if (!outside) return;
        for (ServerPlayer player : serverLevel.players()) {
            ChunkPos playerChunk = player.chunkPosition();
            if (Math.abs(playerChunk.x - pos.x) <= 2 &&
                Math.abs(playerChunk.z - pos.z) <= 2) return;
        }

        if (!(chunk instanceof LevelChunk levelChunk)) return;

        for (LevelChunkSection section : levelChunk.getSections()) {
            if (section == null) continue;
            section.acquire();
            try {
                for (int x = 0; x < 16; x++)
                    for (int y = 0; y < 16; y++)
                        for (int z = 0; z < 16; z++)
                            section.setBlockState(x, y, z, Blocks.AIR.defaultBlockState(), false);
            } finally {
                section.release();
            }
        }
    }
}