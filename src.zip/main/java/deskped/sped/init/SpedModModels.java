/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.sped.client.model.Modelcrusher;
import deskped.sped.client.model.ModelBuildingAssembler;
import deskped.sped.client.model.ModelBarrelPowder;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SpedModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelcrusher.LAYER_LOCATION, Modelcrusher::createBodyLayer);
		event.registerLayerDefinition(ModelBuildingAssembler.LAYER_LOCATION, ModelBuildingAssembler::createBodyLayer);
		event.registerLayerDefinition(ModelBarrelPowder.LAYER_LOCATION, ModelBarrelPowder::createBodyLayer);
	}
}