/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Block;

import deskped.sped.block.entity.MusicBlockBlockEntity;
import deskped.sped.block.entity.CrusherBlockEntity;
import deskped.sped.block.entity.BuildingAssemblerBlockEntity;
import deskped.sped.block.entity.BlockplacerBlockEntity;
import deskped.sped.block.entity.BackpackBlockBlockEntity;
import deskped.sped.SpedMod;

public class SpedModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SpedMod.MODID);
	public static final RegistryObject<BlockEntityType<CrusherBlockEntity>> CRUSHER = register("crusher", SpedModBlocks.CRUSHER, CrusherBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BackpackBlockBlockEntity>> BACKPACK_BLOCK = register("backpack_block", SpedModBlocks.BACKPACK_BLOCK, BackpackBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BlockplacerBlockEntity>> BLOCKPLACER = register("blockplacer", SpedModBlocks.BLOCKPLACER, BlockplacerBlockEntity::new);
	public static final RegistryObject<BlockEntityType<MusicBlockBlockEntity>> MUSIC_BLOCK = register("music_block", SpedModBlocks.MUSIC_BLOCK, MusicBlockBlockEntity::new);
	public static final RegistryObject<BlockEntityType<BuildingAssemblerBlockEntity>> BUILDING_ASSEMBLER = register("building_assembler", SpedModBlocks.BUILDING_ASSEMBLER, BuildingAssemblerBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends BlockEntity> RegistryObject<BlockEntityType<T>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<T> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}