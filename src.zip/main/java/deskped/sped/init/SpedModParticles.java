/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import deskped.sped.client.particle.RodParticle;
import deskped.sped.client.particle.RlstaParticle;
import deskped.sped.client.particle.HotrodParticle;
import deskped.sped.client.particle.FlamerodParticle;
import deskped.sped.client.particle.DarkrodParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SpedModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(SpedModParticleTypes.ROD.get(), RodParticle::provider);
		event.registerSpriteSet(SpedModParticleTypes.RLSTA.get(), RlstaParticle::provider);
		event.registerSpriteSet(SpedModParticleTypes.DARKROD.get(), DarkrodParticle::provider);
		event.registerSpriteSet(SpedModParticleTypes.HOTROD.get(), HotrodParticle::provider);
		event.registerSpriteSet(SpedModParticleTypes.FLAMEROD.get(), FlamerodParticle::provider);
	}
}