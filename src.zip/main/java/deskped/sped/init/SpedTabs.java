package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import deskped.sped.SpedMod;

public class SpedTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpedMod.MODID);
	public static final RegistryObject<CreativeModeTab> SPED = REGISTRY.register("sped",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.sped.sped")).icon(() -> new ItemStack(SpedItems.CAMERA.get())).displayItems((parameters, tabData) -> {
				tabData.accept(SpedItems.CAMERA.get());
				tabData.accept(SpedItems.PHOTO.get());
				tabData.accept(SpedItems.MUSIC_BLOCK.get());
			}).build());
}
