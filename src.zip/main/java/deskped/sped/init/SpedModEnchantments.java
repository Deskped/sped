/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import deskped.sped.enchantment.ForpedEnchantment;
import deskped.sped.SpedMod;

public class SpedModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, SpedMod.MODID);
	public static final RegistryObject<Enchantment> FORPED = REGISTRY.register("forped", () -> new ForpedEnchantment());
}