/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import deskped.sped.SpedMod;

public class SpedModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SpedMod.MODID);
	public static final RegistryObject<SimpleParticleType> ROD = REGISTRY.register("rod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> RLSTA = REGISTRY.register("rlsta", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> DARKROD = REGISTRY.register("darkrod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> HOTROD = REGISTRY.register("hotrod", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> FLAMEROD = REGISTRY.register("flamerod", () -> new SimpleParticleType(true));
}