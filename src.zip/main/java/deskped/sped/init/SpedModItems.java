/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import deskped.sped.item.*;
import deskped.sped.SpedMod;

public class SpedModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SpedMod.MODID);
	public static final RegistryObject<Item> CRUSHER;
	public static final RegistryObject<Item> BACKPACK;
	public static final RegistryObject<Item> CRYSTAL_EYE;
	public static final RegistryObject<Item> TIMER_BLOCK;
	public static final RegistryObject<Item> RETURN_BLOCK;
	public static final RegistryObject<Item> BLOCKPLACER;
	public static final RegistryObject<Item> LONG_LEVER;
	public static final RegistryObject<Item> ROPE;
	public static final RegistryObject<Item> REALM;
	public static final RegistryObject<Item> CAMERA;
	public static final RegistryObject<Item> PHOTO;
	public static final RegistryObject<Item> CRAFTER;
	public static final RegistryObject<Item> BOLT;
	public static final RegistryObject<Item> RED_STRING;
	public static final RegistryObject<Item> MUSIC_BLOCK;
	public static final RegistryObject<Item> POWDER_BARREL;
	public static final RegistryObject<Item> VIK;
	public static final RegistryObject<Item> KUWAND;
	public static final RegistryObject<Item> WARPED_DOOR;
	public static final RegistryObject<Item> COPPER_DOOR;
	public static final RegistryObject<Item> OXIDIZED_COPPER_DOOR;
	public static final RegistryObject<Item> CASING;
	public static final RegistryObject<Item> TN_TCASING;
	public static final RegistryObject<Item> WHEEL;
	public static final RegistryObject<Item> BUILDING_ASSEMBLER;
	public static final RegistryObject<Item> GLOW_SAND;
	public static final RegistryObject<Item> GLOW_SANDSTONE;
	public static final RegistryObject<Item> UNKNOWN_COIN;
	public static final RegistryObject<Item> CLEAR_GOLD;
	public static final RegistryObject<Item> PHYSIC_STAR;
	static {
		CRUSHER = block(SpedModBlocks.CRUSHER);
		BACKPACK = REGISTRY.register("backpack", BackpackItem::new);
		CRYSTAL_EYE = REGISTRY.register("crystal_eye", CrystalEyeItem::new);
		TIMER_BLOCK = block(SpedModBlocks.TIMER_BLOCK);
		RETURN_BLOCK = block(SpedModBlocks.RETURN_BLOCK);
		BLOCKPLACER = block(SpedModBlocks.BLOCKPLACER);
		LONG_LEVER = block(SpedModBlocks.LONG_LEVER);
		ROPE = block(SpedModBlocks.ROPE);
		REALM = REGISTRY.register("realm", RealmItem::new);
		CAMERA = block(SpedModBlocks.CAMERA, new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
		PHOTO = REGISTRY.register("photo", PhotoItem::new);
		CRAFTER = block(SpedModBlocks.CRAFTER);
		BOLT = block(SpedModBlocks.BOLT);
		RED_STRING = REGISTRY.register("red_string", RedStringItem::new);
		MUSIC_BLOCK = block(SpedModBlocks.MUSIC_BLOCK);
		POWDER_BARREL = block(SpedModBlocks.POWDER_BARREL);
		VIK = REGISTRY.register("vik", VIKItem::new);
		KUWAND = REGISTRY.register("kuwand", KuwandItem::new);
		WARPED_DOOR = doubleBlock(SpedModBlocks.WARPED_DOOR, new Item.Properties().stacksTo(3));
		COPPER_DOOR = doubleBlock(SpedModBlocks.COPPER_DOOR);
		OXIDIZED_COPPER_DOOR = doubleBlock(SpedModBlocks.OXIDIZED_COPPER_DOOR);
		CASING = block(SpedModBlocks.CASING);
		TN_TCASING = block(SpedModBlocks.TN_TCASING);
		WHEEL = block(SpedModBlocks.WHEEL);
		BUILDING_ASSEMBLER = block(SpedModBlocks.BUILDING_ASSEMBLER);
		GLOW_SAND = block(SpedModBlocks.GLOW_SAND);
		GLOW_SANDSTONE = block(SpedModBlocks.GLOW_SANDSTONE);
		UNKNOWN_COIN = REGISTRY.register("unknown_coin", UnknownCoinItem::new);
		CLEAR_GOLD = REGISTRY.register("clear_gold", ClearGoldItem::new);
		PHYSIC_STAR = REGISTRY.register("physic_star", PhysicStarItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), properties));
	}
}