/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import deskped.sped.potion.ShakeMobEffect;
import deskped.sped.potion.ExplodeMobEffect;
import deskped.sped.SpedMod;

public class SpedModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, SpedMod.MODID);
	public static final RegistryObject<MobEffect> SHAKE = REGISTRY.register("shake", () -> new ShakeMobEffect());
	public static final RegistryObject<MobEffect> EXPLODE = REGISTRY.register("explode", () -> new ExplodeMobEffect());
}