/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import deskped.sped.SpedMod;

public class SpedModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SpedMod.MODID);
	public static final RegistryObject<SoundEvent> MENU = REGISTRY.register("menu", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "menu")));
	public static final RegistryObject<SoundEvent> TYPING = REGISTRY.register("typing", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "typing")));
	public static final RegistryObject<SoundEvent> ITEM_CRYSTAL_EYE = REGISTRY.register("item_crystal_eye", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "item_crystal_eye")));
	public static final RegistryObject<SoundEvent> EARTH_SOUNDS_OF_HUMAN_AGONY_CAUSED_BY_NOVA = REGISTRY.register("earth_sounds_of_human_agony_caused_by_nova",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "earth_sounds_of_human_agony_caused_by_nova")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_GRAB = REGISTRY.register("gravity_wrench_grab", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "gravity_wrench_grab")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_HUM = REGISTRY.register("gravity_wrench_hum", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "gravity_wrench_hum")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_IMPACT = REGISTRY.register("gravity_wrench_impact", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "gravity_wrench_impact")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_RELEASE = REGISTRY.register("gravity_wrench_release", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "gravity_wrench_release")));
	public static final RegistryObject<SoundEvent> GRAVITY_WRENCH_THROW = REGISTRY.register("gravity_wrench_throw", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "gravity_wrench_throw")));
	public static final RegistryObject<SoundEvent> SOVIET_ATTENTION = REGISTRY.register("soviet_attention", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "soviet_attention")));
	public static final RegistryObject<SoundEvent> SOVIET_ATTENTION_SIMPLE = REGISTRY.register("soviet_attention_simple", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "soviet_attention_simple")));
	public static final RegistryObject<SoundEvent> SOVIET_START = REGISTRY.register("soviet_start", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "soviet_start")));
	public static final RegistryObject<SoundEvent> METRO_WARNING = REGISTRY.register("metro_warning", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "metro_warning")));
	public static final RegistryObject<SoundEvent> CAMERA = REGISTRY.register("camera", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "camera")));
	public static final RegistryObject<SoundEvent> BLOCK_CRAFTER_CRAFT = REGISTRY.register("block.crafter.craft", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "block.crafter.craft")));
	public static final RegistryObject<SoundEvent> BLOCK_CRAFTER_FAIL = REGISTRY.register("block.crafter.fail", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "block.crafter.fail")));
	public static final RegistryObject<SoundEvent> SOUND_UNLUCK = REGISTRY.register("sound_unluck", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "sound_unluck")));
	public static final RegistryObject<SoundEvent> MUSIC_BUILDING_CONTRAPTIONS = REGISTRY.register("music_building_contraptions", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "music_building_contraptions")));
	public static final RegistryObject<SoundEvent> MUSIC_SOUTH_HAMERICA = REGISTRY.register("music_south_hamerica", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("sped", "music_south_hamerica")));
}