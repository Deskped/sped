package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import deskped.sped.block.*;
import deskped.sped.SpedMod;

public class SpedBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SpedMod.MODID);
	public static final RegistryObject<Block> CAMERA = REGISTRY.register("camera", CameraBlock::new);
	public static final RegistryObject<Block> MUSIC_BLOCK = REGISTRY.register("music_block", MusicBlockBlock::new);
}
