/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import deskped.sped.client.gui.CrusherGuiScreen;
import deskped.sped.client.gui.BlockostavGuiScreen;
import deskped.sped.client.gui.BackackScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SpedModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(SpedModMenus.CRUSHER_GUI.get(), CrusherGuiScreen::new);
			MenuScreens.register(SpedModMenus.BACKACK.get(), BackackScreen::new);
			MenuScreens.register(SpedModMenus.BLOCKOSTAV_GUI.get(), BlockostavGuiScreen::new);
		});
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}