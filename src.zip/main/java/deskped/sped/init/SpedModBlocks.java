/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import deskped.sped.block.*;
import deskped.sped.SpedMod;

public class SpedModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SpedMod.MODID);
	public static final RegistryObject<Block> FAN;
	public static final RegistryObject<Block> AIR;
	public static final RegistryObject<Block> CRUSHER;
	public static final RegistryObject<Block> BACKPACK_BLOCK;
	public static final RegistryObject<Block> TIMER_BLOCK;
	public static final RegistryObject<Block> REDSTONE_TIMER;
	public static final RegistryObject<Block> RETURN_BLOCK;
	public static final RegistryObject<Block> BLOCKPLACER;
	public static final RegistryObject<Block> LONG_LEVER;
	public static final RegistryObject<Block> HALF_LONG_LEVER;
	public static final RegistryObject<Block> ACTIVE_LONG_LEVER;
	public static final RegistryObject<Block> HALF_BLYAT_LONG_LEVER;
	public static final RegistryObject<Block> BUTTON_LONG_LEVER;
	public static final RegistryObject<Block> ACTIVE_BUTTON_LONG_LEVER;
	public static final RegistryObject<Block> ROPE;
	public static final RegistryObject<Block> CAMERA;
	public static final RegistryObject<Block> CRAFTER;
	public static final RegistryObject<Block> CRAFTER_CRAFTING;
	public static final RegistryObject<Block> BOLT;
	public static final RegistryObject<Block> MUSIC_BLOCK;
	public static final RegistryObject<Block> POWDER_BARREL;
	public static final RegistryObject<Block> WARPED_DOOR;
	public static final RegistryObject<Block> COPPER_DOOR;
	public static final RegistryObject<Block> OXIDIZED_COPPER_DOOR;
	public static final RegistryObject<Block> CASING;
	public static final RegistryObject<Block> TN_TCASING;
	public static final RegistryObject<Block> WHEEL;
	public static final RegistryObject<Block> BUILDING_ASSEMBLER;
	public static final RegistryObject<Block> GLOW_SAND;
	public static final RegistryObject<Block> GLOW_SANDSTONE;
	static {
		FAN = REGISTRY.register("fan", FanBlock::new);
		AIR = REGISTRY.register("air", AirBlock::new);
		CRUSHER = REGISTRY.register("crusher", CrusherBlock::new);
		BACKPACK_BLOCK = REGISTRY.register("backpack_block", BackpackBlockBlock::new);
		TIMER_BLOCK = REGISTRY.register("timer_block", TimerBlockBlock::new);
		REDSTONE_TIMER = REGISTRY.register("redstone_timer", RedstoneTimerBlock::new);
		RETURN_BLOCK = REGISTRY.register("return_block", ReturnBlockBlock::new);
		BLOCKPLACER = REGISTRY.register("blockplacer", BlockplacerBlock::new);
		LONG_LEVER = REGISTRY.register("long_lever", LongLeverBlock::new);
		HALF_LONG_LEVER = REGISTRY.register("half_long_lever", HalfLongLeverBlock::new);
		ACTIVE_LONG_LEVER = REGISTRY.register("active_long_lever", ActiveLongLeverBlock::new);
		HALF_BLYAT_LONG_LEVER = REGISTRY.register("half_blyat_long_lever", HalfBLYATLongLeverBlock::new);
		BUTTON_LONG_LEVER = REGISTRY.register("button_long_lever", ButtonLongLeverBlock::new);
		ACTIVE_BUTTON_LONG_LEVER = REGISTRY.register("active_button_long_lever", ActiveButtonLongLeverBlock::new);
		ROPE = REGISTRY.register("rope", RopeBlock::new);
		CAMERA = REGISTRY.register("camera", CameraBlock::new);
		CRAFTER = REGISTRY.register("crafter", CrafterBlock::new);
		CRAFTER_CRAFTING = REGISTRY.register("crafter_crafting", CrafterCraftingBlock::new);
		BOLT = REGISTRY.register("bolt", BoltBlock::new);
		MUSIC_BLOCK = REGISTRY.register("music_block", MusicBlockBlock::new);
		POWDER_BARREL = REGISTRY.register("powder_barrel", PowderBarrelBlock::new);
		WARPED_DOOR = REGISTRY.register("warped_door", WarpedDoorBlock::new);
		COPPER_DOOR = REGISTRY.register("copper_door", CopperDoorBlock::new);
		OXIDIZED_COPPER_DOOR = REGISTRY.register("oxidized_copper_door", OxidizedCopperDoorBlock::new);
		CASING = REGISTRY.register("casing", CasingBlock::new);
		TN_TCASING = REGISTRY.register("tn_tcasing", TNTcasingBlock::new);
		WHEEL = REGISTRY.register("wheel", WheelBlock::new);
		BUILDING_ASSEMBLER = REGISTRY.register("building_assembler", BuildingAssemblerBlock::new);
		GLOW_SAND = REGISTRY.register("glow_sand", GlowSandBlock::new);
		GLOW_SANDSTONE = REGISTRY.register("glow_sandstone", GlowSandstoneBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}