package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import deskped.sped.item.CameraBlockItem;
import deskped.sped.item.PhotoItem;
import deskped.sped.SpedMod;

public class SpedItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SpedMod.MODID);
	public static final RegistryObject<Item> CAMERA = REGISTRY.register("camera",
			() -> new CameraBlockItem(SpedBlocks.CAMERA.get(), new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));
	public static final RegistryObject<Item> PHOTO = REGISTRY.register("photo", PhotoItem::new);
	public static final RegistryObject<Item> MUSIC_BLOCK = REGISTRY.register("music_block",
			() -> new BlockItem(SpedBlocks.MUSIC_BLOCK.get(), new Item.Properties()));
}
