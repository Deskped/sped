/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import deskped.sped.SpedMod;

public class SpedModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpedMod.MODID);
	public static final RegistryObject<CreativeModeTab> RPED = REGISTRY.register("rped",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.sped.rped")).icon(() -> new ItemStack(SpedModItems.CRYSTAL_EYE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(SpedModBlocks.CRAFTER.get().asItem());
				tabData.accept(SpedModBlocks.BUILDING_ASSEMBLER.get().asItem());
				tabData.accept(SpedModBlocks.CASING.get().asItem());
				tabData.accept(SpedModBlocks.TIMER_BLOCK.get().asItem());
				tabData.accept(SpedModBlocks.BLOCKPLACER.get().asItem());
				tabData.accept(SpedModBlocks.TN_TCASING.get().asItem());
				tabData.accept(SpedModBlocks.WHEEL.get().asItem());
				tabData.accept(SpedModBlocks.CRUSHER.get().asItem());
				tabData.accept(SpedModBlocks.POWDER_BARREL.get().asItem());
				tabData.accept(SpedModBlocks.RETURN_BLOCK.get().asItem());
				tabData.accept(SpedModBlocks.LONG_LEVER.get().asItem());
				tabData.accept(SpedModItems.CRYSTAL_EYE.get());
				tabData.accept(SpedModItems.REALM.get());
				tabData.accept(SpedModItems.PHYSIC_STAR.get());
				tabData.accept(SpedModBlocks.ROPE.get().asItem());
				tabData.accept(SpedModItems.KUWAND.get());
				tabData.accept(SpedModItems.VIK.get());
				tabData.accept(SpedModBlocks.MUSIC_BLOCK.get().asItem());
				tabData.accept(SpedModItems.BACKPACK.get());
				tabData.accept(SpedModBlocks.CAMERA.get().asItem());
				tabData.accept(SpedModBlocks.BOLT.get().asItem());
				tabData.accept(SpedModItems.PHOTO.get());
				tabData.accept(SpedModItems.RED_STRING.get());
				tabData.accept(SpedModBlocks.COPPER_DOOR.get().asItem());
				tabData.accept(SpedModBlocks.OXIDIZED_COPPER_DOOR.get().asItem());
				tabData.accept(SpedModBlocks.GLOW_SAND.get().asItem());
				tabData.accept(SpedModBlocks.GLOW_SANDSTONE.get().asItem());
				tabData.accept(SpedModItems.UNKNOWN_COIN.get());
				tabData.accept(SpedModItems.CLEAR_GOLD.get());
			}).build());
}