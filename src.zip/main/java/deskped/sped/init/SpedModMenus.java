/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package deskped.sped.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.Minecraft;

import java.util.Map;

import deskped.sped.world.inventory.CrusherGuiMenu;
import deskped.sped.world.inventory.BlockostavGuiMenu;
import deskped.sped.world.inventory.BackackMenu;
import deskped.sped.network.MenuStateUpdateMessage;
import deskped.sped.SpedMod;

public class SpedModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, SpedMod.MODID);
	public static final RegistryObject<MenuType<CrusherGuiMenu>> CRUSHER_GUI = REGISTRY.register("crusher_gui", () -> IForgeMenuType.create(CrusherGuiMenu::new));
	public static final RegistryObject<MenuType<BackackMenu>> BACKACK = REGISTRY.register("backack", () -> IForgeMenuType.create(BackackMenu::new));
	public static final RegistryObject<MenuType<BlockostavGuiMenu>> BLOCKOSTAV_GUI = REGISTRY.register("blockostav_gui", () -> IForgeMenuType.create(BlockostavGuiMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer), new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof SpedModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				SpedMod.PACKET_HANDLER.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}