package deskped.sped;

import deskped.sped.init.SpedItems;
import deskped.sped.network.PhotoDataPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber
public class PhotoStorage {

	private static final int MAX_CHUNK = 28672;
	private static final int MAX_CHUNKS = 90;
	private static final int MAX_BYTES = 2600000;

	private static final Map<UUID, Pending> UPLOADS = new ConcurrentHashMap<>();

	private static class Pending {
		final UUID photoId;
		final byte[][] parts;
		final long started;
		int received;
		int bytes;

		Pending(UUID photoId, int total) {
			this.photoId = photoId;
			this.parts = new byte[total][];
			this.started = System.currentTimeMillis();
		}
	}

	public static Path directory(MinecraftServer server) throws IOException {
		Path dir = server.getWorldPath(LevelResource.ROOT).resolve("sped_photos");
		Files.createDirectories(dir);
		return dir;
	}

	public static void receiveUpload(ServerPlayer player, UUID photoId, int total, int index, byte[] data) {
		if (photoId == null || total < 1 || total > MAX_CHUNKS || index < 0 || index >= total || data == null || data.length == 0 || data.length > MAX_CHUNK)
			return;
		UUID key = player.getUUID();
		Pending pending = UPLOADS.get(key);
		if (pending == null || !pending.photoId.equals(photoId) || pending.parts.length != total || System.currentTimeMillis() - pending.started > 30000L) {
			pending = new Pending(photoId, total);
			UPLOADS.put(key, pending);
		}
		if (pending.parts[index] == null) {
			pending.parts[index] = data;
			pending.received++;
			pending.bytes += data.length;
		}
		if (pending.bytes > MAX_BYTES) {
			UPLOADS.remove(key);
			return;
		}
		if (pending.received < total)
			return;
		UPLOADS.remove(key);
		byte[] full = new byte[pending.bytes];
		int off = 0;
		for (byte[] part : pending.parts) {
			System.arraycopy(part, 0, full, off, part.length);
			off += part.length;
		}
		if (full.length < 8 || (full[0] & 0xFF) != 0x89 || (full[1] & 0xFF) != 0x50 || (full[2] & 0xFF) != 0x4E || (full[3] & 0xFF) != 0x47)
			return;
		if (!consumePaper(player))
			return;
		MinecraftServer server = player.getServer();
		if (server == null)
			return;
		try {
			Files.write(directory(server).resolve(photoId.toString() + ".png"), full);
		} catch (IOException e) {
			SpedMod.LOGGER.error("photo save failed", e);
			return;
		}
		ItemStack photo = new ItemStack(SpedItems.PHOTO.get());
		photo.getOrCreateTag().putString("PhotoId", photoId.toString());
		if (!player.getInventory().add(photo))
			player.drop(photo, false);
		player.level().playSound(null, player.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 0.8f, 0.9f);
	}

	private static boolean consumePaper(ServerPlayer player) {
		if (player.getAbilities().instabuild)
			return true;
		Inventory inv = player.getInventory();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (!stack.isEmpty() && stack.is(Items.PAPER)) {
				stack.shrink(1);
				inv.setChanged();
				return true;
			}
		}
		return false;
	}

	public static void serve(ServerPlayer player, UUID photoId) {
		if (photoId == null)
			return;
		MinecraftServer server = player.getServer();
		if (server == null)
			return;
		byte[] data;
		try {
			Path file = directory(server).resolve(photoId.toString() + ".png");
			if (!Files.isRegularFile(file) || Files.size(file) > 3000000L) {
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new PhotoDataPacket(photoId, 0, 0, new byte[0]));
				return;
			}
			data = Files.readAllBytes(file);
		} catch (IOException e) {
			SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new PhotoDataPacket(photoId, 0, 0, new byte[0]));
			return;
		}
		int total = (data.length + MAX_CHUNK - 1) / MAX_CHUNK;
		for (int i = 0; i < total; i++) {
			int off = i * MAX_CHUNK;
			int len = Math.min(MAX_CHUNK, data.length - off);
			byte[] part = new byte[len];
			System.arraycopy(data, off, part, 0, len);
			SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new PhotoDataPacket(photoId, total, i, part));
		}
	}

	@SubscribeEvent
	public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
		UPLOADS.remove(event.getEntity().getUUID());
	}
}
