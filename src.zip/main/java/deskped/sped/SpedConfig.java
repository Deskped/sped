package deskped.sped;

public class SpedConfig {
    public static final double PLAYER_HP_IGNORE_THRESHOLD = 100.0;
    public static final int BASE_SCAN_RADIUS = 20;
    public static final int SCAN_INTERVAL_TICKS = 60;
    public static final double RAID_CHANCE_PER_MINUTE = 0.05;
    public static final int RAID_CHECK_INTERVAL_TICKS = 1200;
    public static final float EXPLOSION_POWER = 2.5f;
    public static final boolean EXPLOSION_FIRE = true;
}
