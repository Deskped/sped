package deskped.sped;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import deskped.sped.client.ClientPortalState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = "sped", value = Dist.CLIENT)
public class Portal {

    private static final int SUCTION_COUNT = 140;
    private static final int EJECT_COUNT = 36;
    private static final int RING_SEGMENTS = 32;
    private static final int ORBIT_BLOCKS = 90;
    private static final int STREAM_IN = 46;
    private static final int STREAM_OUT = 46;
    private static final long BURST_PERIOD = 600L;
    private static final float BURST_DURATION = 160f;

    private static final float[][] PALETTE = {
            {0.62f, 0.35f, 1.00f},
            {0.35f, 0.85f, 1.00f},
            {0.92f, 0.82f, 1.00f},
            {1.00f, 0.55f, 0.95f}
    };

    private static final ResourceLocation[] END_TEX = {
            new ResourceLocation("minecraft", "block/end_stone"),
            new ResourceLocation("minecraft", "block/end_stone_bricks"),
            new ResourceLocation("minecraft", "block/purpur_block"),
            new ResourceLocation("minecraft", "block/obsidian"),
            new ResourceLocation("minecraft", "block/purpur_pillar")
    };

    private static final ResourceLocation[] OVER_TEX = {
            new ResourceLocation("minecraft", "block/grass_block_side"),
            new ResourceLocation("minecraft", "block/dirt"),
            new ResourceLocation("minecraft", "block/stone"),
            new ResourceLocation("minecraft", "block/cobblestone"),
            new ResourceLocation("minecraft", "block/sand"),
            new ResourceLocation("minecraft", "block/oak_log"),
            new ResourceLocation("minecraft", "block/gravel")
    };

    private static final Layer[] LAYERS = {
            new Layer(new ResourceLocation("sped", "textures/environment/portal.png"), 150F, 260F, 24000L, 1),
            new Layer(new ResourceLocation("sped", "textures/environment/portalone.png"), 175F, 210F, 9600L, -1),
            new Layer(new ResourceLocation("sped", "textures/environment/portaltwo.png"), 200F, 165F, 4800L, 1),
            new Layer(new ResourceLocation("sped", "textures/environment/portalthree.png"), 225F, 125F, 2400L, -1),
            new Layer(new ResourceLocation("sped", "textures/environment/portalfour.png"), 250F, 90F, 1200L, 1)
    };

    private static float openAnim = 1f;
    private static long lastMs = 0L;

    private static class Layer {
        final ResourceLocation tex;
        final float height;
        final float size;
        final long period;
        final int dir;

        Layer(ResourceLocation tex, float height, float size, long period, int dir) {
            this.tex = tex;
            this.height = height;
            this.size = size;
            this.period = period;
            this.dir = dir;
        }
    }

    private static float hash(int n) {
        n = n * 374761393 + 668265263;
        n = (n ^ (n >>> 13)) * 1274126177;
        return ((n ^ (n >>> 16)) & 0x7fffffff) / (float) 0x7fffffff;
    }

    private static float fract(float v) {
        return v - (float) Math.floor(v);
    }

    private static float lerp(float a, float b, float u) {
        return a + (b - a) * u;
    }


    @SubscribeEvent
    public static void onRenderSky(RenderLevelStageEvent event) {

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;

        if (level == null) return;

        long nowMs = System.currentTimeMillis();
        float fdt = lastMs == 0L ? 0f : Math.min((nowMs - lastMs) / 1000f, 0.1f);
        lastMs = nowMs;
        float target = ClientPortalState.isOpen() ? 1f : 0f;
        openAnim += (target - openAnim) * Math.min(1f, fdt * 0.7f);
        if (Math.abs(target - openAnim) < 0.004f) openAnim = target;
        if (openAnim <= 0.01f) return;

        long time = level.getDayTime() % 24000;

        if (time < 11800 || time > 23200) return;

        float envA;

        if (time <= 13800) {
            float tt = (time - 11800) / 2000f;
            tt = Math.min(Math.max(tt, 0f), 1f);
            envA = 0.5f - 0.5f * (float) Math.cos(Math.PI * tt);
        } else if (time >= 21200) {
            float tt = (23200 - time) / 2000f;
            tt = Math.min(Math.max(tt, 0f), 1f);
            envA = 0.5f - 0.5f * (float) Math.cos(Math.PI * tt);
        } else {
            envA = 1.0f;
        }

        envA = Math.min(Math.max(envA, 0f), 1f);
        float alpha = envA * openAnim;
        if (alpha <= 0.01f) return;
        float form = alpha;

        float partial = event.getPartialTick();
        long gt = level.getGameTime();
        float t = (gt % 720000L) + partial;
        float openScale = (float) Math.sqrt(openAnim);
        float flicker = hash((int) (gt >> 3)) > 0.93f ? 0.35f : 0f;

        long phase = gt % BURST_PERIOD;
        float burstU = phase < BURST_DURATION ? (phase + partial) / BURST_DURATION : -1f;
        int burstId = (int) (gt / BURST_PERIOD);

        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        poseStack.mulPose(Axis.XP.rotationDegrees(1.6f * (float) Math.sin(t * 0.004f)));
        poseStack.mulPose(Axis.ZP.rotationDegrees(1.6f * (float) Math.cos(t * 0.003f)));
        Matrix4f mat = poseStack.last().pose();

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);

        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.getBuilder();

        for (int li = 0; li < LAYERS.length; li++) {
            Layer layer = LAYERS[li];
            float e = Math.min(Math.max((form - li * 0.08f) * 1.5f, 0f), 1f);
            e = e * e * (3f - 2f * e);
            float surge = (1f - form) * (1f - form);
            float rotation = ((gt % layer.period) + partial) * (360f / layer.period) * layer.dir + surge * 540f * layer.dir;
            float breathe = 0.97f + 0.03f * (float) Math.sin(t * 0.015f + li * 1.7f);
            float layerAlpha = alpha * (0.86f + 0.14f * (float) Math.sin(t * 0.013f + li * 2.3f)) * (1f + flicker * 0.5f) * (0.55f + 0.45f * e) * (1f + surge * 0.6f);
            float size = layer.size * breathe * openScale * (0.15f + 0.85f * e);

            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(rotation));
            RenderSystem.setShaderTexture(0, layer.tex);
            RenderSystem.setShaderColor(1F, 1F, 1F, Math.min(layerAlpha, 1f));

            float height = layer.height;
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
            buffer.vertex(poseStack.last().pose(), -size, height, -size).uv(0F, 0F).endVertex();
            buffer.vertex(poseStack.last().pose(), size, height, -size).uv(1F, 0F).endVertex();
            buffer.vertex(poseStack.last().pose(), size, height, size).uv(1F, 1F).endVertex();
            buffer.vertex(poseStack.last().pose(), -size, height, size).uv(0F, 1F).endVertex();
            tesselator.end();

            poseStack.popPose();
        }

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        TextureAtlasSprite[] endSpr = resolve(mc, END_TEX);
        TextureAtlasSprite[] overSpr = resolve(mc, OVER_TEX);

        RenderSystem.setShader(GameRenderer::getPositionColorTexShader);
        RenderSystem.setShaderTexture(0, InventoryMenu.BLOCK_ATLAS);
        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR_TEX);

        for (int k = 0; k < ORBIT_BLOCKS; k++) {
            float h1 = hash(k * 5 + 11);
            float h2 = hash(k * 5 + 12);
            float h3 = hash(k * 5 + 13);
            float h4 = hash(k * 5 + 14);
            Layer ref = LAYERS[k % LAYERS.length];
            float radius = (240f + h1 * 200f) * openScale;
            float y = 148f + h2 * 64f + (float) Math.sin(t * 0.015f + h1 * 7f) * 6f;
            float ang = h4 * 360f + t * (360f / ref.period) * ref.dir;
            float px = radius * (float) Math.cos(Math.toRadians(ang));
            float pz = radius * (float) Math.sin(Math.toRadians(ang));
            float size = (0.7f + h2 * 1.4f) * openScale;
            float a = alpha * (0.7f + 0.3f * (float) Math.sin(t * 0.1f + k));
            TextureAtlasSprite spr = (k & 1) == 0 ? endSpr[k % endSpr.length] : overSpr[k % overSpr.length];
            cube(buffer, mat, px, y, pz, size, t * (0.4f + h1) * 0.006f + h3 * 6f, t * (0.3f + h2) * 0.006f + h4 * 6f, spr, a);
        }

        for (int i = 0; i < STREAM_IN; i++) {
            float h1 = hash(i * 7 + 101);
            float h2 = hash(i * 7 + 102);
            float h3 = hash(i * 7 + 103);
            float h4 = hash(i * 7 + 104);
            float period = 900f + h1 * 700f;
            float u = fract(t / period + h2);
            float radius = lerp(680f + h3 * 160f, 28f, (float) Math.pow(u, 2.2f)) * openScale;
            float y = lerp(18f + h4 * 30f, 158f, (float) Math.pow(u, 1.6f));
            float ang = h1 * 360f + u * (720f + h2 * 720f);
            float px = radius * (float) Math.cos(Math.toRadians(ang));
            float pz = radius * (float) Math.sin(Math.toRadians(ang));
            float size = (1.0f + h3 * 1.5f) * (1f - 0.55f * u) * openScale;
            float a = alpha * Math.min(u / 0.08f, 1f) * Math.min((1f - u) / 0.06f, 1f);
            if (a <= 0.01f) continue;
            TextureAtlasSprite spr = overSpr[i % overSpr.length];
            cube(buffer, mat, px, y, pz, size, t * 0.01f * (1f + h1) + h2 * 6f, t * 0.008f * (1f + h2) + h3 * 6f, spr, a);
        }

        for (int j = 0; j < STREAM_OUT; j++) {
            float h1 = hash(j * 7 + 501);
            float h2 = hash(j * 7 + 502);
            float h3 = hash(j * 7 + 503);
            float h4 = hash(j * 7 + 504);
            float period = 900f + h1 * 700f;
            float u = fract(t / period + h2);
            float radius = lerp(25f, 700f + h3 * 150f, 1f - (float) Math.pow(1f - u, 1.8f)) * openScale;
            float y = lerp(162f, 12f + h4 * 25f, (float) Math.pow(u, 1.2f));
            float ang = h2 * 360f - u * (720f + h1 * 540f);
            float px = radius * (float) Math.cos(Math.toRadians(ang));
            float pz = radius * (float) Math.sin(Math.toRadians(ang));
            float size = (1.2f + h3 * 1.5f) * (1f - 0.5f * u) * openScale;
            float a = alpha * Math.min(u / 0.06f, 1f) * Math.min((1f - u) / 0.10f, 1f);
            if (a <= 0.01f) continue;
            TextureAtlasSprite spr = endSpr[j % endSpr.length];
            cube(buffer, mat, px, y, pz, size, t * 0.01f * (1f + h2) + h1 * 6f, t * 0.009f * (1f + h4) + h2 * 6f, spr, a);
        }

        tesselator.end();

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        float ga = alpha * (1f + flicker);

        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        for (int i = 0; i < SUCTION_COUNT; i++) {
            float h1 = hash(i * 4 + 1);
            float h2 = hash(i * 4 + 2);
            float h3 = hash(i * 4 + 3);
            float h4 = hash(i * 4 + 4);
            float period = 400f + h1 * 500f;
            float u = fract(t / period + h2);
            float radial = 1f - (float) Math.pow(u, 1.35f);
            float radius = (26f + radial * (280f + h3 * 260f)) * openScale;
            int dir = (i & 1) == 0 ? 1 : -1;
            float ang = h4 * 360f + u * (540f + h1 * 540f) * dir;
            float y = 84f + h3 * 60f + (158f - 84f - h3 * 60f) * u;
            float size = (0.7f + h2 * 1.8f) * (1f - 0.7f * u) * openScale;
            float pa = (float) Math.pow(Math.sin(Math.PI * u), 0.7f) * (0.45f + 0.5f * h1) * ga * Math.min(2f, 1f + (1f - form) * 1.3f);
            if (pa <= 0.01f) continue;
            float[] col = PALETTE[i & 3];
            float bright = 0.8f + 0.2f * (float) Math.sin(t * 0.06f + i);
            float px = radius * (float) Math.cos(Math.toRadians(ang));
            float pz = radius * (float) Math.sin(Math.toRadians(ang));
            float spin = u * 720f * dir + h4 * 360f;
            flatQuad(buffer, mat, px, y, pz, size, spin, col[0] * bright, col[1] * bright, col[2] * bright, pa);
        }

        if (ClientPortalState.hasOrigin()) {
            float beamA = Math.min(1f, openAnim * (1f - openAnim) * 4f) * envA * (1f + flicker);
            if (beamA > 0.01f) {
                Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
                float bx = (float) (ClientPortalState.originX() - cam.x);
                float by = (float) (ClientPortalState.originY() - cam.y);
                float bz = (float) (ClientPortalState.originZ() - cam.z);
                float pw = 2.5f + 0.8f * (float) Math.sin(t * 0.5f);
                beam(buffer, mat, bx, by, bz, 0f, 152f, 0f, pw, 16f, 0.8f, 0.65f, 1f, beamA * 0.85f);
                for (int i = 0; i < 24; i++) {
                    float hh = hash(i * 3 + 901);
                    float u = fract(t / (25f + hh * 30f) + hash(i * 3 + 902));
                    float px = lerp(bx, 0f, u);
                    float py = lerp(by, 152f, u);
                    float pz = lerp(bz, 0f, u);
                    flatQuad(buffer, mat, px, py, pz, 0.8f + hh * 1.6f, u * 720f, 0.85f, 0.7f, 1f, beamA * (1f - u * 0.5f));
                }
            }
        }

        if (burstU >= 0f) {
            float ringR = (1f - (float) Math.pow(1f - burstU, 2.2f)) * 430f * openScale;
            float ringW = 10f + burstU * 26f;
            float ringA = (float) Math.pow(1f - burstU, 1.8f) * 0.5f * ga;
            if (ringA > 0.01f)
                ring(buffer, mat, 157f, ringR, ringR + ringW, 0.75f, 0.55f, 1f, ringA);

            for (int j = 0; j < EJECT_COUNT; j++) {
                int seed = burstId * 131 + j * 7;
                float h1 = hash(seed + 1);
                float h2 = hash(seed + 2);
                float h3 = hash(seed + 3);
                float h4 = hash(seed + 4);
                float ang = h1 * 360f;
                float maxR = (180f + h2 * 260f) * openScale;
                float radius = (1f - (1f - burstU) * (1f - burstU)) * maxR;
                float y = 160f + burstU * 40f * h3 - burstU * burstU * 95f;
                float size = (0.8f + h4 * 2.2f) * (1f - 0.55f * burstU) * openScale;
                float ea = (float) Math.pow(1f - burstU, 1.4f) * 0.95f * ga;
                if (ea <= 0.01f) continue;
                float[] col = PALETTE[j & 3];
                float mix = Math.min(1f, burstU * 1.6f);
                float cr = 1f + (col[0] - 1f) * mix;
                float cg = 1f + (col[1] - 1f) * mix;
                float cb = 1f + (col[2] - 1f) * mix;
                int dir = (j & 1) == 0 ? 1 : -1;
                float px = radius * (float) Math.cos(Math.toRadians(ang));
                float pz = radius * (float) Math.sin(Math.toRadians(ang));
                float spin = burstU * 900f * dir + h2 * 360f;
                flatQuad(buffer, mat, px, y, pz, size, spin, cr, cg, cb, ea);
            }
        }

        tesselator.end();

        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        poseStack.popPose();
    }

    private static TextureAtlasSprite[] resolve(Minecraft mc, ResourceLocation[] textures) {
        TextureAtlasSprite[] out = new TextureAtlasSprite[textures.length];
        for (int i = 0; i < textures.length; i++)
            out[i] = mc.getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(textures[i]);
        return out;
    }

    private static void cube(BufferBuilder bb, Matrix4f mat, float cx, float cy, float cz, float s, float ya, float xa, TextureAtlasSprite spr, float a) {
        float ca = (float) Math.cos(ya), sa = (float) Math.sin(ya);
        float cb = (float) Math.cos(xa), sb = (float) Math.sin(xa);
        float e1x = ca, e1y = 0f, e1z = -sa;
        float e2x = sb * sa, e2y = cb, e2z = sb * ca;
        float e3x = cb * sa, e3y = -sb, e3z = cb * ca;
        a = Math.min(a, 1f);
        face(bb, mat, cx, cy, cz, s, e2x, e2y, e2z, e1x, e1y, e1z, e3x, e3y, e3z, spr, 1.00f, a);
        face(bb, mat, cx, cy, cz, s, -e2x, -e2y, -e2z, e1x, e1y, e1z, e3x, e3y, e3z, spr, 0.50f, a);
        face(bb, mat, cx, cy, cz, s, e1x, e1y, e1z, e2x, e2y, e2z, e3x, e3y, e3z, spr, 0.75f, a);
        face(bb, mat, cx, cy, cz, s, -e1x, -e1y, -e1z, e2x, e2y, e2z, e3x, e3y, e3z, spr, 0.75f, a);
        face(bb, mat, cx, cy, cz, s, e3x, e3y, e3z, e1x, e1y, e1z, e2x, e2y, e2z, spr, 0.62f, a);
        face(bb, mat, cx, cy, cz, s, -e3x, -e3y, -e3z, e1x, e1y, e1z, e2x, e2y, e2z, spr, 0.62f, a);
    }

    private static void face(BufferBuilder bb, Matrix4f mat, float cx, float cy, float cz, float s,
            float nx, float ny, float nz, float ux, float uy, float uz, float vx, float vy, float vz,
            TextureAtlasSprite spr, float shade, float a) {
        float fx = cx + nx * s, fy = cy + ny * s, fz = cz + nz * s;
        float u0 = spr.getU0(), u1 = spr.getU1(), v0 = spr.getV0(), v1 = spr.getV1();
        bb.vertex(mat, fx - ux * s - vx * s, fy - uy * s - vy * s, fz - uz * s - vz * s).color(shade, shade, shade, a).uv(u0, v1).endVertex();
        bb.vertex(mat, fx + ux * s - vx * s, fy + uy * s - vy * s, fz + uz * s - vz * s).color(shade, shade, shade, a).uv(u1, v1).endVertex();
        bb.vertex(mat, fx + ux * s + vx * s, fy + uy * s + vy * s, fz + uz * s + vz * s).color(shade, shade, shade, a).uv(u1, v0).endVertex();
        bb.vertex(mat, fx - ux * s + vx * s, fy - uy * s + vy * s, fz - uz * s + vz * s).color(shade, shade, shade, a).uv(u0, v0).endVertex();
    }

    private static void flatQuad(BufferBuilder bb, Matrix4f mat, float cx, float y, float cz, float half, float angDeg, float r, float g, float b, float a) {
        float c = (float) Math.cos(Math.toRadians(angDeg));
        float s = (float) Math.sin(Math.toRadians(angDeg));
        float ax = c * half, az = s * half;
        float bx = -s * half, bz = c * half;
        bb.vertex(mat, cx - ax - bx, y, cz - az - bz).color(r, g, b, a).endVertex();
        bb.vertex(mat, cx + ax - bx, y, cz + az - bz).color(r, g, b, a).endVertex();
        bb.vertex(mat, cx + ax + bx, y, cz + az + bz).color(r, g, b, a).endVertex();
        bb.vertex(mat, cx - ax + bx, y, cz - az + bz).color(r, g, b, a).endVertex();
    }

    private static void beam(BufferBuilder bb, Matrix4f mat, float bx, float by, float bz, float tx, float ty, float tz, float w0, float w1, float r, float g, float b, float a) {
        bb.vertex(mat, bx - w0, by, bz).color(r, g, b, a).endVertex();
        bb.vertex(mat, bx + w0, by, bz).color(r, g, b, a).endVertex();
        bb.vertex(mat, tx + w1, ty, tz).color(r, g, b, a * 0.6f).endVertex();
        bb.vertex(mat, tx - w1, ty, tz).color(r, g, b, a * 0.6f).endVertex();
        bb.vertex(mat, bx, by, bz - w0).color(r, g, b, a).endVertex();
        bb.vertex(mat, bx, by, bz + w0).color(r, g, b, a).endVertex();
        bb.vertex(mat, tx, ty, tz + w1).color(r, g, b, a * 0.6f).endVertex();
        bb.vertex(mat, tx, ty, tz - w1).color(r, g, b, a * 0.6f).endVertex();
    }

    private static void ring(BufferBuilder bb, Matrix4f mat, float y, float r0, float r1, float r, float g, float b, float a) {
        for (int i = 0; i < RING_SEGMENTS; i++) {
            double a0 = Math.PI * 2 * i / RING_SEGMENTS;
            double a1 = Math.PI * 2 * (i + 1) / RING_SEGMENTS;
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0);
            float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            bb.vertex(mat, c0 * r0, y, s0 * r0).color(r, g, b, a).endVertex();
            bb.vertex(mat, c1 * r0, y, s1 * r0).color(r, g, b, a).endVertex();
            bb.vertex(mat, c1 * r1, y, s1 * r1).color(r, g, b, a * 0.25f).endVertex();
            bb.vertex(mat, c0 * r1, y, s0 * r1).color(r, g, b, a * 0.25f).endVertex();
        }
    }
}