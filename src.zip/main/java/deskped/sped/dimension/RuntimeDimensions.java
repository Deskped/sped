package deskped.sped.dimension;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.progress.ChunkProgressListenerFactory;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.border.BorderChangeListener;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.storage.DerivedLevelData;
import net.minecraft.world.level.storage.LevelStorageSource;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.LevelEvent;

import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.stream.Stream;

import deskped.sped.SpedMod;

public class RuntimeDimensions {

	@SuppressWarnings("deprecation")
	public static ServerLevel getOrCreate(MinecraftServer server, ResourceKey<Level> key, LevelStem stem) {
		Map<ResourceKey<Level>, ServerLevel> map = server.forgeGetWorldMap();
		ServerLevel existing = map.get(key);
		if (existing != null)
			return existing;

		ServerLevel overworld = server.overworld();
		try {
			Executor executor = (Executor) field(server, Executor.class);
			LevelStorageSource.LevelStorageAccess storage = (LevelStorageSource.LevelStorageAccess) field(server, LevelStorageSource.LevelStorageAccess.class);
			ChunkProgressListenerFactory progress = (ChunkProgressListenerFactory) field(server, ChunkProgressListenerFactory.class);

			DerivedLevelData data = new DerivedLevelData(server.getWorldData(), server.getWorldData().overworldData());
			long biomeSeed = BiomeManager.obfuscateSeed(server.getWorldData().worldGenOptions().seed());

			ServerLevel level = new ServerLevel(server, executor, storage, data, key, stem, progress.create(11), false, biomeSeed, List.of(), false, null);

			overworld.getWorldBorder().addListener(new BorderChangeListener.DelegateBorderChangeListener(level.getWorldBorder()));
			map.put(key, level);
			server.markWorldsDirty();
			MinecraftForge.EVENT_BUS.post(new LevelEvent.Load(level));
			return level;
		} catch (Exception e) {
			SpedMod.LOGGER.error("RuntimeDimensions: не удалось создать измерение {}: {}", key.location(), e.toString());
			return null;
		}
	}

	@SuppressWarnings("deprecation")
	public static void remove(MinecraftServer server, ResourceKey<Level> key) {
		Map<ResourceKey<Level>, ServerLevel> map = server.forgeGetWorldMap();
		ServerLevel level = map.get(key);
		if (level == null) {
			deleteFolder(server, key);
			return;
		}
		MinecraftForge.EVENT_BUS.post(new LevelEvent.Unload(level));
		map.remove(key);
		server.markWorldsDirty();
		try {
			level.close();
		} catch (Exception e) {
			SpedMod.LOGGER.warn("RuntimeDimensions: ошибка закрытия {}: {}", key.location(), e.toString());
		}
		deleteFolder(server, key);
	}

	private static void deleteFolder(MinecraftServer server, ResourceKey<Level> key) {
		try {
			LevelStorageSource.LevelStorageAccess storage = (LevelStorageSource.LevelStorageAccess) field(server, LevelStorageSource.LevelStorageAccess.class);
			Path dir = storage.getDimensionPath(key);
			deleteRecursively(dir);
		} catch (Exception e) {
			SpedMod.LOGGER.warn("RuntimeDimensions: не удалось удалить папку {}: {}", key.location(), e.toString());
		}
	}

	public static void cleanupLeftovers(MinecraftServer server) {
		try {
			LevelStorageSource.LevelStorageAccess storage = (LevelStorageSource.LevelStorageAccess) field(server, LevelStorageSource.LevelStorageAccess.class);
			ResourceKey<Level> probe = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(SpedMod.MODID, "bd_probe"));
			Path base = storage.getDimensionPath(probe).getParent();
			if (base == null || !Files.isDirectory(base))
				return;
			try (Stream<Path> s = Files.list(base)) {
				s.filter(p -> p.getFileName().toString().startsWith("bd_")).forEach(RuntimeDimensions::deleteRecursively);
			}
		} catch (Exception e) {
			SpedMod.LOGGER.warn("RuntimeDimensions: очистка остатков не удалась: {}", e.toString());
		}
	}

	private static void deleteRecursively(Path dir) {
		if (dir == null || !Files.exists(dir))
			return;
		try (Stream<Path> walk = Files.walk(dir)) {
			walk.sorted(Comparator.reverseOrder()).forEach(p -> {
				try {
					Files.deleteIfExists(p);
				} catch (Exception ignored) {
				}
			});
		} catch (Exception ignored) {
		}
	}

	private static Object field(MinecraftServer server, Class<?> type) throws Exception {
		Class<?> c = MinecraftServer.class;
		while (c != null && c != Object.class) {
			for (Field f : c.getDeclaredFields()) {
				if (type.isAssignableFrom(f.getType())) {
					f.setAccessible(true);
					Object v = f.get(server);
					if (v != null)
						return v;
				}
			}
			c = c.getSuperclass();
		}
		throw new NoSuchFieldException("MinecraftServer field of type " + type.getName());
	}
}
