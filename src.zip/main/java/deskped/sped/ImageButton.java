package deskped.sped;

import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Consumer;

public class ImageButton extends AbstractButton {

    public final ResourceLocation tex;
    public final int srcW;
    public final int srcH;
    private final Consumer<ImageButton> onPress;

    public ImageButton(int x, int y, int w, int h, int srcW, int srcH,
                       ResourceLocation tex, Consumer<ImageButton> onPress) {
        super(x, y, w, h, Component.empty());
        this.tex     = tex;
        this.srcW    = srcW;
        this.srcH    = srcH;
        this.onPress = onPress;
    }

    @Override
    public void onPress() { onPress.accept(this); }

    @Override
    public void renderWidget(net.minecraft.client.gui.GuiGraphics g, int mx, int my, float partial) {
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput out) {}
}