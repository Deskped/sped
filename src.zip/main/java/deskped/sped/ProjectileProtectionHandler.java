package deskped.sped;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ProjectileProtectionHandler {

    private static final Map<UUID, Set<UUID>> projectileAttackers = new HashMap<>();
    private static final Map<UUID, Integer> healTickMap = new HashMap<>();

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
            event.setCanceled(true);
            return;
        }

        if (!(event.getEntity() instanceof ServerPlayer victim)) return;

        Entity directEntity = event.getSource().getDirectEntity();
        Entity indirectEntity = event.getSource().getEntity();

        if (directEntity instanceof Projectile
                && indirectEntity instanceof ServerPlayer attacker
                && !attacker.getUUID().equals(victim.getUUID())) {

            UUID victimId = victim.getUUID();
            projectileAttackers.computeIfAbsent(victimId, k -> new HashSet<>()).add(attacker.getUUID());
            healTickMap.put(victimId, 0);
        }
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;

        Entity directEntity = event.getSource().getDirectEntity();
        Entity indirectEntity = event.getSource().getEntity();
        UUID victimId = victim.getUUID();

        if (directEntity instanceof Projectile && indirectEntity instanceof ServerPlayer) {
            Set<UUID> attackers = projectileAttackers.getOrDefault(victimId, Collections.emptySet());
            if (attackers.size() < 2 && victim.getHealth() - event.getAmount() <= 0) {
                float clamped = victim.getHealth() - 1.0f;
                event.setAmount(Math.max(0.0f, clamped));
            }
        }

        if (event.getAmount() < 2.0f) {
            float dmg = event.getAmount();
            event.setCanceled(true);
            float newHealth = victim.getHealth() - dmg;
            victim.setHealth(Math.max(0.0f, newHealth));
            if (newHealth <= 0.0f) {
                victim.kill();
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        UUID id = player.getUUID();
        if (!healTickMap.containsKey(id)) return;

        int ticks = healTickMap.merge(id, 1, Integer::sum);
        if (ticks >= 20) {
            healTickMap.put(id, 0);
            if (player.getHealth() < player.getMaxHealth()) {
                player.heal(1.0f);
            } else {
                healTickMap.remove(id);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            UUID id = player.getUUID();
            projectileAttackers.remove(id);
            healTickMap.remove(id);
        }
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        UUID id = event.getEntity().getUUID();
        projectileAttackers.remove(id);
        healTickMap.remove(id);
    }

    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        projectileAttackers.remove(id);
        healTickMap.remove(id);
    }
}