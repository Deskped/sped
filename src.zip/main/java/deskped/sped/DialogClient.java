package deskped.sped;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@OnlyIn(Dist.CLIENT)
public class DialogClient {

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent evt) {
            Dialog.serverToClientHandler = ClientDialogManager::addRemoteMessage;
            Dialog.openLoreHandler = () -> Minecraft.getInstance().execute(
                    () -> Minecraft.getInstance().setScreen(new LoreScreen()));
            Dialog.syncLoreHandler = pkt -> {
                ClientDialogManager.loreLog.clear();
                for (int i = 0; i < pkt.raws.size(); i++)
                    ClientDialogManager.loreLog.add(new ClientDialogManager.LoreEntry(
                            pkt.raws.get(i), pkt.entries.get(i)[0], ""));
            };
        }
    }

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ClientEvents {
        @SubscribeEvent
        public static void onClientChat(ClientChatEvent event) { ClientDialogManager.onClientChat(event); }

        @SubscribeEvent
        public static void onRenderGui(RenderGuiOverlayEvent.Post event) { ClientDialogManager.onRenderGui(event); }

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) { ClientDialogManager.onClientTick(event); }

        @SubscribeEvent
        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) { ClientDialogManager.onPlayerLogout(event); }

        @SubscribeEvent
        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) { ClientDialogManager.onPlayerRespawn(event); }
    }

    public static class ClientDialogManager {
        private static final long DISPLAY_DURATION_MS = 6000L;
        private static final long FADE_MS    = 800L;
        private static final long FADE_IN_MS = 200L;
        private static final int  MAX_ACTIVE = 20;
        private static final Map<String, ActiveMessage> active = new ConcurrentHashMap<>();

        static final List<LoreEntry> loreLog = new ArrayList<>();
        private static final int MAX_LORE = 200;

        @SuppressWarnings("deprecation")
        private static final SoundEvent TYPING_SOUND = SoundEvent.createVariableRangeEvent(
            ResourceLocation.fromNamespaceAndPath("sped", "typing"));

        private static final ResourceLocation END_PORTAL_TEX =
            ResourceLocation.fromNamespaceAndPath("minecraft", "textures/misc/end_portal.png");

        private static final float[][] LAYERS = {
            { 0.15f, 0.10f, 0.90f, 0.1f,  0.5f,  1.0f,  1.0f,  1.0f,  0.6f },
            { 0.15f, 0.10f, 0.90f, 0.2f,  0.2f,  0.8f,  0.8f,  0.8f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.1f,  0.4f,  0.6f,  0.6f,  0.6f,  0.4f },
            { 0.15f, 0.10f, 0.90f, 0.1f,  0.1f,  0.3f,  0.3f,  0.3f,  0.3f },
            { 0.15f, 0.10f, 0.90f, 0.4f,  0.4f,  0.9f,  0.9f,  0.9f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.5f,  0.1f,  0.1f,  0.5f,  0.1f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.1f,  0.0f,  0.1f,  0.7f,  0.7f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  1.0f,  0.3f,  0.3f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.6f,  0.1f,  0.1f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.5f,  0.5f,  0.5f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.2f,  0.0f,  0.2f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.2f,  0.2f,  0.0f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.0f,  0.2f,  0.0f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.4f,  0.4f,  0.4f,  0.5f },
            { 0.15f, 0.10f, 0.90f, 0.0f,  0.0f,  0.6f,  0.6f,  0.6f,  0.5f },
        };

        static void drawGatewayBg(GuiGraphics g, int x, int y, int w, int h) {
            long now = System.currentTimeMillis();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionTexShader);
            Tesselator tess = Tesselator.getInstance();
            for (int i = 0; i < LAYERS.length; i++) {
                float[] l = LAYERS[i];
                float scale = l[0] + i * l[1];
                float off   = (float)(now * (0.001 + i * 0.000015)) % 1f;
                float u0 = off,           v0 = off;
                float u1 = off + scale,   v1 = off + scale;
                float r = l[6], gr = l[7], b = l[8], a = l[2] / LAYERS.length;
                RenderSystem.setShaderColor(r, gr, b, a);
                RenderSystem.setShaderTexture(0, END_PORTAL_TEX);
                BufferBuilder buf = tess.getBuilder();
                buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
                buf.vertex(x,     y + h, 0).uv(u0, v1).endVertex();
                buf.vertex(x + w, y + h, 0).uv(u1, v1).endVertex();
                buf.vertex(x + w, y,     0).uv(u1, v0).endVertex();
                buf.vertex(x,     y,     0).uv(u0, v0).endVertex();
                tess.end();
            }
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }

        public static void noop() {}

        public static void addRemoteMessage(Dialog.ServerToClientDialogMessage pkt) {
            if (pkt.message == null) return;
            String trimmed = pkt.message.trim();
            if (trimmed.isEmpty()) return;
            String key = pkt.senderUuid + "_" + pkt.startMillis;
            long localStart = System.currentTimeMillis();
            active.put(key, new ActiveMessage(pkt.senderUuid, trimmed, localStart, DISPLAY_DURATION_MS));
            if (active.size() > MAX_ACTIVE) {
                String oldestKey = null; long oldest = Long.MAX_VALUE;
                for (Map.Entry<String, ActiveMessage> e : active.entrySet())
                    if (e.getValue().startMillis < oldest) { oldest = e.getValue().startMillis; oldestKey = e.getKey(); }
                if (oldestKey != null) active.remove(oldestKey);
            }
            if (pkt.named) {
                String locale = Minecraft.getInstance().getLanguageManager().getSelected();
                loreLog.add(new LoreEntry(trimmed, localStart, locale));
                if (loreLog.size() > MAX_LORE) loreLog.remove(0);
            }
        }

        public static void onClientChat(ClientChatEvent event) {
            String m = event.getMessage();
            if (m == null) return;
            if (m.startsWith("%!")) {
                String after = m.substring(2).trim(); event.setCanceled(true);
                if (!after.isEmpty() && Dialog.CHANNEL != null) Dialog.CHANNEL.sendToServer(new Dialog.ClientToServerDialogMessage(after, true));
            } else if (m.startsWith("%")) {
                String after = m.substring(1).trim(); event.setCanceled(true);
                if (!after.isEmpty() && Dialog.CHANNEL != null) Dialog.CHANNEL.sendToServer(new Dialog.ClientToServerDialogMessage(after, false));
            }
        }

        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            long now = System.currentTimeMillis();
            List<String> toRemove = new ArrayList<>();
            for (Map.Entry<String, ActiveMessage> e : active.entrySet())
                if (now - e.getValue().startMillis > e.getValue().duration + FADE_MS) toRemove.add(e.getKey());
            toRemove.forEach(active::remove);
        }

        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            if (event.getEntity() instanceof LocalPlayer) active.clear();
        }

        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            if (event.getEntity() instanceof LocalPlayer) active.clear();
        }

        private static final List<ActiveMessage> renderBuffer = new ArrayList<>(3);
        private static final Comparator<ActiveMessage> BY_START = Comparator.comparingLong(m -> m.startMillis);

        public static void onRenderGui(RenderGuiOverlayEvent.Post event) {
            if (active.isEmpty()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return;

            renderBuffer.clear();
            renderBuffer.addAll(active.values());
            renderBuffer.sort(BY_START);

            Font font = mc.font;
            GuiGraphics gui = event.getGuiGraphics();
            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();
            long now = System.currentTimeMillis();

            final int PX = 10, PY = 5, GAP = 4;
            int bh = font.lineHeight + PY * 2;
            int count = Math.min(3, renderBuffer.size());
            int startY = screenH - 80 - (bh + GAP) * (count - 1);

            int rendered = 0;
            for (int i = renderBuffer.size() - count; i < renderBuffer.size(); i++) {
                if (i < 0) continue;
                ActiveMessage m = renderBuffer.get(i);
                long age = now - m.startMillis;
                if (age < 0 || age > m.duration + FADE_MS) continue;

                float fadeIn  = age < FADE_IN_MS ? (float) age / FADE_IN_MS : 1f;
                float fadeOut = age > m.duration ? 1f - (float)(age - m.duration) / FADE_MS : 1f;
                float alpha   = fadeIn * fadeOut;
                if (alpha <= 0f) continue;

                int visibleChars = (int) Math.min(m.plainText.length(), age / 50L);

                if (visibleChars > m.lastSoundedChar) {
                    m.lastSoundedChar = visibleChars;
                    mc.getSoundManager().play(
                        net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                            TYPING_SOUND, 1.0f));
                }

                int tw = m.cachedWidth >= 0 ? m.cachedWidth : (m.cachedWidth = font.width(m.plainText));
                int bw = tw + PX * 2;
                int x  = (screenW - bw) >> 1;
                int y  = startY + rendered * (bh + GAP);

                int ia = (int)(alpha * 255);
                RenderSystem.enableBlend();
                RenderSystem.defaultBlendFunc();
                RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
                drawGatewayBg(gui, x, y, bw, bh);
                RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                gui.fill(x, y, x + bw, y + bh, (Math.min(ia, 0x88) << 24) | 0x000020);

                renderText(gui, font, m, (screenW - tw) >> 1, y + PY, visibleChars, ia);
                rendered++;
            }
        }

        private static void renderText(GuiGraphics gui, Font font, ActiveMessage msg,
                               int startX, int y, int visibleChars, int alpha) {
            long now = System.currentTimeMillis();
            int curX = startX, count = 0;
            for (ColoredSegment seg : msg.segments) {
                if (count >= visibleChars) break;
                int show = Math.min(seg.text.length(), visibleChars - count);
                for (int ci = 0; ci < show; ci++) {
                    String ch = String.valueOf(seg.text.charAt(ci));
                    int drawY = (int) (y + Math.sin(now * 0.002 + (count + ci) * 0.45) * 1.5);
                    int col = (alpha << 24) | (seg.color & 0xFFFFFF);
                    gui.drawString(font, ch, curX, drawY, col, false);
                    curX += font.width(ch);
                }
                count += show;
            }
        }

        static class ActiveMessage {
            public final UUID sender;
            public final long startMillis, duration;
            public final String rawText;
            public final String plainText;
            public int cachedWidth = -1;
            public int lastSoundedChar = 0;
            public final List<ColoredSegment> segments = new ArrayList<>();

            public ActiveMessage(UUID sender, String rawText, long startMillis, long duration) {
                this.sender = sender; this.rawText = rawText;
                this.plainText = rawText.replaceAll("\u00A7.", "");
                this.startMillis = startMillis; this.duration = duration;
                parseSegments();
            }

            private void parseSegments() {
                int color = 0xCCCCCC; StringBuilder cur = new StringBuilder();
                for (int i = 0; i < rawText.length(); i++) {
                    if (rawText.charAt(i) == '\u00A7' && i + 1 < rawText.length()) {
                        if (cur.length() > 0) { segments.add(new ColoredSegment(cur.toString(), color)); cur = new StringBuilder(); }
                        char code = rawText.charAt(++i);
                        if (code != 'r') color = Dialog.colorFromCode(code);
                    } else cur.append(rawText.charAt(i));
                }
                if (cur.length() > 0) segments.add(new ColoredSegment(cur.toString(), color));
            }
        }

        static class ColoredSegment {
            public final String text; public final int color;
            public ColoredSegment(String text, int color) { this.text = text; this.color = color; }
        }

        public static class LoreEntry {
            public final String rawText;
            public final String plainText;
            public final long timestamp;
            public final List<ColoredSegment> segments = new ArrayList<>();

            public LoreEntry(String rawText, long timestamp, String locale) {
                this.rawText   = rawText;
                this.plainText = rawText.replaceAll("§.", "");
                this.timestamp = timestamp;
                parseSegments();
            }

            private void parseSegments() {
                int color = 0xCCCCCC; StringBuilder cur = new StringBuilder();
                for (int i = 0; i < rawText.length(); i++) {
                    if (rawText.charAt(i) == '\u00A7' && i + 1 < rawText.length()) {
                        if (cur.length() > 0) { segments.add(new ColoredSegment(cur.toString(), color)); cur = new StringBuilder(); }
                        char code = rawText.charAt(++i);
                        if (code != 'r') color = Dialog.colorFromCode(code);
                    } else cur.append(rawText.charAt(i));
                }
                if (cur.length() > 0) segments.add(new ColoredSegment(cur.toString(), color));
            }

            public String getFormattedDateTime() {
                return new SimpleDateFormat("dd.MM.82 HH:mm").format(new Date(timestamp));
            }

            public String getNamePart() {
                int idx = plainText.indexOf(": ");
                return idx > 0 ? plainText.substring(0, idx) : null;
            }

            public int getNameColor() {
                if (segments.isEmpty()) return 0xCCCCCC;
                return segments.get(0).color;
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class LoreScreen extends Screen {

        private int perPage = 1;
        private int currentPage = 0;

        private String searchQuery = "";
        private EditBox searchBox;
        private List<ClientDialogManager.LoreEntry> filtered = new ArrayList<>();

        public LoreScreen() {
            super(Component.literal("Lore"));
        }

        @Override
        public boolean isPauseScreen() { return false; }

        private boolean isRu() {
            String l = Minecraft.getInstance().getLanguageManager().getSelected();
            return l != null && l.startsWith("ru_");
        }

        private int listTop() { return 40; }

        private int listBottom() { return this.height - 58; }

        private int totalPages() {
            return Math.max(1, (int) Math.ceil(filtered.size() / (double) perPage));
        }

        @Override
        protected void init() {
            boolean ru = isRu();
            perPage = Math.max(1, (listBottom() - listTop()) / 26);

            searchBox = new EditBox(this.font, this.width / 2 - 99, this.height - 52, 198, 20,
                    Component.literal(ru ? "\u041f\u043e\u0438\u0441\u043a..." : "Search..."));
            searchBox.setMaxLength(64);
            searchBox.setValue(searchQuery);
            searchBox.setHint(Component.literal(ru ? "\u041f\u043e\u0438\u0441\u043a..." : "Search..."));
            searchBox.setResponder(v -> { searchQuery = v; currentPage = 0; rebuildFilter(); });
            this.addRenderableWidget(searchBox);

            this.addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                    Component.literal("<"), b -> { if (currentPage > 0) currentPage--; })
                    .bounds(this.width / 2 - 100, this.height - 28, 20, 20).build());

            this.addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                    Component.translatable("gui.done"), b -> this.onClose())
                    .bounds(this.width / 2 - 76, this.height - 28, 152, 20).build());

            this.addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                    Component.literal(">"), b -> { if (currentPage < totalPages() - 1) currentPage++; })
                    .bounds(this.width / 2 + 80, this.height - 28, 20, 20).build());

            rebuildFilter();
        }

        private void rebuildFilter() {
            String q = searchQuery.toLowerCase(Locale.ROOT).trim();
            filtered = q.isEmpty()
                ? new ArrayList<>(ClientDialogManager.loreLog)
                : ClientDialogManager.loreLog.stream()
                    .filter(e -> e.plainText.toLowerCase(Locale.ROOT).contains(q))
                    .collect(Collectors.toList());
        }

        @Override
        public void tick() {
            if (searchBox != null) searchBox.tick();
        }

        @Override
        public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            renderBackground(g);
            boolean ru = isRu();
            g.drawCenteredString(font, ru ? "\u0416\u0443\u0440\u043d\u0430\u043b \u0441\u043e\u0431\u044b\u0442\u0438\u0439" : "Lore log", this.width / 2, 12, 0xFFFFFF);
            String sub = (ru ? "\u0417\u0430\u043f\u0438\u0441\u0435\u0439: " : "Entries: ") + filtered.size()
                    + "    " + (ru ? "\u0441\u0442\u0440. " : "page ") + (currentPage + 1) + " / " + totalPages();
            g.drawCenteredString(font, sub, this.width / 2, 24, 0xFFA0A0A0);
            drawEntries(g, mouseX, mouseY);
            super.render(g, mouseX, mouseY, partialTick);
        }

        private void drawEntries(GuiGraphics g, int mouseX, int mouseY) {
            boolean ru = isRu();
            int x = this.width / 2 - 152;
            int w = 304;
            int y = listTop();

            if (filtered.isEmpty()) {
                g.drawCenteredString(font, ru ? "\u0416\u0443\u0440\u043d\u0430\u043b \u043f\u0443\u0441\u0442." : "No entries.", this.width / 2, y + 8, 0xFFA0A0A0);
                return;
            }

            int startIdx = currentPage * perPage;
            int endIdx = Math.min(startIdx + perPage, filtered.size());
            for (int i = endIdx - 1; i >= startIdx; i--) {
                ClientDialogManager.LoreEntry entry = filtered.get(i);
                boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + 24;
                g.fill(x, y, x + w, y + 24, hovered ? 0xFF3C3C3C : 0xFF1E1E1E);
                g.drawString(font, entry.getFormattedDateTime(), x + 4, y + 3, 0xFFA0A0A0, false);
                drawEntryText(g, entry, x + 4, y + 14, x + w - 4);
                y += 26;
            }
        }

        private void drawEntryText(GuiGraphics g, ClientDialogManager.LoreEntry entry, int startX, int y, int maxX) {
            String namePart = entry.getNamePart();
            int nameColor = entry.getNameColor();
            int curX = startX;

            if (namePart != null) {
                String bracket = "<" + namePart + "> ";
                if (font.width(bracket) > maxX - curX) bracket = "..";
                g.drawString(font, bracket, curX, y, 0xFF000000 | nameColor, false);
                curX += font.width(bracket);
            }

            int skipChars = namePart != null ? namePart.length() + 2 : 0;
            int charIdx = 0;

            for (ClientDialogManager.ColoredSegment seg : entry.segments) {
                if (curX >= maxX) break;
                String segText = seg.text;
                if (skipChars > 0) {
                    if (charIdx + segText.length() <= skipChars) { charIdx += segText.length(); continue; }
                    segText = segText.substring(skipChars - charIdx);
                    charIdx = skipChars; skipChars = 0;
                }
                if (curX + font.width(segText) > maxX) {
                    String cut = font.plainSubstrByWidth(segText, Math.max(0, maxX - curX - font.width("..")));
                    g.drawString(font, cut + "..", curX, y, 0xFF000000 | seg.color, false);
                    break;
                }
                g.drawString(font, segText, curX, y, 0xFF000000 | seg.color, false);
                curX += font.width(segText);
                charIdx += segText.length();
            }
        }

        @Override
        public boolean keyPressed(int key, int scan, int mod) {
            if (key == 256) { this.onClose(); return true; }
            if (searchBox != null && searchBox.isFocused()) return super.keyPressed(key, scan, mod);
            if (key == 263 && currentPage > 0) { currentPage--; return true; }
            if (key == 262 && currentPage < totalPages() - 1) { currentPage++; return true; }
            return super.keyPressed(key, scan, mod);
        }
    }
}
