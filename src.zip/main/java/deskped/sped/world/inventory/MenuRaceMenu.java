package deskped.sped.world.inventory;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class MenuRaceMenu extends AbstractContainerMenu {
	public static MenuType<MenuRaceMenu> TYPE;

	@SubscribeEvent
	public static void registerMenus(RegisterEvent event) {
		event.register(ForgeRegistries.Keys.MENU_TYPES, helper -> {
			TYPE = IForgeMenuType.create(MenuRaceMenu::new);
			helper.register(new ResourceLocation("sped", "menu_race"), TYPE);
		});
	}

	public final Player player;
	public final int mode;

	public MenuRaceMenu(int id, Inventory inv, FriendlyByteBuf buf) {
		super(TYPE, id);
		this.player = inv.player;
		int m = 0;
		if (buf != null && buf.isReadable()) {
			buf.readBlockPos();
			if (buf.isReadable())
				m = buf.readInt();
		}
		this.mode = m;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		return ItemStack.EMPTY;
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}
}