package deskped.sped.world.inventory;

import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.Optional;

import deskped.sped.ext.CrafterRegistry;

public class CrafterMenu extends AbstractContainerMenu {
	public static final int SLOT_COUNT = 9;
	public static final int RESULT_SLOT = 9;
	public static final int INV_SLOT_START = 10;
	public static final int INV_SLOT_END = 46;

	private final Player player;
	private final CraftingContainer container;
	private final ContainerData containerData;
	private final ResultContainer resultContainer = new ResultContainer();
	private final NonNullList<ItemStack> lastInput = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

	public CrafterMenu(int id, Inventory inventory, FriendlyByteBuf buffer) {
		this(id, inventory);
	}

	public CrafterMenu(int id, Inventory inventory) {
		super(CrafterRegistry.CRAFTER_MENU.get(), id);
		this.player = inventory.player;
		this.containerData = new SimpleContainerData(10);
		this.container = new TransientCraftingContainer(this, 3, 3);
		this.addSlots(inventory);
		this.addDataSlots(this.containerData);
	}

	public CrafterMenu(int id, Inventory inventory, CraftingContainer container, ContainerData containerData) {
		super(CrafterRegistry.CRAFTER_MENU.get(), id);
		this.player = inventory.player;
		this.containerData = containerData;
		this.container = container;
		this.addSlots(inventory);
		this.addDataSlots(containerData);
		this.refreshRecipeResult();
	}

	private void addSlots(Inventory inventory) {
		for (int row = 0; row < 3; row++)
			for (int column = 0; column < 3; column++)
				this.addSlot(new CrafterSlot(this.container, column + row * 3, 26 + column * 18, 17 + row * 18, this));
		this.addSlot(new ResultSlot(this.resultContainer, 0, 134, 35));
		for (int row = 0; row < 3; row++)
			for (int column = 0; column < 9; column++)
				this.addSlot(new Slot(inventory, column + row * 9 + 9, 8 + column * 18, 84 + row * 18));
		for (int column = 0; column < 9; column++)
			this.addSlot(new Slot(inventory, column, 8 + column * 18, 142));
	}

	public boolean isSlotDisabled(int slot) {
		return slot >= 0 && slot < SLOT_COUNT && this.containerData.get(slot) == 1;
	}

	public boolean isPowered() {
		return this.containerData.get(9) == 1;
	}

	@Override
	public boolean clickMenuButton(Player player, int id) {
		if (id < 0 || id >= SLOT_COUNT)
			return false;
		if (this.getSlot(id).hasItem())
			return false;
		this.containerData.set(id, this.isSlotDisabled(id) ? 0 : 1);
		this.broadcastChanges();
		return true;
	}

	@Override
	public void slotsChanged(Container container) {
		this.refreshRecipeResult();
	}

	@Override
	public void broadcastChanges() {
		boolean changed = false;
		for (int i = 0; i < SLOT_COUNT; i++) {
			ItemStack stack = this.container.getItem(i);
			if (!ItemStack.matches(this.lastInput.get(i), stack)) {
				this.lastInput.set(i, stack.copy());
				changed = true;
			}
		}
		if (changed)
			this.refreshRecipeResult();
		super.broadcastChanges();
	}

	private void refreshRecipeResult() {
		if (!(this.player instanceof ServerPlayer serverPlayer))
			return;
		Level level = serverPlayer.level();
		ItemStack result = ItemStack.EMPTY;
		Optional<CraftingRecipe> recipe = level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, this.container, level);
		if (recipe.isPresent())
			result = recipe.get().assemble(this.container, level.registryAccess());
		this.resultContainer.setItem(0, result);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		ItemStack result = ItemStack.EMPTY;
		Slot slot = this.slots.get(index);
		if (slot != null && slot.hasItem()) {
			ItemStack stack = slot.getItem();
			result = stack.copy();
			if (index == RESULT_SLOT)
				return ItemStack.EMPTY;
			if (index < SLOT_COUNT) {
				if (!this.moveItemStackTo(stack, INV_SLOT_START, INV_SLOT_END, true))
					return ItemStack.EMPTY;
			} else if (!this.moveItemStackTo(stack, 0, SLOT_COUNT, false)) {
				return ItemStack.EMPTY;
			}
			if (stack.isEmpty())
				slot.set(ItemStack.EMPTY);
			else
				slot.setChanged();
		}
		return result;
	}

	@Override
	public boolean stillValid(Player player) {
		return this.container.stillValid(player);
	}

	public static class CrafterSlot extends Slot {
		private final CrafterMenu menu;

		public CrafterSlot(Container container, int index, int x, int y, CrafterMenu menu) {
			super(container, index, x, y);
			this.menu = menu;
		}

		@Override
		public boolean mayPlace(ItemStack stack) {
			return !this.menu.isSlotDisabled(this.getSlotIndex()) && super.mayPlace(stack);
		}

		@Override
		public void setChanged() {
			super.setChanged();
			this.menu.slotsChanged(this.container);
		}
	}

	public static class ResultSlot extends Slot {
		public ResultSlot(Container container, int index, int x, int y) {
			super(container, index, x, y);
		}

		@Override
		public boolean mayPlace(ItemStack stack) {
			return false;
		}

		@Override
		public boolean mayPickup(Player player) {
			return false;
		}
	}
}
