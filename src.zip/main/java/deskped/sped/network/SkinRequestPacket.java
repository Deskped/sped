package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.SkinStore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class SkinRequestPacket {

	public SkinRequestPacket() {
	}

	public SkinRequestPacket(FriendlyByteBuf buf) {
	}

	public static void buffer(SkinRequestPacket msg, FriendlyByteBuf buf) {
	}

	public static void handler(SkinRequestPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer sender = context.getSender();
			if (sender != null)
				SkinStore.onRequest(sender);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(SkinRequestPacket.class, SkinRequestPacket::buffer, SkinRequestPacket::new, SkinRequestPacket::handler);
	}
}
