package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.item.WandItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class WandSpellsPacket {
	private final CompoundTag tag;

	public WandSpellsPacket(CompoundTag tag) {
		this.tag = tag;
	}

	public WandSpellsPacket(FriendlyByteBuf buf) {
		tag = buf.readNbt();
	}

	public static void buffer(WandSpellsPacket msg, FriendlyByteBuf buf) {
		buf.writeNbt(msg.tag);
	}

	private static boolean valid(int id) {
		return (id >= 0 && id < WandItem.FX_COUNT) || id == WandItem.ID_POWER || id == WandItem.ID_RADIUS || id == WandItem.ID_TIME;
	}

	public static void handler(WandSpellsPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer player = context.getSender();
			if (player == null || msg.tag == null)
				return;
			ItemStack stack = player.getMainHandItem();
			if (!(stack.getItem() instanceof WandItem)) {
				stack = player.getOffhandItem();
				if (!(stack.getItem() instanceof WandItem))
					return;
			}
			CompoundTag root = new CompoundTag();
			root.putInt("Active", Mth.clamp(msg.tag.getInt("Active"), 0, WandItem.MAX_SLOTS - 1));
			ListTag in = msg.tag.getList("Slots", Tag.TAG_COMPOUND);
			ListTag out = new ListTag();
			for (int i = 0; i < Math.min(WandItem.MAX_SLOTS, in.size()); i++) {
				CompoundTag s = in.getCompound(i);
				CompoundTag c = new CompoundTag();
				String name = s.getString("Name");
				if (name.length() > 24)
					name = name.substring(0, 24);
				c.putString("Name", name);
				c.putInt("Form", Mth.clamp(s.getInt("Form"), 0, 2));
				int pw = 0;
				int rd = 0;
				int du = 0;
				List<Integer> chain = new ArrayList<>();
				for (int id : s.getIntArray("Chain")) {
					if (!valid(id) || chain.size() >= WandItem.MAX_CHAIN)
						continue;
					if (id == WandItem.ID_POWER) {
						if (pw >= 3)
							continue;
						pw++;
					} else if (id == WandItem.ID_RADIUS) {
						if (rd >= 3)
							continue;
						rd++;
					} else if (id == WandItem.ID_TIME) {
						if (du >= 3)
							continue;
						du++;
					}
					chain.add(id);
				}
				int[] a = new int[chain.size()];
				for (int j = 0; j < a.length; j++)
					a[j] = chain.get(j);
				c.putIntArray("Chain", a);
				out.add(c);
			}
			root.put("Slots", out);
			stack.getOrCreateTag().put(WandItem.TAG, root);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(WandSpellsPacket.class, WandSpellsPacket::buffer, WandSpellsPacket::new, WandSpellsPacket::handler);
	}
}