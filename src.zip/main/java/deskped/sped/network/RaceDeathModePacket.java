package deskped.sped.network;

import deskped.sped.SpedMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RaceDeathModePacket {
	private final int mode;

	public RaceDeathModePacket(int mode) {
		this.mode = mode;
	}

	public RaceDeathModePacket(FriendlyByteBuf buf) {
		this.mode = buf.readInt();
	}

	public static void buffer(RaceDeathModePacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.mode);
	}

	public static void handler(RaceDeathModePacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer player = context.getSender();
			if (player == null)
				return;
			int m = Math.max(0, Math.min(2, msg.mode));
			player.getPersistentData().putInt("sped_death_mode", m);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(RaceDeathModePacket.class, RaceDeathModePacket::buffer, RaceDeathModePacket::new, RaceDeathModePacket::handler);
	}
}