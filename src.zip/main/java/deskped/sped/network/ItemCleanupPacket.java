package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.cleanup.client.ItemCleanupState;

import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ItemCleanupPacket {

	public static final int MODE_HIDDEN = 0;
	public static final int MODE_COUNTDOWN = 1;
	public static final int MODE_DONE = 2;

	private final int mode;
	private final int ticks;

	public ItemCleanupPacket(int mode, int ticks) {
		this.mode = mode;
		this.ticks = ticks;
	}

	public ItemCleanupPacket(FriendlyByteBuf buf) {
		this.mode = buf.readVarInt();
		this.ticks = buf.readVarInt();
	}

	public static void buffer(ItemCleanupPacket msg, FriendlyByteBuf buf) {
		buf.writeVarInt(msg.mode);
		buf.writeVarInt(msg.ticks);
	}

	public static void handler(ItemCleanupPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				ItemCleanupState.set(msg.mode, msg.ticks);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(ItemCleanupPacket.class, ItemCleanupPacket::buffer, ItemCleanupPacket::new, ItemCleanupPacket::handler);
	}
}
