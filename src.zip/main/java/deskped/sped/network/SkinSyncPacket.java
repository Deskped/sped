package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.client.SkinClientCache;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class SkinSyncPacket {

	private final UUID owner;
	private final int type;
	private final boolean slim;
	private final byte[] data;

	public SkinSyncPacket(UUID owner, int type, boolean slim, byte[] data) {
		this.owner = owner;
		this.type = type;
		this.slim = slim;
		this.data = data;
	}

	public SkinSyncPacket(FriendlyByteBuf buf) {
		this.owner = buf.readUUID();
		this.type = buf.readByte();
		this.slim = buf.readBoolean();
		this.data = buf.readByteArray(30000);
	}

	public static void buffer(SkinSyncPacket msg, FriendlyByteBuf buf) {
		buf.writeUUID(msg.owner);
		buf.writeByte(msg.type);
		buf.writeBoolean(msg.slim);
		buf.writeByteArray(msg.data);
	}

	public static void handler(SkinSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				SkinClientCache.handle(msg.owner, msg.type, msg.slim, msg.data);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(SkinSyncPacket.class, SkinSyncPacket::buffer, SkinSyncPacket::new, SkinSyncPacket::handler);
	}
}
