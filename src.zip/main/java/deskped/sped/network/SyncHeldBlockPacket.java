package deskped.sped.network;

import deskped.sped.capability.HeldBlockCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

public class SyncHeldBlockPacket {

    private final UUID playerUUID;
    private final boolean holding;
    private final BlockPos originPos;
    private final BlockState heldState;
    private final CompoundTag beData;

    public SyncHeldBlockPacket(UUID playerUUID, boolean holding, BlockPos originPos, BlockState heldState, CompoundTag beData) {
        this.playerUUID = playerUUID;
        this.holding = holding;
        this.originPos = originPos;
        this.heldState = heldState;
        this.beData = beData;
    }

    public static void encode(SyncHeldBlockPacket pkt, FriendlyByteBuf buf) {
        buf.writeUUID(pkt.playerUUID);
        buf.writeBoolean(pkt.holding);
        if (pkt.holding) {
            buf.writeBlockPos(pkt.originPos);
            buf.writeNbt(NbtUtils.writeBlockState(pkt.heldState));
            buf.writeBoolean(pkt.beData != null);
            if (pkt.beData != null) buf.writeNbt(pkt.beData);
        }
    }

    public static SyncHeldBlockPacket decode(FriendlyByteBuf buf) {
        UUID uuid = buf.readUUID();
        boolean holding = buf.readBoolean();
        if (!holding) return new SyncHeldBlockPacket(uuid, false, BlockPos.ZERO, null, null);
        BlockPos pos = buf.readBlockPos();
        CompoundTag stateTag = buf.readNbt();
        BlockState state = NbtUtils.readBlockState(net.minecraft.core.registries.BuiltInRegistries.BLOCK.asLookup(), stateTag);
        boolean hasBeData = buf.readBoolean();
        CompoundTag beData = hasBeData ? buf.readNbt() : null;
        return new SyncHeldBlockPacket(uuid, true, pos, state, beData);
    }

    public static void handle(SyncHeldBlockPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            net.minecraft.client.multiplayer.ClientLevel level = Minecraft.getInstance().level;
            if (level == null) return;
            Player player = level.getPlayerByUUID(pkt.playerUUID);
            if (player == null) return;
            player.getCapability(HeldBlockCapability.HELD_BLOCK).ifPresent(cap -> {
                if (pkt.holding) {
                    cap.setHeld(pkt.originPos, pkt.heldState, pkt.beData);
                } else {
                    cap.clearHeld();
                }
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
