package deskped.sped.network;

import deskped.sped.PhotoStorage;
import deskped.sped.SpedMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class PhotoUploadPacket {

	private final UUID photoId;
	private final int total;
	private final int index;
	private final byte[] data;

	public PhotoUploadPacket(UUID photoId, int total, int index, byte[] data) {
		this.photoId = photoId;
		this.total = total;
		this.index = index;
		this.data = data;
	}

	public PhotoUploadPacket(FriendlyByteBuf buf) {
		this.photoId = buf.readUUID();
		this.total = buf.readVarInt();
		this.index = buf.readVarInt();
		this.data = buf.readByteArray(30000);
	}

	public static void buffer(PhotoUploadPacket msg, FriendlyByteBuf buf) {
		buf.writeUUID(msg.photoId);
		buf.writeVarInt(msg.total);
		buf.writeVarInt(msg.index);
		buf.writeByteArray(msg.data);
	}

	public static void handler(PhotoUploadPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer sender = context.getSender();
			if (sender != null)
				PhotoStorage.receiveUpload(sender, msg.photoId, msg.total, msg.index, msg.data);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(PhotoUploadPacket.class, PhotoUploadPacket::buffer, PhotoUploadPacket::new, PhotoUploadPacket::handler);
	}
}
