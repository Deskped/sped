package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.client.ClientRaceState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RaceSyncPacket {
	private final List<String> names;

	public RaceSyncPacket(List<String> names) {
		this.names = names;
	}

	public RaceSyncPacket(FriendlyByteBuf buf) {
		int n = buf.readInt();
		names = new ArrayList<>();
		for (int i = 0; i < n; i++)
			names.add(buf.readUtf());
	}

	public static void buffer(RaceSyncPacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.names.size());
		for (String s : msg.names)
			buf.writeUtf(s);
	}

	public static void handler(RaceSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				ClientRaceState.set(msg.names);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(RaceSyncPacket.class, RaceSyncPacket::buffer, RaceSyncPacket::new, RaceSyncPacket::handler);
	}
}