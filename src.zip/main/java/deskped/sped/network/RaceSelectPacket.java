package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.race.RaceAttribute;
import deskped.sped.race.RaceData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RaceSelectPacket {
	private final List<String> names;

	public RaceSelectPacket(List<String> names) {
		this.names = names;
	}

	public RaceSelectPacket(FriendlyByteBuf buf) {
		int n = buf.readInt();
		names = new ArrayList<>();
		for (int i = 0; i < n; i++)
			names.add(buf.readUtf());
	}

	public static void buffer(RaceSelectPacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.names.size());
		for (String s : msg.names)
			buf.writeUtf(s);
	}

	public static void handler(RaceSelectPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer player = context.getSender();
			if (player == null)
				return;
			Set<RaceAttribute> set = EnumSet.noneOf(RaceAttribute.class);
			for (String s : msg.names) {
				try {
					set.add(RaceAttribute.valueOf(s));
				} catch (IllegalArgumentException ignored) {
				}
			}
			if (set.size() > 3)
				return;
			boolean op = player.hasPermissions(2);
			if (set.isEmpty() && !op)
				return;
			if (!op) {
				int need = 0;
				for (RaceAttribute a : set)
					need = Math.max(need, a.group.reqLevel);
				if (player.experienceLevel < need) {
					boolean ru = player.getLanguage() != null && player.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
					player.sendSystemMessage(Component.literal(ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " + need : "Requires XP level: " + need));
					return;
				}
			}
			RaceData.set(player, set);
			boolean fly = set.contains(RaceAttribute.WINGED) || set.contains(RaceAttribute.DRAGON);
			if (!fly && !player.isCreative() && !player.isSpectator()) {
				player.getAbilities().mayfly = false;
				player.getAbilities().flying = false;
				player.onUpdateAbilities();
			}
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(RaceSelectPacket.class, RaceSelectPacket::buffer, RaceSelectPacket::new, RaceSelectPacket::handler);
	}
}
