package deskped.sped.network;

import deskped.sped.PhotoStorage;
import deskped.sped.SpedMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class PhotoRequestPacket {

	private final UUID photoId;

	public PhotoRequestPacket(UUID photoId) {
		this.photoId = photoId;
	}

	public PhotoRequestPacket(FriendlyByteBuf buf) {
		this.photoId = buf.readUUID();
	}

	public static void buffer(PhotoRequestPacket msg, FriendlyByteBuf buf) {
		buf.writeUUID(msg.photoId);
	}

	public static void handler(PhotoRequestPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer sender = context.getSender();
			if (sender != null)
				PhotoStorage.serve(sender, msg.photoId);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(PhotoRequestPacket.class, PhotoRequestPacket::buffer, PhotoRequestPacket::new, PhotoRequestPacket::handler);
	}
}
