package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.client.ClientRaceState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RaceLevelsPacket {
	private final Map<String, Integer> xp;

	public RaceLevelsPacket(Map<String, Integer> xp) {
		this.xp = xp;
	}

	public RaceLevelsPacket(FriendlyByteBuf buf) {
		int n = buf.readInt();
		xp = new HashMap<>();
		for (int i = 0; i < n; i++)
			xp.put(buf.readUtf(), buf.readInt());
	}

	public static void buffer(RaceLevelsPacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.xp.size());
		for (Map.Entry<String, Integer> e : msg.xp.entrySet()) {
			buf.writeUtf(e.getKey());
			buf.writeInt(e.getValue());
		}
	}

	public static void handler(RaceLevelsPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				ClientRaceState.setXp(msg.xp);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(RaceLevelsPacket.class, RaceLevelsPacket::buffer, RaceLevelsPacket::new, RaceLevelsPacket::handler);
	}
}
