package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.client.ClientRaceState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class RaceHudPacket {
	private final List<String[]> entries;

	public RaceHudPacket(List<String[]> entries) {
		this.entries = entries;
	}

	public RaceHudPacket(FriendlyByteBuf buf) {
		int n = buf.readInt();
		entries = new ArrayList<>();
		for (int i = 0; i < n; i++)
			entries.add(new String[]{buf.readUtf(), String.valueOf(buf.readInt()), String.valueOf(buf.readInt())});
	}

	public static void buffer(RaceHudPacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.entries.size());
		for (String[] e : msg.entries) {
			buf.writeUtf(e[0]);
			buf.writeInt(Integer.parseInt(e[1]));
			buf.writeInt(Integer.parseInt(e[2]));
		}
	}

	public static void handler(RaceHudPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				ClientRaceState.setHud(msg.entries);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(RaceHudPacket.class, RaceHudPacket::buffer, RaceHudPacket::new, RaceHudPacket::handler);
	}
}