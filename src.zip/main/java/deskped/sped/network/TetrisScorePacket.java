package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.item.AdvancedClockCircuitItem;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class TetrisScorePacket {

	private final int score;
	private final boolean mainHand;

	public TetrisScorePacket(int score, boolean mainHand) {
		this.score = score;
		this.mainHand = mainHand;
	}

	public TetrisScorePacket(FriendlyByteBuf buf) {
		this.score = buf.readInt();
		this.mainHand = buf.readBoolean();
	}

	public static void buffer(TetrisScorePacket msg, FriendlyByteBuf buf) {
		buf.writeInt(msg.score);
		buf.writeBoolean(msg.mainHand);
	}

	public static void handler(TetrisScorePacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer player = context.getSender();
			if (player == null)
				return;
			int score = Math.max(0, Math.min(msg.score, 100000000));
			ItemStack stack = player.getItemInHand(msg.mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND);
			if (!(stack.getItem() instanceof AdvancedClockCircuitItem)) {
				stack = player.getMainHandItem();
				if (!(stack.getItem() instanceof AdvancedClockCircuitItem)) {
					stack = player.getOffhandItem();
					if (!(stack.getItem() instanceof AdvancedClockCircuitItem))
						return;
				}
			}
			CompoundTag root = stack.getOrCreateTag().getCompound(AdvancedClockCircuitItem.TAG);
			if (score > root.getInt("Best")) {
				root.putInt("Best", score);
				stack.getOrCreateTag().put(AdvancedClockCircuitItem.TAG, root);
			}
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(TetrisScorePacket.class, TetrisScorePacket::buffer, TetrisScorePacket::new, TetrisScorePacket::handler);
	}
}
