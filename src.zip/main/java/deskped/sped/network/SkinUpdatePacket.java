package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.SkinStore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class SkinUpdatePacket {

	private final int type;
	private final boolean slim;
	private final byte[] data;

	public SkinUpdatePacket(int type, boolean slim, byte[] data) {
		this.type = type;
		this.slim = slim;
		this.data = data;
	}

	public SkinUpdatePacket(FriendlyByteBuf buf) {
		this.type = buf.readByte();
		this.slim = buf.readBoolean();
		this.data = buf.readByteArray(30000);
	}

	public static void buffer(SkinUpdatePacket msg, FriendlyByteBuf buf) {
		buf.writeByte(msg.type);
		buf.writeBoolean(msg.slim);
		buf.writeByteArray(msg.data);
	}

	public static void handler(SkinUpdatePacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			ServerPlayer sender = context.getSender();
			if (sender != null)
				SkinStore.receive(sender, msg.type, msg.slim, msg.data);
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(SkinUpdatePacket.class, SkinUpdatePacket::buffer, SkinUpdatePacket::new, SkinUpdatePacket::handler);
	}
}
