package deskped.sped.network;

import deskped.sped.SpedMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class PhotoDataPacket {

	private final UUID photoId;
	private final int total;
	private final int index;
	private final byte[] data;

	public PhotoDataPacket(UUID photoId, int total, int index, byte[] data) {
		this.photoId = photoId;
		this.total = total;
		this.index = index;
		this.data = data;
	}

	public PhotoDataPacket(FriendlyByteBuf buf) {
		this.photoId = buf.readUUID();
		this.total = buf.readVarInt();
		this.index = buf.readVarInt();
		this.data = buf.readByteArray(30000);
	}

	public static void buffer(PhotoDataPacket msg, FriendlyByteBuf buf) {
		buf.writeUUID(msg.photoId);
		buf.writeVarInt(msg.total);
		buf.writeVarInt(msg.index);
		buf.writeByteArray(msg.data);
	}

	public static void handler(PhotoDataPacket msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context context = ctx.get();
		context.enqueueWork(() -> {
			if (context.getDirection().getReceptionSide().isClient())
				DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.client.PhotoClientCache.receive(msg.photoId, msg.total, msg.index, msg.data));
		});
		context.setPacketHandled(true);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(PhotoDataPacket.class, PhotoDataPacket::buffer, PhotoDataPacket::new, PhotoDataPacket::handler);
	}
}
