package deskped.sped.network;

import deskped.sped.SpedMod;
import deskped.sped.client.ClientPortalState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class PortalStatePacket {
    private final boolean open;
    private final boolean hasOrigin;
    private final double x, y, z;

    public PortalStatePacket(boolean open, boolean hasOrigin, double x, double y, double z) {
        this.open = open;
        this.hasOrigin = hasOrigin;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public PortalStatePacket(FriendlyByteBuf buf) {
        this.open = buf.readBoolean();
        this.hasOrigin = buf.readBoolean();
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
    }

    public static void buffer(PortalStatePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.open);
        buf.writeBoolean(msg.hasOrigin);
        buf.writeDouble(msg.x);
        buf.writeDouble(msg.y);
        buf.writeDouble(msg.z);
    }

    public static void handler(PortalStatePacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            if (context.getDirection().getReceptionSide().isClient())
                ClientPortalState.set(msg.open, msg.hasOrigin, msg.x, msg.y, msg.z);
        });
        context.setPacketHandled(true);
    }

    @SubscribeEvent
    public static void registerMessage(FMLCommonSetupEvent event) {
        SpedMod.addNetworkMessage(PortalStatePacket.class, PortalStatePacket::buffer, PortalStatePacket::new, PortalStatePacket::handler);
    }
}