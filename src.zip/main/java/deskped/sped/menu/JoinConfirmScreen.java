package deskped.sped.menu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class JoinConfirmScreen extends Screen {

	private final Screen parent;
	private final boolean ru;
	private long openedAt;

	public JoinConfirmScreen(Screen parent, boolean ru) {
		super(Component.empty());
		this.parent = parent;
		this.ru = ru;
	}

	@Override
	protected void init() {
		openedAt = System.currentTimeMillis();
		int cx = width / 2;
		int cy = height / 2;
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u0414\u0430" : "Yes"), b -> {
			SpedMenu.confirmed = true;
			SpedMenu.connect(parent, Minecraft.getInstance());
		}).bounds(cx - 104, cy + 14, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal(ru ? "\u041d\u0435\u0442" : "No"), b -> onClose())
				.bounds(cx + 4, cy + 14, 100, 20).build());
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		long now = System.currentTimeMillis();
		g.fill(0, 0, width, height, 0xC0000000);

		int pw = 248;
		int ph = 104;
		float t = MenuArt.clamp01((now - openedAt) / 260.0f);
		float enter = MenuArt.backOut(t);
		int x = width / 2 - pw / 2;
		int y = (int) (height / 2 - ph / 2 + (1.0f - enter) * -50.0f);

		g.fill(x, y, x + pw, y + ph, MenuArt.OUTLINE);
		g.fill(x + 1, y + 1, x + pw - 1, y + ph - 1, 0xFF17151A);
		g.fill(x + 1, y + 1, x + pw - 1, y + 3, MenuArt.alpha(MenuArt.FIRE_DEEP, 0.85f));
		g.fill(x + 1, y + ph - 3, x + pw - 1, y + ph - 1, MenuArt.alpha(MenuArt.FIRE_DEEP, 0.45f));

		String title = ru ? "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u043a \u0441\u0435\u0440\u0432\u0435\u0440\u0443?" : "Join the server?";
		int tw = font.width(title);
		g.drawString(font, title, width / 2 - tw / 2, y + 26, 0xFFFFFFFF, true);
		int sw = font.width(SpedMenu.SERVER);
		g.drawString(font, SpedMenu.SERVER, width / 2 - sw / 2, y + 42, MenuArt.FIRE, true);

		super.render(g, mx, my, partial);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
