package deskped.sped.menu;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

@OnlyIn(Dist.CLIENT)
public final class MenuChaos {

	public static final float SCROLL = -5.2f;

	private static final Random RNG = new Random();
	private static final float GRAVITY = 0.34f;

	private static final int INTACT = 0;
	private static final int FLYING = 1;
	private static final int RETURN = 2;

	private static final List<Block> blocks = new ArrayList<>();
	private static final List<Tnt> tnts = new ArrayList<>();
	private static final List<Puff> puffs = new ArrayList<>();

	private static int worldW;
	private static int worldH;
	private static int period;
	private static int groundTop;
	private static long nextTnt;
	private static float shake;

	private static float camFocusX;
	private static float camFocusY;

	private MenuChaos() {
	}

	private static class Block {
		float hx, hy, x, y, vx, vy, rot, vrot, fromX, fromY;
		int w, h, state;
		boolean ground;
		ResourceLocation tex;
		long stateAt;
	}

	private static class Tnt {
		float x, y, vx, vy;
	}

	private static class Puff {
		float x, y, vx, vy, r, grow;
		int life, maxLife, sprite;
	}

	public static float shake() {
		return shake;
	}

	public static float camScale() {
		return 1.0f;
	}

	public static float camFocusX() {
		return camFocusX;
	}

	public static float camFocusY() {
		return camFocusY;
	}

	public static int groundTop() {
		return groundTop;
	}

	public static int groundY(int x, int w, int h) {
		return groundTop;
	}

	public static void build(int w, int h) {
		worldW = w;
		worldH = h;
		groundTop = ((int) (h * 0.80f) / 16) * 16;
		period = (w / 16 + 8) * 16;
		blocks.clear();
		tnts.clear();
		puffs.clear();
		camFocusX = w / 2.0f;
		camFocusY = h / 2.0f;
		nextTnt = System.currentTimeMillis() + 700L;

		for (int c = -4; c * 16 < w + 64; c++) {
			int gx = c * 16;
			addGround(gx, groundTop, MenuArt.T_GRASS_SIDE);
			addGround(gx, groundTop + 16, MenuArt.T_DIRT);
			addGround(gx, groundTop + 32, MenuArt.T_STONE);
		}

		int towers = Math.max(4, w / 130);
		for (int t = 0; t < towers; t++) {
			int baseX = ((int) (w * (0.05f + 0.92f * t / (float) Math.max(1, towers - 1))) / 16) * 16;
			int cols = 2 + RNG.nextInt(3);
			for (int c = 0; c < cols; c++) {
				int rows = 2 + RNG.nextInt(5);
				for (int r = 0; r < rows; r++) {
					Block b = new Block();
					b.w = 16;
					b.h = 16;
					b.hx = baseX + c * 16;
					b.hy = groundTop - (r + 1) * 16;
					b.x = b.hx;
					b.y = b.hy;
					b.tex = MenuArt.RUBBLE[RNG.nextInt(MenuArt.RUBBLE.length)];
					b.state = INTACT;
					blocks.add(b);
				}
			}
		}
	}

	private static void addGround(int gx, int gy, ResourceLocation tex) {
		Block b = new Block();
		b.w = 16;
		b.h = 16;
		b.hx = gx;
		b.hy = gy;
		b.x = gx;
		b.y = gy;
		b.tex = tex;
		b.ground = true;
		b.state = INTACT;
		blocks.add(b);
	}

	public static void update(int w, int h, long now) {
		if (worldW != w || worldH != h || blocks.isEmpty())
			build(w, h);

		shake *= 0.90f;
		if (shake < 0.002f)
			shake = 0.0f;


		if (now >= nextTnt) {
			Tnt t = new Tnt();
			t.x = -32.0f;
			t.y = 40.0f + RNG.nextFloat() * (h * 0.30f);
			t.vx = 6.5f + RNG.nextFloat() * 3.5f;
			t.vy = 0.2f + RNG.nextFloat() * 0.9f;
			tnts.add(t);
			nextTnt = now + 500L + RNG.nextInt(800);
		}

		for (Iterator<Tnt> it = tnts.iterator(); it.hasNext(); ) {
			Tnt t = it.next();
			t.vy += GRAVITY * 0.42f;
			t.x += t.vx;
			t.y += t.vy;
			if (t.y >= groundTop - 8 || hits(t.x, t.y)) {
				boom(t.x, t.y, 54.0f + RNG.nextInt(26), now);
				it.remove();
			} else if (t.x > w + 40) {
				it.remove();
			}
		}

		for (Block b : blocks) {
			b.hx += SCROLL;
			if (b.state == INTACT) {
				b.x = b.hx;
			} else if (b.state == FLYING) {
				b.vy += GRAVITY;
				b.x += b.vx + SCROLL;
				b.y += b.vy;
				b.rot += b.vrot;
				if (b.y + b.h > groundTop) {
					b.y = groundTop - b.h;
					b.vy *= -0.30f;
					b.vx *= 0.6f;
					b.vrot *= 0.5f;
					if (Math.abs(b.vy) < 0.8f)
						b.vy = 0.0f;
				}
				if (now - b.stateAt > 2400L + RNG.nextInt(900)) {
					b.state = RETURN;
					b.stateAt = now;
					b.fromX = b.x;
					b.fromY = b.y;
				}
			} else {
				b.fromX += SCROLL;
				float t = MenuArt.clamp01((now - b.stateAt) / 620.0f);
				float e = MenuArt.backOut(t);
				b.x = b.fromX + (b.hx - b.fromX) * e;
				b.y = b.fromY + (b.hy - b.fromY) * e;
				b.rot *= (1.0f - t);
				if (t >= 1.0f) {
					b.state = INTACT;
					b.x = b.hx;
					b.y = b.hy;
					b.rot = 0.0f;
				}
			}
			if (b.hx < -48.0f) {
				b.hx += period;
				b.x = b.hx;
				b.y = b.hy;
				b.state = INTACT;
				b.rot = 0.0f;
			}
		}

		for (Iterator<Puff> it = puffs.iterator(); it.hasNext(); ) {
			Puff p = it.next();
			p.x += p.vx + SCROLL;
			p.y += p.vy;
			p.vy *= 0.94f;
			p.r += p.grow;
			if (--p.life <= 0)
				it.remove();
		}
	}

	private static boolean hits(float x, float y) {
		for (Block b : blocks)
			if (b.state == INTACT && !b.ground && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h)
				return true;
		return false;
	}

	private static void boom(float ex, float ey, float radius, long now) {
		shake = Math.min(1.6f, shake + 0.85f);

		for (Block b : blocks) {
			if (b.state != INTACT)
				continue;
			float dx = b.hx + b.w / 2.0f - ex;
			float dy = b.hy + b.h / 2.0f - ey;
			float d = (float) Math.sqrt(dx * dx + dy * dy);
			if (d > radius)
				continue;
			float f = 1.0f - d / radius;
			float inv = 1.0f / Math.max(1.0f, d);
			b.state = FLYING;
			b.stateAt = now;
			b.x = b.hx;
			b.y = b.hy;
			b.vx = dx * inv * (2.4f + f * 5.0f) + (RNG.nextFloat() - 0.5f) * 2.0f;
			b.vy = dy * inv * (1.6f + f * 3.4f) - (2.2f + f * 4.4f);
			b.vrot = (RNG.nextFloat() - 0.5f) * 24.0f;
		}

		int n = 8 + RNG.nextInt(6);
		for (int i = 0; i < n; i++) {
			Puff p = new Puff();
			double a = RNG.nextDouble() * Math.PI * 2.0D;
			double dist = RNG.nextDouble() * radius * 0.55D;
			p.x = ex + (float) (Math.cos(a) * dist);
			p.y = ey + (float) (Math.sin(a) * dist);
			p.vx = (float) (Math.cos(a) * 0.6D);
			p.vy = (float) (Math.sin(a) * 0.6D) - 0.25f;
			p.r = 3.0f + RNG.nextFloat() * 4.0f;
			p.grow = 0.42f + RNG.nextFloat() * 0.30f;
			p.maxLife = 26 + RNG.nextInt(18);
			p.life = p.maxLife;
			p.sprite = RNG.nextInt(MenuArt.PARTICLE.length);
			puffs.add(p);
		}

	}

	public static void render(GuiGraphics g, long now) {
		PoseStack pose = g.pose();

		for (Block b : blocks) {
			if (b.state == INTACT) {
				MenuArt.tile(g, b.tex, (int) b.x, (int) b.y, b.w, b.h);
			} else {
				pose.pushPose();
				pose.translate(b.x + b.w / 2.0f, b.y + b.h / 2.0f, 0.0f);
				pose.mulPose(Axis.ZP.rotationDegrees(b.rot));
				MenuArt.tile(g, b.tex, -b.w / 2, -b.h / 2, b.w, b.h);
				pose.popPose();
			}
		}

		for (Tnt t : tnts) {
			int s = 8;
			MenuArt.tile(g, MenuArt.T_TNT_SIDE, (int) t.x - s, (int) t.y - s, s * 2, s * 2);
			if ((now / 100L) % 2L == 0L)
				g.fill((int) t.x - s, (int) t.y - s, (int) t.x + s, (int) t.y + s, MenuArt.alpha(0xFFFFFFFF, 0.55f));
		}

		for (Puff p : puffs) {
			float a = p.life / (float) p.maxLife;
			MenuArt.particle(g, MenuArt.PARTICLE[p.sprite], (int) p.x, (int) p.y, (int) (p.r * 2.0f), a);
		}
	}
}