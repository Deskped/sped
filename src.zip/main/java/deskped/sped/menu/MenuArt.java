package deskped.sped.menu;

import net.minecraft.client.gui.GuiGraphics;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class MenuArt {

	public static final int SKY_TOP = 0xFF07090F;
	public static final int SKY_MID = 0xFF1C1A22;
	public static final int SKY_HAZE = 0xFF4A2A18;
	public static final int SKY_LOW = 0xFF9C3F10;

	public static final int GROUND = 0xFF191512;
	public static final int GROUND_DARK = 0xFF0D0B09;
	public static final int GROUND_EDGE = 0xFF2B231C;

	public static final int RUBBLE_A = 0xFF3A342E;
	public static final int RUBBLE_B = 0xFF2B2620;
	public static final int RUBBLE_C = 0xFF4A403A;
	public static final int RUBBLE_D = 0xFF1E1A16;

	public static final int FIRE_CORE = 0xFFFFF2C0;
	public static final int FIRE = 0xFFFF9A22;
	public static final int FIRE_DEEP = 0xFFE0400A;
	public static final int EMBER = 0xFFFF7A18;
	public static final int SMOKE = 0xFF2A2622;
	public static final int SMOKE_LIT = 0xFF6B4028;
	public static final int ASH = 0xFF6E655C;

	public static final int TNT_RED = 0xFFB4342A;
	public static final int TNT_DARK = 0xFF7A1F16;
	public static final int TNT_BAND = 0xFFE8E4DC;
	public static final int OUTLINE = 0xFF0A0806;

	private MenuArt() {
	}

	public static float backOut(float t) {
		float p = t - 1.0f;
		return 1.0f + 2.70158f * p * p * p + 1.70158f * p * p;
	}

	public static float clamp01(float v) {
		return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
	}

	public static int alpha(int color, float a) {
		int aa = (int) (clamp01(a) * ((color >>> 24) & 255));
		return (aa << 24) | (color & 0x00FFFFFF);
	}

	public static int lerpColor(int a, int b, float t) {
		t = clamp01(t);
		int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
		int rr = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
		int gg = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
		int bb = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
		return (aa << 24) | (rr << 16) | (gg << 8) | bb;
	}

	public static void circle(GuiGraphics g, int cx, int cy, int r, int color) {
		if (r <= 0)
			return;
		for (int dy = -r; dy <= r; dy++) {
			int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
			g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
		}
	}

	public static void ring(GuiGraphics g, int cx, int cy, int outer, int inner, int color) {
		if (outer <= 0)
			return;
		for (int dy = -outer; dy <= outer; dy++) {
			int dxo = (int) Math.round(Math.sqrt(Math.max(0, outer * outer - dy * dy)));
			int dxi = Math.abs(dy) <= inner ? (int) Math.round(Math.sqrt(Math.max(0, inner * inner - dy * dy))) : -1;
			if (dxi < 0) {
				g.fill(cx - dxo, cy + dy, cx + dxo + 1, cy + dy + 1, color);
			} else {
				g.fill(cx - dxo, cy + dy, cx - dxi, cy + dy + 1, color);
				g.fill(cx + dxi + 1, cy + dy, cx + dxo + 1, cy + dy + 1, color);
			}
		}
	}

	public static void ellipse(GuiGraphics g, int cx, int cy, int rx, int ry, int color) {
		if (rx <= 0 || ry <= 0)
			return;
		for (int dy = -ry; dy <= ry; dy++) {
			double k = 1.0D - (double) (dy * dy) / (double) (ry * ry);
			if (k < 0.0D)
				continue;
			int dx = (int) Math.round(rx * Math.sqrt(k));
			g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
		}
	}

	public static void voxel(GuiGraphics g, int x, int y, int w, int h, int face, int dark, float glow) {
		g.fill(x, y, x + w, y + h, dark);
		g.fill(x, y, x + w - 1, y + h - 1, face);
		g.fill(x, y, x + w - 1, y + 1, lerpColor(face, 0xFFFFFFFF, 0.16f));
		if (glow > 0.01f)
			g.fill(x, y, x + w, y + h, alpha(FIRE_DEEP, glow * 0.55f));
	}

	public static final net.minecraft.resources.ResourceLocation T_TNT_SIDE = mc("block/tnt_side");
	public static final net.minecraft.resources.ResourceLocation T_DIRT = mc("block/dirt");
	public static final net.minecraft.resources.ResourceLocation T_GRASS_SIDE = mc("block/grass_block_side");
	public static final net.minecraft.resources.ResourceLocation T_STONE = mc("block/stone");
	public static final net.minecraft.resources.ResourceLocation T_SNOW = mc("block/snow");
	public static final net.minecraft.resources.ResourceLocation T_FIRE = mc("block/fire_0");

	public static final net.minecraft.resources.ResourceLocation[] RUBBLE = {
			mc("block/cobblestone"), mc("block/stone_bricks"), mc("block/oak_planks"),
			mc("block/bricks"), mc("block/mossy_cobblestone"), mc("block/andesite"),
			mc("block/oak_log"), mc("block/iron_block"),
			mc("block/gravel"), mc("block/cracked_stone_bricks"), mc("block/spruce_planks")};

	private static net.minecraft.resources.ResourceLocation mc(String path) {
		return new net.minecraft.resources.ResourceLocation("minecraft", "textures/" + path + ".png");
	}

	public static void tile(GuiGraphics g, net.minecraft.resources.ResourceLocation tex, int x, int y, int w, int h) {
		tile(g, tex, x, y, w, h, 1.0f, 1.0f, 1.0f, 1.0f);
	}

	public static void tile(GuiGraphics g, net.minecraft.resources.ResourceLocation tex, int x, int y, int w, int h,
			float r, float gr, float b, float a) {
		com.mojang.blaze3d.systems.RenderSystem.enableBlend();
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(r, gr, b, a);
		g.blit(tex, x, y, w, h, 0.0f, 0.0f, 16, 16, 16, 16);
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}


	public static final int SKY_VANILLA_TOP = 0xFF6A9BF4;
	public static final int SKY_VANILLA_MID = 0xFF87B9FF;
	public static final int SKY_VANILLA_LOW = 0xFFC5DDFF;

	public static final int BOOM_A = 0xFFF4F4F4;
	public static final int BOOM_B = 0xFFCFCFCF;
	public static final int BOOM_C = 0xFF9A9A9A;
	public static final int BOOM_D = 0xFF6E6E6E;


	public static void sprite(GuiGraphics g, net.minecraft.resources.ResourceLocation tex, int x, int y, int w, int h, int src, float a) {
		com.mojang.blaze3d.systems.RenderSystem.enableBlend();
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, a);
		g.blit(tex, x, y, w, h, 0.0f, 0.0f, src, src, src, src);
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}


	public static final net.minecraft.resources.ResourceLocation T_PLANET =
			new net.minecraft.resources.ResourceLocation("sped", "textures/environment/your_planet.png");

	public static final net.minecraft.resources.ResourceLocation[] PARTICLE = {
			mc("particle/generic_0"), mc("particle/generic_1"), mc("particle/generic_2"), mc("particle/generic_3"),
			mc("particle/generic_4"), mc("particle/generic_5"), mc("particle/generic_6"), mc("particle/generic_7")};

	public static final int CLOUD_TOP = 0xFFFFFFFF;
	public static final int CLOUD_FRONT = 0xFFE6E6E6;
	public static final int CLOUD_SIDE = 0xFFCCCCCC;
	public static final int CLOUD_BOTTOM = 0xFFB3B3B3;

	public static void particle(GuiGraphics g, net.minecraft.resources.ResourceLocation tex, int cx, int cy, int size, float a) {
		com.mojang.blaze3d.systems.RenderSystem.enableBlend();
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, clamp01(a));
		g.blit(tex, cx - size / 2, cy - size / 2, size, size, 0.0f, 0.0f, 8, 8, 8, 8);
		com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}


	public static final int LOGO_FRAMES = 40;
	public static final long LOGO_FRAME_MS = 50L;
	public static final net.minecraft.resources.ResourceLocation[] LOGO = new net.minecraft.resources.ResourceLocation[LOGO_FRAMES];

	static {
		for (int i = 0; i < LOGO_FRAMES; i++)
			LOGO[i] = new net.minecraft.resources.ResourceLocation("sped",
					String.format("textures/gui/menu/logo/frame_%02d.png", i));
	}

	public static final float BPM = 155.0f;
	public static final float BEAT_MS = 60000.0f / BPM;

	public static float beat(long now, long origin) {
		float f = ((now - origin) % (long) BEAT_MS) / BEAT_MS;
		float d = 1.0f - f;
		return d * d * d;
	}


	public static final net.minecraft.resources.ResourceLocation[] SHAFT = {
			mc("block/stone"), mc("block/stone"), mc("block/stone"), mc("block/stone"),
			mc("block/cobblestone"), mc("block/andesite"), mc("block/stone"), mc("block/cobblestone")};

}