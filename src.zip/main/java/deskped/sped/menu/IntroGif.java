package deskped.sped.menu;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class IntroGif {

	private static final int TEX_W = 512;
	private static final int TEX_H = 288;

	private static final int SRC_W = 1280;
	private static final int SRC_H = 720;

	private static final long FRAME_MS = 60L;
	private static final int SAMPLES = 167;
	private static final int UNIQUE = 130;

	public static final long DURATION_MS = SAMPLES * FRAME_MS;

	private static final float LOGO_X0 = 436f;
	private static final float LOGO_Y0 = 240f;
	private static final float LOGO_X1 = 882f;
	private static final float LOGO_Y1 = 489f;

	private static final int[] TIMELINE = {
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
			11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
			31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
			51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
			71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
			91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110,
			111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 129,
			129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129,
			129, 129, 129, 129, 129, 129, 129
	};

	private static final ResourceLocation[] FRAMES = new ResourceLocation[UNIQUE];

	static {
		for (int i = 0; i < UNIQUE; i++)
			FRAMES[i] = new ResourceLocation("sped", String.format("textures/gui/intro_logo/frame_%03d.png", i));
	}

	private IntroGif() {
	}

	private static float scale(int sw, int sh) {
		return Math.min(sw / (float) SRC_W, sh / (float) SRC_H);
	}

	public static void draw(GuiGraphics g, int sw, int sh, long t, float offsetY, float alpha) {
		if (alpha <= 0.004f)
			return;
		int sample = (int) (t / FRAME_MS);
		if (sample < 0)
			sample = 0;
		if (sample >= SAMPLES)
			sample = SAMPLES - 1;
		float sc = scale(sw, sh);
		float dw = SRC_W * sc;
		float dh = SRC_H * sc;
		float x = (sw - dw) * 0.5f;
		float y = (sh - dh) * 0.5f + offsetY;
		RenderSystem.enableBlend();
		RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
		g.pose().pushPose();
		g.pose().translate(x, y, 0.0f);
		g.pose().scale(dw / TEX_W, dh / TEX_H, 1.0f);
		g.blit(FRAMES[TIMELINE[sample]], 0, 0, 0, 0, TEX_W, TEX_H, TEX_W, TEX_H);
		g.pose().popPose();
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	public static int logoX(int sw, int sh) {
		float sc = scale(sw, sh);
		return Math.round((sw - SRC_W * sc) * 0.5f + LOGO_X0 * sc);
	}

	public static int logoY(int sw, int sh, float offsetY) {
		float sc = scale(sw, sh);
		return Math.round((sh - SRC_H * sc) * 0.5f + LOGO_Y0 * sc + offsetY);
	}

	public static int logoW(int sw, int sh) {
		return Math.round((LOGO_X1 - LOGO_X0) * scale(sw, sh));
	}

	public static int logoH(int sw, int sh) {
		return Math.round((LOGO_Y1 - LOGO_Y0) * scale(sw, sh));
	}

	public static void release() {
		try {
			for (ResourceLocation frame : FRAMES)
				Minecraft.getInstance().getTextureManager().release(frame);
		} catch (Throwable ignored) {
		}
	}
}
