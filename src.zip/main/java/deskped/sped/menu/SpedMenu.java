package deskped.sped.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import deskped.sped.SpedMod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Random;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = SpedMod.MODID)
@OnlyIn(Dist.CLIENT)
public class SpedMenu {

	static final String SERVER = "mc.deskped.ru";
	static final String DISCORD = "https://discord.gg/bEZuhpz6ph";

	private static final ResourceLocation LOGO_A = new ResourceLocation("sped", "textures/gui/menu/deskpedlogo.png");
	private static final ResourceLocation LOGO_B = new ResourceLocation("sped", "textures/gui/menu/deskpedforlogo.png");

	private static final int LOGO_W = 128;
	private static final int LOGO_H = 72;
	private static final int SPED_SRC_W = 330;
	private static final int SPED_SRC_H = 275;
	private static final int BTN_SRC_W = 700;
	private static final int BTN_SRC_H = 200;

	private static final long INTRO_END_MS = 11000L;
	private static final long INTRO_DROP_MS = INTRO_END_MS - IntroGif.DURATION_MS;

	private static final Random RNG = new Random();

	public static boolean customMenu = true;
	public static boolean confirmed = false;

	private static StreamingMenuSound customMusic;
	private static boolean musicWanted;
	private static long lastNuke;
	private static long musicStart;

	private static boolean introShown;
	private static boolean introActive;
	private static long introStart;

	private static int cachedW;
	private static int cachedH;
	private static long sceneStart;

	private static int logoX;
	private static int logoY;
	private static int logoW;
	private static int logoH;

	private static float farScroll;
	private static float midScroll;
	private static float cloudScroll;
	private static float farCloudScroll;
	private static float deepCloudScroll;
	private static float bigScroll;

	private static int introLogoX, introLogoY, introLogoW, introLogoH;
	private static int cornerX, cornerY;

	private static class Debris {
		float x, y, vx, vy, rot, vrot;
		ResourceLocation tex;
	}

	private static final Debris[] debris = new Debris[14];

	private static class Streak {
		float x, y, vx, alpha;
		int size, sprite;
	}

	private static final Streak[] streaks = new Streak[46];

	@SubscribeEvent
	public static void onScreenInit(ScreenEvent.Init.Post event) {
		if (!(event.getScreen() instanceof TitleScreen))
			return;
		Screen screen = event.getScreen();
		Minecraft mc = Minecraft.getInstance();

		if (!customMenu) {
			stopMusic();
			musicWanted = false;
			event.addListener(Button.builder(Component.literal("SPED"), b -> {
				customMenu = true;
				mc.setScreen(new TitleScreen());
			}).bounds(screen.width / 2 - 40, screen.height - 24, 80, 20).build());
			return;
		}

		new ArrayList<>(event.getListenersList()).forEach(o -> {
			if (o instanceof Button b)
				event.removeListener(b);
		});

		if (!musicWanted) {
			musicWanted = true;
			nukeMusic();
			startMusic();
		}

		if (cachedW != screen.width || cachedH != screen.height) {
			MenuChaos.build(screen.width, screen.height);
			cachedW = screen.width;
			cachedH = screen.height;
		}
		sceneStart = System.currentTimeMillis();

		if (!introShown) {
			introShown = true;
			introActive = true;
			introStart = System.currentTimeMillis();
		}

		boolean ru = mc.options.languageCode.startsWith("ru");
		String[] keys = {"play", "options", "back", "exit"};
		int gap = 2;
		int margin = 6;
		int pad = 4;
		int avail = screen.height - margin * 2;

		int logoBudget = (int) (avail * 0.55f);
		logoW = Math.min(600, Math.min(screen.width - 16, logoBudget * SPED_SRC_W / SPED_SRC_H));
		logoH = logoW * SPED_SRC_H / SPED_SRC_W;

		int block = Math.min(avail - logoH - pad, 4 * 56 + 3 * gap);
		int bh = Math.max(16, Math.min(56, (block - 3 * gap) / 4));
		int bw = bh * BTN_SRC_W / BTN_SRC_H;
		block = bh * 4 + gap * 3;

		int total = logoH + pad + block;
		int top = margin + Math.max(0, (avail - total) / 2);

		logoX = screen.width / 2 - logoW / 2;
		logoY = top;
		int btnTop = top + logoH + pad;

		for (int i = 0; i < keys.length; i++) {
			int idx = i;
			String name = ru ? keys[i] + "_ru" : keys[i];
			ResourceLocation tex = new ResourceLocation("sped", "textures/gui/menu/btn/" + name + ".png");
			int by = btnTop + i * (bh + gap);
			event.addListener(new ImageButton(screen.width / 2 - bw / 2, by, bw, bh, BTN_SRC_W, BTN_SRC_H, tex,
					80L * i + 200L, b -> click(idx, screen, mc, ru)));
		}
	}

	private static void click(int index, Screen screen, Minecraft mc, boolean ru) {
		switch (index) {
			case 0 -> {
				if (confirmed)
					connect(screen, mc);
				else
					mc.setScreen(new net.minecraft.client.gui.screens.ConfirmScreen(yes -> {
						if (yes) {
							confirmed = true;
							connect(screen, mc);
						} else {
							mc.setScreen(screen);
						}
					}, Component.literal(ru ? "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u043a \u0441\u0435\u0440\u0432\u0435\u0440\u0443?" : "Join the server?"),
							Component.literal(SERVER)));
			}
			case 1 -> mc.setScreen(new OptionsScreen(screen, mc.options));
			case 2 -> {
				customMenu = false;
				stopMusic();
				musicWanted = false;
				mc.setScreen(new TitleScreen());
			}
			default -> mc.stop();
		}
	}

	public static void setCustomMenu(boolean value) {
		customMenu = value;
		if (!value) {
			stopMusic();
			musicWanted = false;
		}
	}

	public static float beat() {
		return MenuArt.beat(System.currentTimeMillis(), musicStart);
	}

	static void connect(Screen from, Minecraft mc) {
		stopMusic();
		musicWanted = false;
		ServerData sd = new ServerData("SPED", SERVER, false);
		ConnectScreen.startConnecting(from, mc, ServerAddress.parseString(SERVER), sd, false);
	}

	private static void startMusic() {
		try {
			SoundManager sm = Minecraft.getInstance().getSoundManager();
			if (customMusic != null) {
				sm.stop(customMusic);
				customMusic = null;
			}
			customMusic = new StreamingMenuSound(new ResourceLocation("sped", "menu"));
			sm.play(customMusic);
			musicStart = System.currentTimeMillis();
		} catch (Exception ignored) {
		}
	}

	private static void stopMusic() {
		if (customMusic != null) {
			Minecraft.getInstance().getSoundManager().stop(customMusic);
			customMusic = null;
		}
	}

	private static void nukeMusic() {
		try {
			Minecraft mc = Minecraft.getInstance();
			mc.getMusicManager().stopPlaying();
			for (SoundSource src : SoundSource.values())
				if (src != SoundSource.MASTER)
					mc.getSoundManager().stop(null, src);
		} catch (Exception ignored) {
		}
	}

	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void onRenderPre(ScreenEvent.Render.Pre event) {
		if (!(event.getScreen() instanceof TitleScreen))
			return;
		if (!customMenu)
			return;
		event.setCanceled(true);

		Screen screen = event.getScreen();
		GuiGraphics g = event.getGuiGraphics();
		int mx = event.getMouseX();
		int my = event.getMouseY();
		float partial = event.getPartialTick();
		long now = System.currentTimeMillis();
		int w = screen.width;
		int h = screen.height;

		if (now - lastNuke > 600L) {
			lastNuke = now;
			nukeMusic();
		}

		if (introActive) {
			renderIntro(g, screen, now);
			return;
		}

		MenuChaos.update(w, h, now);
		drawWorld(g, w, h, now);

		float shake = MenuChaos.shake();
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(shake * (RNG.nextFloat() - 0.5f) * 3.0f, shake * (RNG.nextFloat() - 0.5f) * 3.0f, 0.0f);
		drawSpedLogo(g, now);
		for (Renderable r : screen.renderables)
			r.render(g, mx, my, partial);
		pose.popPose();

		drawCornerLogos(g, w, h);
	}

	private static void drawWorld(GuiGraphics g, int w, int h, long now) {
		PoseStack pose = g.pose();
		float scale = MenuChaos.camScale();
		float shake = MenuChaos.shake();
		pose.pushPose();
		pose.translate(w / 2.0f, h / 2.0f, 0.0f);
		pose.translate(shake * (RNG.nextFloat() - 0.5f) * 9.0f, shake * (RNG.nextFloat() - 0.5f) * 9.0f, 0.0f);
		pose.scale(scale, scale, 1.0f);
		pose.translate(-MenuChaos.camFocusX(), -MenuChaos.camFocusY(), 0.0f);

		drawSky(g, w, h);
		deepCloudScroll -= 1.8f;
		drawCloudLayer(g, w, h, deepCloudScroll, (int) (h * 0.04f), 0.14f, 2);
		drawPlanet(g, w, h, now);
		bigScroll -= 1.0f;
		drawBigMountains(g, w, h, bigScroll);
		drawFlyingBlocks(g, w, h, now);
		farCloudScroll -= 3.4f;
		cloudScroll -= 6.8f;
		drawCloudLayer(g, w, h, farCloudScroll, (int) (h * 0.08f), 0.30f, 2);
		drawCloudLayer(g, w, h, cloudScroll, (int) (h * 0.18f), 0.85f, 3);
		farScroll -= 1.8f;
		midScroll -= 3.4f;
		drawMountains(g, w, h, farScroll, (int) (h * 0.50f), 46, 0.62f, MenuArt.T_STONE, null);
		drawMountains(g, w, h, midScroll, (int) (h * 0.64f), 30, 0.82f, MenuArt.T_DIRT, MenuArt.T_GRASS_SIDE);
		drawBedrockBase(g, w, h);
		MenuChaos.render(g, now);
		drawStreaks(g, w, h, now);
		pose.popPose();
	}

	private static void drawSky(GuiGraphics g, int w, int h) {
		int pad = w;
		g.fillGradient(-pad, -h, w + pad, (int) (h * 0.55f), MenuArt.SKY_VANILLA_TOP, MenuArt.SKY_VANILLA_MID);
		g.fillGradient(-pad, (int) (h * 0.55f), w + pad, h * 2, MenuArt.SKY_VANILLA_MID, MenuArt.SKY_VANILLA_LOW);
	}


	private static void drawMountains(GuiGraphics g, int w, int h, float scroll, int base, int amp, float shade,
			net.minecraft.resources.ResourceLocation body, net.minecraft.resources.ResourceLocation top) {
		int step = 16;
		int off = Math.floorMod((int) scroll, step);
		for (int sx = -step * 2 - off; sx < w + step * 2; sx += step) {
			int world = sx - (int) scroll;
			double n = Math.sin(world * 0.010D) * 0.6D + Math.sin(world * 0.023D) * 0.3D + Math.sin(world * 0.005D) * 0.9D;
			int colTop = base - (int) (n * amp);
			colTop = (colTop / step) * step;
			if (top != null)
				MenuArt.tile(g, top, sx, colTop, step, step, shade, shade, shade, 1.0f);
			int start = top != null ? colTop + step : colTop;
			for (int y = start; y < h + step; y += step)
				MenuArt.tile(g, body, sx, y, step, step, shade, shade, shade, 1.0f);
		}
	}

	private static void drawBedrockBase(GuiGraphics g, int w, int h) {
		int y0 = MenuChaos.groundTop() + 48;
		for (int x = -32; x < w + 32; x += 16)
			for (int y = y0; y < h + 16; y += 16)
				MenuArt.tile(g, MenuArt.T_STONE, x, y, 16, 16, 0.75f, 0.75f, 0.75f, 1.0f);
	}

	private static void drawSpedLogo(GuiGraphics g, long now) {
		if (logoH <= 0)
			return;
		float t = MenuArt.clamp01((now - sceneStart) / 560.0f);
		float enter = MenuArt.backOut(t);
		float pulse = 1.0f + beat() * 0.06f;
		int frame = (int) ((now / MenuArt.LOGO_FRAME_MS) % MenuArt.LOGO_FRAMES);
		int cx = logoX + logoW / 2;
		int cy = (int) (logoY + logoH / 2 + (1.0f - enter) * -160.0f);
		RenderSystem.enableBlend();
		RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, enter);
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(cx, cy, 0.0f);
		pose.scale(pulse * logoW / (float) SPED_SRC_W, pulse * logoH / (float) SPED_SRC_H, 1.0f);
		pose.translate(-SPED_SRC_W * 0.5f, -SPED_SRC_H * 0.5f, 0.0f);
		g.blit(MenuArt.LOGO[frame], 0, 0, 0, 0, SPED_SRC_W, SPED_SRC_H, SPED_SRC_W, SPED_SRC_H);
		pose.popPose();
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	private static void drawCornerLogos(GuiGraphics g, int w, int h) {
		float pulse = 1.0f + beat() * 0.09f;
		cornerX = w - LOGO_W - 10;
		cornerY = h - LOGO_H - 10;
		int cx = cornerX + LOGO_W / 2;
		int cy = cornerY + LOGO_H / 2;
		RenderSystem.enableBlend();
		RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(cx, cy, 0.0f);
		pose.scale(pulse, pulse, 1.0f);
		pose.translate(-LOGO_W * 0.5f, -LOGO_H * 0.5f, 0.0f);
		g.blit(LOGO_A, 0, 0, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);
		g.blit(LOGO_B, 0, 0, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);
		pose.popPose();
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	private static void drawStoneShaft(GuiGraphics g, int w, int h, float camY) {
		int step = 16;
		int base = (int) -camY;
		int off = Math.floorMod(base, step);
		for (int sy = -step + off; sy < h + step; sy += step) {
			int tileY = Math.floorDiv(sy - base, step);
			for (int sx = 0; sx < w + step; sx += step) {
				int tileX = sx / step;
				int hash = (tileX * 73856093) ^ (tileY * 19349663);
				net.minecraft.resources.ResourceLocation tex = MenuArt.SHAFT[Math.floorMod(hash, MenuArt.SHAFT.length)];
				float sh = 0.44f + Math.floorMod(hash / 64, 5) * 0.035f;
				MenuArt.tile(g, tex, sx, sy, step, step, sh, sh, sh * 1.05f, 1.0f);
			}
		}
		g.fillGradient(0, 0, w, h / 4, 0x99000000, 0x00000000);
		g.fillGradient(0, h - h / 4, w, h, 0x00000000, 0x99000000);
	}

	private static void renderIntro(GuiGraphics g, Screen screen, long now) {
		long t = now - introStart;
		if (t >= INTRO_END_MS) {
			introActive = false;
			sceneStart = now;
			IntroGif.release();
			return;
		}
		int w = screen.width;
		int h = screen.height;

		float p = MenuArt.clamp01(t / (float) INTRO_END_MS);
		float travelled;
		if (p < 0.76f) {
			travelled = (p / 0.76f) * 0.86f;
		} else {
			float q = (p - 0.76f) / 0.24f;
			float inv = 1.0f - q;
			travelled = 0.86f + 0.14f * (1.0f - inv * inv * inv);
		}
		float camY = h * 16.0f * (1.0f - travelled);

		drawStoneShaft(g, w, h, camY);

		int reveal = (int) (h - camY);
		if (reveal > 0) {
			MenuChaos.update(w, h, now);
			g.enableScissor(0, 0, w, Math.min(h, reveal));
			PoseStack world = g.pose();
			world.pushPose();
			world.translate(0.0f, -camY, 0.0f);
			drawWorld(g, w, h, now);
			world.popPose();
			g.disableScissor();
		}

		float drop = 0.0f;
		if (t > IntroGif.DURATION_MS && INTRO_DROP_MS > 0L) {
			float q = MenuArt.clamp01((t - IntroGif.DURATION_MS) / (float) INTRO_DROP_MS);
			drop = q * q * (h + h * 0.35f);
		}

		IntroGif.draw(g, w, h, t, drop, 1.0f);

		introLogoX = IntroGif.logoX(w, h);
		introLogoY = IntroGif.logoY(w, h, drop);
		introLogoW = IntroGif.logoW(w, h);
		introLogoH = IntroGif.logoH(w, h);
	}

	private static void blitLogo(GuiGraphics g, ResourceLocation tex, float x, float y, float spin, float alpha) {
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(x, y, 0.0f);
		pose.scale(2.0f, 2.0f, 1.0f);
		pose.mulPose(Axis.ZP.rotationDegrees(spin));
		pose.translate(-LOGO_W * 0.5f, -LOGO_H * 0.5f, 0.0f);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
		g.blit(tex, 0, 0, 0, 0, LOGO_W, LOGO_H, LOGO_W, LOGO_H);
		pose.popPose();
	}

	private static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	private static void openDiscord() {
		try {
			net.minecraft.Util.getPlatform().openUri(DISCORD);
		} catch (Exception ignored) {
		}
	}

	@SubscribeEvent
	public static void onClick(ScreenEvent.MouseButtonPressed.Pre event) {
		if (!(event.getScreen() instanceof TitleScreen))
			return;
		if (!customMenu)
			return;
		double mx = event.getMouseX();
		double my = event.getMouseY();
		if (introActive) {
			if (inside(mx, my, introLogoX, introLogoY, introLogoW, introLogoH)) {
				openDiscord();
				event.setCanceled(true);
				return;
			}
			introActive = false;
			sceneStart = System.currentTimeMillis();
			IntroGif.release();
			event.setCanceled(true);
			return;
		}
		if (inside(mx, my, cornerX, cornerY, LOGO_W, LOGO_H)) {
			openDiscord();
			event.setCanceled(true);
		}
	}

	private static void drawPlanet(GuiGraphics g, int w, int h, long now) {
		int size = (int) (Math.max(w, h) * 0.95f);
		float spin = (now % 360000L) / 340.0f;
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(w * 0.70f, h * 0.04f, 0.0f);
		pose.mulPose(Axis.ZP.rotationDegrees(spin));
		RenderSystem.enableBlend();
		RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 0.38f);
		g.blit(MenuArt.T_PLANET, -size / 2, -size / 2, size, size, 0.0f, 0.0f, 256, 256, 256, 256);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
		pose.popPose();
	}

	private static void drawCloudLayer(GuiGraphics g, int w, int h, float scroll, int band, float alpha, int count) {
		int period = w + 260;
		for (int i = 0; i < count * 3; i++) {
			int seed = i * 97 + count * 31;
			int cw = 56 + (seed % 5) * 26;
			int ch = 12 + (seed % 3) * 6;
			int depth = 8 + (seed % 4) * 5;
			float raw = (seed * 53.0f + scroll) % period;
			int x = (int) ((raw + period) % period) - 160;
			int y = band + (seed % 7) * 10;
			g.fill(x + depth, y - depth, x + cw + depth, y + ch - depth, MenuArt.alpha(MenuArt.CLOUD_TOP, alpha));
			g.fill(x, y, x + cw, y + ch, MenuArt.alpha(MenuArt.CLOUD_FRONT, alpha));
			for (int d = 0; d < depth; d++)
				g.fill(x + cw + d, y - d, x + cw + d + 1, y + ch - d, MenuArt.alpha(MenuArt.CLOUD_SIDE, alpha));
			g.fill(x, y + ch - 2, x + cw, y + ch, MenuArt.alpha(MenuArt.CLOUD_BOTTOM, alpha));
		}
	}

	private static void drawFlyingBlocks(GuiGraphics g, int w, int h, long now) {
		if (debris[0] == null)
			for (int i = 0; i < debris.length; i++)
				debris[i] = spawnDebris(w, h, true);
		PoseStack pose = g.pose();
		for (int i = 0; i < debris.length; i++) {
			Debris d = debris[i];
			d.vy += 0.07f;
			d.x += d.vx;
			d.y += d.vy;
			d.rot += d.vrot;
			if (d.x < -40.0f || d.y > h * 0.62f) {
				debris[i] = spawnDebris(w, h, false);
				continue;
			}
			pose.pushPose();
			pose.translate(d.x, d.y, 0.0f);
			pose.mulPose(Axis.ZP.rotationDegrees(d.rot));
			MenuArt.tile(g, d.tex, -8, -8, 16, 16, 0.72f, 0.72f, 0.78f, 1.0f);
			pose.popPose();
		}
	}

	private static Debris spawnDebris(int w, int h, boolean anywhere) {
		Debris d = new Debris();
		d.x = anywhere ? RNG.nextFloat() * w : w + 20.0f + RNG.nextFloat() * 120.0f;
		d.y = anywhere ? RNG.nextFloat() * h * 0.35f : -40.0f - RNG.nextFloat() * 60.0f;
		d.vx = -7.5f - RNG.nextFloat() * 5.0f;
		d.vy = 0.2f + RNG.nextFloat() * 1.2f;
		d.rot = RNG.nextInt(360);
		d.vrot = -9.0f + RNG.nextFloat() * 18.0f;
		d.tex = MenuArt.RUBBLE[RNG.nextInt(MenuArt.RUBBLE.length)];
		return d;
	}

	private static void drawStreaks(GuiGraphics g, int w, int h, long now) {
		if (streaks[0] == null)
			for (int i = 0; i < streaks.length; i++)
				streaks[i] = spawnStreak(w, h, true);
		for (int i = 0; i < streaks.length; i++) {
			Streak k = streaks[i];
			k.x += k.vx;
			if (k.x < -30.0f) {
				streaks[i] = spawnStreak(w, h, false);
				continue;
			}
			MenuArt.particle(g, MenuArt.PARTICLE[k.sprite], (int) k.x, (int) k.y, k.size, k.alpha);
		}
	}

	private static Streak spawnStreak(int w, int h, boolean anywhere) {
		Streak k = new Streak();
		k.x = anywhere ? RNG.nextFloat() * w : w + 10.0f + RNG.nextFloat() * 90.0f;
		k.y = RNG.nextFloat() * h;
		k.vx = -13.0f - RNG.nextFloat() * 16.0f;
		k.size = 4 + RNG.nextInt(6);
		k.alpha = 0.25f + RNG.nextFloat() * 0.45f;
		k.sprite = RNG.nextInt(MenuArt.PARTICLE.length);
		return k;
	}

	private static void drawBigMountains(GuiGraphics g, int w, int h, float scroll) {
		int step = 16;
		int base = (int) (h * 0.72f);
		int off = Math.floorMod((int) scroll, step);
		for (int sx = -step * 2 - off; sx < w + step * 2; sx += step) {
			int world = sx - (int) scroll;
			double n = Math.sin(world * 0.0042D) * 1.05D + Math.sin(world * 0.0115D) * 0.45D
					+ Math.sin(world * 0.0026D) * 0.75D;
			int colTop = base - (int) (n * 108.0D);
			colTop = (colTop / step) * step;
			int snowRows = 2 + (Math.floorMod(world, 5) == 0 ? 1 : 0);
			for (int r = 0; r < snowRows; r++)
				MenuArt.tile(g, MenuArt.T_SNOW, sx, colTop + r * step, step, step, 0.72f, 0.75f, 0.82f, 1.0f);
			for (int y = colTop + snowRows * step; y < h + step; y += step)
				MenuArt.tile(g, MenuArt.T_STONE, sx, y, step, step, 0.46f, 0.48f, 0.56f, 1.0f);
		}
	}
}