package deskped.sped.menu;

import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class StreamingMenuSound extends AbstractSoundInstance {

	public StreamingMenuSound(ResourceLocation location) {
		super(location, SoundSource.MASTER, SoundInstance.createUnseededRandom());
		this.looping = true;
		this.delay = 0;
		this.volume = 1.0f;
		this.pitch = 1.0f;
		this.x = 0.0D;
		this.y = 0.0D;
		this.z = 0.0D;
		this.attenuation = Attenuation.NONE;
	}

	@Override
	public boolean canPlaySound() {
		return true;
	}

	@Override
	public boolean canStartSilent() {
		return true;
	}
}
