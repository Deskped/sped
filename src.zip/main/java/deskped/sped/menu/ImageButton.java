package deskped.sped.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Consumer;

@OnlyIn(Dist.CLIENT)
public class ImageButton extends AbstractButton {

	public final ResourceLocation tex;
	public final int srcW;
	public final int srcH;

	private final Consumer<ImageButton> onPress;
	private final long delay;
	private final long bornAt;

	private float hover;
	private float scale = 1.0f;

	public ImageButton(int x, int y, int w, int h, int srcW, int srcH, ResourceLocation tex, long delay, Consumer<ImageButton> onPress) {
		super(x, y, w, h, Component.empty());
		this.tex = tex;
		this.srcW = srcW;
		this.srcH = srcH;
		this.delay = delay;
		this.onPress = onPress;
		this.bornAt = System.currentTimeMillis();
	}

	@Override
	public void onPress() {
		onPress.accept(this);
	}

	@Override
	public void renderWidget(GuiGraphics g, int mx, int my, float partial) {
		long now = System.currentTimeMillis();
		float t = MenuArt.clamp01((now - bornAt - delay) / 360.0f);
		if (t <= 0.0f)
			return;
		float enter = MenuArt.backOut(t);
		float slide = (1.0f - enter) * -(width + 120);

		boolean hov = isHoveredOrFocused();
		hover = MenuArt.clamp01(hover + (hov ? 0.08f : -0.06f));
		float target = 1.0f + hover * 0.04f;
		scale += (target - scale) * 0.15f;

		float jolt = MenuChaos.shake() * 0.4f;
		float kick = jolt * (float) Math.sin(now / 33.0D) * 2.2f;
		float thump = SpedMenu.beat() * 0.05f;

		float bcx = getX() + width * 0.5f + slide + kick;
		float bcy = getY() + height * 0.5f;
		float sx = (float) width / srcW * (scale + thump);
		float sy = (float) height / srcH * (scale + thump);

		RenderSystem.enableBlend();
		RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, (0.85f + hover * 0.15f) * enter);
		PoseStack pose = g.pose();
		pose.pushPose();
		pose.translate(bcx, bcy, 0.0f);
		pose.scale(sx, sy, 1.0f);
		pose.translate(-srcW * 0.5f, -srcH * 0.5f, 0.0f);
		g.blit(tex, 0, 0, 0, 0, srcW, srcH, srcW, srcH);
		pose.popPose();
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput out) {
		this.defaultButtonNarrationText(out);
	}
}
