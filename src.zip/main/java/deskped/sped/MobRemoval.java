package deskped.sped;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class MobRemoval {

    private static boolean banned(EntityType<?> type) {
        return type == EntityType.PILLAGER || type == EntityType.VILLAGER || type == EntityType.ZOMBIE_VILLAGER;
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (banned(event.getEntity().getType())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        Entity entity = event.getEntity();
        if (!entity.level().isClientSide() && banned(entity.getType())) {
            entity.discard();
        }
    }
}