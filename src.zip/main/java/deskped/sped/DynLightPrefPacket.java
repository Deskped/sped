package deskped.sped;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DynLightPrefPacket {

    public final boolean enabled;

    public DynLightPrefPacket(boolean enabled) {
        this.enabled = enabled;
    }

    public static void encode(DynLightPrefPacket pkt, FriendlyByteBuf buf) {
        buf.writeBoolean(pkt.enabled);
    }

    public static DynLightPrefPacket decode(FriendlyByteBuf buf) {
        return new DynLightPrefPacket(buf.readBoolean());
    }

    public static void handle(DynLightPrefPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null)
                DynamicLight.setDisabled(player.getUUID(), !pkt.enabled);
        });
        ctx.get().setPacketHandled(true);
    }
}
