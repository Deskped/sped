package deskped.sped.capability;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class HeldBlockImpl implements IHeldBlock {

    private boolean holding = false;
    private BlockPos originPos = BlockPos.ZERO;
    private BlockState heldState = Blocks.AIR.defaultBlockState();
    private CompoundTag blockEntityData = null;
    private float rotationAngle = 0f;
    private int holdTick = 0;

    @Override
    public boolean isHolding() {
        return holding;
    }

    @Override
    public BlockPos getOriginPos() {
        return originPos;
    }

    @Override
    public BlockState getHeldState() {
        return heldState;
    }

    @Override
    public CompoundTag getBlockEntityData() {
        return blockEntityData;
    }

    @Override
    public float getRotationAngle() {
        return rotationAngle;
    }

    @Override
    public int getHoldTick() {
        return holdTick;
    }

    @Override
    public void setHeld(BlockPos pos, BlockState state, CompoundTag beData) {
        this.holding = true;
        this.originPos = pos;
        this.heldState = state;
        this.blockEntityData = beData;
        this.rotationAngle = 0f;
        this.holdTick = 0;
    }

    @Override
    public void clearHeld() {
        this.holding = false;
        this.originPos = BlockPos.ZERO;
        this.heldState = Blocks.AIR.defaultBlockState();
        this.blockEntityData = null;
        this.rotationAngle = 0f;
        this.holdTick = 0;
    }

    @Override
    public void tickRotation() {
        rotationAngle += 4.0f;
        if (rotationAngle >= 360f) rotationAngle -= 360f;
        holdTick++;
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("holding", holding);
        if (holding) {
            tag.put("originPos", NbtUtils.writeBlockPos(originPos));
            tag.put("heldState", NbtUtils.writeBlockState(heldState));
            if (blockEntityData != null) {
                tag.put("beData", blockEntityData);
            }
            tag.putFloat("rotation", rotationAngle);
            tag.putInt("holdTick", holdTick);
        }
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        holding = tag.getBoolean("holding");
        if (holding) {
            originPos = NbtUtils.readBlockPos(tag.getCompound("originPos"));
            heldState = NbtUtils.readBlockState(net.minecraft.core.registries.BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("heldState"));
            blockEntityData = tag.contains("beData") ? tag.getCompound("beData") : null;
            rotationAngle = tag.getFloat("rotation");
            holdTick = tag.getInt("holdTick");
        }
    }
}
