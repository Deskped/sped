package deskped.sped.capability;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.state.BlockState;

public interface IHeldBlock {
    boolean isHolding();
    BlockPos getOriginPos();
    BlockState getHeldState();
    CompoundTag getBlockEntityData();
    float getRotationAngle();
    int getHoldTick();

    void setHeld(BlockPos pos, BlockState state, CompoundTag beData);
    void clearHeld();
    void tickRotation();

    CompoundTag serializeNBT();
    void deserializeNBT(CompoundTag tag);
}
