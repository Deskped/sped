package deskped.sped;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class SpedClientConfig {

	public static final ForgeConfigSpec SPEC;
	private static final ForgeConfigSpec.BooleanValue CLAIM_HUD_V;
	private static final ForgeConfigSpec.BooleanValue CLAIM_BORDERS_V;
	private static final ForgeConfigSpec.BooleanValue CUSTOM_MENU_V;
	private static final ForgeConfigSpec.BooleanValue BLOCK_HUD_V;
	private static final ForgeConfigSpec.BooleanValue DYNAMIC_LIGHT_V;

	public static boolean CLAIM_HUD = true;
	public static boolean CLAIM_BORDERS = true;
	public static boolean CUSTOM_MENU = true;
	public static boolean BLOCK_HUD = true;
	public static boolean DYNAMIC_LIGHT = true;

	static {
		ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
		b.push("hud");
		CLAIM_HUD_V = b.define("claim_owner_hud", true);
		CLAIM_BORDERS_V = b.define("claim_borders", true);
		BLOCK_HUD_V = b.define("block_hud", true);
		DYNAMIC_LIGHT_V = b.define("dynamic_light", true);
		b.pop();
		b.push("menu");
		CUSTOM_MENU_V = b.define("custom_title_screen", true);
		b.pop();
		SPEC = b.build();
	}

	public static void register() {
		sanitize("sped-options.toml");
		ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SPEC, "sped-options.toml");
	}

	private static void sanitize(String name) {
		try {
			Path path = FMLPaths.CONFIGDIR.get().resolve(name);
			if (!Files.exists(path))
				return;
			if (Files.size(path) == 0) {
				Files.delete(path);
				return;
			}
			try (Reader reader = Files.newBufferedReader(path)) {
				new com.electronwill.nightconfig.toml.TomlParser().parse(reader);
			} catch (Throwable broken) {
				Files.deleteIfExists(path);
			}
		} catch (Throwable ignored) {
		}
	}

	public static void setCustomMenu(boolean v) {
		CUSTOM_MENU = v;
		CUSTOM_MENU_V.set(v);
		SPEC.save();
	}

	public static void setClaimHud(boolean v) {
		CLAIM_HUD = v;
		CLAIM_HUD_V.set(v);
		SPEC.save();
	}

	public static void setBlockHud(boolean v) {
		BLOCK_HUD = v;
		BLOCK_HUD_V.set(v);
		SPEC.save();
	}

	public static void setDynamicLight(boolean v) {
		DYNAMIC_LIGHT = v;
		DYNAMIC_LIGHT_V.set(v);
		SPEC.save();
	}

	public static void setClaimBorders(boolean v) {
		CLAIM_BORDERS = v;
		CLAIM_BORDERS_V.set(v);
		SPEC.save();
	}

	@SubscribeEvent
	public static void onLoad(ModConfigEvent event) {
		if (event.getConfig().getSpec() == SPEC) {
			CLAIM_HUD = CLAIM_HUD_V.get();
			CLAIM_BORDERS = CLAIM_BORDERS_V.get();
			CUSTOM_MENU = CUSTOM_MENU_V.get();
			BLOCK_HUD = BLOCK_HUD_V.get();
			DYNAMIC_LIGHT = DYNAMIC_LIGHT_V.get();
		}
	}
}