package deskped.sped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BlockNbtHudConfigScreen extends Screen {

    private final Screen parent;
    private Button toggleButton;

    public BlockNbtHudConfigScreen(Screen parent) {
        super(Component.literal("Sped"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        boolean enabled = BlockNbtHudConfig.ENABLED;

        String label = isRussian()
                ? ("Показ названия блока: " + (enabled ? "ВКЛ" : "ВЫКЛ"))
                : ("Block name display: " + (enabled ? "ON" : "OFF"));

        toggleButton = Button.builder(Component.literal(label), btn -> {
            boolean next = !BlockNbtHudConfig.ENABLED;
            BlockNbtHudConfig.setEnabled(next);
            String newLabel = isRussian()
                    ? ("Показ названия блока: " + (next ? "ВКЛ" : "ВЫКЛ"))
                    : ("Block name display: " + (next ? "ON" : "OFF"));
            btn.setMessage(Component.literal(newLabel));
        }).bounds(this.width / 2 - 100, this.height / 2 - 10, 200, 20).build();

        this.addRenderableWidget(toggleButton);

        String doneLabel = isRussian() ? "Готово" : "Done";
        this.addRenderableWidget(
            Button.builder(Component.literal(doneLabel), btn -> onClose())
                .bounds(this.width / 2 - 75, this.height / 2 + 20, 150, 20)
                .build()
        );
    }

    private static boolean isRussian() {
        String lang = Minecraft.getInstance().options.languageCode;
        return lang != null && lang.startsWith("ru");
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        String title = isRussian() ? "Настройки Sped" : "Sped Settings";
        graphics.drawCenteredString(this.font, title, this.width / 2, this.height / 2 - 40, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}