package deskped.sped.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SkinLang {

	private static boolean ru() {
		try {
			String lang = Minecraft.getInstance().getLanguageManager().getSelected();
			return lang != null && lang.startsWith("ru");
		} catch (Exception e) {
			return false;
		}
	}

	public static String buttonSkin() {
		return ru() ? "\u0421\u043c\u0435\u043d\u0438\u0442\u044c \u0441\u043a\u0438\u043d" : "Change skin";
	}

	public static String buttonCape() {
		return ru() ? "\u0421\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u043b\u0430\u0449" : "Change cape";
	}

	public static String titleSkin() {
		return ru() ? "\u0421\u041c\u0415\u041d\u0410 \u0421\u041a\u0418\u041d\u0410" : "CHANGE SKIN";
	}

	public static String titleCape() {
		return ru() ? "\u0421\u041c\u0415\u041d\u0410 \u041f\u041b\u0410\u0429\u0410" : "CHANGE CAPE";
	}

	public static String pick() {
		return ru() ? "\u0412\u044b\u0431\u0440\u0430\u0442\u044c PNG" : "Choose PNG";
	}

	public static String confirm() {
		return ru() ? "\u041f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044c" : "Confirm";
	}

	public static String reset() {
		return ru() ? "\u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c" : "Reset";
	}

	public static String modelWide() {
		return ru() ? "\u041c\u043e\u0434\u0435\u043b\u044c: \u0448\u0438\u0440\u043e\u043a\u0430\u044f" : "Model: classic";
	}

	public static String modelSlim() {
		return ru() ? "\u041c\u043e\u0434\u0435\u043b\u044c: \u0442\u043e\u043d\u043a\u0430\u044f" : "Model: slim";
	}

	public static String errRead() {
		return ru() ? "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u0444\u0430\u0439\u043b" : "Failed to read file";
	}

	public static String errSizeSkin() {
		return ru() ? "\u041d\u0443\u0436\u0435\u043d 64x64, 64x32 \u0438\u043b\u0438 HD \u043a\u0432\u0430\u0434\u0440\u0430\u0442" : "Needs 64x64, 64x32 or HD square";
	}

	public static String errSizeCape() {
		return ru() ? "\u041d\u0443\u0436\u0435\u043d 64x32 \u0438\u043b\u0438 HD 2:1" : "Needs 64x32 or HD 2:1";
	}

	public static String errHeavy() {
		return ru() ? "\u0424\u0430\u0439\u043b \u0441\u043b\u0438\u0448\u043a\u043e\u043c \u0431\u043e\u043b\u044c\u0448\u043e\u0439" : "File is too heavy";
	}

	public static String sent() {
		return ru() ? "\u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e" : "Saved";
	}

	public static String resetDone() {
		return ru() ? "\u0421\u0431\u0440\u043e\u0448\u0435\u043d\u043e" : "Reset done";
	}

	public static String hint() {
		return ru() ? "\u0424\u0430\u0439\u043b \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d" : "No file selected";
	}

	public static String dropHint() {
		return ru() ? "\u041c\u043e\u0436\u043d\u043e \u043f\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u044c PNG \u0432 \u043e\u043a\u043d\u043e" : "You can drag a PNG into the window";
	}

	public static String noCape() {
		return ru() ? "\u041f\u043b\u0430\u0449 \u043d\u0435 \u043d\u0430\u0434\u0435\u0442" : "No cape equipped";
	}
}
