package deskped.sped.client;

import com.mojang.math.Axis;

import net.minecraft.client.gui.GuiGraphics;

import java.util.Random;

public final class CosmicBg {

    private CosmicBg() {
    }

    private static int sw = -1;
    private static int sh = -1;
    private static Star[] stars = new Star[0];
    private static float[][] nebulae = new float[0][];
    private static float[][] constel = new float[0][];
    private static final Random RNG = new Random(48813571L);

    public static void render(GuiGraphics g, int w, int h, long now) {
        if (w != sw || h != sh) {
            build(w, h);
            sw = w;
            sh = h;
        }
        g.fillGradient(0, 0, w, h / 2, 0xFF06020F, 0xFF0B0522);
        g.fillGradient(0, h / 2, w, h, 0xFF0B0522, 0xFF050010);
        double t = now / 1000.0;
        for (float[] n : nebulae)
            drawNebula(g, n, t);
        drawConstel(g, t);
        double sec = now / 1000.0;
        for (Star s : stars) {
            s.angle += s.rotSpd;
            float tw = 0.35f + 0.65f * (float) Math.sin(sec * s.twSpd + s.twPh);
            int alpha = Math.max(0, Math.min(255, (int) (s.alpha * tw * 255)));
            if (alpha < 6)
                continue;
            float cs = 0.5f + 0.5f * (float) Math.sin(sec * 0.3 + s.twPh);
            int r = lerp(s.cA >> 16 & 0xFF, s.cB >> 16 & 0xFF, cs);
            int gg = lerp(s.cA >> 8 & 0xFF, s.cB >> 8 & 0xFF, cs);
            int b = lerp(s.cA & 0xFF, s.cB & 0xFF, cs);
            int col = (alpha << 24) | (r << 16) | (gg << 8) | b;
            float hs = s.size * 0.5f;
            int sz = Math.max(1, (int) s.size);
            g.pose().pushPose();
            g.pose().translate(s.x, s.y, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees(s.angle));
            g.pose().translate(-hs, -hs, 0);
            g.fill(0, 0, sz, sz, col);
            g.pose().popPose();
        }
    }

    private static void build(int w, int h) {
        int n = Math.max(140, (w * h) / 2600);
        stars = new Star[n];
        for (int i = 0; i < n; i++)
            stars[i] = new Star(RNG.nextFloat() * w, RNG.nextFloat() * h);
        int[] ncol = {0x3A1A80, 0x102A60, 0x401040};
        nebulae = new float[3][];
        for (int i = 0; i < 3; i++)
            nebulae[i] = new float[]{w * (0.15f + RNG.nextFloat() * 0.7f), h * (0.15f + RNG.nextFloat() * 0.7f), 60f + RNG.nextFloat() * 90f, ncol[i]};
        int[] pat = {0, 0, 20, 12, 38, 6, 30, 28, 12, 34};
        float ox = w * (0.1f + RNG.nextFloat() * 0.5f);
        float oy = h * (0.1f + RNG.nextFloat() * 0.5f);
        float sc = 2f + RNG.nextFloat() * 2f;
        constel = new float[5][];
        for (int i = 0; i < 5; i++)
            constel[i] = new float[]{ox + pat[i * 2] * sc, oy + pat[i * 2 + 1] * sc};
    }

    private static void drawNebula(GuiGraphics g, float[] n, double t) {
        float px = n[0];
        float py = n[1];
        float r = n[2];
        int base = (int) n[3];
        float pulse = 0.85f + 0.15f * (float) Math.sin(t * 0.5);
        for (int i = 6; i >= 1; i--) {
            float rr = r * pulse * i / 6f;
            int a = (int) (10 * (i / 6f));
            int col = (a << 24) | base;
            g.fill((int) (px - rr), (int) (py - rr), (int) (px + rr), (int) (py + rr), col);
        }
    }

    private static void drawConstel(GuiGraphics g, double t) {
        if (constel.length < 2)
            return;
        int la = Math.max(0, Math.min(255, (int) (40 + 25 * Math.sin(t * 0.8))));
        for (int i = 0; i < constel.length - 1; i++)
            drawLine(g, constel[i][0], constel[i][1], constel[i + 1][0], constel[i + 1][1], la);
        for (float[] p : constel) {
            int a = Math.max(0, Math.min(255, (int) (150 + 80 * Math.sin(t * 1.2))));
            g.fill((int) p[0] - 1, (int) p[1] - 1, (int) p[0] + 2, (int) p[1] + 2, (a << 24) | 0xFFFFFF);
            g.fill((int) p[0] - 2, (int) p[1] - 2, (int) p[0] + 3, (int) p[1] + 3, ((a / 3) << 24) | 0xB9A8FF);
        }
    }

    private static void drawLine(GuiGraphics g, float x1, float y1, float x2, float y2, int a) {
        int steps = (int) Math.max(2, Math.hypot(x2 - x1, y2 - y1) / 3);
        for (int i = 0; i <= steps; i++) {
            float tt = i / (float) steps;
            int x = (int) (x1 + (x2 - x1) * tt);
            int y = (int) (y1 + (y2 - y1) * tt);
            g.fill(x, y, x + 1, y + 1, (a << 24) | 0x99AAFF);
        }
    }

    private static int lerp(int a, int b, float t) {
        return (int) (a + (b - a) * t);
    }

    static final class Star {
        float x;
        float y;
        float size;
        float alpha;
        float angle;
        float rotSpd;
        float twSpd;
        float twPh;
        int cA;
        int cB;

        Star(float x, float y) {
            this.x = x;
            this.y = y;
            size = 1f + RNG.nextFloat() * 1.4f;
            alpha = 0.6f + RNG.nextFloat() * 0.4f;
            angle = RNG.nextFloat() * 360f;
            rotSpd = (RNG.nextBoolean() ? 1f : -1f) * (0.05f + RNG.nextFloat() * 0.3f);
            twSpd = 0.4f + RNG.nextFloat() * 2.2f;
            twPh = RNG.nextFloat() * 6.2831855f;
            int[][] pairs = {{0xFFFFFF, 0xEEDDFF}, {0xFFFFFF, 0xDDEEFF}, {0xFFFFFF, 0xFFCCFF}, {0xFFFFFF, 0xCCDDFF}};
            int[] p = pairs[RNG.nextInt(pairs.length)];
            cA = p[0];
            cB = p[1];
        }
    }
}
