package deskped.sped.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import deskped.sped.init.SpedItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderItemInFrameEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "sped")
public class PhotoFrameRenderer {

	@SubscribeEvent
	public static void onRenderInFrame(RenderItemInFrameEvent event) {
		ItemStack stack = event.getItemStack();
		if (stack.isEmpty() || !stack.is(SpedItems.PHOTO.get()) || stack.getTag() == null)
			return;
		PhotoClientCache.Entry entry = PhotoClientCache.get(stack.getTag().getString("PhotoId"));
		if (entry == null)
			return;

		PoseStack pose = event.getPoseStack();
		MultiBufferSource buffer = event.getMultiBufferSource();
		int light = event.getPackedLight();

		pose.pushPose();
		float h = 0.34f;
		Matrix4f m = pose.last().pose();
		VertexConsumer vc = buffer.getBuffer(RenderType.text(entry.texture));
		quad(vc, m, -h, -h, h, h, 0.005f, false, light);
		quad(vc, m, -h, -h, h, h, -0.005f, true, light);
		pose.popPose();

		event.setCanceled(true);
	}

	private static void quad(VertexConsumer vc, Matrix4f m, float x0, float y0, float x1, float y1, float z, boolean back, int light) {
		if (back) {
			vc.vertex(m, x1, y0, z).color(255, 255, 255, 255).uv(0f, 1f).uv2(light).endVertex();
			vc.vertex(m, x0, y0, z).color(255, 255, 255, 255).uv(1f, 1f).uv2(light).endVertex();
			vc.vertex(m, x0, y1, z).color(255, 255, 255, 255).uv(1f, 0f).uv2(light).endVertex();
			vc.vertex(m, x1, y1, z).color(255, 255, 255, 255).uv(0f, 0f).uv2(light).endVertex();
		} else {
			vc.vertex(m, x0, y0, z).color(255, 255, 255, 255).uv(0f, 1f).uv2(light).endVertex();
			vc.vertex(m, x1, y0, z).color(255, 255, 255, 255).uv(1f, 1f).uv2(light).endVertex();
			vc.vertex(m, x1, y1, z).color(255, 255, 255, 255).uv(1f, 0f).uv2(light).endVertex();
			vc.vertex(m, x0, y1, z).color(255, 255, 255, 255).uv(0f, 0f).uv2(light).endVertex();
		}
	}
}
