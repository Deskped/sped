package deskped.sped.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import deskped.sped.SpedMod;
import deskped.sped.client.ClientRaceState;
import deskped.sped.network.RaceDeathModePacket;
import deskped.sped.network.RaceSelectPacket;
import deskped.sped.race.RaceAttribute;
import deskped.sped.race.RaceGroup;
import deskped.sped.race.RaceLevels;
import deskped.sped.world.inventory.MenuRaceMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

@OnlyIn(Dist.CLIENT)
public class MenuRaceScreen extends AbstractContainerScreen<MenuRaceMenu> {

	private static final Random RNG = new Random();
	private static final ResourceLocation PLANET = new ResourceLocation("sped", "textures/environment/your_planet.png");
	private static final ResourceLocation ENDTEX = new ResourceLocation("sped", "textures/environment/your_end.png");
	private static final ResourceLocation PORTAL = new ResourceLocation("sped", "textures/environment/portal_normal.png");
	private static final int TEX = 256;
	private static final int MIN_SELECT = 1;
	private static final float[] ZERO2 = {0f, 0f};

	private final Set<RaceAttribute> selected = EnumSet.noneOf(RaceAttribute.class);
	private final Map<RaceAttribute, Float> knob = new EnumMap<>(RaceAttribute.class);
	private final Map<RaceAttribute, Float> hoverAnim = new EnumMap<>(RaceAttribute.class);
	private final List<Row> rows = new ArrayList<>();
	private final List<float[]> stars = new ArrayList<>();
	private final List<float[]> meteors = new ArrayList<>();
	private final List<float[]> flames = new ArrayList<>();
	private final List<float[]> orbiters = new ArrayList<>();

	private float scroll = 0f;
	private float maxScroll = 0f;
	private int uiState = 0;
	private boolean locked;
	private boolean ru;
	private boolean isOp;
	private boolean nothingPending;
	private int nothX, nothY;
	private final int nothW = 90;

	private float wOver = 1f, wNether = 0f, wEnd = 0f;
	private RaceGroup curGroup = RaceGroup.FOREST;
	private float smoothMX = -1000f, smoothMY = -1000f;
	private float accentR = 0x4C, accentG = 0xAF, accentB = 0x50;

	private SoundInstance music;
	private int musicKey = -1;
	private long lastCrackle = 0L;

	private int selX, selY;
	private final int selW = 150, selH = 20;
	private int yesX, yesY, noX, noY;
	private final int cbW = 70, cbH = 20;
	private int opt1X, opt1Y, opt2X, opt2Y;
	private final int optW = 270, optH = 20;

	private static class Row {
		final RaceAttribute attr;
		final int x1, y1, x2, y2;
		final boolean lockedGrp;

		Row(RaceAttribute attr, int x1, int y1, int x2, int y2, boolean lockedGrp) {
			this.attr = attr;
			this.x1 = x1;
			this.y1 = y1;
			this.x2 = x2;
			this.y2 = y2;
			this.lockedGrp = lockedGrp;
		}
	}

	public MenuRaceScreen(MenuRaceMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
	}

	@Override
	protected void init() {
		super.init();
		ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
		isOp = Minecraft.getInstance().player != null && Minecraft.getInstance().player.hasPermissions(2);
		nothingPending = false;
		uiState = menu.mode == 1 ? 2 : 0;
		locked = menu.mode == 0 && ClientRaceState.get().isEmpty();
		selected.clear();
		for (String s : ClientRaceState.get()) {
			try {
				selected.add(RaceAttribute.valueOf(s));
			} catch (IllegalArgumentException ignored) {
			}
		}
		for (RaceAttribute a : RaceAttribute.values()) {
			knob.put(a, selected.contains(a) ? 1f : 0f);
			hoverAnim.put(a, 0f);
		}
		stars.clear();
		for (int i = 0; i < 240; i++)
			stars.add(new float[]{RNG.nextFloat() * width, RNG.nextFloat() * height, 0.3f + RNG.nextFloat() * 2.2f, RNG.nextFloat() * (float) (Math.PI * 2), RNG.nextFloat()});
		orbiters.clear();
		for (int i = 0; i < 70; i++)
			orbiters.add(new float[]{RNG.nextFloat() * (float) (Math.PI * 2), height * (0.1f + RNG.nextFloat() * 0.55f), 0.015f + RNG.nextFloat() * 0.03f, 1f + RNG.nextFloat() * 1.5f});
		meteors.clear();
		flames.clear();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
		double t = System.currentTimeMillis() / 1000.0;
		long now = System.currentTimeMillis();
		if (smoothMX < -900f) {
			smoothMX = mouseX;
			smoothMY = mouseY;
		}
		smoothMX += (mouseX - smoothMX) * 0.05f;
		smoothMY += (mouseY - smoothMY) * 0.05f;
		float cx = width / 2f, cy = height / 2f;
		float avX = (smoothMX - cx) / width;
		float avY = (smoothMY - cy) / height;

		int theme = curGroup == RaceGroup.NETHER ? 1 : curGroup == RaceGroup.END ? 2 : 0;
		wOver += ((theme == 0 ? 1f : 0f) - wOver) * 0.05f;
		wNether += ((theme == 1 ? 1f : 0f) - wNether) * 0.05f;
		wEnd += ((theme == 2 ? 1f : 0f) - wEnd) * 0.05f;

		int topCol = blend3(0xFF03000C, 0xFF150000, 0xFF0B0016);
		int botCol = blend3(0xFF060016, 0xFF2A0500, 0xFF14002A);
		g.fillGradient(0, 0, width, height / 2, topCol, mid(topCol, botCol));
		g.fillGradient(0, height / 2, width, height, mid(topCol, botCol), botCol);

		float starA = 1f - wNether;
		double rotA = t * 0.2 * wEnd;
		float cosR = (float) Math.cos(rotA), sinR = (float) Math.sin(rotA);
		for (float[] s : stars) {
			float px = s[0] - avX * (8f + s[4] * 18f);
			float py = s[1] - avY * (8f + s[4] * 18f);
			if (wEnd > 0.01f) {
				float dx = px - cx, dy = py - cy;
				float shrink = 1f - 0.22f * wEnd;
				px = cx + (dx * cosR - dy * sinR) * shrink;
				py = cy + (dx * sinR + dy * cosR) * shrink;
			}
			float tw = 0.35f + 0.65f * (float) Math.abs(Math.sin(t * s[2] + s[3]));
			int a = (int) (tw * starA * 170);
			if (a < 4)
				continue;
			g.fill((int) px, (int) py, (int) px + 1, (int) py + 1, (a << 24) | 0xFFFFFF);
		}

		float slide = 1f - wOver;
		float planetY = cy - slide * slide * height * 1.35f;
		drawRot(g, PLANET, cx - avX * 20f, planetY - avY * 20f, Math.min(width, height) * 0.95f, (float) (t * 12 % 360), wOver);

		if (wEnd > 0.02f) {
			drawRot(g, ENDTEX, cx - avX * 16f, cy - avY * 16f, height * 0.85f, (float) (t * 9 % 360), wEnd);
			for (float[] o : orbiters) {
				o[0] += o[2] * (0.5f + wEnd);
				o[1] -= 0.45f * wEnd;
				if (o[1] < height * 0.07f) {
					o[1] = height * (0.45f + RNG.nextFloat() * 0.3f);
					o[0] = RNG.nextFloat() * (float) (Math.PI * 2);
				}
				float ox = cx + (float) Math.cos(o[0]) * o[1] - avX * 10f;
				float oy = cy + (float) Math.sin(o[0]) * o[1] * 0.85f - avY * 10f;
				float twk = 0.5f + 0.5f * (float) Math.abs(Math.sin(t * 2 + o[0] * 5));
				int a = (int) (wEnd * twk * 200);
				int col = (o[3] > 1.7f) ? 0xCC66FF : 0xAA44EE;
				int sz = (int) o[3];
				g.fill((int) ox, (int) oy, (int) ox + sz, (int) oy + sz, (a << 24) | col);
			}
			drawRot(g, PORTAL, cx - avX * 12f, cy - avY * 12f, height * 1.0f, (float) (-t * 13 % 360), wEnd * 0.9f);
		}

		if (wNether > 0.02f) {
			g.fillGradient(0, (int) (height * 0.6f), width, height, 0x00FF4400, ((int) (wNether * 200) << 24) | 0xCC3300);
			if (flames.size() < 90 && RNG.nextFloat() < wNether * 0.6f)
				flames.add(new float[]{RNG.nextFloat() * width, height + 4, -(0.7f + RNG.nextFloat() * 1.5f), 2f + RNG.nextFloat() * 2.5f, 1f});
			for (float[] f : flames) {
				f[1] += f[2];
				f[4] -= 0.012f;
			}
			flames.removeIf(f -> f[4] <= 0f);
			for (float[] f : flames) {
				int a = (int) (f[4] * wNether * 200);
				int col = f[4] > 0.5f ? 0xFF7A22 : 0xFFC044;
				int sz = (int) f[3];
				g.fill((int) f[0], (int) f[1], (int) f[0] + sz, (int) f[1] + sz, (a << 24) | col);
			}
			if (wNether > 0.5f && now - lastCrackle > 1700) {
				lastCrackle = now;
				Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.FIRE_AMBIENT, 0.8f + RNG.nextFloat() * 0.4f, 0.6f));
			}
			if (RNG.nextFloat() < wNether * 0.05f)
				meteors.add(new float[]{width * 0.55f + RNG.nextFloat() * width * 0.65f, -20f, -(2.5f + RNG.nextFloat() * 2.5f), 2f + RNG.nextFloat() * 2f});
			for (float[] m : meteors) {
				m[0] += m[2];
				m[1] += m[3];
			}
			meteors.removeIf(m -> m[1] > height + 40 || m[0] < -60);
			for (float[] m : meteors) {
				for (int i = 0; i < 16; i++) {
					float fade = 1f - i / 16f;
					int a = (int) (fade * fade * wNether * 220);
					int col = i < 2 ? 0xFFFFE8 : 0xFF9050;
					g.fill((int) (m[0] - m[2] * i * 0.8f), (int) (m[1] - m[3] * i * 0.8f), (int) (m[0] - m[2] * i * 0.8f) + 2, (int) (m[1] - m[3] * i * 0.8f) + 2, (a << 24) | col);
				}
			}
		}

		int panelW = 280;
		int left = width / 2 - panelW / 2;
		int right = left + panelW;
		int top = 36;
		int bottom = height - 46;

		RaceAttribute hovered = null;
		RaceGroup topGroup = null;

		int contentH = RaceGroup.values().length * (22 + 3 * 24 + 10);
		maxScroll = Math.max(0, contentH - (bottom - top));
		scroll = Math.max(0, Math.min(scroll, maxScroll));

		int xpLvl = Minecraft.getInstance().player != null ? Minecraft.getInstance().player.experienceLevel : 0;
		rows.clear();
		g.enableScissor(left - 24, top, right + 24, bottom);
		int y = top - (int) scroll;
		int rowIdx = 0;
		for (RaceGroup grp : RaceGroup.values()) {
			if (topGroup == null && y + 22 + 3 * 24 > top + 4)
				topGroup = grp;
			int gc = grp.color;
			boolean grpLocked = !isOp && xpLvl < grp.reqLevel;
			float hFloat = (float) Math.sin(t * 0.8 + rowIdx * 1.1) * 2f;
			if (y + 22 > top - 30 && y < bottom + 30) {
				g.fill(left, (int) (y + 15 + hFloat), right, (int) (y + 16 + hFloat), 0x66000000 | gc);
				g.drawString(font, grp.title(ru), left + (int) (avX * -4), (int) (y + 4 + hFloat), 0xFF000000 | gc, false);
				if (grp.reqLevel > 0) {
					String req = (grpLocked ? "\u2716 " : "\u2714 ") + grp.reqLevel + (ru ? " \u0443\u0440." : " lvl");
					g.drawString(font, req, right - font.width(req), (int) (y + 4 + hFloat), grpLocked ? 0xFFE05555 : 0xFF7FBF7F, false);
				}
			}
			y += 22;
			for (RaceAttribute attr : RaceAttribute.values()) {
				if (attr.group != grp)
					continue;
				rowIdx++;
				float fl = (float) Math.sin(t * 1.1 + rowIdx * 1.45) * 2f;
				int rowY = (int) (y + fl);
				float[] fear = fear(left + panelW / 2f, rowY + 11, mouseX, mouseY);
				int rx = left + (int) fear[0];
				int ry = rowY + (int) (fear[1] * 0.5f);
				boolean visible = ry + 24 > top && ry < bottom;
				boolean hov = visible && uiState == 0 && mouseX >= rx && mouseX <= rx + panelW && mouseY >= ry && mouseY < ry + 22 && mouseY >= top && mouseY <= bottom;
				if (hov)
					hovered = attr;
				float h = clamp01(hoverAnim.get(attr) + (hov ? 0.12f : -0.08f));
				hoverAnim.put(attr, h);
				boolean on = selected.contains(attr);
				float k = knob.get(attr);
				k += ((on ? 1f : 0f) - k) * 0.25f;
				knob.put(attr, k);
				if (visible) {
					int bgA = (int) (40 + h * 55);
					g.fill(rx, ry, rx + panelW, ry + 22, (bgA << 24) | 0x101030);
					if (on)
						g.fill(rx, ry, rx + 2, ry + 22, 0xFF000000 | gc);
					int nameCol = grpLocked ? 0xFF55555F : (on ? (0xFF000000 | gc) : (h > 0.01f ? 0xFFFFFFFF : 0xFFB8B8C8));
					g.drawString(font, attr.displayName(ru), rx + 8, ry + 7, nameCol, false);
					int rl = RaceLevels.level(ClientRaceState.xp(attr.name()));
					if (rl > 0) {
						String lv = "\u2726" + rl;
						g.drawString(font, lv, rx + panelW - 50 - font.width(lv), ry + 7, 0xFF9FD5FF, false);
					}
					int tx = rx + panelW - 44;
					int ty = ry + 5;
					int tw2 = 34, th = 12;
					int frameCol = on ? (0xFF000000 | gc) : 0xFF3A3A55;
					g.fill(tx, ty, tx + tw2, ty + th, 0xAA0A0A18);
					border(g, tx, ty, tw2, th, frameCol);
					int kx = tx + 2 + (int) (k * (tw2 - 12));
					g.fill(kx, ty + 2, kx + 8, ty + th - 2, on ? (0xFF000000 | gc) : 0xFF666688);
					rows.add(new Row(attr, rx, ry, rx + panelW, ry + 22, grpLocked));
				}
				y += 24;
			}
			y += 10;
		}
		g.disableScissor();

		if (hovered != null)
			topGroup = hovered.group;
		if (topGroup == null)
			topGroup = RaceGroup.FOREST;
		curGroup = topGroup;
		int gc = curGroup.color;
		accentR += (((gc >> 16) & 0xFF) - accentR) * 0.08f;
		accentG += (((gc >> 8) & 0xFF) - accentG) * 0.08f;
		accentB += ((gc & 0xFF) - accentB) * 0.08f;
		int accent = 0xFF000000 | ((int) accentR << 16) | ((int) accentG << 8) | (int) accentB;

		float titleFl = (float) Math.sin(t * 0.7) * 2f;
		g.fill(left - 12, (int) (top - 24 + titleFl), right + 12, (int) (top - 23 + titleFl), accent);
		g.fill(left - 12, bottom + 4, right + 12, bottom + 5, accent);
		g.drawCenteredString(font, ru ? "\u0412\u044b\u0431\u043e\u0440 \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043e\u0432" : "Attribute Selection", width / 2 + (int) (avX * -5), (int) (top - 18 + titleFl), accent);
		g.drawCenteredString(font, (ru ? "\u0412\u044b\u0431\u0440\u0430\u043d\u043e: " : "Selected: ") + selected.size() + "/3", width / 2, bottom + 9, 0xFFCCCCDD);
		int rlSel = 0;
		for (RaceAttribute a : selected)
			rlSel = Math.max(rlSel, a.group.reqLevel);
		if (rlSel > 0 && !isOp)
			g.drawCenteredString(font, (ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " : "Requires XP level: ") + rlSel, width / 2, bottom + 9 - 12, xpLvl >= rlSel ? 0xFF7FBF7F : 0xFFE05555);

		float[] selFear = fear(width / 2f, bottom + 30, mouseX, mouseY);
		selX = width / 2 - selW / 2 + (int) selFear[0];
		selY = bottom + 20 + (int) (selFear[1] * 0.4f) + (int) (Math.sin(t * 0.9 + 3) * 1.5f);
		boolean canSel = selected.size() >= MIN_SELECT && selected.size() <= 3;
		boolean selHov = uiState == 0 && in(mouseX, mouseY, selX, selY, selW, selH);
		g.fill(selX, selY, selX + selW, selY + selH, canSel ? (selHov ? 0xCC202048 : 0xAA15152F) : 0x88101018);
		border(g, selX, selY, selW, selH, canSel ? accent : 0xFF444455);
		g.drawCenteredString(font, (ru ? "\u0412\u044b\u0431\u0440\u0430\u0442\u044c" : "Select") + " (" + selected.size() + "/3)", selX + selW / 2, selY + 6, canSel ? 0xFFFFFFFF : 0xFF777788);
		if (isOp) {
			nothX = selX + selW + 10;
			nothY = selY;
			boolean nHov = uiState == 0 && in(mouseX, mouseY, nothX, nothY, nothW, selH);
			g.fill(nothX, nothY, nothX + nothW, nothY + selH, nHov ? 0xCC402020 : 0xAA2F1515);
			border(g, nothX, nothY, nothW, selH, 0xFF884444);
			g.drawCenteredString(font, ru ? "\u041d\u0438\u0447\u0442\u043e" : "Nothing", nothX + nothW / 2, nothY + 6, 0xFFDDBBBB);
		}

		if (uiState == 1) {
			g.fill(0, 0, width, height, 0xB0000008);
			int bw = 220, bh = 86;
			int bx = width / 2 - bw / 2, by = (int) (height / 2 - bh / 2 + Math.sin(t * 0.8) * 2);
			g.fill(bx, by, bx + bw, by + bh, 0xF0101024);
			border(g, bx, by, bw, bh, accent);
			g.drawCenteredString(font, ru ? "\u0412\u044b \u0443\u0432\u0435\u0440\u0435\u043d\u044b?" : "Are you sure?", width / 2, by + 16, 0xFFFFFFFF);
			float[] f1 = fear(bx + 24 + cbW / 2f, by + bh - 24, mouseX, mouseY);
			float[] f2 = fear(bx + bw - 24 - cbW / 2f, by + bh - 24, mouseX, mouseY);
			yesX = bx + 24 + (int) f1[0];
			yesY = by + bh - 34 + (int) (f1[1] * 0.4f);
			noX = bx + bw - 24 - cbW + (int) f2[0];
			noY = by + bh - 34 + (int) (f2[1] * 0.4f);
			confirmButton(g, yesX, yesY, cbW, ru ? "\u0414\u0430" : "Yes", mouseX, mouseY, accent);
			confirmButton(g, noX, noY, cbW, ru ? "\u041d\u0435\u0442" : "No", mouseX, mouseY, accent);
		}

		if (uiState == 2) {
			g.fill(0, 0, width, height, 0xB0000008);
			int bw = 260, bh = 100;
			int bx = width / 2 - bw / 2, by = (int) (height / 2 - bh / 2 + Math.sin(t * 0.8) * 2);
			g.fill(bx, by, bx + bw, by + bh, 0xF0101024);
			border(g, bx, by, bw, bh, accent);
			g.drawCenteredString(font, ru ? "\u0412\u044b \u0443\u043c\u0435\u0440\u043b\u0438." : "You died.", width / 2, by + 12, 0xFFE86060);
			g.drawCenteredString(font, ru ? "\u0416\u0435\u043b\u0430\u0435\u0442\u0435 \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0432\u044b\u0431\u043e\u0440?" : "Do you want to change your choice?", width / 2, by + 26, 0xFFFFFFFF);
			float[] f1 = fear(bx + 30 + cbW / 2f, by + bh - 22, mouseX, mouseY);
			float[] f2 = fear(bx + bw - 30 - cbW / 2f, by + bh - 22, mouseX, mouseY);
			yesX = bx + 30 + (int) f1[0];
			yesY = by + bh - 32 + (int) (f1[1] * 0.4f);
			noX = bx + bw - 30 - cbW + (int) f2[0];
			noY = by + bh - 32 + (int) (f2[1] * 0.4f);
			confirmButton(g, yesX, yesY, cbW, ru ? "\u0414\u0430" : "Yes", mouseX, mouseY, accent);
			confirmButton(g, noX, noY, cbW, ru ? "\u041d\u0435\u0442" : "No", mouseX, mouseY, accent);
		}

		if (uiState == 3) {
			g.fill(0, 0, width, height, 0xB0000008);
			int bw = 300, bh = 104;
			int bx = width / 2 - bw / 2, by = (int) (height / 2 - bh / 2 + Math.sin(t * 0.8) * 2);
			g.fill(bx, by, bx + bw, by + bh, 0xF0101024);
			border(g, bx, by, bw, bh, accent);
			g.drawCenteredString(font, ru ? "\u041d\u0443\u0436\u0435\u043d \u043b\u0438 \u0432\u044b\u0431\u043e\u0440 \u043f\u043e\u0441\u043b\u0435 \u0441\u043c\u0435\u0440\u0442\u0438?" : "Choose race after every death?", width / 2, by + 14, 0xFFFFFFFF);
			opt1X = bx + (bw - optW) / 2;
			opt1Y = by + 36;
			opt2X = opt1X;
			opt2Y = by + 64;
			confirmButton(g, opt1X, opt1Y, optW, ru ? "\u042f \u0445\u043e\u0447\u0443 \u0432\u044b\u0431\u0438\u0440\u0430\u0442\u044c \u0440\u0430\u0441\u0443 \u043a\u0430\u0436\u0434\u0443\u044e \u0441\u043c\u0435\u0440\u0442\u044c" : "I want to choose my race every death", mouseX, mouseY, accent);
			confirmButton(g, opt2X, opt2Y, optW, ru ? "\u042f \u043d\u0435 \u0445\u043e\u0447\u0443 \u0432\u044b\u0431\u0438\u0440\u0430\u0442\u044c \u043d\u0438\u043a\u043e\u0433\u0434\u0430" : "I never want to choose again", mouseX, mouseY, accent);
		}

		if (hovered != null && uiState == 0) {
			final RaceAttribute hv = hovered;
			boolean hvLocked = !isOp && xpLvl < hv.group.reqLevel;
			int xp = ClientRaceState.xp(hv.name());
			int lvl = RaceLevels.level(xp);
			int nBuffs = RaceLevels.buffs(lvl);
			int nDebuffs = RaceLevels.debuffs(lvl);
			List<Component> lines = new ArrayList<>();
			lines.add(Component.literal(hv.displayName(ru)).withStyle(s -> s.withColor(hv.group.color).withBold(true)));
			if (hvLocked)
				lines.add(Component.literal((ru ? "\u041d\u0443\u0436\u0435\u043d \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043e\u043f\u044b\u0442\u0430: " : "Requires XP level: ") + hv.group.reqLevel).withStyle(ChatFormatting.RED));
			String lvlLine = (ru ? "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0440\u0430\u0441\u044b: " : "Race level: ") + lvl + " / " + RaceLevels.MAX_LEVEL;
			if (lvl < RaceLevels.MAX_LEVEL)
				lvlLine += (ru ? "  (\u0434\u043e \u0441\u043b\u0435\u0434.: " : "  (to next: ") + RaceLevels.toNext(xp) + (ru ? " \u043e\u043f.)" : " xp)");
			lines.add(Component.literal(lvlLine).withStyle(ChatFormatting.AQUA));
			String[] ls = hv.lines(ru);
			int bi = 0, di = 0;
			for (String line : ls) {
				if (line.startsWith("+")) {
					if (bi < nBuffs)
						lines.add(Component.literal(line).withStyle(ChatFormatting.GREEN));
					else
						lines.add(Component.literal(line + "  [" + (ru ? "\u0443\u0440. " : "lvl ") + RaceLevels.buffUnlockLevel(bi) + "]").withStyle(ChatFormatting.DARK_GRAY));
					bi++;
				} else {
					if (di < nDebuffs)
						lines.add(Component.literal(line).withStyle(ChatFormatting.RED));
					else
						lines.add(Component.literal(line).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.STRIKETHROUGH));
					di++;
				}
			}
			g.renderComponentTooltip(font, lines, mouseX, mouseY);
		}

		updateMusic(theme);
	}

	private void updateMusic(int theme) {
		if (musicKey == theme)
			return;
		stopMusic();
		ResourceLocation loc = switch (theme) {
			case 1 -> new ResourceLocation("minecraft", "music_disc.pigstep");
			case 2 -> new ResourceLocation("sped", "music_honoro");
			default -> new ResourceLocation("sped", "music_dying_world");
		};
		music = new SimpleSoundInstance(loc, SoundSource.MUSIC, 0.8f, 1f, SoundInstance.createUnseededRandom(), true, 0, SoundInstance.Attenuation.NONE, 0, 0, 0, true);
		Minecraft.getInstance().getSoundManager().play(music);
		musicKey = theme;
	}

	private void stopMusic() {
		if (music != null) {
			Minecraft.getInstance().getSoundManager().stop(music);
			music = null;
		}
	}

	private void drawRot(GuiGraphics g, ResourceLocation tex, float cx, float cy, float size, float rot, float alpha) {
		if (alpha <= 0.02f)
			return;
		float sc = size / TEX;
		RenderSystem.enableBlend();
		RenderSystem.setShaderColor(1, 1, 1, Math.min(1f, alpha));
		g.pose().pushPose();
		g.pose().translate(cx, cy, 0);
		g.pose().mulPose(Axis.ZP.rotationDegrees(rot));
		g.pose().scale(sc, sc, 1f);
		g.pose().translate(-TEX / 2f, -TEX / 2f, 0);
		g.blit(tex, 0, 0, 0, 0, TEX, TEX, TEX, TEX);
		g.pose().popPose();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}

	private int blend3(int c0, int c1, int c2) {
		float sum = wOver + wNether + wEnd;
		if (sum < 0.001f)
			return c0;
		float a = wOver / sum, b = wNether / sum, c = wEnd / sum;
		int r = (int) (((c0 >> 16) & 0xFF) * a + ((c1 >> 16) & 0xFF) * b + ((c2 >> 16) & 0xFF) * c);
		int gr = (int) (((c0 >> 8) & 0xFF) * a + ((c1 >> 8) & 0xFF) * b + ((c2 >> 8) & 0xFF) * c);
		int bl = (int) ((c0 & 0xFF) * a + (c1 & 0xFF) * b + (c2 & 0xFF) * c);
		return 0xFF000000 | (r << 16) | (gr << 8) | bl;
	}

	private static int mid(int a, int b) {
		int r = (((a >> 16) & 0xFF) + ((b >> 16) & 0xFF)) / 2;
		int g = (((a >> 8) & 0xFF) + ((b >> 8) & 0xFF)) / 2;
		int bl = ((a & 0xFF) + (b & 0xFF)) / 2;
		return 0xFF000000 | (r << 16) | (g << 8) | bl;
	}

	private float[] fear(float cx, float cy, int mx, int my) {
		float dx = cx - mx, dy = cy - my;
		float d = (float) Math.sqrt(dx * dx + dy * dy);
		if (d > 70f || d < 0.01f)
			return ZERO2;
		float f = (1f - d / 70f) * 4f;
		return new float[]{dx / d * f, dy / d * f};
	}

	private void confirmButton(GuiGraphics g, int x, int y, int w, String text, int mx, int my, int accent) {
		boolean hov = in(mx, my, x, y, w, cbH);
		g.fill(x, y, x + w, y + cbH, hov ? 0xCC202048 : 0xAA15152F);
		border(g, x, y, w, cbH, accent);
		g.drawCenteredString(font, text, x + w / 2, y + 6, 0xFFFFFFFF);
	}

	private void border(GuiGraphics g, int x, int y, int w, int h, int col) {
		g.fill(x, y, x + w, y + 1, col);
		g.fill(x, y + h - 1, x + w, y + h, col);
		g.fill(x, y, x + 1, y + h, col);
		g.fill(x + w - 1, y, x + w, y + h, col);
	}

	private void click(float pitch) {
		Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, pitch));
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (button != 0)
			return super.mouseClicked(mx, my, button);
		if (uiState == 2) {
			if (in(mx, my, yesX, yesY, cbW, cbH)) {
				click(1f);
				uiState = 3;
				return true;
			}
			if (in(mx, my, noX, noY, cbW, cbH)) {
				click(0.8f);
				locked = false;
				this.onClose();
				return true;
			}
			return true;
		}
		if (uiState == 3) {
			if (in(mx, my, opt1X, opt1Y, optW, optH)) {
				click(1f);
				SpedMod.PACKET_HANDLER.sendToServer(new RaceDeathModePacket(1));
				uiState = 0;
				return true;
			}
			if (in(mx, my, opt2X, opt2Y, optW, optH)) {
				click(1f);
				SpedMod.PACKET_HANDLER.sendToServer(new RaceDeathModePacket(2));
				uiState = 0;
				return true;
			}
			return true;
		}
		if (uiState == 1) {
			if (in(mx, my, yesX, yesY, cbW, cbH)) {
				click(1.2f);
				List<String> names = new ArrayList<>();
				if (!nothingPending)
					for (RaceAttribute a : selected)
						names.add(a.name());
				SpedMod.PACKET_HANDLER.sendToServer(new RaceSelectPacket(names));
				ClientRaceState.set(names);
				nothingPending = false;
				locked = false;
				uiState = 0;
				this.onClose();
				return true;
			}
			if (in(mx, my, noX, noY, cbW, cbH)) {
				click(0.8f);
				nothingPending = false;
				uiState = 0;
			}
			return true;
		}
		if (selected.size() >= MIN_SELECT && selected.size() <= 3 && in(mx, my, selX, selY, selW, selH)) {
			click(1f);
			nothingPending = false;
			uiState = 1;
			return true;
		}
		if (isOp && in(mx, my, nothX, nothY, nothW, selH)) {
			click(0.9f);
			nothingPending = true;
			uiState = 1;
			return true;
		}
		for (Row row : rows) {
			if (mx >= row.x1 && mx <= row.x2 && my >= row.y1 && my < row.y2) {
				if (row.lockedGrp) {
					click(0.4f);
					return true;
				}
				if (selected.contains(row.attr)) {
					selected.remove(row.attr);
					click(0.7f);
				} else if (selected.size() < 3) {
					selected.add(row.attr);
					click(1.1f);
				} else
					click(0.5f);
				return true;
			}
		}
		return super.mouseClicked(mx, my, button);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double delta) {
		if (uiState == 0) {
			scroll -= (float) delta * 24f;
			return true;
		}
		return false;
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (locked && (keyCode == 256 || Minecraft.getInstance().options.keyInventory.matches(keyCode, scanCode)))
			return true;
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return !locked;
	}

	@Override
	public void onClose() {
		if (locked)
			return;
		super.onClose();
	}

	@Override
	public void removed() {
		stopMusic();
		super.removed();
	}

	private boolean in(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx <= x + w && my >= y && my <= y + h;
	}

	private static float clamp01(float v) {
		return Math.max(0f, Math.min(1f, v));
	}

	@Override
	protected void renderBg(GuiGraphics g, float partial, int mx, int my) {
	}

	@Override
	protected void renderLabels(GuiGraphics g, int mx, int my) {
	}
}