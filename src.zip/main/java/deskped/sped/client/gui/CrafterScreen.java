package deskped.sped.client.gui;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;

import com.mojang.blaze3d.systems.RenderSystem;

import deskped.sped.world.inventory.CrafterMenu;

@OnlyIn(Dist.CLIENT)
public class CrafterScreen extends AbstractContainerScreen<CrafterMenu> {
	private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/gui/container/crafter.png");
	private static final ResourceLocation DISABLED_SLOT = new ResourceLocation("sped", "textures/gui/crafter_disabled_slot.png");
	private static final ResourceLocation POWERED_REDSTONE = new ResourceLocation("sped", "textures/gui/crafter_powered_redstone.png");
	private static final ResourceLocation UNPOWERED_REDSTONE = new ResourceLocation("sped", "textures/gui/crafter_unpowered_redstone.png");

	public CrafterScreen(CrafterMenu menu, Inventory inventory, Component title) {
		super(menu, inventory, title);
		this.imageWidth = 176;
		this.imageHeight = 166;
		this.inventoryLabelY = this.imageHeight - 94;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, 256, 256);
		guiGraphics.blit(this.menu.isPowered() ? POWERED_REDSTONE : UNPOWERED_REDSTONE, this.leftPos + 86, this.topPos + 35, 0, 0, 16, 16, 16, 16);
		for (int slot = 0; slot < 9; slot++)
			if (this.menu.isSlotDisabled(slot))
				guiGraphics.blit(DISABLED_SLOT, this.leftPos + 26 + slot % 3 * 18, this.topPos + 17 + slot / 3 * 18, 0, 0, 16, 16, 16, 16);
		RenderSystem.disableBlend();
	}

	@Override
	protected void slotClicked(Slot slot, int slotId, int mouseButton, ClickType clickType) {
		if (slot != null && slotId >= 0 && slotId < 9 && !slot.hasItem() && this.menu.getCarried().isEmpty() && this.minecraft != null && this.minecraft.gameMode != null) {
			this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1));
			this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, slotId);
			return;
		}
		super.slotClicked(slot, slotId, mouseButton, clickType);
	}
}
