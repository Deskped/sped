package deskped.sped.client;

import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

public class StreamingMenuSound extends AbstractSoundInstance {

    public StreamingMenuSound(ResourceLocation location) {
        super(location, SoundSource.MASTER, SoundInstance.createUnseededRandom());
        this.looping = true;
        this.delay   = 0;
        this.volume  = 1.0f;
        this.pitch   = 1.0f;
        this.x       = 0.0;
        this.y       = 0.0;
        this.z       = 0.0;
        this.attenuation = Attenuation.NONE;
    }

    @Override
    public boolean canPlaySound()  { return true; }

    @Override
    public boolean canStartSilent() { return true; }
}
