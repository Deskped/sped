package deskped.sped.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClientRaceState {
	private static final Set<String> RACES = new HashSet<>();
	private static final Map<String, Integer> XP = new HashMap<>();
	private static volatile List<String[]> HUD = new ArrayList<>();

	public static synchronized void set(List<String> names) {
		RACES.clear();
		RACES.addAll(names);
	}

	public static synchronized Set<String> get() {
		return new HashSet<>(RACES);
	}

	public static synchronized boolean has(String name) {
		return RACES.contains(name);
	}

	public static synchronized void setXp(Map<String, Integer> map) {
		XP.clear();
		XP.putAll(map);
	}

	public static synchronized int xp(String name) {
		return XP.getOrDefault(name, 0);
	}

	public static void setHud(List<String[]> entries) {
		HUD = entries;
	}

	public static List<String[]> hud() {
		return HUD;
	}
}
