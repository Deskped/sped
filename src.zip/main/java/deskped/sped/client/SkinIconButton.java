package deskped.sped.client;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Consumer;
import java.util.function.Supplier;

@OnlyIn(Dist.CLIENT)
public class SkinIconButton extends AbstractButton {

	private static final ResourceLocation WIDGETS = new ResourceLocation("textures/gui/widgets.png");

	private final Supplier<ResourceLocation> icon;
	private final Consumer<SkinIconButton> action;
	private final Supplier<int[]> position;

	public SkinIconButton(int x, int y, int size, Supplier<ResourceLocation> icon, Component tooltip, Consumer<SkinIconButton> action, Supplier<int[]> position) {
		super(x, y, size, size, Component.empty());
		this.icon = icon;
		this.action = action;
		this.position = position;
		this.setTooltip(Tooltip.create(tooltip));
	}

	@Override
	public void onPress() {
		this.action.accept(this);
	}

	private int textureY() {
		int state = 1;
		if (!this.active)
			state = 0;
		else if (this.isHoveredOrFocused())
			state = 2;
		return 46 + state * 20;
	}

	@Override
	public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partial) {
		if (this.position != null) {
			int[] pos = this.position.get();
			this.setX(pos[0]);
			this.setY(pos[1]);
		}
		RenderSystem.enableBlend();
		RenderSystem.enableDepthTest();
		graphics.setColor(1.0f, 1.0f, 1.0f, this.alpha);
		graphics.blitNineSliced(WIDGETS, this.getX(), this.getY(), this.width, this.height, 20, 4, 200, 20, 0, this.textureY());
		graphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
		int pad = 2;
		graphics.blit(this.icon.get(), this.getX() + pad, this.getY() + pad, this.width - pad * 2, this.height - pad * 2, 0.0f, 0.0f, 8, 8, 8, 8);
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput output) {
		this.defaultButtonNarrationText(output);
	}
}
