package deskped.sped.client;

import deskped.sped.SpedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
@OnlyIn(Dist.CLIENT)
public class IntroCommand {

	@SubscribeEvent
	public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("intro")
				.executes(ctx -> {
					Minecraft mc = Minecraft.getInstance();
					mc.tell(() -> mc.setScreen(new IntroScreen()));
					return 1;
				})
				.then(Commands.literal("reset").executes(ctx -> {
					IntroScreen.resetSeen();
					boolean ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
					ctx.getSource().sendSuccess(() -> Component.literal(ru
							? "\u0418\u043d\u0442\u0440\u043e \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u043e. \u041e\u043d\u043e \u0441\u043d\u043e\u0432\u0430 \u043f\u043e\u043a\u0430\u0436\u0435\u0442\u0441\u044f \u043f\u0440\u0438 \u0441\u043b\u0435\u0434\u0443\u044e\u0449\u0435\u043c \u0432\u0445\u043e\u0434\u0435 \u0432 \u043c\u0438\u0440."
							: "Intro reset. It will play again on the next world join."), false);
					return 1;
				})));
		SpedMod.LOGGER.info("[sped] Nova intro client command registered: /intro, /intro reset");
	}
}
