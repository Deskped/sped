package deskped.sped.client;

import deskped.sped.SpedMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
@OnlyIn(Dist.CLIENT)
public class IntroHandler {

	private static boolean shown = false;

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) {
			shown = false;
			return;
		}
		if (shown)
			return;
		if (mc.screen != null || mc.getOverlay() != null)
			return;
		shown = true;
		if (IntroScreen.seen()) {
			SpedMod.LOGGER.info("[sped] Nova intro skipped, marker exists at {}", IntroScreen.markerInfo());
			return;
		}
		SpedMod.LOGGER.info("[sped] Nova intro starting, marker not found at {}", IntroScreen.markerInfo());
		mc.setScreen(new IntroScreen());
	}
}
