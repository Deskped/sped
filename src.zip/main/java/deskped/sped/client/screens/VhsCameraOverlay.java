package deskped.sped.client.screens;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.PostChain;
import deskped.sped.procedures.VhsCameraTrueFalseProcedure;
import java.util.Random;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class VhsCameraOverlay {
    private static final ResourceLocation FISHEYE_SHADER = new ResourceLocation("sped", "shaders/post/fisheye.json");

    private static boolean fisheyeUnavailable = false;

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void eventHandler(RenderGuiEvent.Pre event) {
        int w = event.getWindow().getGuiScaledWidth();
        int h = event.getWindow().getGuiScaledHeight();
        Level world = null;
        double x = 0;
        double y = 0;
        double z = 0;
        Player entity = Minecraft.getInstance().player;
        if (entity != null) {
            world = entity.level();
            x = entity.getX();
            y = entity.getY();
            z = entity.getZ();
        }
        if (VhsCameraTrueFalseProcedure.execute(entity)) {
            GuiGraphics guiGraphics = event.getGuiGraphics();
            long nowMs = System.currentTimeMillis();
            double now = nowMs;
            int size = (int) (Math.min(w, h) * 0.75);
            int left = (w - size) / 2;
            int top = (h - size) / 2;
            int right = left + size;
            int bottom = top + size;
            guiGraphics.fill(0, 0, w, top, 0xFF000000);
            guiGraphics.fill(0, bottom, w, h, 0xFF000000);
            guiGraphics.fill(0, top, left, bottom, 0xFF000000);
            guiGraphics.fill(right, top, w, bottom, 0xFF000000);
            int tintAlpha = 30 + (int) (Math.sin(now * 0.0015) * 15);
            guiGraphics.fill(left, top, right, bottom, (tintAlpha << 24) | 0xFF0000);
            int scroll = (int) ((nowMs / 30L) % 4L);
            for (int ly = top + scroll; ly < bottom; ly += 4) {
                int lineAlpha = 15 + (int) (Math.abs(Math.sin(now * 0.001 + ly)) * 25);
                guiGraphics.fill(left, ly, right, Math.min(ly + 1, bottom), lineAlpha << 24);
            }
            int bandH = Math.max(4, size / 40);
            int bandY = top + (int) ((nowMs / 12L) % Math.max(1L, (long) size));
            guiGraphics.fill(left, bandY, right, Math.min(bandY + bandH, bottom), 0x16FFFFFF);
            guiGraphics.fill(left, Math.min(bandY + bandH, bottom - 1), right, Math.min(bandY + bandH + 1, bottom), 0x30000000);
            Random random = new Random();
            for (int i = 0; i < 50; i++) {
                int nx = left + random.nextInt(size);
                int ny = top + random.nextInt(size);
                int alpha = 20 + random.nextInt(60);
                guiGraphics.fill(nx, ny, nx + 1, ny + 1, (alpha << 24) | 0xFFFFFF);
            }
            if (random.nextInt(20) == 0) {
                int glitchHeight = 2 + random.nextInt(6);
                int glitchY = top + random.nextInt(Math.max(1, size - glitchHeight));
                int glitchShift = random.nextInt(11) - 5;
                int glitchLeft = Math.max(left, left + glitchShift);
                int glitchRight = Math.min(right, right + glitchShift);
                guiGraphics.fill(glitchLeft, glitchY, glitchRight, glitchY + glitchHeight, 0x55FF3333);
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END)
            return;
        Minecraft mc = Minecraft.getInstance();
        GameRenderer renderer = mc.gameRenderer;
        PostChain current = renderer.currentEffect();
        boolean ours = current != null && FISHEYE_SHADER.toString().equals(current.getName());
        boolean vhs = mc.player != null && mc.level != null && VhsCameraTrueFalseProcedure.execute(mc.player);
        if (vhs && !ours) {
            if (!fisheyeUnavailable) {
                renderer.loadEffect(FISHEYE_SHADER);
                PostChain loaded = renderer.currentEffect();
                if (loaded == null || !FISHEYE_SHADER.toString().equals(loaded.getName()))
                    fisheyeUnavailable = true;
            }
        } else if (!vhs && ours) {
            renderer.shutdownEffect();
        }
    }

    @SubscribeEvent
    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        Player entity = Minecraft.getInstance().player;
        if (VhsCameraTrueFalseProcedure.execute(entity)) {
            event.setFOV(event.getFOV() * 1.15);
        }
    }

    @SubscribeEvent
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Player entity = Minecraft.getInstance().player;
        if (entity != null && VhsCameraTrueFalseProcedure.execute(entity)) {
            double now = System.currentTimeMillis();
            Vec3 vel = entity.getDeltaMovement();
            double horizontalSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            double walkFactor = Math.min(1.0, horizontalSpeed / 0.15);
            double yawSway = Math.sin(now * 0.0006) * (1.2 + walkFactor * 2.8) + Math.sin(now * 0.0021) * 0.4;
            double pitchSway = Math.sin(now * 0.0009 + 1.5) * (0.8 + walkFactor * 2.0) + Math.sin(now * 0.0027 + 0.6) * 0.3;
            double rollSway = Math.sin(now * 0.00045) * (2.0 + walkFactor * 4.0);
            event.setYaw((float) (event.getYaw() + yawSway));
            event.setPitch((float) (event.getPitch() + pitchSway));
            event.setRoll((float) (event.getRoll() + rollSway));
        }
    }

    @SubscribeEvent
    public static void onRenderOverlayPre(RenderGuiOverlayEvent.Pre event) {
        Player entity = Minecraft.getInstance().player;
        if (VhsCameraTrueFalseProcedure.execute(entity)) {
            if (event.getOverlay() == VanillaGuiOverlay.HOTBAR.type()
                    || event.getOverlay() == VanillaGuiOverlay.CROSSHAIR.type()
                    || event.getOverlay() == VanillaGuiOverlay.PLAYER_HEALTH.type()
                    || event.getOverlay() == VanillaGuiOverlay.FOOD_LEVEL.type()
                    || event.getOverlay() == VanillaGuiOverlay.ARMOR_LEVEL.type()
                    || event.getOverlay() == VanillaGuiOverlay.AIR_LEVEL.type()
                    || event.getOverlay() == VanillaGuiOverlay.EXPERIENCE_BAR.type()
                    || event.getOverlay() == VanillaGuiOverlay.JUMP_BAR.type()
                    || event.getOverlay() == VanillaGuiOverlay.MOUNT_HEALTH.type()
                    || event.getOverlay() == VanillaGuiOverlay.ITEM_NAME.type()) {
                event.setCanceled(true);
            }
        }
    }
}
