package deskped.sped.client.screens;

import deskped.sped.SpedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class EdgeOverlay {

    private static final double BORDER_WARN = 9000.0;
    private static final double BORDER = 10000.0;

    @SubscribeEvent
    public static void onRenderHotbar(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        double x = Math.abs(mc.player.getX());
        double z = Math.abs(mc.player.getZ());

        if (x < BORDER_WARN && z < BORDER_WARN) return;

        String lang = mc.getLanguageManager().getSelected();
        String text = lang.startsWith("ru_") 
            ? "Это край нашего плоского мира, далее космос"
            : "This is the edge of our flat world, beyond that is space";

        GuiGraphics gui = event.getGuiGraphics();
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int screenHeight = mc.getWindow().getGuiScaledHeight();

        int textWidth = mc.font.width(text);
        int textX = (screenWidth - textWidth) / 2;
        int textY = screenHeight - 59;

        gui.drawString(mc.font, text, textX, textY, 0x55FFFF, true);
    }
}