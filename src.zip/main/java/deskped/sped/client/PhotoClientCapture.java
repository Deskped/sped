package deskped.sped.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.pipeline.RenderTarget;
import deskped.sped.SpedMod;
import deskped.sped.network.PhotoUploadPacket;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.UUID;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class PhotoClientCapture {

	private static final int TARGET_SIZE = 384;
	private static final int CHUNK = 28000;
	private static final int MAX_CHUNKS = 90;

	private static volatile boolean pending = false;
	private static boolean prevHideGui = false;
	private static volatile long flashStart = -100000L;

	public static void begin() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || pending)
			return;
		if (mc.player.getInventory().countItem(Items.PAPER) <= 0) {
			mc.player.displayClientMessage(Component.literal(isRu() ? "\u041d\u0443\u0436\u043d\u0430 \u0431\u0443\u043c\u0430\u0433\u0430" : "Paper required"), true);
			mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.DISPENSER_FAIL, 1.4f));
			return;
		}
		prevHideGui = mc.options.hideGui;
		mc.options.hideGui = true;
		pending = true;
	}

	@SubscribeEvent
	public static void onRenderTick(TickEvent.RenderTickEvent event) {
		if (event.phase != TickEvent.Phase.END || !pending)
			return;
		pending = false;
		Minecraft mc = Minecraft.getInstance();
		mc.options.hideGui = prevHideGui;
		if (mc.level == null || mc.player == null || mc.getConnection() == null)
			return;

		RenderTarget target = mc.getMainRenderTarget();
		int fw = target.width;
		int fh = target.height;
		int side = (int) (Math.min(fw, fh) * 0.75);
		if (side < 32)
			return;
		int left = (fw - side) / 2;
		int top = (fh - side) / 2;

		int dst = TARGET_SIZE;
		int[] argb = new int[dst * dst];
		NativeImage small = new NativeImage(NativeImage.Format.RGBA, dst, dst, false);
		try (NativeImage shot = Screenshot.takeScreenshot(target)) {
			for (int dy = 0; dy < dst; dy++) {
				int sy0 = top + dy * side / dst;
				int sy1 = top + Math.max((dy + 1) * side / dst, dy * side / dst + 1);
				for (int dx = 0; dx < dst; dx++) {
					int sx0 = left + dx * side / dst;
					int sx1 = left + Math.max((dx + 1) * side / dst, dx * side / dst + 1);
					long r = 0, g = 0, b = 0;
					int n = 0;
					for (int sy = sy0; sy < sy1; sy++) {
						for (int sx = sx0; sx < sx1; sx++) {
							int abgr = shot.getPixelRGBA(sx, sy);
							r += abgr & 0xFF;
							g += (abgr >>> 8) & 0xFF;
							b += (abgr >>> 16) & 0xFF;
							n++;
						}
					}
					int rr = (int) (r / n), gg = (int) (g / n), bb = (int) (b / n);
					argb[dy * dst + dx] = (rr << 16) | (gg << 8) | bb;
					small.setPixelRGBA(dx, dy, (0xFF << 24) | (bb << 16) | (gg << 8) | rr);
				}
			}
		} catch (Exception e) {
			SpedMod.LOGGER.error("photo capture failed", e);
			small.close();
			return;
		}

		UUID id = UUID.randomUUID();
		flashStart = System.currentTimeMillis();
		mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.LEVER_CLICK, 1.9f));
		PhotoClientCache.putReady(id, small);

		Util.backgroundExecutor().execute(() -> {
			try {
				BufferedImage img = new BufferedImage(dst, dst, BufferedImage.TYPE_INT_RGB);
				img.setRGB(0, 0, dst, dst, argb, 0, dst);
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				if (!ImageIO.write(img, "png", out))
					return;
				byte[] png = out.toByteArray();
				if (png.length == 0 || png.length > CHUNK * MAX_CHUNKS)
					return;
				int total = (png.length + CHUNK - 1) / CHUNK;
				Minecraft.getInstance().execute(() -> {
					if (Minecraft.getInstance().getConnection() == null)
						return;
					for (int i = 0; i < total; i++) {
						int off = i * CHUNK;
						byte[] part = Arrays.copyOfRange(png, off, Math.min(off + CHUNK, png.length));
						SpedMod.PACKET_HANDLER.sendToServer(new PhotoUploadPacket(id, total, i, part));
					}
				});
			} catch (Exception e) {
				SpedMod.LOGGER.error("photo encode failed", e);
			}
		});
	}

	public static float flashAlpha() {
		long dt = System.currentTimeMillis() - flashStart;
		if (dt < 0 || dt > 450)
			return 0f;
		return 1f - dt / 450f;
	}

	private static boolean isRu() {
		try {
			String lang = Minecraft.getInstance().getLanguageManager().getSelected();
			return lang != null && lang.startsWith("ru");
		} catch (Exception e) {
			return false;
		}
	}
}
