package deskped.sped.client;

public class ClientMenuState {
    public static boolean customMenu = true;
    public static boolean confirmed  = false;
}
