package deskped.sped.client;

import deskped.sped.client.overlay.BackpackAnimationOverlay;
import deskped.sped.client.overlay.CrusherAnimationOverlay;
import deskped.sped.client.renderer.CrusherBEWLR;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(
            CrusherBEWLR.CrusherItemModel.LAYER_LOCATION,
            CrusherBEWLR.CrusherItemModel::createBodyLayer
        );
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "crusher_animation", new CrusherAnimationOverlay());
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "backpack_animation", new BackpackAnimationOverlay());
    }
}