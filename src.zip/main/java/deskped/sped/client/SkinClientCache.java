package deskped.sped.client;

import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.blaze3d.platform.NativeImage;
import deskped.sped.SpedMod;
import deskped.sped.network.SkinRequestPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "sped")
public class SkinClientCache {

	public static class Entry {
		public ResourceLocation skin;
		public boolean slim;
		public ResourceLocation cape;
	}

	private static final Map<UUID, Entry> ENTRIES = new ConcurrentHashMap<>();
	private static boolean requested;
	private static Field texturesField;
	private static Field modelField;
	private static Field pendingField;
	private static boolean resolved;

	public static void handle(UUID owner, int type, boolean slim, byte[] data) {
		Minecraft mc = Minecraft.getInstance();
		if (data == null || data.length == 0) {
			clearType(owner, type);
			return;
		}
		try {
			NativeImage image = NativeImage.read(new ByteArrayInputStream(data));
			if (type == 0)
				image = processSkin(image);
			ResourceLocation loc = new ResourceLocation("sped", "skins/" + owner.toString().replace("-", "") + (type == 1 ? "_cape" : "_skin"));
			mc.getTextureManager().register(loc, new DynamicTexture(image));
			Entry entry = ENTRIES.computeIfAbsent(owner, k -> new Entry());
			if (type == 1) {
				entry.cape = loc;
			} else {
				entry.skin = loc;
				entry.slim = slim;
			}
			apply(owner, entry);
		} catch (Exception e) {
			SpedMod.LOGGER.error("[sped skins] client load failed", e);
		}
	}

	public static Entry entry(UUID owner) {
		return ENTRIES.get(owner);
	}

	private static void apply(UUID owner, Entry entry) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.getConnection() == null)
			return;
		PlayerInfo info = mc.getConnection().getPlayerInfo(owner);
		if (info == null)
			return;
		Map<MinecraftProfileTexture.Type, ResourceLocation> map = textures(info);
		if (map == null)
			return;
		if (entry.skin != null) {
			map.put(MinecraftProfileTexture.Type.SKIN, entry.skin);
			setModel(info, entry.slim ? "slim" : "default");
			setPending(info, true);
		}
		if (entry.cape != null)
			map.put(MinecraftProfileTexture.Type.CAPE, entry.cape);
	}

	private static void clearType(UUID owner, int type) {
		Entry entry = ENTRIES.get(owner);
		if (entry == null)
			return;
		if (type == 1)
			entry.cape = null;
		else
			entry.skin = null;
		Minecraft mc = Minecraft.getInstance();
		PlayerInfo info = mc.getConnection() != null ? mc.getConnection().getPlayerInfo(owner) : null;
		if (info != null) {
			Map<MinecraftProfileTexture.Type, ResourceLocation> map = textures(info);
			if (map != null) {
				if (type == 1) {
					map.remove(MinecraftProfileTexture.Type.CAPE);
				} else {
					map.remove(MinecraftProfileTexture.Type.SKIN);
					setModel(info, null);
					setPending(info, false);
				}
			}
		}
		if (entry.skin == null && entry.cape == null)
			ENTRIES.remove(owner);
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.getConnection() == null) {
			requested = false;
			return;
		}
		if (!requested && mc.player != null && mc.level != null) {
			requested = true;
			SpedMod.PACKET_HANDLER.sendToServer(new SkinRequestPacket());
		}
		if (ENTRIES.isEmpty())
			return;
		for (Map.Entry<UUID, Entry> e : ENTRIES.entrySet()) {
			PlayerInfo info = mc.getConnection().getPlayerInfo(e.getKey());
			if (info == null)
				continue;
			Map<MinecraftProfileTexture.Type, ResourceLocation> map = textures(info);
			if (map == null)
				return;
			Entry entry = e.getValue();
			if (entry.skin != null) {
				String want = entry.slim ? "slim" : "default";
				if (!entry.skin.equals(map.get(MinecraftProfileTexture.Type.SKIN)) || !want.equals(info.getModelName())) {
					map.put(MinecraftProfileTexture.Type.SKIN, entry.skin);
					setModel(info, want);
					setPending(info, true);
				}
			}
			if (entry.cape != null && !entry.cape.equals(map.get(MinecraftProfileTexture.Type.CAPE)))
				map.put(MinecraftProfileTexture.Type.CAPE, entry.cape);
		}
	}

	@SubscribeEvent
	public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
		ENTRIES.clear();
		requested = false;
	}

	@SubscribeEvent
	public static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
		ENTRIES.clear();
		requested = false;
	}

	private static NativeImage processSkin(NativeImage image) {
		if (image.getWidth() != 64)
			return image;
		boolean legacy = image.getHeight() == 32;
		if (legacy) {
			NativeImage expanded = new NativeImage(64, 64, true);
			expanded.copyFrom(image);
			image.close();
			image = expanded;
			image.fillRect(0, 32, 64, 32, 0);
			image.copyRect(4, 16, 16, 32, 4, 4, true, false);
			image.copyRect(8, 16, 16, 32, 4, 4, true, false);
			image.copyRect(0, 20, 24, 32, 4, 12, true, false);
			image.copyRect(4, 20, 16, 32, 4, 12, true, false);
			image.copyRect(8, 20, 8, 32, 4, 12, true, false);
			image.copyRect(12, 20, 16, 32, 4, 12, true, false);
			image.copyRect(44, 16, -8, 32, 4, 4, true, false);
			image.copyRect(48, 16, -8, 32, 4, 4, true, false);
			image.copyRect(40, 20, 0, 32, 4, 12, true, false);
			image.copyRect(44, 20, -8, 32, 4, 12, true, false);
			image.copyRect(48, 20, -16, 32, 4, 12, true, false);
			image.copyRect(52, 20, -8, 32, 4, 12, true, false);
		}
		if (image.getHeight() != 64)
			return image;
		opaque(image, 0, 0, 32, 16);
		opaque(image, 0, 16, 64, 32);
		opaque(image, 16, 48, 48, 64);
		notch(image, 32, 0, 64, 32);
		notch(image, 0, 32, 16, 48);
		notch(image, 16, 32, 40, 48);
		notch(image, 40, 32, 56, 48);
		notch(image, 0, 48, 16, 64);
		notch(image, 48, 48, 64, 64);
		return image;
	}

	private static void opaque(NativeImage image, int x0, int y0, int x1, int y1) {
		for (int y = y0; y < y1; y++)
			for (int x = x0; x < x1; x++)
				image.setPixelRGBA(x, y, image.getPixelRGBA(x, y) | 0xFF000000);
	}

	private static void notch(NativeImage image, int x0, int y0, int x1, int y1) {
		for (int x = x0; x < x1; x++)
			for (int y = y0; y < y1; y++)
				if ((image.getPixelRGBA(x, y) >> 24 & 0xFF) < 128)
					return;
		for (int x = x0; x < x1; x++)
			for (int y = y0; y < y1; y++)
				image.setPixelRGBA(x, y, image.getPixelRGBA(x, y) & 0x00FFFFFF);
	}

	private static void resolve() {
		if (resolved)
			return;
		resolved = true;
		List<Field> booleans = new ArrayList<>();
		for (Field f : PlayerInfo.class.getDeclaredFields()) {
			if (texturesField == null && Map.class.isAssignableFrom(f.getType())) {
				Type generic = f.getGenericType();
				if (generic instanceof ParameterizedType pt && pt.getActualTypeArguments().length == 2 && pt.getActualTypeArguments()[1] == ResourceLocation.class) {
					f.setAccessible(true);
					texturesField = f;
				}
			} else if (modelField == null && f.getType() == String.class) {
				f.setAccessible(true);
				modelField = f;
			} else if (f.getType() == boolean.class) {
				booleans.add(f);
			}
		}
		if (texturesField == null) {
			for (Field f : PlayerInfo.class.getDeclaredFields()) {
				if (Map.class.isAssignableFrom(f.getType())) {
					f.setAccessible(true);
					texturesField = f;
					break;
				}
			}
		}
		if (booleans.size() == 1) {
			pendingField = booleans.get(0);
			pendingField.setAccessible(true);
		}
		if (texturesField == null)
			SpedMod.LOGGER.error("[sped skins] textures field not found");
	}

	@SuppressWarnings("unchecked")
	private static Map<MinecraftProfileTexture.Type, ResourceLocation> textures(PlayerInfo info) {
		resolve();
		if (texturesField == null)
			return null;
		try {
			return (Map<MinecraftProfileTexture.Type, ResourceLocation>) texturesField.get(info);
		} catch (Exception e) {
			return null;
		}
	}

	private static void setModel(PlayerInfo info, String value) {
		resolve();
		if (modelField == null)
			return;
		try {
			modelField.set(info, value);
		} catch (Exception ignored) {
		}
	}

	private static void setPending(PlayerInfo info, boolean value) {
		resolve();
		if (pendingField == null)
			return;
		try {
			pendingField.setBoolean(info, value);
		} catch (Exception ignored) {
		}
	}
}
