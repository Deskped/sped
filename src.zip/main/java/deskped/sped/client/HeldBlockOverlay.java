package deskped.sped.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import deskped.sped.capability.HeldBlockCapability;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.world.phys.Vec3;

public class HeldBlockOverlay {

    @SubscribeEvent
    public static void onRenderWorldLast(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) return;

        player.getCapability(HeldBlockCapability.HELD_BLOCK).ifPresent(cap -> {
            if (!cap.isHolding()) return;

            BlockState state = cap.getHeldState();
            float rotation = cap.getRotationAngle() + event.getPartialTick() * 4f;

            PoseStack poseStack = event.getPoseStack();
            MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();

            Vec3 cam = event.getCamera().getPosition();

            double eyeX = player.getX() - cam.x;
            double eyeY = player.getY() + player.getEyeHeight() - cam.y;
            double eyeZ = player.getZ() - cam.z;

            float yaw = (float) Math.toRadians(player.getYRot());
            float pitch = (float) Math.toRadians(player.getXRot());

            double holdDist = 2.5;
            double dx = -Math.sin(yaw) * Math.cos(pitch) * holdDist;
            double dy = -Math.sin(pitch) * holdDist;
            double dz = Math.cos(yaw) * Math.cos(pitch) * holdDist;

            poseStack.pushPose();
            poseStack.translate(eyeX + dx, eyeY + dy, eyeZ + dz);
            poseStack.mulPose(Axis.YP.rotationDegrees(rotation));
            poseStack.mulPose(Axis.XP.rotationDegrees(rotation * 0.5f));
            poseStack.translate(-0.5, -0.5, -0.5);

            BlockRenderDispatcher dispatcher = mc.getBlockRenderer();
            dispatcher.renderSingleBlock(state, poseStack, bufferSource, 0xF000F0, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);

            bufferSource.endBatch();
            poseStack.popPose();
        });
    }
}
