package deskped.sped.client;

import deskped.sped.client.gui.MenuRaceScreen;
import deskped.sped.race.RaceLevels;
import deskped.sped.world.inventory.MenuRaceMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@OnlyIn(Dist.CLIENT)
public class RaceClientHandler {

	@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ModBus {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			event.enqueueWork(() -> MenuScreens.register(MenuRaceMenu.TYPE, MenuRaceScreen::new));
		}
	}

	@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
	public static class ForgeBus {
		private static int hopCombo;
		private static int groundTicks = 100;

		@SubscribeEvent
		public static void fov(ComputeFovModifierEvent event) {
			if (ClientRaceState.has("GOBLIN"))
				event.setNewFovModifier(1.0f);
		}

		@SubscribeEvent
		public static void onJump(LivingEvent.LivingJumpEvent event) {
			Minecraft mc = Minecraft.getInstance();
			LocalPlayer p = mc.player;
			if (p == null || event.getEntity() != p)
				return;
			if (!ClientRaceState.has("WINGED"))
				return;
			if (RaceLevels.buffs(RaceLevels.level(ClientRaceState.xp("WINGED"))) < 3)
				return;
			if (p.getAbilities().flying || p.isPassenger() || p.isInWater() || p.isInLava())
				return;
			Vec3 dm = p.getDeltaMovement();
			double hsp = Math.sqrt(dm.x * dm.x + dm.z * dm.z);
			if (hsp < 0.05) {
				hopCombo = 0;
				return;
			}
			hopCombo = groundTicks <= 7 ? Math.min(hopCombo + 1, 12) : 1;
			if (hopCombo < 2)
				return;
			double scale = 1.0 + 0.07 * hopCombo;
			double nx = dm.x * scale;
			double nz = dm.z * scale;
			double nsp = Math.sqrt(nx * nx + nz * nz);
			double cap = 1.4;
			if (nsp > cap) {
				nx = nx / nsp * cap;
				nz = nz / nsp * cap;
			}
			p.setDeltaMovement(nx, dm.y, nz);
			p.playSound(SoundEvents.AMETHYST_BLOCK_STEP, 0.35f, 0.7f + Math.min(hopCombo, 10) * 0.08f);
			for (int i = 0; i < 4; i++)
				p.level().addParticle(ParticleTypes.CLOUD, p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.4, p.getY() + 0.05, p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.4, -nx * 0.2, 0.01, -nz * 0.2);
		}

		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (event.phase != TickEvent.Phase.END)
				return;
			LocalPlayer p = Minecraft.getInstance().player;
			if (p == null)
				return;
			if (p.onGround()) {
				if (groundTicks < 100)
					groundTicks++;
				if (groundTicks > 7)
					hopCombo = 0;
			} else
				groundTicks = 0;
		}
	}
}
