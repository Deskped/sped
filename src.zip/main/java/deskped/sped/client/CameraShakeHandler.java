package deskped.sped.client;

import deskped.sped.init.SpedModMobEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class CameraShakeHandler {

    private static final float SHAKE_YAW_AMP   = 1.2f;
    private static final float SHAKE_PITCH_AMP = 0.6f;
    private static final float SHAKE_SPEED      = 0.08f;

    private static final float EXPLODE_YAW_AMP   = 3.5f;
    private static final float EXPLODE_PITCH_AMP = 2.0f;
    private static final float EXPLODE_SPEED      = 0.22f;

    @SubscribeEvent
    public static void onCameraSetup(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        Player player = mc.player;
        long time = player.tickCount;
        float t = (float)((time + event.getPartialTick()) * 20.0);

        boolean hasShake   = player.hasEffect(SpedModMobEffects.SHAKE.get());
        boolean hasExplode = player.hasEffect(SpedModMobEffects.EXPLODE.get());

        if (!hasShake && !hasExplode) return;

        float yaw   = event.getYaw();
        float pitch = event.getPitch();

        if (hasShake) {
            float s = SHAKE_SPEED;
            yaw   += SHAKE_YAW_AMP   * (Math.sin(t * s) * 0.7f + Math.sin(t * s * 1.7f) * 0.3f);
            pitch += SHAKE_PITCH_AMP * (Math.sin(t * s * 1.3f) * 0.6f + Math.sin(t * s * 2.3f) * 0.4f);
        }

        if (hasExplode) {
            float s = EXPLODE_SPEED;
            yaw   += EXPLODE_YAW_AMP   * (Math.sin(t * s) * 0.5f + Math.sin(t * s * 2.1f) * 0.3f + Math.sin(t * s * 3.7f) * 0.2f);
            pitch += EXPLODE_PITCH_AMP * (Math.sin(t * s * 1.6f) * 0.5f + Math.sin(t * s * 2.9f) * 0.3f + Math.sin(t * s * 4.3f) * 0.2f);
        }

        event.setYaw(yaw);
        event.setPitch(pitch);
    }
}