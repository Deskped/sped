package deskped.sped.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class PocketDimWarningScreen extends Screen {

	private final boolean ru;

	public PocketDimWarningScreen() {
		super(Component.empty());
		this.ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
	}

	@Override
	protected void init() {
		int bw = 96;
		int bh = 20;
		this.addRenderableWidget(Button.builder(
				Component.literal(ru ? "Понял" : "Got it"),
				b -> this.onClose()
		).bounds(this.width / 2 - bw / 2, this.height / 2 + 26, bw, bh).build());
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		this.renderBackground(g);
		String title = ru ? "ВНИМАНИЕ" : "WARNING";
		String line = ru
				? "Попав в карманное измерение машины портала назад не будет."
				: "Once inside the portal machine's pocket dimension, there is no way back.";
		int cx = this.width / 2;
		g.drawCenteredString(this.font, title, cx, this.height / 2 - 42, 0xFF5555);
		int ty = this.height / 2 - 24;
		var lines = this.font.split(Component.literal(line), 300);
		for (var seq : lines) {
			g.drawCenteredString(this.font, seq, cx, ty, 0xFFFFFF);
			ty += 11;
		}
		super.render(g, mx, my, partial);
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}
}
