package deskped.sped.client;
import net.minecraft.client.Minecraft;
public class Lang {
    private static boolean isRu() {
        try {
            String lang = Minecraft.getInstance().getLanguageManager().getSelected();
            return lang != null && lang.startsWith("ru");
        } catch (Exception e) {
            return false;
        }
    }
    public static String map_title()    { return isRu() ? "КАРТА OverPED"   : "OverPED MAP"; }
    public static String key_open_map() { return isRu() ? "Открыть карту"   : "Open map"; }
    public static String key_category() { return "OverPED"; }
    public static String claim_free()   { return isRu() ? "Свободный чанк"  : "Free chunk"; }
    public static String claim_yours()  { return isRu() ? "Ваш приват"       : "Your claim"; }
    public static String claim_other()  { return isRu() ? "Чужой приват"     : "Someone else's"; }
    public static String claim_count(int used, int max) {
        return isRu()
            ? "Ваши приваты: " + used + " / " + max
            : "Your claims: " + used + " / " + max;
    }
    public static String claim_footer() {
        return isRu()
            ? "Неактивные игроки теряют приваты через 7 дней"
            : "Inactive players lose claims after 7 days";
    }
    public static String claim_full() {
        return isRu()
            ? "Достигнут максимум приватов (33)"
            : "Maximum claims reached (33)";
    }
    public static String claim_taken() {
        return isRu() ? "Этот чанк уже занят" : "This chunk is already claimed";
    }
    public static String claim_notowner() {
        return isRu() ? "Нельзя убрать чужой приват" : "Cannot remove someone else's claim";
    }
    public static String cmd_map_hint() {
        return isRu()
            ? "Нажмите M чтобы открыть карту (переназначить в управлении)"
            : "Press M to open the map (rebind in controls)";
    }
    public static String trust_open_btn()   { return isRu() ? "Доступ к привату ▶" : "Claim Access ▶"; }
    public static String trust_title()      { return isRu() ? "ДОСТУП К ПРИВАТУ"    : "CLAIM ACCESS"; }
    public static String trust_add()        { return isRu() ? "Добавить"            : "Add"; }
    public static String trust_kick()       { return isRu() ? "Кикнуть"                 : "Kick"; }
    public static String trust_placeholder(){ return isRu() ? "Ник игрока..."       : "Player name..."; }
    public static String trust_empty()      { return isRu() ? "Нет игроков в привате" : "No players in claim"; }
}