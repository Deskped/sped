package deskped.sped.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import deskped.sped.SpedMod;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.loading.FMLPaths;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@OnlyIn(Dist.CLIENT)
public class IntroScreen extends Screen {

	private static final int TEX_W = 1024;
	private static final int TEX_H = 576;
	private static final int SLIDES = 12;

	private static final long FADE_IN_MS = 650L;
	private static final long FADE_OUT_MS = 650L;
	private static final long CHAR_MS = 26L;
	private static final long TAP_MS = 260L;
	private static final long SKIP_HOLD_MS = 1300L;

	private static final float TEXT_SCALE = 1.25f;
	private static final int GOLD = 0xEDB55D;

	private static final int PHASE_FADE_IN = 0;
	private static final int PHASE_TYPE = 1;
	private static final int PHASE_HOLD = 2;
	private static final int PHASE_FADE_OUT = 3;

	private static Boolean seenCache;

	private static final ResourceLocation[] TEX = new ResourceLocation[SLIDES];
	static {
		for (int i = 0; i < SLIDES; i++)
			TEX[i] = new ResourceLocation("sped", String.format("textures/screens/intro/slide_%02d.png", i + 1));
	}

	private static final ResourceLocation SPR_PLATFORM = new ResourceLocation("sped", "textures/screens/intro/spr_platform.png");
	private static final ResourceLocation SPR_PERF = new ResourceLocation("sped", "textures/screens/intro/spr_perfonov.png");
	private static final ResourceLocation SPR_RELE = new ResourceLocation("sped", "textures/screens/intro/spr_relegant.png");
	private static final ResourceLocation SPR_NOVAM = new ResourceLocation("sped", "textures/screens/intro/spr_novam.png");
	private static final ResourceLocation SPR_PAPER = new ResourceLocation("sped", "textures/screens/intro/spr_paper.png");
	private static final ResourceLocation SPR_ENNA = new ResourceLocation("sped", "textures/screens/intro/spr_enna.png");
	private static final ResourceLocation SPR_TIKH = new ResourceLocation("sped", "textures/screens/intro/spr_tikhon.png");

	private static final float[][] PLATFORMS = {
			{ 180, 150, 130 }, { 355, 105, 105 }, { 700, 120, 125 }, { 868, 200, 115 },
			{ 200, 420, 135 }, { 505, 470, 150 }, { 830, 430, 130 }
	};

	private static final int[][] STAR_PAIRS = {
			{ 0xFFFFFF, 0xE8E0FC }, { 0xFFFFFF, 0xD8EFFF }, { 0xFFFFFF, 0xFFD5FF },
			{ 0xFFFFFF, 0xD4DEF8 }, { 0xFFFFFF, 0xFB97AD }, { 0xFFFFFF, 0xFFFFFF }, { 0xFFEBF2, 0xFFFFFF }
	};

	private static final String[] RU_TEXT = {
			"\u0414\u0430\u0432\u043d\u044b\u043c \u0434\u0430\u0432\u043d\u043e \u0417\u0435\u043c\u043b\u044f \u0436\u0438\u043b\u0430 \u043a\u0430\u043a \u043f\u0440\u0435\u0436\u0434\u0435.\n\u041e\u0434\u043d\u0430\u0436\u0434\u044b \u043e\u0431\u0441\u0435\u0440\u0432\u0430\u0442\u043e\u0440\u0438\u0438 \u0443\u043b\u043e\u0432\u0438\u043b\u0438 \u0441\u0438\u0433\u043d\u0430\u043b.\n\u041e\u043d \u0448\u0451\u043b \u043d\u0435 \u0438\u0437 \u043a\u043e\u0441\u043c\u043e\u0441\u0430.\n\u041e\u043d \u0448\u0451\u043b \u0438\u0437 \u0441\u0430\u043c\u043e\u0439 \u0417\u0435\u043c\u043b\u0438.",
			"\u042d\u043a\u0441\u043f\u0435\u0434\u0438\u0446\u0438\u044f Undertaking Frendler \u043d\u0430\u0448\u043b\u0430 \u0432 \u043b\u0435\u0441\u0430\u0445 \u041d\u043e\u0432\u043e\u043b\u044d\u0440\u044b\n\u043f\u0435\u0449\u0435\u0440\u0443 \u043f\u043e\u043b\u043d\u0443\u044e \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b\u043e\u0432.\n\u0414\u044f\u0434\u044f \u0428\u0430\u043b\u044f, \u0410\u0446\u0435\u043d\u0442\u0438\u0443\u0441, \u0437\u0430\u0445\u0432\u0430\u0442\u0438\u043b \u0435\u0451.\n\u041e\u0442\u0434\u0435\u043b\u0435\u043d\u0438\u0435 Frendler \u043e\u043d \u043f\u0435\u0440\u0435\u0438\u043c\u0435\u043d\u043e\u0432\u0430\u043b \u0432 CorPED,\n\u0430 \u041d\u043e\u0432\u043e\u043b\u044d\u0440\u0443 \u043d\u0430\u043a\u0440\u044b\u043b \u043a\u0443\u043f\u043e\u043b\u043e\u043c.",
			"\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b, \u0431\u0440\u043e\u0448\u0435\u043d\u043d\u044b\u0435 \u0432 \u043f\u0435\u0449\u0435\u0440\u0443, \u043c\u0435\u043d\u044f\u043b\u0438\u0441\u044c.\n\u041f\u043e\u0437\u043e\u043b\u043e\u0447\u0435\u043d\u043d\u043e\u0435 \u043e\u0436\u0435\u0440\u0435\u043b\u044c\u0435 \u0442\u0440\u0438\u0436\u0434\u044b \u0440\u0430\u0437\u0440\u0430\u0441\u0442\u0430\u043b\u043e\u0441\u044c \u0432 \u043b\u0430\u0442\u0443\u043d\u043d\u044b\u0439 \u0434\u0438\u0441\u043a.\n\u0422\u0430\u043a \u043f\u043e\u043b\u0443\u0447\u0438\u043b\u0438 \u0440\u043e\u0432\u043d\u043e \u0442\u0440\u0438 \u041d\u043e\u0432\u0430\u043c\u0430.\n\u0422\u0443\u043c\u0430\u043d\u0438\u0442\u043e\u0432\u044b\u0439 \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b \u0434\u0430\u043b \u0420\u044d\u043b\u0435, \u043c\u0433\u043d\u043e\u0432\u0435\u043d\u043d\u043e\u0435 \u0438\u0441\u0446\u0435\u043b\u0435\u043d\u0438\u0435.\n\u041d\u043e\u0432\u0430\u043c \u0436\u0435 \u043e\u0442\u0440\u0430\u0436\u0430\u043b \u044f\u0437\u044b\u043a \u0438 \u0441\u043c\u044b\u0441\u043b \u0432 \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b\u044b.\n\u041c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0434\u043b\u044f \u043c\u0430\u0433\u0438\u0438, \u043b\u0438\u0448\u0451\u043d\u043d\u044b\u0439 \u0440\u0430\u0437\u0443\u043c\u0430.",
			"\u0428\u0430\u043b\u044c, \u043f\u043b\u0435\u043c\u044f\u043d\u043d\u0438\u043a \u0410\u0446\u0435\u043d\u0442\u0438\u0443\u0441\u0430, \u0437\u0430\u0434\u044b\u0445\u0430\u043b\u0441\u044f \u043e\u0442 \u0432\u043e\u0439\u043d\u044b \u0438 \u0433\u043e\u043b\u043e\u0434\u0430.\n\u041e\u043d \u043f\u0438\u0441\u0430\u043b \u0441\u043e\u0442\u043d\u0438 \u043c\u0438\u0440\u043e\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432. \u041c\u0438\u0440\u044b, \u0433\u0434\u0435 \u043d\u0435\u0442 \u0432\u043e\u0439\u043d.\n\u041d\u043e\u0432\u0430\u043c \u0432\u0438\u0441\u0435\u043b \u043d\u0430 \u0435\u0433\u043e \u0441\u0442\u0435\u043d\u0435 \u0438 \u043f\u0443\u0442\u0430\u043b \u043c\u044b\u0441\u043b\u0438 \u043a\u043d\u0438\u0433\u0430\u043c\u0438 \u0438 \u044d\u043a\u0440\u0430\u043d\u043e\u043c.\n\u041f\u0440\u043e\u0440\u0432\u0430\u0432\u0448\u0438\u0441\u044c \u0432 \u043f\u0435\u0449\u0435\u0440\u0443, \u043f\u0435\u0440\u0435\u0434 \u0433\u0438\u0431\u0435\u043b\u044c\u044e\n\u0428\u0430\u043b\u044c \u0432\u044b\u0440\u043e\u043d\u0438\u043b \u041d\u043e\u0432\u0430\u043c \u0432\u043c\u0435\u0441\u0442\u0435 \u0441 \u043c\u044f\u0442\u044b\u043c \u043b\u0438\u0441\u0442\u043e\u043c.",
			"\u041d\u043e\u0432\u0430\u043c \u043d\u0435 \u0438\u043c\u0435\u043b \u0440\u0430\u0437\u0443\u043c\u0430.\n\u041e\u043d \u0441\u0442\u0430\u043b \u0432\u043e\u043f\u043b\u043e\u0449\u0430\u0442\u044c \u043d\u0430\u043f\u0438\u0441\u0430\u043d\u043d\u043e\u0435 \u043d\u0430 \u043b\u0438\u0441\u0442\u0435.\n\u0417\u0435\u043c\u043b\u044f \u0440\u0430\u0441\u043a\u043e\u043b\u043e\u043b\u0430\u0441\u044c \u043d\u0430 \u0441\u0435\u043c\u044c \u043f\u043b\u043e\u0441\u043a\u0438\u0445 \u043c\u0438\u0440\u043e\u0432.\n\u0412 \u0446\u0435\u043d\u0442\u0440\u0435 \u0432\u043e\u0441\u0441\u0442\u0430\u043b\u0430 \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u044c\u043d\u0430\u044f \u043f\u043b\u0430\u043d\u0435\u0442\u0430.\n\u0415\u0451 \u043d\u0430\u0437\u0432\u0430\u043b\u0438 \u041d\u043e\u0432\u043e\u0439.",
			"\u0421\u0442\u0440\u043e\u043a\u0438 \u043c\u044f\u0442\u043e\u0433\u043e \u043b\u0438\u0441\u0442\u0430 \u043d\u0430\u0437\u043d\u0430\u0447\u0438\u043b\u0438 \u0447\u0435\u0442\u044b\u0440\u0451\u0445 \u0421\u0442\u0440\u0430\u0436\u0435\u0439.\n\u041c\u0438\u0440\u043e\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e \u0428\u0430\u043b\u044f \u043e\u0431\u0440\u0435\u043b\u043e \u043f\u043b\u043e\u0442\u044c.\n\u041b\u044e\u0434\u0438 \u043e\u0442\u0441\u0442\u0440\u043e\u0438\u043b\u0438\u0441\u044c \u0438 \u0440\u0430\u0441\u0446\u0432\u0435\u043b\u0438.\n\u041d\u043e\u0432\u0430 \u0441\u0442\u0430\u043b\u0430 \u0434\u043e\u043c\u043e\u043c \u0434\u043b\u044f \u0432\u0441\u0435\u0445.",
			"\u041d\u043e \u0434\u0432\u043e\u0435 \u043d\u0435 \u0441\u043c\u043e\u0433\u043b\u0438 \u0437\u0430\u0431\u044b\u0442\u044c \u0417\u0435\u043c\u043b\u044e.\n\u042d\u043d\u043d\u0430 \u0438 \u0422\u0438\u0445\u043e\u043d \u0432\u043e\u0441\u0441\u0442\u0430\u043b\u0438 \u043f\u0440\u043e\u0442\u0438\u0432 \u041d\u043e\u0432\u044b.\n\u041e\u043d\u0438 \u0440\u0435\u0448\u0438\u043b\u0438 \u0440\u0430\u0437\u043e\u0431\u0440\u0430\u0442\u044c \u043c\u0438\u0440\u044b \u0434\u043e \u0431\u043b\u043e\u043a\u043e\u0432\n\u0438 \u0432\u0435\u0440\u043d\u0443\u0442\u044c \u0417\u0435\u043c\u043b\u044e.",
			"\u041d\u0430\u0447\u0430\u043b\u0430\u0441\u044c \u0432\u043e\u0439\u043d\u0430 \u0437\u0430 \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0435\u043d\u0438\u0435 \u0417\u0435\u043c\u043b\u0438.\n\u0421\u0442\u0440\u0430\u0436\u0438 \u043f\u0430\u043b\u0438 \u043e\u0434\u0438\u043d \u0437\u0430 \u0434\u0440\u0443\u0433\u0438\u043c.\n\u0412\u0441\u043f\u044b\u0448\u043a\u0438 \u043e\u0442\u0434\u0430\u0432\u0430\u043b\u0438 \u0441\u0432\u0435\u0442 \u041d\u043e\u0432\u044b.\n\u0417\u0430\u0442\u043c\u0435\u043d\u0438\u044f \u0437\u0430\u0431\u0438\u0440\u0430\u043b\u0438 \u0432\u0441\u0451.",
			"\u0412\u0441\u0451 \u044d\u0442\u043e \u043f\u043e\u0432\u0442\u043e\u0440\u044f\u0435\u0442\u0441\u044f \u0443\u0436\u0435 83 \u0440\u0430\u0437\u0430.\n\u041a\u0430\u0436\u0434\u044b\u0439 \u0446\u0438\u043a\u043b \u043f\u043e \u043e\u043a\u043e\u043d\u0447\u0430\u043d\u0438\u0438 \u0442\u0440\u0451\u0445 \u043b\u0435\u0442 \u0432\u043e\u0437\u043e\u0431\u043d\u043e\u0432\u043b\u044f\u0435\u0442\u0441\u044f.\n\u041f\u0440\u043e\u0448\u043b\u043e \u0432\u043e\u0432\u0441\u0435 \u043d\u0435 83 \u0433\u043e\u0434\u0430,\n\u0430 \u0432\u043e\u0441\u0435\u043c\u044c \u0446\u0438\u043a\u043b\u043e\u0432 \u043f\u043e \u0442\u0440\u0438 \u0433\u043e\u0434\u0430.",
			"\u041f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439 \u043c\u0438\u0440 \u0437\u043e\u0432\u0451\u0442\u0441\u044f \u0420\u041f\u0415\u0414.\n\u041d\u0430\u0434 \u043d\u0438\u043c \u0441\u043e\u0448\u043b\u0438\u0441\u044c \u0434\u0432\u043e\u0435.\n\u041f\u0435\u0440\u0444\u043e\u043d\u043e\u0432 \u0436\u0435\u043b\u0430\u0435\u0442, \u0447\u0442\u043e\u0431\u044b \u0438\u0441\u0442\u043e\u0440\u0438\u044f \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0430\u043b\u0430\u0441\u044c.\n\u0420\u0435\u043b\u0435\u0433\u0430\u043d\u0442 \u0436\u0435\u043b\u0430\u0435\u0442, \u0447\u0442\u043e\u0431\u044b \u0432\u0441\u0451 \u0437\u0430\u043a\u043e\u043d\u0447\u0438\u043b\u043e\u0441\u044c.\n\u041f\u043e\u0431\u0435\u0434\u0430 \u041f\u0435\u0440\u0444\u043e\u043d\u043e\u0432\u0430 \u043d\u0430\u0447\u043d\u0451\u0442 90 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b.\n\u041f\u043e\u0431\u0435\u0434\u0430 \u0420\u0435\u043b\u0435\u0433\u0430\u043d\u0442\u0430 \u043e\u043a\u043e\u043d\u0447\u0438\u0442 \u0438\u0441\u0442\u043e\u0440\u0438\u0438 \u0447\u0435\u0440\u043d\u043e\u0442\u043e\u0439.",
			"\u041e\u043d\u0438 \u0438\u0433\u0440\u0430\u044e\u0442 \u043b\u044e\u0434\u044c\u043c\u0438.\n\u041a\u0430\u0436\u0434\u044b\u0439 \u0442\u0432\u043e\u0439 \u0448\u0430\u0433 \u0435\u0441\u0442\u044c \u0445\u043e\u0434 \u043e\u0434\u043d\u043e\u0433\u043e \u0438\u0437 \u043d\u0438\u0445.\n\u041c\u044f\u0442\u0430\u044f \u0431\u0443\u043c\u0430\u0436\u043a\u0430 \u0432\u043d\u0443\u0442\u0440\u0438 \u041f\u0435\u0440\u0444\u043e\u043d\u043e\u0432\u0430 \u0440\u0432\u0451\u0442\u0441\u044f \u0438 \u0438\u0441\u043a\u0430\u0436\u0430\u0435\u0442\u0441\u044f.\n\u0418\u0441\u0442\u043e\u0440\u0438\u044f \u0438 \u043c\u0438\u0440\u043e\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e \u0428\u0430\u043b\u044f \u0440\u0443\u0448\u0438\u0442\u0441\u044f.\n\u0412\u044b\u0431\u0435\u0440\u0438 \u0441\u0442\u043e\u0440\u043e\u043d\u0443.\n\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0430\u0442\u044c \u043b\u0438 \u0438\u0441\u0442\u043e\u0440\u0438\u044e \u0435\u0449\u0451 \u043d\u0430 \u043e\u0434\u0438\u043d \u0446\u0438\u043a\u043b \u043f\u0430\u0440\u0442\u0438\u0439?",
			"\u0421\u0435\u0439\u0447\u0430\u0441 \u043a\u043e\u043d\u0435\u0446 \u043f\u0435\u0440\u0432\u043e\u0433\u043e \u0442\u043e\u043c\u0430 \u043a\u043d\u0438\u0433\u0438 \u041d\u043e\u0432\u044b\n\u041a\u0443\u0437\u044c\u043c\u044b \u0418\u0437\u044a\u044f\u043d\u043e\u0432\u0430.\n\u0410 \u0432\u044b \u0432\u043e\u0439\u0434\u0451\u0442\u0435 \u0432 \u0438\u0441\u0442\u043e\u0440\u0438\u044e\n\u0432\u0442\u043e\u0440\u044b\u043c, \u0444\u0438\u043d\u0430\u043b\u044c\u043d\u044b\u043c \u0442\u043e\u043c\u043e\u043c \u043a\u043d\u0438\u0433\u0438."
	};

	private static final String[] EN_TEXT = {
			"Long ago the Earth lived as it always had.\nOne day the observatories caught a signal.\nIt did not come from space.\nIt came from the Earth itself.",
			"The Undertaking Frendler expedition found a cave\nfull of crystals in the woods of Novolera.\nShal's uncle, Acentius, seized it.\nHe renamed the Frendler division into CorPED\nand covered Novolera with a dome.",
			"Objects thrown into the cave changed.\nA gilded necklace grew three times into a brass disc.\nThat is how exactly three Novams were made.\nThe tumanite crystal gave the Rele, instant healing.\nThe Novam reflected language and meaning into crystals.\nA microphone for magic, deprived of a mind.",
			"Shal, nephew of Acentius, was choking on war and hunger.\nHe wrote hundreds of world orders. Worlds without wars.\nThe Novam hung on his wall, twisting his mind\nwith books and the screen.\nBreaking into the cave, before his death\nShal dropped the Novam along with a crumpled sheet.",
			"The Novam had no mind.\nIt began to embody what was written on the sheet.\nThe Earth shattered into seven flat worlds.\nA crystal planet rose at the center.\nThey named it Nova.",
			"The lines of the crumpled sheet appointed four Guardians.\nShal's world order took flesh.\nPeople rebuilt and flourished.\nNova became a home for everyone.",
			"Yet two of them could not forget the Earth.\nEnna and Tikhon rose against Nova.\nThey chose to take the worlds apart block by block\nand bring the Earth back.",
			"The war to bring back the Earth began.\nThe Guardians fell one by one.\nFlashes gave away the light of Nova.\nEclipses took everything.",
			"All of this has repeated 83 times already.\nEach cycle renews itself after three years.\nNot 83 years have passed,\nbut eight cycles of three years.",
			"The last world is called SPED.\nTwo beings met above it.\nPerfonov wants the story to go on.\nRelegant wants it all to end.\nPerfonov's victory will begin the 90th year of Nova.\nRelegant's victory will end the stories in blackness.",
			"They play with people.\nEvery step you take is a move by one of them.\nThe crumpled sheet inside Perfonov tears and warps.\nShal's story and world order are collapsing.\nChoose a side.\nWill the story go on for one more cycle of games?",
			"This is the end of the first volume of Nova\nby Kuzma Izyanov.\nAnd you will enter history\nas the second, final volume of the book."
	};

	private static final String[] RU_DATE = {
			"\u0417\u0435\u043c\u043b\u044f. 2016 \u0433\u043e\u0434",
			"\u0417\u0435\u043c\u043b\u044f. 2017 \u0433\u043e\u0434",
			"\u0417\u0435\u043c\u043b\u044f. 2017 \u0433\u043e\u0434",
			"\u0417\u0435\u043c\u043b\u044f. 2017 \u0433\u043e\u0434. \u041f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439 \u0434\u0435\u043d\u044c",
			"0 \u0433\u043e\u0434 \u044d\u0440\u044b \u041d\u043e\u0432\u044b",
			"\u0421 1 \u043f\u043e 43 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b",
			"73 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b",
			"80 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b",
			"82 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b. \u0412\u043e\u0441\u044c\u043c\u043e\u0439 \u0446\u0438\u043a\u043b",
			"83 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b",
			"83 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b. \u041f\u0430\u0440\u0442\u0438\u044f \u043d\u0430\u0447\u0430\u043b\u0430\u0441\u044c",
			"83 \u0433\u043e\u0434 \u041d\u043e\u0432\u044b. \u0422\u043e\u043c \u0432\u0442\u043e\u0440\u043e\u0439"
	};

	private static final String[] EN_DATE = {
			"Earth. Year 2016",
			"Earth. Year 2017",
			"Earth. Year 2017",
			"Earth. Year 2017. The final day",
			"Year 0 of the Nova era",
			"Years 1 to 43 of Nova",
			"Year 73 of Nova",
			"Year 80 of Nova",
			"Year 82 of Nova. The eighth cycle",
			"Year 83 of Nova",
			"Year 83 of Nova. The game has begun",
			"Year 83 of Nova. Volume two"
	};

	private final boolean ru;
	private final String[] texts;
	private final String[] dates;

	private int slide;
	private int phase;
	private long phaseStart;
	private long typeDur;
	private long slideEnter;

	private boolean spaceDown;
	private long spaceDownAt;
	private boolean finished;

	private List<String> lines;
	private int linesWidth = -1;
	private int linesSlide = -1;

	private float curU;
	private float curV;
	private float curSrcW;
	private float curSrcH;

	public IntroScreen() {
		super(Component.empty());
		this.ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
		this.texts = ru ? RU_TEXT : EN_TEXT;
		this.dates = ru ? RU_DATE : EN_DATE;
		this.slide = 0;
		this.phase = PHASE_FADE_IN;
		long now = Util.getMillis();
		this.phaseStart = now;
		this.slideEnter = now;
		this.typeDur = texts[0].length() * CHAR_MS;
		SpedMod.LOGGER.info("[sped] Nova intro opened");
	}

	public static boolean seen() {
		if (seenCache != null)
			return seenCache;
		try {
			seenCache = Files.exists(markerPath());
		} catch (Exception e) {
			seenCache = true;
		}
		return seenCache;
	}

	public static void resetSeen() {
		seenCache = false;
		try {
			Files.deleteIfExists(markerPath());
		} catch (Exception ignored) {
		}
	}

	public static String markerInfo() {
		try {
			return markerPath().toAbsolutePath().toString();
		} catch (Exception e) {
			return "unavailable";
		}
	}

	private static Path markerPath() {
		return FMLPaths.CONFIGDIR.get().resolve("sped_intro_seen.dat");
	}

	private static void markSeen() {
		seenCache = true;
		try {
			Files.write(markerPath(), new byte[] { 1 });
		} catch (Exception ignored) {
		}
	}

	private void tickPhases(long now) {
		if (phase == PHASE_FADE_IN && now - phaseStart >= FADE_IN_MS) {
			phase = PHASE_TYPE;
			phaseStart = phaseStart + FADE_IN_MS;
		}
		if (phase == PHASE_TYPE && now - phaseStart >= typeDur) {
			phase = PHASE_HOLD;
			phaseStart = now;
		}
		if (phase == PHASE_FADE_OUT && now - phaseStart >= FADE_OUT_MS) {
			nextSlide(now);
		}
	}

	private void nextSlide(long now) {
		slide++;
		if (slide >= texts.length) {
			finishIntro();
			return;
		}
		phase = PHASE_FADE_IN;
		phaseStart = now;
		slideEnter = now;
		typeDur = texts[slide].length() * CHAR_MS;
	}

	private void advance(long now) {
		if (finished)
			return;
		if (phase == PHASE_FADE_IN || phase == PHASE_TYPE) {
			phase = PHASE_HOLD;
			phaseStart = now;
		} else if (phase == PHASE_HOLD) {
			phase = PHASE_FADE_OUT;
			phaseStart = now;
		}
	}

	private void finishIntro() {
		if (finished)
			return;
		finished = true;
		markSeen();
		Minecraft.getInstance().setScreen(null);
	}

	private float slideAlpha(long now) {
		long e = now - phaseStart;
		if (phase == PHASE_FADE_IN)
			return Math.min(1f, e / (float) FADE_IN_MS);
		if (phase == PHASE_FADE_OUT)
			return Math.max(0f, 1f - e / (float) FADE_OUT_MS);
		return 1f;
	}

	private int revealedChars(long now) {
		if (phase == PHASE_FADE_IN)
			return 0;
		if (phase == PHASE_TYPE)
			return (int) Math.min(texts[slide].length(), (now - phaseStart) / CHAR_MS);
		return texts[slide].length();
	}

	private void rebuildLines() {
		if (linesSlide == slide && linesWidth == this.width && lines != null)
			return;
		linesSlide = slide;
		linesWidth = this.width;
		lines = new ArrayList<>();
		int maxPx = (int) (this.width * 0.82f / TEXT_SCALE);
		for (String para : texts[slide].split("\n")) {
			String cur = "";
			for (String word : para.split(" ")) {
				String test = cur.isEmpty() ? word : cur + " " + word;
				if (this.font.width(test) <= maxPx) {
					cur = test;
				} else {
					if (!cur.isEmpty())
						lines.add(cur);
					cur = word;
				}
			}
			lines.add(cur);
		}
	}

	private static float ease(float t) {
		t = Math.max(0f, Math.min(1f, t));
		return t * t * (3f - 2f * t);
	}

	private static float frac(float x) {
		return x - (float) Math.floor(x);
	}

	private static float hash(int i) {
		double s = Math.sin(i * 12.9898 + 4.1414) * 43758.5453;
		return (float) (s - Math.floor(s));
	}

	private static float lerpF(float a, float b, float t) {
		return a + (b - a) * t;
	}

	private float t2sx(float tx) {
		return (tx - curU) / curSrcW * this.width;
	}

	private float t2sy(float ty) {
		return (ty - curV) / curSrcH * this.height;
	}

	private float scl() {
		return this.width / curSrcW;
	}

	private void quadF(GuiGraphics g, float x, float y, float w, float h, int color) {
		g.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), color);
	}

	private void seg(GuiGraphics g, float x1, float y1, float x2, float y2, float th, int color) {
		float dx = x2 - x1;
		float dy = y2 - y1;
		float len = (float) Math.sqrt(dx * dx + dy * dy);
		if (len < 0.5f)
			return;
		g.pose().pushPose();
		g.pose().translate(x1, y1, 0);
		g.pose().mulPose(Axis.ZP.rotation((float) Math.atan2(dy, dx)));
		g.fill(0, Math.round(-th / 2f), Math.round(len), Math.round(th / 2f), color);
		g.pose().popPose();
	}

	private void ringDots(GuiGraphics g, float cx, float cy, float rx, float ry, int n, float s, int color, float rot) {
		for (int k = 0; k < n; k++) {
			float a = (float) (Math.PI * 2 * k / n) + rot;
			float x = cx + (float) Math.cos(a) * rx;
			float y = cy + (float) Math.sin(a) * ry;
			quadF(g, x - s / 2f, y - s / 2f, s, s, color);
		}
	}

	private void sparkle(GuiGraphics g, float x, float y, float size, int rgb, float pulse) {
		int a = (int) (255f * Math.max(0f, Math.min(1f, pulse)));
		if (a < 5)
			return;
		int c = (a << 24) | rgb;
		quadF(g, x - size, y - 0.7f, size * 2f, 1.4f, c);
		quadF(g, x - 0.7f, y - size, 1.4f, size * 2f, c);
	}

	private void drawSprite(GuiGraphics g, ResourceLocation rl, int natW, int natH, float au, float av, float texX, float texY, float texScale, float rot) {
		float ax = t2sx(texX);
		float ay = t2sy(texY);
		float w = natW * texScale * scl();
		float h = natH * texScale * scl();
		g.pose().pushPose();
		g.pose().translate(ax, ay, 0);
		if (rot != 0f)
			g.pose().mulPose(Axis.ZP.rotation(rot));
		g.blit(rl, Math.round(-au * w), Math.round(-av * h), Math.round(w), Math.round(h), 0f, 0f, natW, natH, natW, natH);
		g.pose().popPose();
	}

	private void renderKenBurns(GuiGraphics g, long now) {
		int sw = this.width;
		int sh = this.height;
		float cover = Math.max(sw / (float) TEX_W, sh / (float) TEX_H);
		float srcW = sw / cover;
		float srcH = sh / cover;
		float u = (TEX_W - srcW) / 2f;
		float v = (TEX_H - srcH) / 2f;
		curU = u;
		curV = v;
		curSrcW = srcW;
		curSrcH = srcH;
		RenderSystem.enableBlend();
		g.blit(TEX[slide], 0, 0, sw, sh, u, v, Math.round(srcW), Math.round(srcH), TEX_W, TEX_H);
	}

	private void renderScene(GuiGraphics g, long now) {
		float sc = scl();
		if (slide == 2) {
			float dy = (float) Math.sin(now / 1600.0) * 2f;
			float rot = 0.06f * (float) Math.sin(now / 1300.0);
			drawSprite(g, SPR_NOVAM, 104, 104, 0.5f, 0.5f, 512f, 368f + dy, 1f, rot);
		} else if (slide == 3) {
			float dyD = (float) Math.sin(now / 1100.0) * 3f;
			float rotD = 0.09f * (float) Math.sin(now / 900.0);
			drawSprite(g, SPR_NOVAM, 104, 104, 0.5f, 0.5f, 468f, 356f + dyD, 1f, rotD);
			float dyP = (float) Math.sin(now / 650.0 + 1.0) * 2.5f;
			float rotP = 0.3f * (float) Math.sin(now / 800.0);
			drawSprite(g, SPR_PAPER, 28, 28, 0.5f, 0.5f, 552f, 300f + dyP, 1f, rotP);
		} else if (slide == 6) {
			float dyE = (float) Math.sin(now / 1700.0) * 2f;
			float dyT = (float) Math.sin(now / 1700.0 + Math.PI) * 2f;
			drawSprite(g, SPR_ENNA, 120, 168, 0.5f, 0.976f, 400f, 492f + dyE, 1f, 0f);
			drawSprite(g, SPR_TIKH, 136, 188, 0.5f, 0.979f, 624f, 492f + dyT, 1f, 0f);
		} else if (slide == 4) {
			float px = t2sx(512);
			float py = t2sy(268);
			for (int i = 0; i < PLATFORMS.length; i++) {
				float bob = (float) Math.sin(now / 1400.0 + i * 1.7) * 4f;
				seg(g, px, py, t2sx(PLATFORMS[i][0]), t2sy(PLATFORMS[i][1] + bob), Math.max(1f, 1.5f * sc), 0x169FE2FD);
			}
			for (int i = 0; i < PLATFORMS.length; i++) {
				float bob = (float) Math.sin(now / 1400.0 + i * 1.7) * 4f;
				drawSprite(g, SPR_PLATFORM, 320, 112, 0.5f, 0.2143f, PLATFORMS[i][0], PLATFORMS[i][1] + bob, PLATFORMS[i][2] / 296f, 0f);
			}
		} else if (slide == 8) {
			float bob = (float) Math.sin(now / 1500.0) * 3f;
			drawSprite(g, SPR_PLATFORM, 320, 112, 0.5f, 0.2143f, 810f, 452f + bob, 190f / 296f, 0f);
		} else if (slide == 9) {
			float perfDy = (float) Math.sin(now / 1900.0) * 4f;
			float relDy = (float) Math.sin(now / 1900.0 + Math.PI) * 4f;
			float perfRot = 0.02f * (float) Math.sin(now / 2600.0);
			drawSprite(g, SPR_PERF, 260, 400, 0.5f, 0.24f, 250f, 196f + perfDy, 0.938f, perfRot);
			drawSprite(g, SPR_RELE, 300, 432, 0.5f, 0.2222f, 774f, 180f + relDy, 0.884f, 0f);
		}
	}

	private void renderDust(GuiGraphics g, long now) {
		int sw = this.width;
		int sh = this.height;
		float t = now / 1000f;
		for (int i = 0; i < 24; i++) {
			float h1 = hash(i * 3 + 1);
			float h2 = hash(i * 3 + 2);
			float h3 = hash(i * 3 + 3);
			float x = frac(h1 + t * (0.008f + 0.010f * h3) * (i % 2 == 0 ? 1f : -1f)) * (sw + 20) - 10;
			float y = h2 * sh + (float) Math.sin(t * 0.8f + i) * 6f;
			int a = (int) (26f + 40f * h3);
			float s = 1f + h1;
			quadF(g, x, y, s, s, (a << 24) | 0xFFFFFF);
		}
	}

	private void fxMenuStars(GuiGraphics g, long now, int seed, int count) {
		double sec = now / 1000.0;
		int sw = this.width;
		int sh = this.height;
		for (int i = 0; i < count; i++) {
			float h1 = hash(seed + i * 4);
			float h2 = hash(seed + i * 4 + 1);
			float h3 = hash(seed + i * 4 + 2);
			float h4 = hash(seed + i * 4 + 3);
			float px = h1 * sw;
			float py = h2 * sh * 0.85f;
			float size = 1f + h3 * 1.3f;
			float baseA = 0.65f + 0.35f * h4;
			float tw = 0.3f + 0.7f * (float) Math.sin(sec * (0.3f + h1 * 2.5f) + h2 * 6.283f);
			int alpha = (int) Math.max(0, Math.min(255, baseA * tw * 255f));
			if (alpha < 4)
				continue;
			int[] pair = STAR_PAIRS[((int) (h3 * 97f)) % STAR_PAIRS.length];
			float cs = 0.5f + 0.5f * (float) Math.sin(sec * (0.08f + h4 * 0.5f) + h1 * 6.283f);
			int r2 = (int) lerpF(pair[0] >> 16 & 255, pair[1] >> 16 & 255, cs);
			int g2 = (int) lerpF(pair[0] >> 8 & 255, pair[1] >> 8 & 255, cs);
			int b2 = (int) lerpF(pair[0] & 255, pair[1] & 255, cs);
			int col = (alpha << 24) | (r2 << 16) | (g2 << 8) | b2;
			float degPerSec = (h2 > 0.5f ? 1f : -1f) * (2.4f + h4 * 16f);
			float ang = h3 * 360f + (float) (sec * degPerSec);
			g.pose().pushPose();
			g.pose().translate(px, py, 0);
			g.pose().mulPose(Axis.ZP.rotationDegrees(ang));
			g.pose().translate(-size / 2f, -size / 2f, 0);
			g.fill(0, 0, Math.round(size), Math.round(size), col);
			g.pose().popPose();
		}
	}

	private void fxSignal(GuiGraphics g, long now) {
		float cx = t2sx(415);
		float cy = t2sy(372);
		float sc = scl();
		for (int k = 0; k < 3; k++) {
			float p = frac(now / 1700f + k / 3f);
			float r = (10f + 95f * p) * sc;
			int a = (int) (170f * (1f - p));
			ringDots(g, cx, cy, r, r * 0.55f, 34, 1.6f * sc, (a << 24) | 0xEDB55D, 0f);
		}
		float pulse = 0.6f + 0.4f * (float) Math.sin(now / 260.0);
		quadF(g, cx - 2f * sc, cy - 2f * sc, 4f * sc, 4f * sc, ((int) (200 * pulse) << 24) | 0xFFEB94);
	}

	private void fxCave(GuiGraphics g, long now) {
		float sc = scl();
		float[][] tips = { { 296, 344 }, { 256, 424 }, { 336, 436 }, { 472, 320 }, { 428, 436 }, { 520, 408 }, { 632, 380 }, { 672, 444 } };
		for (int i = 0; i < tips.length; i++) {
			float ph = hash(i * 5 + 40);
			float pulse = 0.5f + 0.5f * (float) Math.sin(now / 420.0 + ph * 6.28);
			sparkle(g, t2sx(tips[i][0]), t2sy(tips[i][1]), (3f + 2f * ph) * sc, 0xE8E0FC, pulse * 0.9f);
		}
		int breath = (int) (8f + 7f * (float) Math.sin(now / 1100.0));
		g.fill(0, 0, this.width, this.height, (breath << 24) | 0x8D6ACC);
	}

	private void fxLab(GuiGraphics g, long now) {
		float sc = scl();
		sparkle(g, t2sx(300), t2sy(406), 3.4f * sc, 0xFFEB94, 0.5f + 0.5f * (float) Math.sin(now / 430.0));
		sparkle(g, t2sx(512), t2sy(368), 4f * sc, 0xFFF1A7, 0.5f + 0.5f * (float) Math.sin(now / 360.0 + 1.8));
		sparkle(g, t2sx(646), t2sy(410), 3f * sc, 0xFFEB94, 0.5f + 0.5f * (float) Math.sin(now / 500.0 + 3.4));
		sparkle(g, t2sx(852), t2sy(332), 3.6f * sc, 0xA1FBE8, 0.5f + 0.5f * (float) Math.sin(now / 300.0));
		float pr = (16f + 2f * (float) Math.sin(now / 520.0)) * sc;
		ringDots(g, t2sx(852), t2sy(388), pr, pr * 0.45f, 18, 1.4f * sc, 0x487DF0E7, now / 2400f);
	}

	private void fxShal(GuiGraphics g, long now) {
		float sc = scl();
		float dyP = (float) Math.sin(now / 650.0 + 1.0) * 2.5f;
		sparkle(g, t2sx(552), t2sy(296f + dyP), 3f * sc, 0xFFFFFF, 0.5f + 0.5f * (float) Math.sin(now / 470.0));
	}

	private void fxWorlds(GuiGraphics g, long now) {
		float sc = scl();
		sparkle(g, t2sx(498), t2sy(246), 3.5f * sc, 0xFFFFFF, 0.5f + 0.5f * (float) Math.sin(now / 380.0));
		sparkle(g, t2sx(530), t2sy(286), 2.6f * sc, 0xAEEDFE, 0.5f + 0.5f * (float) Math.sin(now / 520.0 + 2.0));
	}

	private void fxGuardians(GuiGraphics g, long now) {
		float sc = scl();
		int sh = this.height;
		float t = now / 1000f;
		for (int i = 0; i < 22; i++) {
			float h1 = hash(i * 9 + 11);
			float h2 = hash(i * 9 + 13);
			float y = sh - frac(t * (0.03f + 0.03f * h2) + h1) * (sh + 30);
			float x = h1 * this.width + (float) Math.sin(t * 1.3f + i) * 9f;
			int a = (int) (30f + 60f * h2 * (0.5f + 0.5f * Math.sin(t * 2f + i)));
			quadF(g, x, y, 1.6f * sc + h2, 1.6f * sc + h2, (Math.max(6, a) << 24) | 0xFCC969);
		}
		sparkle(g, t2sx(700), t2sy(165), 4f * sc, 0xC1ECFD, 0.5f + 0.5f * (float) Math.sin(now / 450.0));
	}

	private void fxHeart(GuiGraphics g, long now) {
		float cx = t2sx(512);
		float cy = t2sy(250);
		float sc = scl();
		Random r = new Random(now / 120L * 31L + 7L);
		{
			int bolts = 8 + r.nextInt(5);
			for (int b = 0; b < bolts; b++) {
				float a = r.nextFloat() * (float) Math.PI * 2f;
				float px = cx;
				float py = cy;
				for (int s2 = 0; s2 < 6; s2++) {
					float len = (10f + r.nextFloat() * 20f) * sc;
					float nx = px + (float) Math.cos(a) * len;
					float ny = py + (float) Math.sin(a) * len;
					seg(g, px, py, nx, ny, Math.max(1f, 1.4f * sc), 0xC8FFF5D4);
					px = nx;
					py = ny;
					a += (r.nextFloat() - 0.5f) * 1.1f;
				}
			}
		}
		float pr = (150f + 6f * (float) Math.sin(now / 640.0)) * sc;
		ringDots(g, cx, cy, pr, pr, 44, 2f * sc, 0x38FFD18B, -now / 3400f);
	}

	private void fxWar(GuiGraphics g, long now) {
		float sc = scl();
		int sw = this.width;
		int sh = this.height;
		float t = now / 1000f;
		for (int i = 0; i < 40; i++) {
			float h1 = hash(i * 11 + 17);
			float h2 = hash(i * 11 + 19);
			float y = sh - frac(t * (0.05f + 0.06f * h2) + h1) * (sh + 40);
			float x = h1 * sw + (float) Math.sin(t * 2f + i) * 12f;
			float fade = Math.max(0f, Math.min(1f, y / (sh * 0.5f)));
			int a = (int) (200f * fade * (0.4f + 0.6f * h2));
			int rgb = h2 > 0.6f ? 0xFCC969 : 0xFF7B56;
			quadF(g, x, y, 1.5f + 1.5f * h2, 1.5f + 1.5f * h2, (Math.max(6, a) << 24) | rgb);
		}
		int pulse = (int) (14f + 12f * (float) Math.sin(now / 640.0));
		g.fillGradient(0, 0, sw, sh / 2, (pulse << 24) | 0xE71C23, 0x00000000);
		float er = (58f + 5f * (float) Math.sin(now / 900.0)) * sc;
		ringDots(g, t2sx(200), t2sy(130), er, er, 30, 1.8f * sc, 0x50FFF5D4, now / 5200f);
	}

	private void fxBelt(GuiGraphics g, long now) {
		float cx = t2sx(512);
		float cy = t2sy(240);
		float sc = scl();
		for (int i = 0; i < 46; i++) {
			float h1 = hash(i * 13 + 23);
			float h2 = hash(i * 13 + 29);
			float a = h1 * (float) Math.PI * 2f + now / 16000f;
			float rx = 400f * (0.94f + 0.1f * h2) * sc;
			float ry = 120f * (0.9f + 0.18f * h1) * sc;
			float x = cx + (float) Math.cos(a) * rx;
			float y = cy + (float) Math.sin(a) * ry;
			boolean front = Math.sin(a) > 0;
			float s = (front ? 2.4f : 1.5f) * sc * (0.7f + 0.6f * h2);
			int al = front ? 150 : 60;
			quadF(g, x - s / 2f, y - s / 2f, s, s, (al << 24) | 0x91A2B6);
		}
		sparkle(g, t2sx(500), t2sy(222), 3.2f * sc, 0xD8EFFF, 0.5f + 0.5f * (float) Math.sin(now / 430.0 + 1.2));
	}

	private void fxDuel(GuiGraphics g, long now) {
		float sc = scl();
		int sw = this.width;
		int sh = this.height;
		float perfDy = (float) Math.sin(now / 1900.0) * 4f;
		float relDy = (float) Math.sin(now / 1900.0 + Math.PI) * 4f;
		float bl = 0.65f + 0.35f * (float) Math.sin(now / 1050.0);
		float br = 0.65f + 0.35f * (float) Math.sin(now / 1050.0 + Math.PI);
		int strip = Math.max(1, sw / 20);
		int[] base = { 26, 19, 13, 8, 4 };
		for (int i = 0; i < 5; i++) {
			int al = (int) (base[i] * bl);
			int ar = (int) (base[i] * br);
			if (al > 2)
				g.fill(i * strip, 0, (i + 1) * strip, sh, (al << 24) | 0xFFFFFF);
			if (ar > 2)
				g.fill(sw - (i + 1) * strip, 0, sw - i * strip, sh, (ar << 24) | 0x390102);
		}
		float ep = 0.45f + 0.55f * (float) Math.sin(now / 260.0);
		float s1 = 4.2f * sc;
		float s2 = 3.4f * sc;
		quadF(g, t2sx(754.6f) - s1 / 2f, t2sy(174.7f + relDy) - s1 / 2f, s1, s1, ((int) (190 * ep) << 24) | 0xE3345A);
		quadF(g, t2sx(786.4f) - s2 / 2f, t2sy(183.5f + relDy) - s2 / 2f, s2, s2, ((int) (190 * ep) << 24) | 0xE3345A);
		float hr = (56f + 4f * (float) Math.sin(now / 800.0)) * sc;
		ringDots(g, t2sx(250), t2sy(196f + perfDy), hr, hr, 32, 1.8f * sc, 0x30FFFFFF, now / 6000f);
	}

	private void fxChess(GuiGraphics g, long now) {
		float sc = scl();
		int sw = this.width;
		int sh = this.height;
		float band = frac(now / 5200f) * (sw + 240) - 120;
		for (int i = -2; i <= 2; i++) {
			int a = 14 - Math.abs(i) * 4;
			g.fill(Math.round(band + i * 22f), 0, Math.round(band + i * 22f + 22f), sh, (a << 24) | 0xFFFFFF);
		}
		float band2 = frac(now / 5200f + 0.5f) * (sw + 240) - 120;
		for (int i = -2; i <= 2; i++) {
			int a = 16 - Math.abs(i) * 4;
			g.fill(Math.round(band2 + i * 22f), 0, Math.round(band2 + i * 22f + 22f), sh, (a << 24) | 0x000000);
		}
		float pr = (46f + 5f * (float) Math.sin(now / 820.0)) * sc;
		ringDots(g, t2sx(512), t2sy(452), pr, pr * 0.4f, 30, 1.7f * sc, 0x2EFFFFFF, now / 5200f);
	}

	private void fxTome(GuiGraphics g, long now) {
		float sc = scl();
		for (int i = 0; i < 18; i++) {
			float h1 = hash(i * 5 + 61);
			float h2 = hash(i * 5 + 63);
			float s = frac(now / 2100f + h1);
			float x = t2sx(560f + h2 * 170f) + (float) Math.sin(s * Math.PI * 2 + i) * 7f * sc;
			float y = t2sy(452f) + (t2sy(292f + (h1 - 0.5f) * 40f) - t2sy(452f)) * s;
			int a = (int) ((1f - s) * (110f + 90f * h2));
			float size = (1.6f + h1) * sc;
			quadF(g, x, y, size, size, (Math.max(5, a) << 24) | 0xFFD18B);
		}
		sparkle(g, t2sx(647), t2sy(380), 3.6f * sc, 0xFFF1A7, 0.5f + 0.5f * (float) Math.sin(now / 520.0));
		sparkle(g, t2sx(320), t2sy(352), 2.4f * sc, 0xFFEFC9, 0.5f + 0.5f * (float) Math.sin(now / 640.0 + 2.4));
	}

	private void renderEffects(GuiGraphics g, long now) {
		if (slide == 0 || slide == 4 || slide == 8 || slide == 9 || slide == 10 || slide == 11)
			fxMenuStars(g, now, 900 + slide * 137, 16);
		switch (slide) {
			case 0: fxSignal(g, now); break;
			case 1: fxCave(g, now); break;
			case 2: fxLab(g, now); break;
			case 3: fxShal(g, now); break;
			case 4: fxWorlds(g, now); break;
			case 5: fxGuardians(g, now); break;
			case 6: fxHeart(g, now); break;
			case 7: fxWar(g, now); break;
			case 8: fxBelt(g, now); break;
			case 9: fxDuel(g, now); break;
			case 10: fxChess(g, now); break;
			default: fxTome(g, now); break;
		}
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		long now = Util.getMillis();
		if (spaceDown && now - spaceDownAt >= SKIP_HOLD_MS)
			finishIntro();
		if (finished)
			return;
		tickPhases(now);
		if (finished)
			return;
		rebuildLines();

		float alpha = slideAlpha(now);
		int sw = this.width;
		int sh = this.height;

		g.fill(0, 0, sw, sh, 0xFF000000);
		renderKenBurns(g, now);
		renderScene(g, now);
		renderEffects(g, now);
		renderDust(g, now);

		int cover = (int) ((1f - alpha) * 255f);
		if (cover > 0)
			g.fill(0, 0, sw, sh, (cover << 24));

		g.fillGradient(0, 0, sw, (int) (sh * 0.12f), 0x88000000, 0x00000000);
		g.fillGradient(0, (int) (sh * 0.50f), sw, sh, 0x00000000, 0xE8000000);

		int a8 = (int) (alpha * 255f);
		if (a8 > 5) {
			int textColor = (a8 << 24) | 0xF6F3F2;
			int dim = ((int) (a8 * 0.55f) << 24) | GOLD;
			int goldCol = (a8 << 24) | GOLD;

			int rise = (int) ((1f - alpha) * 8f);
			int dateY = sh - 30 + rise;
			String date = dates[slide];
			int dw = this.font.width(date);
			g.drawCenteredString(this.font, date, sw / 2, dateY, goldCol);
			g.fill(sw / 2 - dw / 2 - 46, dateY + 3, sw / 2 - dw / 2 - 10, dateY + 4, dim);
			g.fill(sw / 2 + dw / 2 + 10, dateY + 3, sw / 2 + dw / 2 + 46, dateY + 4, dim);

			int reveal = revealedChars(now);
			int lineH = 12;
			int blockBottom = sh - 48 + rise;
			float blockTop = blockBottom - lines.size() * lineH * TEXT_SCALE;
			g.pose().pushPose();
			g.pose().translate(sw / 2f, blockTop, 0);
			g.pose().scale(TEXT_SCALE, TEXT_SCALE, 1f);
			int remaining = reveal;
			for (int i = 0; i < lines.size(); i++) {
				String full = lines.get(i);
				if (remaining <= 0)
					break;
				String part = remaining >= full.length() ? full : full.substring(0, remaining);
				remaining -= full.length() + 1;
				g.drawCenteredString(this.font, part, 0, i * lineH, textColor);
			}
			g.pose().popPose();

			if (phase == PHASE_HOLD) {
				int pa = (int) (255f * (0.5f + 0.35f * (float) Math.sin(now / 240.0)));
				g.drawCenteredString(this.font, "\u25bc", sw / 2, sh - 45, (pa << 24) | 0xFFFFFF);
			}
		}

		for (int i = 0; i < texts.length; i++) {
			int dx = 10 + i * 9;
			int dy = sh - 12;
			int c = i == slide ? 0xCCFFFFFF : (i < slide ? 0x66EDB55D : 0x44FFFFFF);
			g.fill(dx, dy, dx + 4, dy + 4, c);
		}

		String hint = ru ? "\u041f\u0420\u041e\u0411\u0415\u041b: \u0434\u0430\u043b\u044c\u0448\u0435. \u0417\u0430\u0436\u0430\u0442\u044c: \u043f\u0440\u043e\u043f\u0443\u0441\u0442\u0438\u0442\u044c" : "SPACE: next. Hold: skip";
		int hw = this.font.width(hint);
		int hx = sw - 10 - hw;
		int hy = sh - 22;
		float hold = spaceDown ? Math.min(1f, (now - spaceDownAt) / (float) SKIP_HOLD_MS) : 0f;
		int hintCol = spaceDown ? 0xFFFFFFFF : 0x66FFFFFF;
		g.drawString(this.font, hint, hx, hy, hintCol);
		int barW = 70;
		int bx = sw - 10 - barW;
		int by = sh - 10;
		g.fill(bx, by, bx + barW, by + 2, 0x40FFFFFF);
		if (hold > 0f)
			g.fill(bx, by, bx + (int) (barW * hold), by + 2, 0xFFEDB55D);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		long now = Util.getMillis();
		if (keyCode == GLFW.GLFW_KEY_SPACE) {
			if (!spaceDown) {
				spaceDown = true;
				spaceDownAt = now;
			}
			return true;
		}
		if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
			advance(now);
			return true;
		}
		if (keyCode == GLFW.GLFW_KEY_ESCAPE)
			return true;
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_SPACE) {
			long now = Util.getMillis();
			if (spaceDown) {
				long held = now - spaceDownAt;
				spaceDown = false;
				if (!finished && held < TAP_MS)
					advance(now);
			}
			return true;
		}
		return super.keyReleased(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean mouseClicked(double x, double y, int button) {
		advance(Util.getMillis());
		return true;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}
}
