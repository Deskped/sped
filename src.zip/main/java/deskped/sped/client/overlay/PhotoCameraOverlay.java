package deskped.sped.client.overlay;

import deskped.sped.client.PhotoClientCapture;
import deskped.sped.procedures.VhsCameraTrueFalseProcedure;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class PhotoCameraOverlay {

	@SubscribeEvent(priority = EventPriority.LOWEST)
	public static void onRenderGui(RenderGuiEvent.Post event) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null)
			return;
		GuiGraphics g = event.getGuiGraphics();
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();

		if (VhsCameraTrueFalseProcedure.execute(mc.player)) {
			int size = (int) (Math.min(w, h) * 0.75);
			int bottom = (h - size) / 2 + size;
			int count = mc.player.getInventory().countItem(Items.PAPER);
			String num = String.valueOf(count);
			int textW = mc.font.width(num);
			int groupW = 16 + 3 + textW;
			int gx = (w - groupW) / 2;
			int gy = bottom + 6;
			if (gy + 16 > h)
				gy = h - 18;
			g.renderItem(new ItemStack(Items.PAPER), gx, gy);
			int col = count > 0 ? 0xFFFFFF : 0xFFFF5555;
			g.drawString(mc.font, num, gx + 16 + 3, gy + 4, col, true);
		}

		float flash = PhotoClientCapture.flashAlpha();
		if (flash > 0f) {
			int a = (int) (flash * 235f);
			g.fill(0, 0, w, h, (a << 24) | 0xFFFFFF);
		}
	}
}
