package deskped.sped.client.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import deskped.sped.client.gui.CrusherGuiScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class CrusherAnimationOverlay implements IGuiOverlay {

    private static final int FRAME_COUNT = 19;
    private static final int TICKS_PER_FRAME = 1;
    private static final int ANIM_WIDTH = 440;
    private static final int ANIM_HEIGHT = 690;

    private static final ResourceLocation[] FRAMES = new ResourceLocation[FRAME_COUNT];

    static {
        for (int i = 0; i < FRAME_COUNT; i++) {
            FRAMES[i] = new ResourceLocation("sped", "textures/screens/crushers_ui/crusher_" + i + ".png");
        }
    }

    private int tickCounter = 0;
    private int currentFrame = 0;
    private long lastTick = 0;

    @Override
    public void render(ForgeGui gui, GuiGraphics guiGraphics, float partialTick, int screenWidth, int screenHeight) {
        Minecraft mc = Minecraft.getInstance();

        if (!(mc.screen instanceof CrusherGuiScreen screen)) {
            return;
        }

        long currentTime = mc.level != null ? mc.level.getGameTime() : 0;
        if (currentTime != lastTick) {
            lastTick = currentTime;
            tickCounter++;
            if (tickCounter >= TICKS_PER_FRAME) {
                tickCounter = 0;
                currentFrame = (currentFrame + 1) % FRAME_COUNT;
            }
        }

        int bgCenterX = screen.getGuiLeft() - 128 + 176 / 2;
        int bgCenterY = screen.getGuiTop() - 23 + 90 / 2;

        int x = bgCenterX - ANIM_WIDTH / 2 - 5;
        int y = bgCenterY - ANIM_HEIGHT / 2;

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.blit(FRAMES[currentFrame], x, y, 0, 0, ANIM_WIDTH, ANIM_HEIGHT, ANIM_WIDTH, ANIM_HEIGHT);
        RenderSystem.disableBlend();
    }
}