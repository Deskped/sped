package deskped.sped.client.renderer.block;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import deskped.sped.block.CrusherBlock;
import deskped.sped.block.entity.CrusherBlockEntity;
import deskped.sped.client.model.Modelcrusher;
import deskped.sped.init.SpedModBlockEntities;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.WeakHashMap;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CrusherSpinRenderer implements BlockEntityRenderer<CrusherBlockEntity> {

	private static final ResourceLocation TEXTURE = new ResourceLocation("sped", "textures/block/crusher.png");
	private final Modelcrusher<Entity> model;
	private final Map<CrusherBlockEntity, Spin> spins = new WeakHashMap<>();

	private static class Spin {
		float angle;
		float speed;
		float last = Float.NaN;
	}

	public CrusherSpinRenderer(BlockEntityRendererProvider.Context context) {
		this.model = new Modelcrusher<>(context.bakeLayer(Modelcrusher.LAYER_LOCATION));
	}

	@Override
	public void render(CrusherBlockEntity blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		if (blockEntity.getLevel() == null)
			return;
		Spin spin = spins.computeIfAbsent(blockEntity, k -> new Spin());
		float now = blockEntity.getLevel().getGameTime() + partialTick;
		float dt = Float.isNaN(spin.last) ? 0f : now - spin.last;
		if (dt < 0f || dt > 40f)
			dt = 0f;
		spin.last = now;
		boolean on = blockEntity.getPersistentData().getBoolean("on");
		float target = on ? 18f : 0f;
		spin.speed += (target - spin.speed) * Math.min(1f, dt * 0.12f);
		spin.angle = (spin.angle + spin.speed * dt) % 360f;

		poseStack.pushPose();
		poseStack.scale(-1, -1, 1);
		poseStack.translate(-0.5, -0.5, 0.5);
		Direction facing = blockEntity.getBlockState().hasProperty(CrusherBlock.FACING) ? blockEntity.getBlockState().getValue(CrusherBlock.FACING) : Direction.NORTH;
		switch (facing) {
			case NORTH -> {
			}
			case EAST -> poseStack.mulPose(Axis.YP.rotationDegrees(90));
			case WEST -> poseStack.mulPose(Axis.YP.rotationDegrees(-90));
			case SOUTH -> poseStack.mulPose(Axis.YP.rotationDegrees(180));
			case UP -> poseStack.mulPose(Axis.XN.rotationDegrees(90));
			case DOWN -> poseStack.mulPose(Axis.XN.rotationDegrees(-90));
		}
		poseStack.translate(0, -1, 0);
		model.konchik.xRot = (float) Math.toRadians(-spin.angle);
		VertexConsumer builder = bufferSource.getBuffer(RenderType.entityCutout(TEXTURE));
		model.renderToBuffer(poseStack, builder, packedLight, packedOverlay, 1f, 1f, 1f, 1f);
		poseStack.popPose();
	}

	@SubscribeEvent(priority = EventPriority.LOWEST)
	public static void register(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(SpedModBlockEntities.CRUSHER.get(), CrusherSpinRenderer::new);
	}
}
