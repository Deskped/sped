package deskped.sped.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CrusherBEWLR extends BlockEntityWithoutLevelRenderer {

    private static CrusherBEWLR instance;

    private static final ResourceLocation TEXTURE =
        new ResourceLocation("sped", "textures/block/crusher.png");

    private CrusherItemModel model;

    private CrusherBEWLR() {
        super(
            Minecraft.getInstance().getBlockEntityRenderDispatcher(),
            Minecraft.getInstance().getEntityModels()
        );
    }

    public static CrusherBEWLR getInstance() {
        if (instance == null) {
            instance = new CrusherBEWLR();
        }
        return instance;
    }

    @Override
    public void onResourceManagerReload(net.minecraft.server.packs.resources.ResourceManager manager) {
        model = new CrusherItemModel(
            Minecraft.getInstance().getEntityModels()
                .bakeLayer(CrusherItemModel.LAYER_LOCATION)
        );
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext context,
                             PoseStack poseStack, MultiBufferSource buffer,
                             int packedLight, int packedOverlay) {
        if (model == null) {
            model = new CrusherItemModel(
                Minecraft.getInstance().getEntityModels()
                    .bakeLayer(CrusherItemModel.LAYER_LOCATION)
            );
        }

        poseStack.pushPose();

        applyContextTransform(context, poseStack);

        VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        model.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY,
            1f, 1f, 1f, 1f);

        poseStack.popPose();
    }

    private void applyContextTransform(ItemDisplayContext context, PoseStack poseStack) {
        switch (context) {
            case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.mulPose(Axis.XP.rotationDegrees(4.31f));
                poseStack.mulPose(Axis.YP.rotationDegrees(-4.23f));
                poseStack.mulPose(Axis.ZP.rotationDegrees(5.71f));
                poseStack.translate(0.25 / 16f, -1.75 / 16f, 1.5 / 16f);
                poseStack.scale(0.375f, 0.375f, 0.375f);
            }
            case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.mulPose(Axis.YP.rotationDegrees(8.5f));
                poseStack.scale(0.4f, 0.4f, 0.4f);
            }
            case GROUND -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.translate(0, 3 / 16f, 0);
                poseStack.scale(0.25f, 0.25f, 0.25f);
            }
            case GUI -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.mulPose(Axis.XP.rotationDegrees(30f));
                poseStack.mulPose(Axis.YP.rotationDegrees(-135f));
                poseStack.translate(-1.5 / 16f, 0.75 / 16f, 0);
                poseStack.scale(0.44141f, 0.4668f, 0.40625f);
            }
            case FIXED -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.translate(0, 0, -10 / 16f);
            }
            case HEAD -> {
                poseStack.translate(0.5, 0.5, 0.5);
                poseStack.translate(0, 0, -1.25 / 16f);
            }
            default -> {
                poseStack.translate(0.5, 0.5, 0.5);
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class CrusherItemModel extends EntityModel<Entity> {

        public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation("sped", "crusher_item"), "main");

        private final ModelPart block;
        private final ModelPart konchik;

        public CrusherItemModel(ModelPart root) {
            this.block = root.getChild("block");
            this.konchik = root.getChild("konchik");
        }

        public static LayerDefinition createBodyLayer() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();

            root.addOrReplaceChild("block",
                CubeListBuilder.create()
                    .texOffs(16, 16)
                    .addBox(-8f, -16f, -8f, 16f, 16f, 16f, new CubeDeformation(0f))
                    .texOffs(48, 32)
                    .addBox(-4.4f, -10f, -17f, 9f, 3f, 15f, new CubeDeformation(0f)),
                PartPose.offset(0f, 24f, 0f)
            );

            root.addOrReplaceChild("konchik",
                CubeListBuilder.create()
                    .texOffs(0, 32)
                    .addBox(-4f, -8f, -8f, 8f, 16f, 16f, new CubeDeformation(0f)),
                PartPose.offset(0f, 16f, -16f)
            );

            return LayerDefinition.create(mesh, 128, 128);
        }

        @Override
        public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount,
                              float ageInTicks, float netHeadYaw, float headPitch) {
        }

        @Override
        public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer,
                                   int packedLight, int packedOverlay,
                                   float red, float green, float blue, float alpha) {
            block.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            konchik.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }
}
