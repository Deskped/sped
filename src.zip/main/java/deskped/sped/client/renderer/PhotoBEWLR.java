package deskped.sped.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import deskped.sped.client.PhotoClientCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class PhotoBEWLR extends BlockEntityWithoutLevelRenderer {

	private static PhotoBEWLR instance;

	private static final ResourceLocation BLANK = new ResourceLocation("sped", "textures/item/photo.png");

	private PhotoBEWLR() {
		super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
	}

	public static PhotoBEWLR getInstance() {
		if (instance == null)
			instance = new PhotoBEWLR();
		return instance;
	}

	@Override
	public void onResourceManagerReload(ResourceManager manager) {
	}

	@Override
	public void renderByItem(ItemStack stack, ItemDisplayContext context, PoseStack poseStack, MultiBufferSource buffer, int packedLight, int packedOverlay) {
		PhotoClientCache.Entry entry = null;
		if (stack.getTag() != null)
			entry = PhotoClientCache.get(stack.getTag().getString("PhotoId"));

		ResourceLocation texture = entry != null ? entry.texture : BLANK;
		float wOverH = entry != null ? entry.wOverH : 1.0f;
		int alpha = entry != null ? (int) (Math.min(1f, (System.currentTimeMillis() - entry.readyAt) / 1200f) * 255f) : 255;

		float halfW = (wOverH >= 1f ? 1f : wOverH) * 0.5f;
		float halfH = (wOverH >= 1f ? 1f / wOverH : 1f) * 0.5f;

		poseStack.pushPose();
		poseStack.translate(0.5f, 0.5f, 0.5f);
		applyContextTransform(context, poseStack);

		Matrix4f m = poseStack.last().pose();
		VertexConsumer vc = buffer.getBuffer(RenderType.text(texture));
		face(vc, m, -halfW, -halfH, halfW, halfH, 0.031f, 0f, 0f, 1f, 1f, false, packedLight, alpha);
		face(vc, m, -halfW, -halfH, halfW, halfH, -0.031f, 0f, 0f, 1f, 1f, true, packedLight, alpha);
		poseStack.popPose();
	}

	private void applyContextTransform(ItemDisplayContext context, PoseStack poseStack) {
		switch (context) {
			case GUI -> poseStack.scale(1.0f, 1.0f, 1.0f);
			case FIXED -> {
				poseStack.mulPose(Axis.YP.rotationDegrees(180f));
				poseStack.scale(1.2f, 1.2f, 1.2f);
			}
			case GROUND -> {
				poseStack.scale(0.5f, 0.5f, 0.5f);
				poseStack.mulPose(Axis.XP.rotationDegrees(90f));
			}
			case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> {
				poseStack.scale(0.9f, 0.9f, 0.9f);
				poseStack.mulPose(Axis.XP.rotationDegrees(25f));
			}
			case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
				poseStack.scale(0.85f, 0.85f, 0.85f);
				poseStack.mulPose(Axis.XP.rotationDegrees(65f));
			}
			default -> {
			}
		}
	}

	private static void face(VertexConsumer vc, Matrix4f m, float x0, float y0, float x1, float y1, float z, float u0, float v0, float u1, float v1, boolean back, int light, int alpha) {
		if (alpha <= 0)
			return;
		if (back) {
			vc.vertex(m, x1, y0, z).color(255, 255, 255, alpha).uv(u0, v1).uv2(light).endVertex();
			vc.vertex(m, x0, y0, z).color(255, 255, 255, alpha).uv(u1, v1).uv2(light).endVertex();
			vc.vertex(m, x0, y1, z).color(255, 255, 255, alpha).uv(u1, v0).uv2(light).endVertex();
			vc.vertex(m, x1, y1, z).color(255, 255, 255, alpha).uv(u0, v0).uv2(light).endVertex();
		} else {
			vc.vertex(m, x0, y0, z).color(255, 255, 255, alpha).uv(u0, v1).uv2(light).endVertex();
			vc.vertex(m, x1, y0, z).color(255, 255, 255, alpha).uv(u1, v1).uv2(light).endVertex();
			vc.vertex(m, x1, y1, z).color(255, 255, 255, alpha).uv(u1, v0).uv2(light).endVertex();
			vc.vertex(m, x0, y1, z).color(255, 255, 255, alpha).uv(u0, v0).uv2(light).endVertex();
		}
	}
}
