package deskped.sped.client;

public class ClientPortalState {
    private static volatile boolean open = true;
    private static volatile boolean hasOrigin = false;
    private static volatile double ox, oy, oz;

    public static void set(boolean v, boolean withOrigin, double x, double y, double z) {
        open = v;
        hasOrigin = withOrigin;
        if (withOrigin) {
            ox = x;
            oy = y;
            oz = z;
        }
    }

    public static boolean isOpen() {
        return open;
    }

    public static boolean hasOrigin() {
        return hasOrigin;
    }

    public static double originX() {
        return ox;
    }

    public static double originY() {
        return oy;
    }

    public static double originZ() {
        return oz;
    }
}