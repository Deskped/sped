package deskped.sped.client;

import deskped.sped.race.RaceAttribute;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.BrushItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Mod.EventBusSubscriber(modid = "sped", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
@OnlyIn(Dist.CLIENT)
public class RaceClientOverlays {

	@SubscribeEvent
	public static void onScreenInit(ScreenEvent.Init.Post event) {
		if (event.getScreen() instanceof InventoryScreen)
			new ArrayList<>(event.getListenersList()).forEach(l -> {
				if (l instanceof ImageButton b && b.getWidth() == 20 && b.getHeight() == 18)
					event.removeListener(b);
			});
	}

	@SubscribeEvent
	public static void onScreenRender(ScreenEvent.Render.Post event) {
		try {
			if (!(event.getScreen() instanceof InventoryScreen))
				return;
			Set<String> races = ClientRaceState.get();
			if (races.isEmpty())
				return;
			Minecraft mc = Minecraft.getInstance();
			boolean ru = mc.options.languageCode.startsWith("ru");
			GuiGraphics g = event.getGuiGraphics();
			Font font = mc.font;
			g.pose().pushPose();
			g.pose().translate(6, 8, 0);
			g.pose().scale(0.62f, 0.62f, 1f);
			int line = 0;
			for (String name : races) {
				RaceAttribute attr;
				try {
					attr = RaceAttribute.valueOf(name);
				} catch (IllegalArgumentException e) {
					continue;
				}
				g.drawString(font, attr.displayName(ru), 0, line * 10, 0xFF000000 | attr.group.color, false);
				line++;
				for (String l : attr.lines(ru)) {
					g.drawString(font, l, 4, line * 10, l.startsWith("+") ? 0xFF7CE87C : 0xFFE87C7C, false);
					line++;
				}
				line++;
			}
			g.pose().popPose();
		} catch (Exception ignored) {
		}
	}

	@SubscribeEvent
	public static void onHud(RenderGuiEvent.Post event) {
		try {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null || mc.level == null)
				return;
			GuiGraphics g = event.getGuiGraphics();
			Font font = mc.font;
			boolean ru = mc.options.languageCode.startsWith("ru");
			int w = g.guiWidth(), h = g.guiHeight();

			if (mc.screen == null && mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK && mc.hitResult instanceof BlockHitResult bhr) {
				BlockState state = mc.level.getBlockState(bhr.getBlockPos());
				ItemStack held = mc.player.getMainHandItem();
				String hint = null;
				if (ClientRaceState.has("ANCIENT")) {
					if (state.is(Blocks.GOLD_BLOCK) && held.isEmpty())
						hint = ru ? "ПКМ: древние обломки" : "RMB: ancient debris";
					else if (state.is(Blocks.ANCIENT_DEBRIS) && held.getItem() instanceof BrushItem)
						hint = ru ? "ПКМ кистью: незеритовый блок" : "RMB with brush: netherite block";
				}
				if (hint == null && ClientRaceState.has("SKELETON") && mc.player.isShiftKeyDown() && held.isEmpty()
						&& !state.is(Blocks.BONE_BLOCK) && !state.isAir())
					hint = ru ? "ПКМ: костный блок" : "RMB: bone block";
				if (hint != null) {
					int tw = font.width(hint);
					g.fill(w / 2 - tw / 2 - 3, h / 2 + 10, w / 2 + tw / 2 + 3, h / 2 + 21, 0x90000000);
					g.drawCenteredString(font, hint, w / 2, h / 2 + 12, 0xFFFFE08A);
				}
			}

			List<String[]> hud = ClientRaceState.hud();
			if (!hud.isEmpty() && mc.screen == null) {
				int y = h - 24;
				for (int i = hud.size() - 1; i >= 0; i--) {
					String[] e = hud.get(i);
					boolean cd = "1".equals(e[1]);
					String text = label(e[0], ru) + " " + (cd ? (ru ? "КД " : "CD ") : "") + e[2] + (ru ? "с" : "s");
					int tw = font.width(text);
					g.fill(w - tw - 12, y - 2, w - 4, y + 9, 0x80000000);
					g.drawString(font, text, w - tw - 8, y, cd ? 0xFFAAAAB8 : 0xFF8CE88C, false);
					y -= 13;
				}
			}
		} catch (Exception ignored) {
		}
	}

	private static String label(String key, boolean ru) {
		return switch (key) {
			case "WINGED", "DRAGON" -> ru ? "Полёт" : "Flight";
			case "ENDERMAN" -> ru ? "Телепорт" : "Teleport";
			case "AMPH" -> ru ? "Дыхание" : "Breathing";
			case "DEMON_FATIGUE" -> ru ? "Утомление" : "Fatigue";
			case "ARACH_BLIND" -> ru ? "Слепота" : "Blindness";
			case "AIR_SLOW" -> ru ? "Медлительность" : "Slowness";
			default -> key;
		};
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null || mc.isPaused())
			return;
		if ((ClientRaceState.has("WINGED") || ClientRaceState.has("DRAGON")) && p.getAbilities().flying) {
			Vec3 dm = p.getDeltaMovement();
			p.setDeltaMovement(dm.x, dm.y + Math.sin(p.tickCount * 0.09) * 0.014, dm.z);
		}
	}
}