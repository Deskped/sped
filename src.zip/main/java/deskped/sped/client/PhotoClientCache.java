package deskped.sped.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import deskped.sped.SpedMod;
import deskped.sped.network.PhotoRequestPacket;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class PhotoClientCache {

	public static class Entry {
		public final ResourceLocation texture;
		public final long readyAt;
		public final float wOverH;

		Entry(ResourceLocation texture, long readyAt, float wOverH) {
			this.texture = texture;
			this.readyAt = readyAt;
			this.wOverH = wOverH;
		}
	}

	private static final Map<String, Entry> READY = new ConcurrentHashMap<>();
	private static final Set<String> REQUESTED = ConcurrentHashMap.newKeySet();
	private static final Set<String> MISSING = ConcurrentHashMap.newKeySet();

	public static Entry get(String id) {
		if (id == null || id.isEmpty())
			return null;
		Entry entry = READY.get(id);
		if (entry != null)
			return entry;
		if (MISSING.contains(id))
			return null;
		if (REQUESTED.add(id)) {
			try {
				UUID uuid = UUID.fromString(id);
				if (Minecraft.getInstance().getConnection() != null)
					SpedMod.PACKET_HANDLER.sendToServer(new PhotoRequestPacket(uuid));
				else
					REQUESTED.remove(id);
			} catch (IllegalArgumentException e) {
				MISSING.add(id);
			}
		}
		return null;
	}

	public static void putReady(UUID photoId, NativeImage image) {
		if (!RenderSystem.isOnRenderThread()) {
			Minecraft.getInstance().execute(() -> putReady(photoId, image));
			return;
		}
		String id = photoId.toString();
		if (READY.containsKey(id)) {
			image.close();
			return;
		}
		try {
			DynamicTexture texture = new DynamicTexture(image);
			ResourceLocation rl = new ResourceLocation("sped", "photos/" + id);
			Minecraft.getInstance().getTextureManager().register(rl, texture);
			float wOverH = image.getHeight() > 0 ? (float) image.getWidth() / (float) image.getHeight() : 1f;
			READY.put(id, new Entry(rl, System.currentTimeMillis(), wOverH));
			MISSING.remove(id);
		} catch (Exception e) {
			SpedMod.LOGGER.error("photo texture register failed", e);
			image.close();
			MISSING.add(id);
		}
	}

	public static void receive(UUID photoId, int total, int index, byte[] data) {
		String id = photoId.toString();
		if (READY.containsKey(id))
			return;
		if (total <= 0) {
			MISSING.add(id);
			PARTS.remove(id);
			return;
		}
		if (total > 128 || index < 0 || index >= total || data == null)
			return;
		byte[][] parts = PARTS.computeIfAbsent(id, k -> new byte[total][]);
		if (parts.length != total) {
			PARTS.remove(id);
			return;
		}
		parts[index] = data;
		int size = 0;
		for (byte[] part : parts) {
			if (part == null)
				return;
			size += part.length;
		}
		PARTS.remove(id);
		byte[] full = new byte[size];
		int off = 0;
		for (byte[] part : parts) {
			System.arraycopy(part, 0, full, off, part.length);
			off += part.length;
		}
		Util.backgroundExecutor().execute(() -> {
			try {
				NativeImage image = NativeImage.read(new ByteArrayInputStream(full));
				putReady(photoId, image);
			} catch (Exception e) {
				SpedMod.LOGGER.error("photo decode failed", e);
				MISSING.add(id);
			}
		});
	}

	private static final Map<String, byte[][]> PARTS = new ConcurrentHashMap<>();

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		Minecraft mc = Minecraft.getInstance();
		for (Entry entry : READY.values())
			mc.getTextureManager().release(entry.texture);
		READY.clear();
		PARTS.clear();
		REQUESTED.clear();
		MISSING.clear();
	}
}
