package deskped.sped.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "sped")
public class SkinInventoryButtons {

	private static final ResourceLocation ICON_SKIN = new ResourceLocation("sped", "textures/gui/skin/face.png");
	private static final ResourceLocation ICON_CAPE = new ResourceLocation("sped", "textures/gui/skin/cape.png");

	@SubscribeEvent
	public static void onScreenInit(ScreenEvent.Init.Post event) {
		if (!(event.getScreen() instanceof InventoryScreen screen))
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.getConnection() == null)
			return;
		event.addListener(new SkinIconButton(screen.getGuiLeft() + 27, screen.getGuiTop() + 9, 12, () -> ICON_SKIN, Component.literal(SkinLang.buttonSkin()), b -> mc.setScreen(new SkinPickScreen(0)), () -> new int[]{screen.getGuiLeft() + 27, screen.getGuiTop() + 9}));
		event.addListener(new SkinIconButton(screen.getGuiLeft() + 62, screen.getGuiTop() + 9, 12, () -> ICON_CAPE, Component.literal(SkinLang.buttonCape()), b -> mc.setScreen(new SkinPickScreen(1)), () -> new int[]{screen.getGuiLeft() + 62, screen.getGuiTop() + 9}));
	}
}
