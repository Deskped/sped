package deskped.sped.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ContainerScreenEvent;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.sped.ext.BannerDividers;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class BannerDividersClient {
    private static final ResourceLocation SLOT_BG = new ResourceLocation("textures/gui/container/creative_inventory/tab_items.png");
    private static final ResourceLocation BANNER_MACHINES = new ResourceLocation("sped", "textures/gui/banner_machines.png");
    private static final ResourceLocation BANNER_PROCHEE = new ResourceLocation("sped", "textures/gui/banner_prochee.png");
    private static final ResourceLocation BANNER_INFINITY = new ResourceLocation("sped", "textures/gui/banner_infinity.png");
    private static final ResourceLocation BANNER_OVERPED = new ResourceLocation("sped", "textures/gui/banner_overped.png");
    private static final ResourceLocation BANNER_MYPED = new ResourceLocation("sped", "textures/gui/banner_myped.png");
    private static final ResourceLocation BANNER_SPED = new ResourceLocation("sped", "textures/gui/banner_sped.png");
    private static final ResourceLocation BANNER_ICE = new ResourceLocation("sped", "textures/gui/banner_ice.png");
    private static final ResourceLocation BANNER_GOLD = new ResourceLocation("sped", "textures/gui/banner_gold.png");

    private static final int BANNER_WIDTH = 162;
    private static final int BANNER_HEIGHT = 18;

    private static ResourceLocation banner(int type) {
        switch (type) {
            case 1:
                return BANNER_PROCHEE;
            case 2:
                return BANNER_INFINITY;
            case 3:
            	return BANNER_OVERPED;
            case 4:
            	return BANNER_MYPED;
           	case 5:
            	return BANNER_SPED;
           	case 6:
            	return BANNER_ICE;
           	case 7:
            	return BANNER_GOLD;
            default:
                return BANNER_MACHINES;
        }
    }

    @SubscribeEvent
    public static void onForeground(ContainerScreenEvent.Render.Foreground event) {
        if (!(event.getContainerScreen() instanceof CreativeModeInventoryScreen screen))
            return;
        GuiGraphics g = event.getGuiGraphics();
        Map<Integer, int[]> rows = new HashMap<>();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        for (Slot slot : screen.getMenu().slots) {
            ItemStack stack = slot.getItem();
            int role = BannerDividers.role(stack);
            if (role == 0)
                continue;
            g.blit(SLOT_BG, slot.x - 1, slot.y - 1, slot.x - 1, slot.y - 1, 18, 18);
            if (role == 1) {
                int[] r = rows.computeIfAbsent(slot.y, k -> new int[]{0, Integer.MAX_VALUE, 0});
                r[0]++;
                if (slot.x < r[1])
                    r[1] = slot.x;
                r[2] = BannerDividers.bannerType(stack);
            }
        }
        for (Map.Entry<Integer, int[]> e : rows.entrySet()) {
            if (e.getValue()[0] < 9)
                continue;
            int x = e.getValue()[1] - 1;
            int y = e.getKey() - 1;
            g.blit(banner(e.getValue()[2]), x, y, BANNER_WIDTH, BANNER_HEIGHT, 0.0F, 0.0F, BANNER_WIDTH, BANNER_HEIGHT, BANNER_WIDTH, BANNER_HEIGHT);
        }
        RenderSystem.enableDepthTest();
    }

    @SubscribeEvent
    public static void onTooltip(RenderTooltipEvent.Pre event) {
        if (BannerDividers.role(event.getItemStack()) != 0)
            event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onClick(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!(event.getScreen() instanceof CreativeModeInventoryScreen screen))
            return;
        Slot slot = screen.getSlotUnderMouse();
        if (slot != null && BannerDividers.role(slot.getItem()) != 0)
            event.setCanceled(true);
    }
}