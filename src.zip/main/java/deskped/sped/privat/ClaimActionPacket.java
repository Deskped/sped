package deskped.sped.privat;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import net.minecraftforge.network.NetworkEvent;

import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

public class ClaimActionPacket {

    public final int cx;
    public final int cz;
    public final boolean add;

    public ClaimActionPacket(int cx, int cz, boolean add) {
        this.cx = cx;
        this.cz = cz;
        this.add = add;
    }

    public static void encode(ClaimActionPacket pkt, FriendlyByteBuf buf) {
        buf.writeInt(pkt.cx);
        buf.writeInt(pkt.cz);
        buf.writeBoolean(pkt.add);
    }

    public static ClaimActionPacket decode(FriendlyByteBuf buf) {
        return new ClaimActionPacket(buf.readInt(), buf.readInt(), buf.readBoolean());
    }

    public static void handle(ClaimActionPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null)
                return;
            if (!player.level().dimension().equals(Level.OVERWORLD))
                return;
            boolean ru = player.getLanguage() != null && player.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
            ClaimData data = ClaimData.get(player.getServer());
            boolean isOp = player.hasPermissions(2);
            if (pkt.add) {
                if (data.countClaims(player.getUUID()) >= ClaimData.MAX_CLAIMS) {
                    player.sendSystemMessage(Component.literal(ru ? "\u0414\u043e\u0441\u0442\u0438\u0433\u043d\u0443\u0442 \u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c (" + ClaimData.MAX_CLAIMS + ")" : "Maximum claims reached (" + ClaimData.MAX_CLAIMS + ")"));
                    return;
                }
                boolean ok = data.claim(pkt.cx, pkt.cz, player.getUUID());
                if (!ok)
                    player.sendSystemMessage(Component.literal(ru ? "\u042d\u0442\u043e\u0442 \u0447\u0430\u043d\u043a \u0443\u0436\u0435 \u0437\u0430\u043d\u044f\u0442" : "This chunk is already claimed"));
            } else {
                Optional<UUID> owner = data.getOwner(pkt.cx, pkt.cz);
                if (owner.isEmpty())
                    return;
                if (!isOp && !owner.get().equals(player.getUUID())) {
                    player.sendSystemMessage(Component.literal(ru ? "\u041d\u0435\u043b\u044c\u0437\u044f \u0443\u0431\u0440\u0430\u0442\u044c \u0447\u0443\u0436\u043e\u0439 \u043f\u0440\u0438\u0432\u0430\u0442" : "Cannot remove someone else's claim"));
                    return;
                }
                data.unclaim(pkt.cx, pkt.cz, player.getUUID(), isOp);
            }
            ClaimNetwork.sendClaimSync(player);
        });
        ctx.get().setPacketHandled(true);
    }
}
