package deskped.sped.privat.client;

import deskped.sped.privat.ClaimData;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ClientClaimCache {

    private static Map<Long, UUID> claims = new HashMap<>();
    private static int count = 0;
    private static UUID local = null;
    private static Map<UUID, String> trustedNames = new HashMap<>();
    private static Map<UUID, String> ownerNames = new HashMap<>();
    private static boolean op = false;

    public static void applySync(Map<Long, UUID> newClaims, int newCount, Map<UUID, String> newTrusted, Map<UUID, String> newOwners, boolean newOp) {
        claims = new HashMap<>(newClaims);
        count = newCount;
        trustedNames = new HashMap<>(newTrusted);
        ownerNames = new HashMap<>(newOwners);
        op = newOp;
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.player != null)
            local = mc.player.getUUID();
    }

    public static UUID owner(int cx, int cz) {
        return claims.get(ClaimData.chunkKey(cx, cz));
    }

    public static boolean isMine(int cx, int cz) {
        UUID o = owner(cx, cz);
        return local != null && local.equals(o);
    }

    public static boolean isClaimed(int cx, int cz) {
        return claims.containsKey(ClaimData.chunkKey(cx, cz));
    }

    public static int count() {
        return count;
    }

    public static int max() {
        return ClaimData.MAX_CLAIMS;
    }

    public static Map<UUID, String> trustedNames() {
        return Collections.unmodifiableMap(trustedNames);
    }

    public static UUID local() {
        return local;
    }

    public static boolean isOp() {
        return op;
    }

    public static String ownerName(int cx, int cz) {
        UUID o = owner(cx, cz);
        if (o == null)
            return null;
        return ownerNames.get(o);
    }
}
