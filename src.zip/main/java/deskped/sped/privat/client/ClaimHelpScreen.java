package deskped.sped.privat.client;

import deskped.sped.ext.ExtLang;
import deskped.sped.voice.client.ui.Ui;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

public class ClaimHelpScreen extends Screen {

    private static final int WIDTH = 304;
    private static final int LINE = 10;

    private final Screen parent;
    private final List<FormattedCharSequence> lines = new ArrayList<>();
    private int scroll;

    public ClaimHelpScreen(Screen parent) {
        super(Component.literal(ExtLang.pick("\u041a\u0430\u043a \u044d\u0442\u043e \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442?", "How does this work?")));
        this.parent = parent;
    }

    @Override
    protected void init() {
        lines.clear();
        head(ExtLang.pick("\u041a\u0430\u043a \u043f\u0440\u0438\u0432\u0430\u0442\u0438\u0442\u044c", "Claiming"));
        body(ExtLang.pick(
                "\u041e\u0442\u043a\u0440\u043e\u0439 \u044d\u0442\u043e \u043c\u0435\u043d\u044e \u043a\u043b\u0430\u0432\u0438\u0448\u0435\u0439 Z \u0438\u043b\u0438 \u043a\u043e\u043c\u0430\u043d\u0434\u043e\u0439 /sped private. \u041a\u0430\u0436\u0434\u0430\u044f \u043a\u043b\u0435\u0442\u043a\u0430 \u043a\u0430\u0440\u0442\u044b \u044d\u0442\u043e \u043e\u0434\u0438\u043d \u0447\u0430\u043d\u043a, 16\u00d716 \u0431\u043b\u043e\u043a\u043e\u0432.",
                "Open this menu with Z or the /sped private command. Each map tile is one chunk, 16x16 blocks."));
        body(ExtLang.pick(
                "\u041b\u041a\u041c \u043f\u043e \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u043e\u0439 \u043a\u043b\u0435\u0442\u043a\u0435 \u043f\u0440\u0438\u0432\u0430\u0442\u0438\u0442 \u0447\u0430\u043d\u043a. \u041b\u041a\u041c \u043f\u043e \u0441\u0432\u043e\u0435\u043c\u0443 \u0447\u0430\u043d\u043a\u0443 \u0441\u043d\u0438\u043c\u0430\u0435\u0442 \u043f\u0440\u0438\u0432\u0430\u0442.",
                "Left-click a free tile to claim it. Left-click your own chunk to unclaim it."));
        body(ExtLang.pick(
                "\u041b\u0438\u043c\u0438\u0442: 133 \u0447\u0430\u043d\u043a\u0430 \u043d\u0430 \u0438\u0433\u0440\u043e\u043a\u0430. \u0421\u0447\u0451\u0442\u0447\u0438\u043a \u043f\u043e\u043a\u0430\u0437\u0430\u043d \u0441\u0432\u0435\u0440\u0445\u0443.",
                "The limit is 133 chunks per player. The counter is shown at the top."));
        gap();

        head(ExtLang.pick("\u041a\u0430\u043a \u0440\u0430\u0437\u043b\u0438\u0447\u0430\u0442\u044c \u043f\u0440\u0438\u0432\u0430\u0442\u044b", "Reading the map"));
        body(ExtLang.pick(
                "\u0417\u0435\u043b\u0451\u043d\u0430\u044f \u0437\u0430\u043b\u0438\u0432\u043a\u0430 \u043e\u0437\u043d\u0430\u0447\u0430\u0435\u0442 \u0442\u0432\u043e\u0439 \u0447\u0430\u043d\u043a, \u043a\u0440\u0430\u0441\u043d\u0430\u044f \u0447\u0443\u0436\u043e\u0439, \u0431\u0435\u0437 \u0437\u0430\u043b\u0438\u0432\u043a\u0438 \u0441\u0432\u043e\u0431\u043e\u0434\u043d\u043e.",
                "Green tint means your chunk, red means someone else's, no tint means free."));
        body(ExtLang.pick(
                "\u0416\u0451\u043b\u0442\u0430\u044f \u0440\u0430\u043c\u043a\u0430 \u043f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0447\u0430\u043d\u043a, \u0432 \u043a\u043e\u0442\u043e\u0440\u043e\u043c \u0442\u044b \u0441\u0435\u0439\u0447\u0430\u0441 \u0441\u0442\u043e\u0438\u0448\u044c, \u0430 \u0431\u0435\u043b\u0430\u044f \u0442\u043e\u0447\u043a\u0430 \u0442\u0432\u043e\u044e \u043f\u043e\u0437\u0438\u0446\u0438\u044e.",
                "The yellow outline is the chunk you are standing in, the white dot is your position."));
        body(ExtLang.pick(
                "\u041d\u0430\u0432\u0435\u0434\u0438 \u043a\u0443\u0440\u0441\u043e\u0440 \u043d\u0430 \u043a\u043b\u0435\u0442\u043a\u0443, \u0438 \u043e\u043d\u0430 \u043f\u043e\u043a\u0430\u0436\u0435\u0442 \u0441\u0442\u0430\u0442\u0443\u0441 \u0438 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0447\u0430\u043d\u043a\u0430.",
                "Hover a tile to see its status and chunk coordinates."));
        body(ExtLang.pick(
                "\u0412 \u0438\u0433\u0440\u0435 \u0438\u043c\u044f \u0432\u043b\u0430\u0434\u0435\u043b\u044c\u0446\u0430 \u0432\u0438\u0434\u043d\u043e \u043f\u043e\u0434 \u043f\u0440\u0438\u0446\u0435\u043b\u043e\u043c, \u0430 \u043a\u043d\u043e\u043f\u043a\u0430 \u00ab\u0413\u0440\u0430\u043d\u0438\u0446\u044b\u00bb \u043f\u043e\u0434\u0441\u0432\u0435\u0447\u0438\u0432\u0430\u0435\u0442 \u043a\u0440\u0430\u044f \u043f\u0440\u0438\u0432\u0430\u0442\u0430 \u0441\u0442\u043e\u043b\u0431\u0430\u043c\u0438.",
                "In game the owner name shows under the crosshair, and the Borders button draws claim edges in the world."));
        gap();

        head(ExtLang.pick("\u0414\u043e\u0432\u0435\u0440\u0435\u043d\u043d\u044b\u0435", "Trusted players"));
        body(ExtLang.pick(
                "\u0412\u043f\u0438\u0448\u0438 \u043d\u0438\u043a \u0441\u043f\u0440\u0430\u0432\u0430 \u0438 \u043d\u0430\u0436\u043c\u0438 \u00ab+\u00bb, \u0442\u043e\u0433\u0434\u0430 \u0438\u0433\u0440\u043e\u043a \u0441\u043c\u043e\u0436\u0435\u0442 \u0441\u0442\u0440\u043e\u0438\u0442\u044c \u0438 \u043e\u0442\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u0441\u0443\u043d\u0434\u0443\u043a\u0438 \u0432\u043e \u0432\u0441\u0435\u0445 \u0442\u0432\u043e\u0438\u0445 \u0447\u0430\u043d\u043a\u0430\u0445. \u041a\u0440\u0435\u0441\u0442\u0438\u043a \u0440\u044f\u0434\u043e\u043c \u0441 \u043d\u0438\u043a\u043e\u043c \u0443\u0431\u0438\u0440\u0430\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f.",
                "Type a nickname on the right and press + to let that player build and open containers in all your chunks. The cross next to a name removes access."));
        gap();

        warn(ExtLang.pick("\u041f\u0440\u0438\u0432\u0430\u0442\u044b \u043c\u043e\u0436\u043d\u043e \u0432\u0437\u0440\u044b\u0432\u0430\u0442\u044c", "Claims can be blown up"));
        body(ExtLang.pick(
                "\u041f\u0440\u0438\u0432\u0430\u0442 \u0437\u0430\u0449\u0438\u0449\u0430\u0435\u0442 \u043e\u0442 \u0447\u0443\u0436\u0438\u0445 \u0440\u0443\u043a: \u0441\u043b\u043e\u043c\u0430\u0442\u044c, \u043f\u043e\u0441\u0442\u0430\u0432\u0438\u0442\u044c, \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u0443\u043d\u0434\u0443\u043a \u0438\u043b\u0438 \u0434\u0432\u0435\u0440\u044c \u0447\u0443\u0436\u043e\u043c\u0443 \u043d\u0435 \u0432\u044b\u0439\u0434\u0435\u0442.",
                "A claim blocks other players from breaking, placing, and opening containers or doors."));
        body(ExtLang.pick(
                "\u041d\u043e \u043e\u0442 \u0432\u0437\u0440\u044b\u0432\u043e\u0432 \u043e\u043d \u041d\u0415 \u0437\u0430\u0449\u0438\u0449\u0430\u0435\u0442. \u0422\u041d\u0422, \u043a\u0440\u0438\u043f\u0435\u0440\u044b \u0438 \u0437\u0430\u0440\u044f\u0434\u044b \u043b\u043e\u043c\u0430\u044e\u0442 \u0431\u043b\u043e\u043a\u0438 \u0432\u043d\u0443\u0442\u0440\u0438 \u043f\u0440\u0438\u0432\u0430\u0442\u0430 \u0442\u0430\u043a \u0436\u0435, \u043a\u0430\u043a \u0441\u043d\u0430\u0440\u0443\u0436\u0438.",
                "Explosions are NOT blocked. TNT, creepers and charges break blocks inside a claim exactly as outside."));
        body(ExtLang.pick(
                "\u0417\u043d\u0430\u0447\u0438\u0442, \u043e\u0434\u043d\u043e\u0433\u043e \u043f\u0440\u0438\u0432\u0430\u0442\u0430 \u043c\u0430\u043b\u043e: \u043f\u0440\u044f\u0447\u044c \u0446\u0435\u043d\u043d\u043e\u0435 \u0433\u043b\u0443\u0431\u0436\u0435, \u0441\u0442\u0430\u0432\u044c \u043e\u0431\u0432\u0430\u043b\u043e\u0443\u0441\u0442\u043e\u0439\u0447\u0438\u0432\u044b\u0435 \u0431\u043b\u043e\u043a\u0438 \u0438 \u043d\u0435 \u0441\u043a\u043b\u0430\u0434\u044b\u0432\u0430\u0439 \u0432\u0441\u0451 \u0432 \u043e\u0434\u043d\u043e\u043c \u043c\u0435\u0441\u0442\u0435.",
                "So a claim alone is not enough: hide valuables deeper, use blast resistant blocks, and do not keep everything in one place."));
        gap();

        note(ExtLang.pick(
                "\u041f\u0440\u0438\u0432\u0430\u0442\u044b \u0440\u0430\u0431\u043e\u0442\u0430\u044e\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u043e\u0431\u044b\u0447\u043d\u043e\u043c \u043c\u0438\u0440\u0435. \u0415\u0441\u043b\u0438 \u043d\u0435 \u0437\u0430\u0445\u043e\u0434\u0438\u0442\u044c \u0432 \u0438\u0433\u0440\u0443 33 \u0434\u043d\u044f, \u043f\u0440\u0438\u0432\u0430\u0442\u044b \u0441\u043d\u0438\u043c\u0430\u044e\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438.",
                "Claims work in the overworld only. After 33 days offline your claims are released automatically."));

        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(width / 2 - 100, height - 28, 200, 20).build());
        scroll = Mth.clamp(scroll, 0, maxScroll());
    }

    private void head(String text) {
        lines.addAll(font.split(Component.literal(text).withStyle(ChatFormatting.YELLOW), WIDTH));
    }

    private void warn(String text) {
        lines.addAll(font.split(Component.literal(text).withStyle(ChatFormatting.RED), WIDTH));
    }

    private void body(String text) {
        lines.addAll(font.split(Component.literal("\u2022 " + text), WIDTH));
    }

    private void note(String text) {
        lines.addAll(font.split(Component.literal(text).withStyle(ChatFormatting.GRAY), WIDTH));
    }

    private void gap() {
        lines.add(FormattedCharSequence.EMPTY);
    }

    private int viewTop() {
        return 30;
    }

    private int viewBottom() {
        return height - 34;
    }

    private int maxScroll() {
        return Math.max(0, lines.size() * LINE - (viewBottom() - viewTop()));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 12, 0xFFFFFF);
        int x = width / 2 - WIDTH / 2;
        int top = viewTop();
        int bottom = viewBottom();
        g.enableScissor(x, top, x + WIDTH, bottom);
        int y = top - scroll;
        for (FormattedCharSequence line : lines) {
            if (y + LINE >= top && y <= bottom)
                g.drawString(font, line, x, y, 0xFFFFFF, false);
            y += LINE;
        }
        g.disableScissor();
        if (maxScroll() > 0) {
            int trackH = bottom - top;
            int barH = Math.max(16, trackH * trackH / (lines.size() * LINE));
            int barY = top + (trackH - barH) * scroll / maxScroll();
            g.fill(x + WIDTH + 2, top, x + WIDTH + 5, bottom, Ui.SLOT_BG);
            g.fill(x + WIDTH + 2, barY, x + WIDTH + 5, barY + barH, Ui.DIM);
        }
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll = Mth.clamp(scroll - (int) (delta * 12.0D), 0, maxScroll());
        return true;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
