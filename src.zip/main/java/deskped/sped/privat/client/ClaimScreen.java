package deskped.sped.privat.client;

import deskped.sped.SpedClientConfig;
import deskped.sped.ext.ExtLang;
import deskped.sped.privat.ClaimActionPacket;
import deskped.sped.privat.ClaimNetwork;
import deskped.sped.privat.ClaimTrustPacket;
import deskped.sped.voice.client.ui.Ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ClaimScreen extends Screen {

    private static final int GRID = ClaimMap.CHUNKS;
    private static final int RIGHT_W = 150;

    private static final int TINT_MINE = 0x6633CC33;
    private static final int TINT_OTHER = 0x66CC3333;
    private static final int SWATCH_MINE = 0xFF3FA34D;
    private static final int SWATCH_OTHER = 0xFFA33F3F;

    private int cell;
    private int mapPx;
    private int mapX;
    private int mapY;
    private int rightX;
    private int listTop;
    private int rows;

    private EditBox nick;

    public ClaimScreen() {
        super(Component.literal(ExtLang.pick("\u041f\u0440\u0438\u0432\u0430\u0442\u044b", "Claims")));
    }

    @Override
    protected void init() {
        cell = Math.max(10, Math.min(16, (height - 130) / GRID));
        mapPx = GRID * cell;
        mapX = width / 2 - 8 - mapPx;
        rightX = width / 2 + 8;
        mapY = 34;
        listTop = mapY + 46;
        rows = Math.max(0, (mapY + mapPx - listTop) / 20);

        nick = new EditBox(this.font, rightX, mapY + 22, RIGHT_W - 26, 18, Component.literal(""));
        nick.setMaxLength(16);
        nick.setHint(Component.literal(ExtLang.pick("\u043d\u0438\u043a", "nick")));
        addRenderableWidget(nick);
        addRenderableWidget(Button.builder(Component.literal("+"), b -> submitAdd())
                .bounds(rightX + RIGHT_W - 22, mapY + 22, 22, 18).build());

        int togglesY = mapY + mapPx + 8;
        addRenderableWidget(Button.builder(Component.literal(ExtLang.pick("\u041a\u0430\u043a \u044d\u0442\u043e \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442?", "How does this work?")),
                b -> minecraft.setScreen(new ClaimHelpScreen(this))).bounds(width / 2 - 152, togglesY, 150, 20).build());
        addRenderableWidget(Button.builder(bordersText(), b -> {
            SpedClientConfig.setClaimBorders(!SpedClientConfig.CLAIM_BORDERS);
            b.setMessage(bordersText());
        }).bounds(width / 2 + 2, togglesY, 150, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(width / 2 - 100, height - 28, 200, 20).build());

        int[] c = centerChunk();
        ClaimMap.ensure(c[0], c[1]);
    }

    private Component bordersText() {
        return Component.literal(ExtLang.pick("\u0413\u0440\u0430\u043d\u0438\u0446\u044b: ", "Borders: ")
                + (SpedClientConfig.CLAIM_BORDERS ? ExtLang.pick("\u0432\u043a\u043b.", "on") : ExtLang.pick("\u0432\u044b\u043a\u043b.", "off")));
    }

    private int[] centerChunk() {
        Minecraft mc = Minecraft.getInstance();
        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;
        return new int[]{pcx, pcz};
    }

    private List<Map.Entry<UUID, String>> sortedTrusted() {
        List<Map.Entry<UUID, String>> list = new ArrayList<>(ClientClaimCache.trustedNames().entrySet());
        list.sort((a, b) -> a.getValue().compareToIgnoreCase(b.getValue()));
        return list;
    }

    @Override
    public void tick() {
        if (nick != null)
            nick.tick();
        int[] c = centerChunk();
        ClaimMap.ensure(c[0], c[1]);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
        String counter = ClientClaimCache.count() + " / " + ClientClaimCache.max();
        g.drawCenteredString(this.font, counter, this.width / 2, 22, Ui.ACCENT);

        renderMap(g, mouseX, mouseY);
        renderTrustPanel(g, mouseX, mouseY);
        renderFooter(g);

        super.render(g, mouseX, mouseY, partial);

        renderHoverTooltip(g, mouseX, mouseY);
    }

    private void renderMap(GuiGraphics g, int mouseX, int mouseY) {
        Ui.slot(g, mapX, mapY, mapPx, mapPx);
        g.blit(ClaimMap.texture(), mapX, mapY, mapPx, mapPx, 0.0f, 0.0f, ClaimMap.SIZE, ClaimMap.SIZE, ClaimMap.SIZE, ClaimMap.SIZE);

        int[] c = centerChunk();
        for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
                int cx = c[0] + i - GRID / 2;
                int cz = c[1] + j - GRID / 2;
                int px = mapX + i * cell;
                int py = mapY + j * cell;
                if (ClientClaimCache.isMine(cx, cz))
                    g.fill(px, py, px + cell, py + cell, TINT_MINE);
                else if (ClientClaimCache.isClaimed(cx, cz))
                    g.fill(px, py, px + cell, py + cell, TINT_OTHER);
                if (inside(mouseX, mouseY, px, py, cell, cell))
                    g.fill(px, py, px + cell, py + cell, 0x33FFFFFF);
            }
        }

        for (int i = 1; i < GRID; i++) {
            g.fill(mapX + i * cell, mapY, mapX + i * cell + 1, mapY + mapPx, 0x40000000);
            g.fill(mapX, mapY + i * cell, mapX + mapPx, mapY + i * cell + 1, 0x40000000);
        }

        int hx = mapX + (GRID / 2) * cell;
        int hy = mapY + (GRID / 2) * cell;
        g.fill(hx, hy, hx + cell, hy + 1, Ui.ACCENT);
        g.fill(hx, hy + cell - 1, hx + cell, hy + cell, Ui.ACCENT);
        g.fill(hx, hy, hx + 1, hy + cell, Ui.ACCENT);
        g.fill(hx + cell - 1, hy, hx + cell, hy + cell, Ui.ACCENT);

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            int originX = (c[0] - GRID / 2) << 4;
            int originZ = (c[1] - GRID / 2) << 4;
            int bx = mc.player.blockPosition().getX() - originX;
            int bz = mc.player.blockPosition().getZ() - originZ;
            if (bx >= 0 && bx < ClaimMap.SIZE && bz >= 0 && bz < ClaimMap.SIZE) {
                int dx = mapX + bx * mapPx / ClaimMap.SIZE;
                int dz = mapY + bz * mapPx / ClaimMap.SIZE;
                g.fill(dx - 2, dz - 2, dx + 3, dz + 3, 0xFF000000);
                g.fill(dx - 1, dz - 1, dx + 2, dz + 2, 0xFFFFFFFF);
            }
        }
    }

    private void renderTrustPanel(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(this.font, ExtLang.pick("\u0414\u043e\u0432\u0435\u0440\u0435\u043d\u043d\u044b\u0435", "Trusted"), rightX, mapY + 6, Ui.DIM, false);
        List<Map.Entry<UUID, String>> list = sortedTrusted();
        if (list.isEmpty()) {
            g.drawString(this.font, ExtLang.pick("\u043d\u0438\u043a\u043e\u0433\u043e", "nobody"), rightX + 2, listTop + 6, Ui.DIM, false);
            return;
        }
        for (int i = 0; i < list.size() && i < rows; i++) {
            String name = list.get(i).getValue();
            int ry = listTop + i * 20;
            g.fill(rightX, ry, rightX + RIGHT_W, ry + 18, Ui.ROW_BG);
            g.drawString(this.font, trim(name, RIGHT_W - 24), rightX + 4, ry + 5, Ui.TEXT, false);
            int bx = rightX + RIGHT_W - 18;
            boolean rmHover = inside(mouseX, mouseY, bx, ry + 1, 16, 16);
            g.fill(bx, ry + 1, bx + 16, ry + 17, rmHover ? Ui.ROW_HOVER : 0xFF2B2B2B);
            g.drawString(this.font, "\u2715", bx + 5, ry + 5, rmHover ? Ui.RED : Ui.DIM, false);
        }
        if (list.size() > rows)
            g.drawString(this.font, "+" + (list.size() - rows), rightX, listTop + rows * 20 + 2, Ui.DIM, false);
    }

    private void renderFooter(GuiGraphics g) {
        int fy = mapY + mapPx + 34;
        int x = width / 2 - 152;
        x = legend(g, x, fy, SWATCH_MINE, ExtLang.pick("\u0412\u0430\u0448", "Yours"));
        legend(g, x + 10, fy, SWATCH_OTHER, ExtLang.pick("\u0427\u0443\u0436\u043e\u0439", "Other"));
        String hint = ExtLang.pick("\u041b\u041a\u041c \u043f\u043e \u043a\u043b\u0435\u0442\u043a\u0435: \u043f\u0440\u0438\u0432\u0430\u0442 \u0438\u043b\u0438 \u0441\u043d\u044f\u0442\u044c", "Click a tile to claim/unclaim");
        g.drawString(this.font, hint, width / 2 + 152 - this.font.width(hint), fy + 1, Ui.DIM, false);
    }

    private int legend(GuiGraphics g, int x, int y, int col, String label) {
        g.fill(x, y + 1, x + 8, y + 9, col);
        g.drawString(this.font, label, x + 11, y + 1, Ui.DIM, false);
        return x + 11 + this.font.width(label);
    }

    private void renderHoverTooltip(GuiGraphics g, int mouseX, int mouseY) {
        int[] c = centerChunk();
        for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
                int px = mapX + i * cell;
                int py = mapY + j * cell;
                if (!inside(mouseX, mouseY, px, py, cell, cell))
                    continue;
                int cx = c[0] + i - GRID / 2;
                int cz = c[1] + j - GRID / 2;
                String t;
                if (ClientClaimCache.isMine(cx, cz))
                    t = ExtLang.pick("\u0412\u0430\u0448 \u043f\u0440\u0438\u0432\u0430\u0442", "Your claim");
                else if (ClientClaimCache.isClaimed(cx, cz)) {
                    String owner = ClientClaimCache.isOp() ? ClientClaimCache.ownerName(cx, cz) : null;
                    if (owner != null)
                        t = ExtLang.pick("\u041f\u0440\u0438\u0432\u0430\u0442: ", "Claim: ") + owner + ExtLang.pick("  [\u041b\u041a\u041c: \u0441\u043d\u044f\u0442\u044c]", "  [Click to unclaim]");
                    else
                        t = ExtLang.pick("\u0417\u0430\u043d\u044f\u0442\u043e", "Claimed");
                } else
                    t = ExtLang.pick("\u0421\u0432\u043e\u0431\u043e\u0434\u043d\u043e", "Free");
                g.renderTooltip(this.font, Component.literal(t + "  [" + cx + ", " + cz + "]"), mouseX, mouseY);
                return;
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button))
            return true;
        if (button != 0)
            return false;

        int[] c = centerChunk();
        for (int i = 0; i < GRID; i++) {
            for (int j = 0; j < GRID; j++) {
                int px = mapX + i * cell;
                int py = mapY + j * cell;
                if (!inside((int) mx, (int) my, px, py, cell, cell))
                    continue;
                int cx = c[0] + i - GRID / 2;
                int cz = c[1] + j - GRID / 2;
                if (ClientClaimCache.isMine(cx, cz))
                    ClaimNetwork.CHANNEL.sendToServer(new ClaimActionPacket(cx, cz, false));
                else if (!ClientClaimCache.isClaimed(cx, cz))
                    ClaimNetwork.CHANNEL.sendToServer(new ClaimActionPacket(cx, cz, true));
                else if (ClientClaimCache.isOp())
                    ClaimNetwork.CHANNEL.sendToServer(new ClaimActionPacket(cx, cz, false));
                else
                    return true;
                clickFeedback();
                return true;
            }
        }

        List<Map.Entry<UUID, String>> list = sortedTrusted();
        for (int i = 0; i < list.size() && i < rows; i++) {
            int ry = listTop + i * 20;
            int bx = rightX + RIGHT_W - 18;
            if (inside((int) mx, (int) my, bx, ry + 1, 16, 16)) {
                ClaimNetwork.CHANNEL.sendToServer(new ClaimTrustPacket(list.get(i).getValue(), false));
                clickFeedback();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (nick != null && nick.isFocused() && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            submitAdd();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private void submitAdd() {
        if (nick == null)
            return;
        String n = nick.getValue().trim();
        if (n.isEmpty())
            return;
        ClaimNetwork.CHANNEL.sendToServer(new ClaimTrustPacket(n, true));
        nick.setValue("");
        clickFeedback();
    }

    private void clickFeedback() {
        Minecraft mc = Minecraft.getInstance();
        mc.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private String trim(String s, int maxW) {
        if (this.font.width(s) <= maxW)
            return s;
        while (s.length() > 1 && this.font.width(s + "\u2026") > maxW)
            s = s.substring(0, s.length() - 1);
        return s + "\u2026";
    }

    @Override
    public void removed() {
        ClaimMap.release();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
