package deskped.sped.privat.client;

import com.mojang.blaze3d.platform.NativeImage;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClaimMap {

	public static final int CHUNKS = 9;
	public static final int SIZE = CHUNKS * 16;

	private static final ResourceLocation TEXTURE = new ResourceLocation("sped", "claim_minimap");
	private static final int UNKNOWN = 0xFF1A1A1A;
	private static final long REFRESH_MS = 3000L;

	private static DynamicTexture texture;
	private static int builtCx = Integer.MIN_VALUE;
	private static int builtCz = Integer.MIN_VALUE;
	private static long builtAt;

	private ClaimMap() {
	}

	public static ResourceLocation texture() {
		return TEXTURE;
	}

	public static void ensure(int centerCx, int centerCz) {
		long now = System.currentTimeMillis();
		if (texture != null && centerCx == builtCx && centerCz == builtCz && now - builtAt < REFRESH_MS)
			return;
		if (build(centerCx, centerCz)) {
			builtCx = centerCx;
			builtCz = centerCz;
			builtAt = now;
		}
	}

	public static void release() {
		Minecraft mc = Minecraft.getInstance();
		DynamicTexture current = texture;
		texture = null;
		builtCx = Integer.MIN_VALUE;
		builtCz = Integer.MIN_VALUE;
		if (current != null) {
			mc.getTextureManager().release(TEXTURE);
			current.close();
		}
	}

	private static boolean build(int centerCx, int centerCz) {
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null)
			return false;
		if (texture == null) {
			texture = new DynamicTexture(new NativeImage(NativeImage.Format.RGBA, SIZE, SIZE, false));
			mc.getTextureManager().register(TEXTURE, texture);
		}
		NativeImage image = texture.getPixels();
		if (image == null)
			return false;

		int half = CHUNKS / 2;
		int minY = level.getMinBuildHeight();
		LevelChunk[] chunks = new LevelChunk[CHUNKS * CHUNKS];
		for (int i = 0; i < CHUNKS; i++)
			for (int j = 0; j < CHUNKS; j++)
				chunks[j * CHUNKS + i] = level.getChunkSource().getChunk(centerCx + i - half, centerCz + j - half, false);

		int[] heights = new int[SIZE * SIZE];
		for (int i = 0; i < CHUNKS; i++) {
			for (int j = 0; j < CHUNKS; j++) {
				LevelChunk chunk = chunks[j * CHUNKS + i];
				for (int bx = 0; bx < 16; bx++) {
					for (int bz = 0; bz < 16; bz++) {
						int index = (j * 16 + bz) * SIZE + i * 16 + bx;
						heights[index] = chunk == null ? Integer.MIN_VALUE : chunk.getHeight(Heightmap.Types.MOTION_BLOCKING, bx, bz);
					}
				}
			}
		}

		BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
		for (int i = 0; i < CHUNKS; i++) {
			for (int j = 0; j < CHUNKS; j++) {
				LevelChunk chunk = chunks[j * CHUNKS + i];
				int originX = (centerCx + i - half) << 4;
				int originZ = (centerCz + j - half) << 4;
				for (int bx = 0; bx < 16; bx++) {
					for (int bz = 0; bz < 16; bz++) {
						int px = i * 16 + bx;
						int pz = j * 16 + bz;
						if (chunk == null) {
							image.setPixelRGBA(px, pz, UNKNOWN);
							continue;
						}
						int y = heights[pz * SIZE + px];
						if (y < minY) {
							image.setPixelRGBA(px, pz, UNKNOWN);
							continue;
						}
						cursor.set(originX + bx, y, originZ + bz);
						BlockState state = chunk.getBlockState(cursor);
						MapColor color = state.getMapColor(level, cursor);
						if (color == MapColor.NONE) {
							image.setPixelRGBA(px, pz, UNKNOWN);
							continue;
						}
						int north = pz > 0 ? heights[(pz - 1) * SIZE + px] : y;
						if (north < minY)
							north = y;
						MapColor.Brightness brightness = north < y ? MapColor.Brightness.HIGH
								: (north > y ? MapColor.Brightness.LOW : MapColor.Brightness.NORMAL);
						image.setPixelRGBA(px, pz, color.calculateRGBColor(brightness));
					}
				}
			}
		}
		texture.upload();
		return true;
	}
}
