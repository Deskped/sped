package deskped.sped.privat.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.GameRenderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

import java.util.UUID;

import deskped.sped.SpedMod;
import deskped.sped.privat.ClaimKeybind;
import deskped.sped.privat.ClaimNetwork;
import deskped.sped.privat.ClaimRequestSyncPacket;
import deskped.sped.SpedClientConfig;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClaimClientEvents {

    private static final int MINE = 0x3DD68C;
    private static final int OTHER = 0xE0654F;

    public static void openScreen() {
        Minecraft.getInstance().setScreen(new ClaimScreen());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ClaimKeybind.OPEN == null)
            return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null)
            return;
        while (ClaimKeybind.OPEN.consumeClick()) {
            ClaimNetwork.CHANNEL.sendToServer(new ClaimRequestSyncPacket());
            mc.setScreen(new ClaimScreen());
        }
    }

    @SubscribeEvent
    public static void onCrosshair(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type())
            return;
        if (!SpedClientConfig.CLAIM_HUD)
            return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK)
            return;
        BlockPos pos = ((BlockHitResult) mc.hitResult).getBlockPos();
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;
        if (!ClientClaimCache.isClaimed(cx, cz))
            return;
        UUID owner = ClientClaimCache.owner(cx, cz);
        boolean mine = ClientClaimCache.local() != null && ClientClaimCache.local().equals(owner);
        String name = mine ? null : ClientClaimCache.trustedNames().get(owner);
        String opName = mine || !ClientClaimCache.isOp() ? null : ClientClaimCache.ownerName(cx, cz);
        String label = mine ? tr("\u0412\u0430\u0448 \u043f\u0440\u0438\u0432\u0430\u0442", "Your claim")
                : (name != null ? tr("\u0414\u0440\u0443\u0433: ", "Trusted: ") + name
                : (opName != null ? tr("\u041f\u0440\u0438\u0432\u0430\u0442: ", "Claim: ") + opName : tr("\u0427\u0443\u0436\u043e\u0439 \u043f\u0440\u0438\u0432\u0430\u0442", "Claimed")));
        GuiGraphics g = event.getGuiGraphics();
        int w = mc.font.width(label);
        int x = (mc.getWindow().getGuiScaledWidth() - w) / 2;
        int y = mc.getWindow().getGuiScaledHeight() / 2 - 28;
        g.fill(x - 4, y - 3, x + w + 4, y + mc.font.lineHeight + 2, 0x88000000);
        g.fill(x - 4, y - 3, x - 3, y + mc.font.lineHeight + 2, 0xFF000000 | (mine ? MINE : OTHER));
        g.drawString(mc.font, label, x, y, 0xFFE6EAF0, false);
    }

    @SubscribeEvent
    public static void onRenderWorld(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS)
            return;
        if (!SpedClientConfig.CLAIM_BORDERS)
            return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null)
            return;
        Player player = mc.player;
        int pcx = player.blockPosition().getX() >> 4;
        int pcz = player.blockPosition().getZ() >> 4;
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ps.last().pose();

        float t = mc.level.getGameTime() + event.getPartialTick();
        float py = (float) player.getY();
        float yLow = py - 8f;
        float yHigh = py + 12f;
        float yScan = py + 0.6f + (float) Math.sin(t * 0.06f) * 1.4f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder bb = tess.getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);

        int r = 7;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = pcx + dx;
                int cz = pcz + dz;
                if (!ClientClaimCache.isClaimed(cx, cz))
                    continue;
                boolean mine = ClientClaimCache.isMine(cx, cz);
                int col = mine ? MINE : OTHER;
                float cr = ((col >> 16) & 0xFF) / 255f;
                float cg = ((col >> 8) & 0xFF) / 255f;
                float cb = (col & 0xFF) / 255f;
                float pulse = 0.82f + 0.18f * (float) Math.sin(t * 0.09f + (cx * 31 + cz * 17));
                float aWall = (mine ? 0.20f : 0.14f) * pulse;
                float aLine = (mine ? 0.85f : 0.55f) * pulse;
                float x0 = cx << 4;
                float z0 = cz << 4;
                float x1 = x0 + 16;
                float z1 = z0 + 16;
                if (exposed(cx - 1, cz, mine))
                    sideX(bb, mat, x0, z0, z1, yLow, py, yHigh, yScan, cr, cg, cb, aWall, aLine);
                if (exposed(cx + 1, cz, mine))
                    sideX(bb, mat, x1, z0, z1, yLow, py, yHigh, yScan, cr, cg, cb, aWall, aLine);
                if (exposed(cx, cz - 1, mine))
                    sideZ(bb, mat, z0, x0, x1, yLow, py, yHigh, yScan, cr, cg, cb, aWall, aLine);
                if (exposed(cx, cz + 1, mine))
                    sideZ(bb, mat, z1, x0, x1, yLow, py, yHigh, yScan, cr, cg, cb, aWall, aLine);
            }
        }

        tess.end();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ps.popPose();
    }

    private static void sideX(BufferBuilder bb, Matrix4f mat, float x, float z0, float z1, float yLow, float yMid, float yHigh, float yScan, float r, float g, float b, float aWall, float aLine) {
        bb.vertex(mat, x, yLow, z0).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x, yLow, z1).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x, yMid, z1).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x, yMid, z0).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x, yMid, z0).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x, yMid, z1).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x, yHigh, z1).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x, yHigh, z0).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x, yScan - 0.07f, z0).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x, yScan - 0.07f, z1).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x, yScan + 0.07f, z1).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x, yScan + 0.07f, z0).color(r, g, b, aLine).endVertex();
        edge(bb, mat, x, z0, yLow, yHigh, r, g, b, aLine * 0.7f, true);
        edge(bb, mat, x, z1, yLow, yHigh, r, g, b, aLine * 0.7f, true);
    }

    private static void sideZ(BufferBuilder bb, Matrix4f mat, float z, float x0, float x1, float yLow, float yMid, float yHigh, float yScan, float r, float g, float b, float aWall, float aLine) {
        bb.vertex(mat, x0, yLow, z).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x1, yLow, z).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x1, yMid, z).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x0, yMid, z).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x0, yMid, z).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x1, yMid, z).color(r, g, b, aWall).endVertex();
        bb.vertex(mat, x1, yHigh, z).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x0, yHigh, z).color(r, g, b, 0f).endVertex();
        bb.vertex(mat, x0, yScan - 0.07f, z).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x1, yScan - 0.07f, z).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x1, yScan + 0.07f, z).color(r, g, b, aLine).endVertex();
        bb.vertex(mat, x0, yScan + 0.07f, z).color(r, g, b, aLine).endVertex();
        edge(bb, mat, x0, z, yLow, yHigh, r, g, b, aLine * 0.7f, false);
        edge(bb, mat, x1, z, yLow, yHigh, r, g, b, aLine * 0.7f, false);
    }

    private static void edge(BufferBuilder bb, Matrix4f mat, float x, float z, float y0, float y1, float r, float g, float b, float a, boolean alongZ) {
        float w = 0.06f;
        if (alongZ) {
            bb.vertex(mat, x, y0, z - w).color(r, g, b, a).endVertex();
            bb.vertex(mat, x, y0, z + w).color(r, g, b, a).endVertex();
            bb.vertex(mat, x, y1, z + w).color(r, g, b, a).endVertex();
            bb.vertex(mat, x, y1, z - w).color(r, g, b, a).endVertex();
        } else {
            bb.vertex(mat, x - w, y0, z).color(r, g, b, a).endVertex();
            bb.vertex(mat, x + w, y0, z).color(r, g, b, a).endVertex();
            bb.vertex(mat, x + w, y1, z).color(r, g, b, a).endVertex();
            bb.vertex(mat, x - w, y1, z).color(r, g, b, a).endVertex();
        }
    }

    private static boolean exposed(int cx, int cz, boolean mine) {
        return !ClientClaimCache.isClaimed(cx, cz) || ClientClaimCache.isMine(cx, cz) != mine;
    }

    private static String tr(String ru, String en) {
        return deskped.sped.ext.ExtLang.pick(ru, en);
    }
}
