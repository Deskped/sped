package deskped.sped.privat;

import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

public class ClaimSyncPacket {

    public final Map<Long, UUID> claims;
    public final int playerClaimCount;
    public final Map<UUID, String> trustedNames;
    public final Map<UUID, String> ownerNames;
    public final boolean op;

    public ClaimSyncPacket(Map<Long, UUID> claims, int playerClaimCount, Map<UUID, String> trustedNames, Map<UUID, String> ownerNames, boolean op) {
        this.claims = claims;
        this.playerClaimCount = playerClaimCount;
        this.trustedNames = trustedNames;
        this.ownerNames = ownerNames;
        this.op = op;
    }

    public static void encode(ClaimSyncPacket pkt, FriendlyByteBuf buf) {
        buf.writeInt(pkt.claims.size());
        pkt.claims.forEach((key, owner) -> {
            buf.writeLong(key);
            buf.writeLong(owner.getMostSignificantBits());
            buf.writeLong(owner.getLeastSignificantBits());
        });
        buf.writeInt(pkt.playerClaimCount);
        buf.writeInt(pkt.trustedNames.size());
        pkt.trustedNames.forEach((uuid, name) -> {
            buf.writeLong(uuid.getMostSignificantBits());
            buf.writeLong(uuid.getLeastSignificantBits());
            buf.writeUtf(name, 64);
        });
        buf.writeBoolean(pkt.op);
        buf.writeInt(pkt.ownerNames.size());
        pkt.ownerNames.forEach((uuid, name) -> {
            buf.writeLong(uuid.getMostSignificantBits());
            buf.writeLong(uuid.getLeastSignificantBits());
            buf.writeUtf(name, 64);
        });
    }

    public static ClaimSyncPacket decode(FriendlyByteBuf buf) {
        int size = buf.readInt();
        Map<Long, UUID> map = new HashMap<>();
        for (int i = 0; i < size; i++) {
            long pos = buf.readLong();
            UUID uuid = new UUID(buf.readLong(), buf.readLong());
            map.put(pos, uuid);
        }
        int count = buf.readInt();
        int trustSize = buf.readInt();
        Map<UUID, String> trustedNames = new HashMap<>();
        for (int i = 0; i < trustSize; i++) {
            UUID uuid = new UUID(buf.readLong(), buf.readLong());
            String name = buf.readUtf(64);
            trustedNames.put(uuid, name);
        }
        boolean op = buf.readBoolean();
        int ownSize = buf.readInt();
        Map<UUID, String> ownerNames = new HashMap<>();
        for (int i = 0; i < ownSize; i++) {
            UUID uuid = new UUID(buf.readLong(), buf.readLong());
            String name = buf.readUtf(64);
            ownerNames.put(uuid, name);
        }
        return new ClaimSyncPacket(map, count, trustedNames, ownerNames, op);
    }

    public static void handle(ClaimSyncPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        deskped.sped.privat.client.ClientClaimCache.applySync(pkt.claims, pkt.playerClaimCount, pkt.trustedNames, pkt.ownerNames, pkt.op)));
        ctx.get().setPacketHandled(true);
    }
}
