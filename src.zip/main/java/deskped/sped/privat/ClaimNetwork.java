package deskped.sped.privat;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClaimNetwork {

    private static final String VERSION = "1";
    public static SimpleChannel CHANNEL;

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        if (CHANNEL != null)
            return;
        CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SpedMod.MODID, "claim"),
                () -> VERSION, VERSION::equals, VERSION::equals);
        int id = 0;
        CHANNEL.registerMessage(id++, ClaimSyncPacket.class, ClaimSyncPacket::encode, ClaimSyncPacket::decode, ClaimSyncPacket::handle);
        CHANNEL.registerMessage(id++, ClaimActionPacket.class, ClaimActionPacket::encode, ClaimActionPacket::decode, ClaimActionPacket::handle);
        CHANNEL.registerMessage(id++, ClaimTrustPacket.class, ClaimTrustPacket::encode, ClaimTrustPacket::decode, ClaimTrustPacket::handle);
        CHANNEL.registerMessage(id++, ClaimRequestSyncPacket.class, ClaimRequestSyncPacket::encode, ClaimRequestSyncPacket::decode, ClaimRequestSyncPacket::handle);
        CHANNEL.registerMessage(id++, OpenScreenPacket.class, OpenScreenPacket::encode, OpenScreenPacket::decode, OpenScreenPacket::handle);
    }

    public static void sendClaimSync(ServerPlayer player) {
        if (player.getServer() == null)
            return;
        ClaimData data = ClaimData.get(player.getServer());
        int count = data.countClaims(player.getUUID());
        Map<UUID, String> trustedNames = data.getTrustedNames(player.getUUID(), player.getServer());
        boolean op = player.hasPermissions(2);
        Map<UUID, String> ownerNames = new HashMap<>();
        if (op) {
            for (UUID owner : new HashSet<>(data.getAllClaims().values())) {
                String name = player.getServer().getProfileCache() != null
                        ? player.getServer().getProfileCache().get(owner).map(pr -> pr.getName()).orElse(null)
                        : null;
                ownerNames.put(owner, name != null ? name : owner.toString().substring(0, 8));
            }
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ClaimSyncPacket(data.getAllClaims(), count, trustedNames, ownerNames, op));
    }

    public static void openScreen(ServerPlayer player) {
        sendClaimSync(player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenScreenPacket());
    }
}
