package deskped.sped.privat;

import net.minecraft.network.FriendlyByteBuf;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenScreenPacket {

    public OpenScreenPacket() {
    }

    public static void encode(OpenScreenPacket pkt, FriendlyByteBuf buf) {
    }

    public static OpenScreenPacket decode(FriendlyByteBuf buf) {
        return new OpenScreenPacket();
    }

    public static void handle(OpenScreenPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                        deskped.sped.privat.client.ClaimClientEvents.openScreen()));
        ctx.get().setPacketHandled(true);
    }
}
