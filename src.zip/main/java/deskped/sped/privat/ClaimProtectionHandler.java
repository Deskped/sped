package deskped.sped.privat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BeaconBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.BlastFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.CraftingTableBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.DropperBlock;
import net.minecraft.world.level.block.EnchantmentTableBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SmokerBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TrappedChestBlock;
import net.minecraft.world.level.block.piston.PistonStructureResolver;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.PistonEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.Optional;
import java.util.UUID;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClaimProtectionHandler {

    private static int tick = 0;

    private static boolean overworld(Level level) {
        return level.dimension().equals(Level.OVERWORLD);
    }

    private static boolean protectedFor(Level level, BlockPos pos, UUID actor, boolean op) {
        if (!overworld(level))
            return false;
        if (op)
            return false;
        MinecraftServer server = level.getServer();
        if (server == null)
            return false;
        ClaimData data = ClaimData.get(server);
        Optional<UUID> owner = data.getOwner(pos.getX() >> 4, pos.getZ() >> 4);
        if (owner.isEmpty())
            return false;
        if (owner.get().equals(actor))
            return false;
        return !data.isTrusted(owner.get(), actor);
    }

    private static boolean protectedFor(Level level, BlockPos pos, Player player) {
        if (!(player instanceof ServerPlayer sp))
            return false;
        return protectedFor(level, pos, sp.getUUID(), sp.hasPermissions(2));
    }

    private static void deny(Player player) {
        if (player instanceof ServerPlayer sp) {
            boolean ru = sp.getLanguage() != null && sp.getLanguage().toLowerCase(java.util.Locale.ROOT).startsWith("ru");
            sp.displayClientMessage(Component.literal(ru ? "\u042d\u0442\u043e \u043f\u0440\u0438\u0432\u0430\u0442" : "Protected claim"), true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (event.getPlayer() == null)
            return;
        if (protectedFor((Level) event.getLevel(), event.getPos(), event.getPlayer())) {
            event.setCanceled(true);
            deny(event.getPlayer());
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof Player player))
            return;
        if (protectedFor((Level) event.getLevel(), event.getPos(), player)) {
            event.setCanceled(true);
            deny(player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onMultiPlace(BlockEvent.EntityMultiPlaceEvent event) {
        if (!(event.getEntity() instanceof Player player))
            return;
        Level level = (Level) event.getLevel();
        for (BlockSnapshot snapshot : event.getReplacedBlockSnapshots()) {
            if (protectedFor(level, snapshot.getPos(), player)) {
                event.setCanceled(true);
                deny(player);
                return;
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getLevel().isClientSide)
            return;
        Level level = event.getLevel();
        Player player = event.getEntity();
        BlockPos pos = event.getPos();
        var held = player.getItemInHand(event.getHand());
        if (held.getItem() instanceof BucketItem && held.getItem() != Items.BUCKET) {
            BlockPos placePos = pos.relative(event.getHitVec().getDirection());
            if (protectedFor(level, placePos, player)) {
                event.setCanceled(true);
                deny(player);
                return;
            }
        }
        if (!protectedFor(level, pos, player))
            return;
        BlockState state = level.getBlockState(pos);
        Block block = state.getBlock();
        boolean interactive =
                block instanceof ChestBlock || block instanceof BarrelBlock ||
                block instanceof ShulkerBoxBlock || block instanceof TrappedChestBlock ||
                block instanceof HopperBlock || block instanceof DispenserBlock ||
                block instanceof DropperBlock || block instanceof FurnaceBlock ||
                block instanceof BlastFurnaceBlock || block instanceof SmokerBlock ||
                block instanceof CraftingTableBlock || block instanceof AnvilBlock ||
                block instanceof EnchantmentTableBlock || block instanceof LecternBlock ||
                block instanceof DoorBlock || block instanceof TrapDoorBlock ||
                block instanceof FenceGateBlock || block instanceof ButtonBlock ||
                block instanceof LeverBlock || block instanceof NoteBlock ||
                block instanceof JukeboxBlock || block instanceof BeaconBlock ||
                block instanceof BedBlock;
        if (interactive) {
            event.setCanceled(true);
            deny(player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        Entity target = event.getTarget();
        if (target instanceof Enemy)
            return;
        if (protectedFor(event.getLevel(), target.blockPosition(), event.getEntity())) {
            event.setCanceled(true);
            deny(event.getEntity());
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(AttackEntityEvent event) {
        Entity target = event.getTarget();
        if (target instanceof Enemy || target instanceof Player)
            return;
        if (protectedFor(event.getEntity().level(), target.blockPosition(), event.getEntity())) {
            event.setCanceled(true);
            deny(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        HitResult hit = event.getRayTraceResult();
        if (hit.getType() != HitResult.Type.BLOCK)
            return;
        Projectile projectile = event.getProjectile();
        Level level = projectile.level();
        if (!overworld(level))
            return;
        BlockPos pos = ((BlockHitResult) hit).getBlockPos();
        Entity owner = projectile.getOwner();
        if (!(owner instanceof Player shooter))
            return;
        if (protectedFor(level, pos, shooter.getUUID(), shooter.hasPermissions(2)))
            event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFluid(BlockEvent.FluidPlaceBlockEvent event) {
        if (!(event.getLevel() instanceof Level level) || !overworld(level))
            return;
        MinecraftServer server = level.getServer();
        if (server == null)
            return;
        BlockPos pos = event.getPos();
        Optional<UUID> owner = data(server).getOwner(pos.getX() >> 4, pos.getZ() >> 4);
        if (owner.isEmpty())
            return;
        for (Direction d : Direction.values()) {
            if (d == Direction.UP)
                continue;
            BlockPos n = pos.relative(d);
            if (!level.getFluidState(n).isEmpty()) {
                Optional<UUID> nOwner = data(server).getOwner(n.getX() >> 4, n.getZ() >> 4);
                if (!owner.equals(nOwner)) {
                    event.setCanceled(true);
                    return;
                }
            }
        }
    }

    @SubscribeEvent
    public static void onPiston(PistonEvent.Pre event) {
        if (!(event.getLevel() instanceof Level level) || !overworld(level))
            return;
        MinecraftServer server = level.getServer();
        if (server == null)
            return;
        ClaimData data = ClaimData.get(server);
        BlockPos piston = event.getPos();
        Optional<UUID> pistonOwner = data.getOwner(piston.getX() >> 4, piston.getZ() >> 4);
        PistonStructureResolver resolver = event.getStructureHelper();
        if (resolver != null && resolver.resolve()) {
            for (BlockPos p : resolver.getToPush()) {
                if (foreign(data, p, pistonOwner) || foreign(data, p.relative(event.getDirection()), pistonOwner)) {
                    event.setCanceled(true);
                    return;
                }
            }
            for (BlockPos p : resolver.getToDestroy()) {
                if (foreign(data, p, pistonOwner)) {
                    event.setCanceled(true);
                    return;
                }
            }
        } else if (foreign(data, piston.relative(event.getDirection()), pistonOwner)) {
            event.setCanceled(true);
        }
    }

    private static ClaimData data(MinecraftServer server) {
        return ClaimData.get(server);
    }

    private static boolean foreign(ClaimData data, BlockPos pos, Optional<UUID> pistonOwner) {
        Optional<UUID> owner = data.getOwner(pos.getX() >> 4, pos.getZ() >> 4);
        if (owner.isEmpty())
            return false;
        return !owner.equals(pistonOwner);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.getServer() == null)
            return;
        ClaimData data = ClaimData.get(player.getServer());
        data.updateLastOnline(player.getUUID());
        data.purgeExpired();
        ClaimNetwork.sendClaimSync(player);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.getServer() == null)
            return;
        ClaimData.get(player.getServer()).updateLastOnline(player.getUUID());
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END)
            return;
        if (++tick % 6000 != 0)
            return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null)
            ClaimData.get(server).purgeExpired();
    }
}
