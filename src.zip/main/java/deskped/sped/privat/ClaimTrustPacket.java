package deskped.sped.privat;

import com.mojang.authlib.GameProfile;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.network.NetworkEvent;

import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

public class ClaimTrustPacket {

    public final String targetName;
    public final boolean add;

    public ClaimTrustPacket(String targetName, boolean add) {
        this.targetName = targetName;
        this.add = add;
    }

    public static void encode(ClaimTrustPacket pkt, FriendlyByteBuf buf) {
        buf.writeUtf(pkt.targetName, 64);
        buf.writeBoolean(pkt.add);
    }

    public static ClaimTrustPacket decode(FriendlyByteBuf buf) {
        return new ClaimTrustPacket(buf.readUtf(64), buf.readBoolean());
    }

    public static void handle(ClaimTrustPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null)
                return;
            boolean ru = player.getLanguage() != null && player.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
            ClaimData data = ClaimData.get(player.getServer());
            if (data.countClaims(player.getUUID()) == 0) {
                player.sendSystemMessage(Component.literal(ru ? "\u0423 \u0432\u0430\u0441 \u043d\u0435\u0442 \u043f\u0440\u0438\u0432\u0430\u0442\u043e\u0432" : "You have no claims"));
                return;
            }
            Optional<GameProfile> profileOpt = player.getServer().getProfileCache().get(pkt.targetName);
            if (profileOpt.isEmpty()) {
                player.sendSystemMessage(Component.literal((ru ? "\u0418\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d: " : "Player not found: ") + pkt.targetName));
                return;
            }
            UUID targetUUID = profileOpt.get().getId();
            if (targetUUID.equals(player.getUUID())) {
                player.sendSystemMessage(Component.literal(ru ? "\u041d\u0435\u043b\u044c\u0437\u044f \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u0435\u0431\u044f" : "Cannot add yourself"));
                return;
            }
            if (pkt.add) {
                boolean ok = data.addTrusted(player.getUUID(), targetUUID);
                player.sendSystemMessage(Component.literal(ok
                        ? (ru ? pkt.targetName + " \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d" : pkt.targetName + " added")
                        : (ru ? pkt.targetName + " \u0443\u0436\u0435 \u0432 \u0441\u043f\u0438\u0441\u043a\u0435" : pkt.targetName + " is already trusted")));
            } else {
                boolean ok = data.removeTrusted(player.getUUID(), targetUUID);
                player.sendSystemMessage(Component.literal(ok
                        ? (ru ? pkt.targetName + " \u0443\u0434\u0430\u043b\u0451\u043d" : pkt.targetName + " removed")
                        : (ru ? pkt.targetName + " \u043d\u0435 \u0432 \u0441\u043f\u0438\u0441\u043a\u0435" : pkt.targetName + " is not in your list")));
            }
            ClaimNetwork.sendClaimSync(player);
        });
        ctx.get().setPacketHandled(true);
    }
}
