package deskped.sped.privat;

import com.mojang.authlib.GameProfile;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class ClaimData extends SavedData {

    private static final String NAME = "sped_claims";
    public static final int MAX_CLAIMS = 133;
    private static final long EXPIRE_MS = 33L * 24L * 60L * 60L * 1000L;

    private final Map<Long, UUID> claims = new HashMap<>();
    private final Map<UUID, Long> lastOnline = new HashMap<>();
    private final Map<UUID, Set<UUID>> trusted = new HashMap<>();

    public static ClaimData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(ClaimData::load, ClaimData::new, NAME);
    }

    private static ClaimData load(CompoundTag tag) {
        ClaimData data = new ClaimData();
        ListTag claimList = tag.getList("claims", Tag.TAG_COMPOUND);
        for (Tag t : claimList) {
            CompoundTag c = (CompoundTag) t;
            data.claims.put(c.getLong("chunk"), c.getUUID("owner"));
        }
        ListTag onlineList = tag.getList("lastOnline", Tag.TAG_COMPOUND);
        for (Tag t : onlineList) {
            CompoundTag c = (CompoundTag) t;
            data.lastOnline.put(c.getUUID("player"), c.getLong("time"));
        }
        ListTag trustList = tag.getList("trusted", Tag.TAG_COMPOUND);
        for (Tag t : trustList) {
            CompoundTag c = (CompoundTag) t;
            UUID owner = c.getUUID("owner");
            ListTag members = c.getList("members", Tag.TAG_COMPOUND);
            Set<UUID> set = new HashSet<>();
            for (Tag m : members)
                set.add(((CompoundTag) m).getUUID("uuid"));
            data.trusted.put(owner, set);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag claimList = new ListTag();
        claims.forEach((key, owner) -> {
            CompoundTag c = new CompoundTag();
            c.putLong("chunk", key);
            c.putUUID("owner", owner);
            claimList.add(c);
        });
        tag.put("claims", claimList);

        ListTag onlineList = new ListTag();
        lastOnline.forEach((player, time) -> {
            CompoundTag c = new CompoundTag();
            c.putUUID("player", player);
            c.putLong("time", time);
            onlineList.add(c);
        });
        tag.put("lastOnline", onlineList);

        ListTag trustList = new ListTag();
        trusted.forEach((owner, members) -> {
            CompoundTag c = new CompoundTag();
            c.putUUID("owner", owner);
            ListTag membersTag = new ListTag();
            for (UUID m : members) {
                CompoundTag mt = new CompoundTag();
                mt.putUUID("uuid", m);
                membersTag.add(mt);
            }
            c.put("members", membersTag);
            trustList.add(c);
        });
        tag.put("trusted", trustList);
        return tag;
    }

    public static long chunkKey(int cx, int cz) {
        return ((long) cx & 0xFFFFFFFFL) << 32 | ((long) cz & 0xFFFFFFFFL);
    }

    public Optional<UUID> getOwner(int cx, int cz) {
        return Optional.ofNullable(claims.get(chunkKey(cx, cz)));
    }

    public int countClaims(UUID player) {
        int count = 0;
        for (UUID v : claims.values())
            if (v.equals(player))
                count++;
        return count;
    }

    public boolean claim(int cx, int cz, UUID player) {
        long key = chunkKey(cx, cz);
        if (claims.containsKey(key))
            return false;
        if (countClaims(player) >= MAX_CLAIMS)
            return false;
        claims.put(key, player);
        setDirty();
        return true;
    }

    public boolean unclaim(int cx, int cz, UUID requester, boolean isOp) {
        long key = chunkKey(cx, cz);
        UUID owner = claims.get(key);
        if (owner == null)
            return false;
        if (!isOp && !owner.equals(requester))
            return false;
        claims.remove(key);
        setDirty();
        return true;
    }

    public int wipe(UUID target) {
        int before = claims.size();
        claims.entrySet().removeIf(e -> e.getValue().equals(target));
        trusted.remove(target);
        int removed = before - claims.size();
        if (removed > 0)
            setDirty();
        return removed;
    }

    public Map<Long, UUID> getAllClaims() {
        return Collections.unmodifiableMap(claims);
    }

    public boolean addTrusted(UUID owner, UUID target) {
        if (owner.equals(target))
            return false;
        boolean added = trusted.computeIfAbsent(owner, k -> new HashSet<>()).add(target);
        if (added)
            setDirty();
        return added;
    }

    public boolean removeTrusted(UUID owner, UUID target) {
        Set<UUID> set = trusted.get(owner);
        if (set == null)
            return false;
        boolean removed = set.remove(target);
        if (set.isEmpty())
            trusted.remove(owner);
        if (removed)
            setDirty();
        return removed;
    }

    public boolean isTrusted(UUID owner, UUID player) {
        Set<UUID> set = trusted.get(owner);
        return set != null && set.contains(player);
    }

    public Map<UUID, String> getTrustedNames(UUID owner, MinecraftServer server) {
        Set<UUID> set = trusted.getOrDefault(owner, Collections.emptySet());
        Map<UUID, String> result = new HashMap<>();
        for (UUID uuid : set) {
            String name = server.getProfileCache().get(uuid).map(GameProfile::getName).orElse(uuid.toString().substring(0, 8));
            result.put(uuid, name);
        }
        return result;
    }

    public void updateLastOnline(UUID player) {
        lastOnline.put(player, System.currentTimeMillis());
        setDirty();
    }

    public void purgeExpired() {
        long now = System.currentTimeMillis();
        Set<UUID> expired = new HashSet<>();
        lastOnline.forEach((p, t) -> {
            if (now - t > EXPIRE_MS)
                expired.add(p);
        });
        if (expired.isEmpty())
            return;
        claims.entrySet().removeIf(e -> expired.contains(e.getValue()));
        expired.forEach(lastOnline::remove);
        expired.forEach(trusted::remove);
        setDirty();
    }
}
