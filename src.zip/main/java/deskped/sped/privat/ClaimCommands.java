package deskped.sped.privat;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClaimCommands {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("sped").then(Commands.literal("private")
                .executes(ctx -> {
                    ClaimNetwork.openScreen(ctx.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.literal("claim").executes(ctx -> action(ctx.getSource(), true)))
                .then(Commands.literal("unclaim").executes(ctx -> action(ctx.getSource(), false)))
                .then(Commands.literal("trust").then(Commands.argument("nick", StringArgumentType.word())
                        .executes(ctx -> trust(ctx.getSource(), StringArgumentType.getString(ctx, "nick"), true))))
                .then(Commands.literal("untrust").then(Commands.argument("nick", StringArgumentType.word())
                        .executes(ctx -> trust(ctx.getSource(), StringArgumentType.getString(ctx, "nick"), false))))
                .then(Commands.literal("wipe").requires(s -> s.hasPermission(2)).then(Commands.argument("nick", StringArgumentType.word())
                        .executes(ctx -> wipe(ctx.getSource(), StringArgumentType.getString(ctx, "nick")))))));
    }

    private static boolean ru(CommandSourceStack src) {
        return src.getEntity() instanceof ServerPlayer p
                && p.getLanguage() != null && p.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
    }

    private static int action(CommandSourceStack src, boolean add) {
        ServerPlayer p;
        try {
            p = src.getPlayerOrException();
        } catch (Exception e) {
            return 0;
        }
        if (!p.level().dimension().equals(Level.OVERWORLD)) {
            p.sendSystemMessage(Component.literal(ru(src) ? "\u041f\u0440\u0438\u0432\u0430\u0442\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u043e\u0431\u044b\u0447\u043d\u043e\u043c \u043c\u0438\u0440\u0435" : "Claims only in the overworld"));
            return 0;
        }
        int cx = p.blockPosition().getX() >> 4;
        int cz = p.blockPosition().getZ() >> 4;
        ClaimData data = ClaimData.get(p.getServer());
        if (add) {
            if (data.countClaims(p.getUUID()) >= ClaimData.MAX_CLAIMS) {
                p.sendSystemMessage(Component.literal(ru(src) ? "\u0414\u043e\u0441\u0442\u0438\u0433\u043d\u0443\u0442 \u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c (" + ClaimData.MAX_CLAIMS + ")" : "Maximum reached (" + ClaimData.MAX_CLAIMS + ")"));
                return 0;
            }
            boolean ok = data.claim(cx, cz, p.getUUID());
            p.sendSystemMessage(Component.literal(ok
                    ? (ru(src) ? "\u0427\u0430\u043d\u043a \u043f\u0440\u0438\u0432\u0430\u0447\u0435\u043d" : "Chunk claimed")
                    : (ru(src) ? "\u0427\u0430\u043d\u043a \u0443\u0436\u0435 \u0437\u0430\u043d\u044f\u0442" : "Already claimed")));
        } else {
            boolean ok = data.unclaim(cx, cz, p.getUUID(), p.hasPermissions(2));
            p.sendSystemMessage(Component.literal(ok
                    ? (ru(src) ? "\u041f\u0440\u0438\u0432\u0430\u0442 \u0441\u043d\u044f\u0442" : "Claim removed")
                    : (ru(src) ? "\u0417\u0434\u0435\u0441\u044c \u043d\u0435\u0442 \u0442\u0432\u043e\u0435\u0433\u043e \u043f\u0440\u0438\u0432\u0430\u0442\u0430" : "No claim of yours here")));
        }
        ClaimNetwork.sendClaimSync(p);
        return 1;
    }

    private static int trust(CommandSourceStack src, String nick, boolean add) {
        ServerPlayer p;
        try {
            p = src.getPlayerOrException();
        } catch (Exception e) {
            return 0;
        }
        Optional<GameProfile> profile = p.getServer().getProfileCache().get(nick);
        if (profile.isEmpty()) {
            p.sendSystemMessage(Component.literal((ru(src) ? "\u0418\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d: " : "Player not found: ") + nick));
            return 0;
        }
        UUID id = profile.get().getId();
        ClaimData data = ClaimData.get(p.getServer());
        if (add)
            data.addTrusted(p.getUUID(), id);
        else
            data.removeTrusted(p.getUUID(), id);
        ClaimNetwork.sendClaimSync(p);
        p.sendSystemMessage(Component.literal(nick + (add ? (ru(src) ? " \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d" : " added") : (ru(src) ? " \u0443\u0434\u0430\u043b\u0451\u043d" : " removed"))));
        return 1;
    }

    private static int wipe(CommandSourceStack src, String nick) {
        UUID id = null;
        ServerPlayer online = src.getServer().getPlayerList().getPlayerByName(nick);
        if (online != null) {
            id = online.getUUID();
        } else {
            Optional<GameProfile> gp = src.getServer().getProfileCache().get(nick);
            if (gp.isPresent())
                id = gp.get().getId();
        }
        if (id == null) {
            src.sendFailure(Component.literal((ru(src) ? "\u0418\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d: " : "Player not found: ") + nick));
            return 0;
        }
        int removed = ClaimData.get(src.getServer()).wipe(id);
        final int fr = removed;
        src.sendSuccess(() -> Component.literal((ru(src) ? "\u0421\u043d\u044f\u0442\u043e \u043f\u0440\u0438\u0432\u0430\u0442\u043e\u0432: " : "Claims wiped: ") + fr + " (" + nick + ")"), true);
        for (ServerPlayer pl : src.getServer().getPlayerList().getPlayers())
            ClaimNetwork.sendClaimSync(pl);
        return 1;
    }
}
