package deskped.sped.privat;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.lwjgl.glfw.GLFW;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClaimKeybind {

    public static KeyMapping OPEN;

    @SubscribeEvent
    public static void onRegister(RegisterKeyMappingsEvent event) {
        OPEN = new KeyMapping("key.sped.privat", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.sped");
        event.register(OPEN);
    }
}
