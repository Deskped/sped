package deskped.sped.privat;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ClaimRequestSyncPacket {

    public ClaimRequestSyncPacket() {
    }

    public static void encode(ClaimRequestSyncPacket pkt, FriendlyByteBuf buf) {
    }

    public static ClaimRequestSyncPacket decode(FriendlyByteBuf buf) {
        return new ClaimRequestSyncPacket();
    }

    public static void handle(ClaimRequestSyncPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null)
                ClaimNetwork.sendClaimSync(player);
        });
        ctx.get().setPacketHandled(true);
    }
}
