package deskped.sped;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import deskped.sped.client.ClientMenuState;
import deskped.sped.client.StreamingMenuSound;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


@OnlyIn(Dist.CLIENT)
public class Menu {

    private static final int LOGO_SRC_W = 870;
    private static final int LOGO_SRC_H = 440;
    private static final int LOGO_W     = 280;
    private static final int LOGO_H     = 142;

    private static final int BTN_SRC_W = 700;
    private static final int BTN_SRC_H = 200;
    private static final int BTN_W     = 160;
    private static final int BTN_H     = 44;
    private static final int BTN_GAP   = 6;

    private static final int PLANET_W = 256;
    private static final int PLANET_H = 256;
    private static final int END_W    = 256;
    private static final int END_H    = 256;
    private static final int NOVA_W   = 256;
    private static final int NOVA_H   = 256;

    private static final String SERVER = "mc.deskped.ru";

    private static final long INTRO_END_MS    = 8000L;
    private static final long INTRO_LOGO1_MS  =  500L;
    private static final long INTRO_LOGO2_MS  = 2000L;
    private static final long INTRO_LAUNCH_MS = 7000L;

    private static final int DESKPED_LOGO_W = 128;
    private static final int DESKPED_LOGO_H = 72;
    private static final int DESKPED_FOR_W  = 128;
    private static final int DESKPED_FOR_H  = 72;

    private static StreamingMenuSound customMusic;
    private static boolean wasCustomMenu;

    private static final List<ImageButton>   imgButtons     = new ArrayList<>();

    private static boolean introShown  = false;
    private static boolean introActive = false;
    private static long    introStart  = 0L;

    private static final List<Star>          stars          = new ArrayList<>();
    private static final List<Particle>      particles      = new ArrayList<>();
    private static final List<Comet>         comets         = new ArrayList<>();
    private static final List<DeepObject>    deepObjects    = new ArrayList<>();
    private static final List<Constellation> constellations = new ArrayList<>();
    private static final Random              RNG            = new Random();

    private static float breathScale = 1f;
    private static float breathDir   = 1f;
    private static final float BREATH_SPD = 0.00022f;
    private static final float BREATH_MAX = 0.011f;

    private static float planetRot = 0f;
    private static float endRot    = 0f;
    private static float novaRot   = 0f;

    private static float smoothMX = 0f;
    private static float smoothMY = 0f;

    private static final float[] btnHover = new float[4];
    private static final float[] btnScale = new float[4];

    private static int cachedSW = 0;
    private static int cachedSH = 0;

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        Screen    screen = event.getScreen();
        Minecraft mc     = Minecraft.getInstance();
        imgButtons.clear();

        boolean isCustom = ClientMenuState.customMenu;
        if (isCustom != wasCustomMenu) {
            if (isCustom) { nukeMusic(); startMusic(); } else stopMusic();
            wasCustomMenu = isCustom;
        }

        if (ClientMenuState.customMenu) {
            new ArrayList<>(event.getListenersList()).forEach(o -> { if (o instanceof Button b) event.removeListener(b); });

            if (cachedSW != screen.width || cachedSH != screen.height || stars.isEmpty()) {
                buildWorld(screen.width, screen.height);
                cachedSW = screen.width;
                cachedSH = screen.height;
            }

            boolean ru = mc.options.languageCode.startsWith("ru");
            int cx        = screen.width / 2;
            int logoTopY  = 14;
            int btnStartY = logoTopY + LOGO_H + 14;

            String[] keys = {"play", "options", "back", "exit"};
            for (int i = 0; i < keys.length; i++) {
                String key     = keys[i];
                String texName = ru ? key + "_ru" : key;
                ResourceLocation tex = ResourceLocation.fromNamespaceAndPath("sped", "textures/gui/menu/btn/" + texName + ".png");
                int bx = cx - BTN_W / 2;
                int by = btnStartY + i * (BTN_H + BTN_GAP);
                final String k = key;
                ImageButton ib = new ImageButton(bx, by, BTN_W, BTN_H, BTN_SRC_W, BTN_SRC_H, tex,
                        b -> handleButtonClick(k, screen, mc, ru));
                imgButtons.add(ib);
                event.addListener(ib);
                btnHover[i] = 0f;
                btnScale[i] = 1f;
            }

            if (!introShown) { introActive = true; introStart = System.currentTimeMillis(); introShown = true; }
        }
    }

    private static void handleButtonClick(String key, Screen screen, Minecraft mc, boolean ru) {
        switch (key) {
            case "play" -> {
                if (ClientMenuState.confirmed) { connect(screen, mc); return; }
                mc.setScreen(new ConfirmScreen(screen, mc, ru));
            }
            case "options" -> mc.setScreen(new net.minecraft.client.gui.screens.OptionsScreen(screen, mc.options));
            case "back"    -> { ClientMenuState.customMenu = false; stopMusic(); mc.setScreen(new TitleScreen()); }
            case "exit"    -> mc.stop();
        }
    }

    static void connect(Screen from, Minecraft mc) {
        ServerData sd = new ServerData("SPED", SERVER, false);
        ConnectScreen.startConnecting(from, mc, ServerAddress.parseString(SERVER), sd, false);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onRenderPre(ScreenEvent.Render.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen)) return;
        if (!ClientMenuState.customMenu) return;

        nukeMusic();
        event.setCanceled(true);

        Screen      screen  = event.getScreen();
        GuiGraphics g       = event.getGuiGraphics();
        long        now     = System.currentTimeMillis();
        int         mx      = event.getMouseX();
        int         my      = event.getMouseY();
        float       partial = event.getPartialTick();

        if (introActive) { renderIntro(g, screen, now); return; }

        smoothMX += (mx - smoothMX) * 0.04f;
        smoothMY += (my - smoothMY) * 0.04f;

        updateBreath();
        planetRot += 0.08f;
        endRot    += 0.05f;
        novaRot   -= 0.07f;

        tickParticles(screen.width, screen.height);
        tickComets(screen.width, screen.height);

        float pcx = screen.width  * 0.5f;
        float pcy = screen.height * 0.5f;
        float avX = (smoothMX - pcx) / screen.width;
        float avY = (smoothMY - pcy) / screen.height;

        drawSpaceBg(g, screen.width, screen.height, now, avX, avY);
        drawDeepObjects(g, now, avX, avY);
        drawConstellations(g, now, avX, avY);
        drawComets(g, avX, avY);
        drawPlanetLeft(g, screen, avX, avY, now);
        drawEndRight(g, screen, avX, avY);
        drawParticles(g, avX, avY);
        drawLogo(g, screen.width, screen.height, now);
        drawImageButtons(g, mx, my, partial, now);
        drawCornerLogos(g, screen.width, screen.height);

        for (Renderable r : screen.renderables) {
            if (r instanceof ImageButton) continue;
            r.render(g, mx, my, partial);
        }
    }

    private static void buildWorld(int sw, int sh) {
        stars.clear();
        deepObjects.clear();
        constellations.clear();
        particles.clear();

        for (int i = 0; i < 1200; i++)
            stars.add(new Star(RNG.nextFloat() * sw, RNG.nextFloat() * sh));

        int[] nebColors = {0x1A0050, 0x0A0035, 0x200060, 0x002240, 0x003318, 0x400010, 0x250070, 0x001840};
        for (int i = 0; i < 7; i++) {
            deepObjects.add(new DeepObject(
                sw * (0.04f + RNG.nextFloat() * 0.92f),
                sh * (0.04f + RNG.nextFloat() * 0.92f),
                DeepObject.TYPE_NEBULA,
                55f + RNG.nextFloat() * 150f,
                RNG.nextFloat() * (float)(Math.PI * 2),
                nebColors[i % nebColors.length]
            ));
        }

        int[] galTypes = {DeepObject.TYPE_GALAXY_SPIRAL, DeepObject.TYPE_GALAXY_RING,
                          DeepObject.TYPE_GALAXY_ELLIPTIC, DeepObject.TYPE_GALAXY_SPIRAL,
                          DeepObject.TYPE_GALAXY_IRREGULAR};
        for (int i = 0; i < 5; i++) {
            deepObjects.add(new DeepObject(
                sw * (0.08f + RNG.nextFloat() * 0.84f),
                sh * (0.08f + RNG.nextFloat() * 0.84f),
                galTypes[i],
                25f + RNG.nextFloat() * 60f,
                RNG.nextFloat() * (float)(Math.PI * 2),
                0
            ));
        }

        for (int i = 0; i < 4; i++) {
            deepObjects.add(new DeepObject(
                sw * (0.05f + RNG.nextFloat() * 0.9f),
                sh * (0.05f + RNG.nextFloat() * 0.9f),
                DeepObject.TYPE_CLUSTER,
                15f + RNG.nextFloat() * 35f,
                0,
                0
            ));
        }

        int[][] patterns = {
            {0,0, 20,15, 35,5, 50,20, 40,35},
            {0,0, 15,20, 30,10, 50,25, 25,35, 10,30},
            {0,20, 20,0, 40,15, 35,35, 10,40},
            {0,10, 25,0, 45,20, 30,40, 5,35, 20,20},
            {10,0, 0,25, 20,35, 40,30, 50,10, 30,5}
        };
        for (int c = 0; c < 5; c++) {
            int[] pat = patterns[c % patterns.length];
            float ox = sw * (0.05f + RNG.nextFloat() * 0.85f);
            float oy = sh * (0.05f + RNG.nextFloat() * 0.85f);
            float sc = 1.6f + RNG.nextFloat() * 3.0f;
            List<float[]> pts = new ArrayList<>();
            for (int i = 0; i < pat.length; i += 2)
                pts.add(new float[]{ox + pat[i] * sc, oy + pat[i+1] * sc});
            constellations.add(new Constellation(pts));
        }
    }

    private static void drawDeepObjects(GuiGraphics g, long now, float avX, float avY) {
        double t = now / 1000.0;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);

        for (DeepObject obj : deepObjects) {
            float px = obj.x - avX * obj.parallax;
            float py = obj.y - avY * obj.parallax;

            switch (obj.type) {
                case DeepObject.TYPE_NEBULA         -> drawNebula(g, px, py, obj, t);
                case DeepObject.TYPE_GALAXY_SPIRAL  -> drawGalaxySpiral(g, px, py, obj, t);
                case DeepObject.TYPE_GALAXY_RING    -> drawGalaxyRing(g, px, py, obj, t);
                case DeepObject.TYPE_GALAXY_ELLIPTIC-> drawGalaxyElliptic(g, px, py, obj, t);
                case DeepObject.TYPE_GALAXY_IRREGULAR->drawGalaxyIrregular(g, px, py, obj, t);
                case DeepObject.TYPE_CLUSTER        -> drawCluster(g, px, py, obj, t);
            }
        }
    }

    private static void drawNebula(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        float breathe = obj.radius * (1f + 0.05f * (float) Math.sin(t * obj.phase + obj.offset));
        int layers = 16;
        for (int i = layers; i > 0; i--) {
            float frac = i / (float) layers;
            float r    = breathe * frac;
            float a    = (1f - frac) * (1f - frac) * 0.08f;
            int   col  = ((int)(a * 255) << 24) | obj.color;
            int   ir   = (int) r;
            g.fill((int)(px - ir), (int)(py - ir), (int)(px + ir), (int)(py + ir), col);
        }
    }

    private static void drawGalaxySpiral(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        float rot  = (float)(t * 0.01f * obj.rotDir);
        int   arms = obj.arms;
        int   pts  = 55;
        for (int arm = 0; arm < arms; arm++) {
            float armAngle = (float)(arm * Math.PI * 2 / arms) + rot;
            for (int i = 0; i < pts; i++) {
                float frac  = i / (float) pts;
                float r     = frac * obj.radius;
                float theta = armAngle + frac * (float)(Math.PI * 2.8);
                float sx    = px + (float)(Math.cos(theta) * r);
                float sy    = py + (float)(Math.sin(theta) * r * obj.flat);
                float a     = (1f - frac) * (1f - frac) * 0.5f;
                int   alpha = (int)(a * 255);
                if (alpha < 4) continue;
                int cr = lerp(0xAA, 0xFF, frac);
                int cg = lerp(0x88, 0xCC, frac);
                g.fill((int)sx, (int)sy, (int)sx + 1, (int)sy + 1,
                       (alpha << 24) | (cr << 16) | (cg << 8) | 0xFF);
            }
        }
        for (int i = 8; i > 0; i--) {
            float frac = i / 8f;
            float r    = obj.radius * 0.09f * frac;
            float a    = (1f - frac) * (1f - frac) * 0.3f;
            g.fill((int)(px - r), (int)(py - r), (int)(px + r), (int)(py + r), ((int)(a * 255) << 24) | 0xEEDDFF);
        }
    }

    private static void drawGalaxyRing(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        float rot   = (float)(t * 0.008f * obj.rotDir);
        int   steps = 90;
        for (int i = 0; i < steps; i++) {
            float angle = (float)(i * Math.PI * 2 / steps) + rot;
            float rVar  = obj.radius * (0.88f + 0.12f * (float) Math.sin(angle * 5 + t * 0.3));
            float sx    = px + (float)(Math.cos(angle) * rVar);
            float sy    = py + (float)(Math.sin(angle) * rVar * obj.flat);
            float a     = 0.45f + 0.15f * (float) Math.sin(angle * 3 + t * 0.2);
            int   alpha = (int)(a * 255);
            int   cr    = lerp(0xCC, 0xFF, (float) Math.abs(Math.sin(angle)));
            g.fill((int)sx, (int)sy, (int)sx + 1, (int)sy + 1, (alpha << 24) | (cr << 16) | 0xAAFF);
        }
        for (int i = 6; i > 0; i--) {
            float frac = i / 6f;
            float r    = obj.radius * 0.08f * frac;
            float a    = (1f - frac) * 0.25f;
            g.fill((int)(px - r), (int)(py - r), (int)(px + r), (int)(py + r), ((int)(a * 255) << 24) | 0xDDCCFF);
        }
    }

    private static void drawGalaxyElliptic(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        int layers = 14;
        for (int layer = layers; layer > 0; layer--) {
            float frac  = layer / (float) layers;
            float rx    = obj.radius * frac;
            float ry    = obj.radius * frac * obj.flat * 0.65f;
            float a     = (1f - frac) * (1f - frac) * 0.32f;
            int   steps = Math.max(16, (int)(rx * 4));
            steps = Math.min(steps, 64);
            for (int i = 0; i < steps; i++) {
                float angle = (float)(i * Math.PI * 2 / steps);
                float sx    = px + (float)(Math.cos(angle) * rx);
                float sy    = py + (float)(Math.sin(angle) * ry);
                int   alpha = (int)(a * 255);
                if (alpha < 3) continue;
                int cr = lerp(0xDD, 0xFF, 1f - frac);
                int cb = lerp(0xAA, 0xFF, 1f - frac);
                g.fill((int)sx, (int)sy, (int)sx + 1, (int)sy + 1, (alpha << 24) | (cr << 16) | (cr << 8) | cb);
            }
        }
    }

    private static void drawGalaxyIrregular(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        float rot = (float)(t * 0.006f * obj.rotDir);
        for (int b = 0; b < obj.arms; b++) {
            float ba  = obj.blobAngles[b] + rot;
            float br  = obj.radius * obj.blobDists[b];
            float bcx = px + (float)(Math.cos(ba) * br);
            float bcy = py + (float)(Math.sin(ba) * br * obj.flat);
            float brad = obj.radius * obj.blobSizes[b];
            int   pts  = 35;
            for (int i = 0; i < pts; i++) {
                float frac = i / (float) pts;
                float r    = brad * frac;
                float ang  = obj.blobAngles[b] * 7 + frac * (float)(Math.PI * 2);
                float sx   = bcx + (float)(Math.cos(ang) * r);
                float sy   = bcy + (float)(Math.sin(ang) * r);
                float a    = (1f - frac) * 0.38f;
                int   alpha = (int)(a * 255);
                if (alpha < 3) continue;
                int cr = lerp(0x88, 0xFF, frac);
                int cg = lerp(0x66, 0xBB, frac);
                g.fill((int)sx, (int)sy, (int)sx + 1, (int)sy + 1, (alpha << 24) | (cr << 16) | (cg << 8) | 0xFF);
            }
        }
    }

    private static void drawCluster(GuiGraphics g, float px, float py, DeepObject obj, double t) {
        for (int i = 6; i > 0; i--) {
            float frac = i / 6f;
            float r    = obj.radius * frac * 0.55f;
            float a    = (1f - frac) * (1f - frac) * 0.10f;
            g.fill((int)(px - r), (int)(py - r), (int)(px + r), (int)(py + r), ((int)(a * 255) << 24) | 0xEECCFF);
        }
        int count = obj.clusterCount;
        for (int i = 0; i < count; i++) {
            float sr    = obj.radius * (float) Math.sqrt(obj.rands[i * 3]);
            float sa    = obj.rands[i * 3 + 1] * (float)(Math.PI * 2);
            float sx    = px + (float)(Math.cos(sa) * sr);
            float sy    = py + (float)(Math.sin(sa) * sr);
            float twink = 0.4f + 0.6f * (float) Math.abs(Math.sin(t * (0.5f + obj.rands[i * 3 + 2]) + i));
            int   alpha = (int)(twink * 190);
            g.fill((int)sx, (int)sy, (int)sx + 1, (int)sy + 1, (alpha << 24) | 0xFFEEFF);
        }
    }

    private static void drawConstellations(GuiGraphics g, long now, float avX, float avY) {
        double t = now / 1000.0;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        for (Constellation c : constellations) {
            float pulse = 0.4f + 0.15f * (float) Math.sin(t * c.pulseSpd + c.pulsePh);
            float ox2   = -avX * 12f;
            float oy2   = -avY * 12f;
            List<float[]> pts = c.points;
            for (int i = 0; i < pts.size() - 1; i++) {
                float x1 = pts.get(i)[0]     + ox2;
                float y1 = pts.get(i)[1]     + oy2;
                float x2 = pts.get(i + 1)[0] + ox2;
                float y2 = pts.get(i + 1)[1] + oy2;
                drawLine(g, x1, y1, x2, y2, (int)(pulse * 45), 0xAABBFF);
            }
            for (float[] pt : pts) {
                float ppx = pt[0] + ox2;
                float ppy = pt[1] + oy2;
                int   sa2 = (int)(pulse * 0.9f * 255);
                g.fill((int)(ppx - 1), (int)(ppy - 1), (int)(ppx + 2), (int)(ppy + 2), (sa2 << 24) | 0xFFFFFF);
                int glowA = (int)(pulse * 0.28f * 255);
                g.fill((int)(ppx - 2), (int)(ppy - 2), (int)(ppx + 3), (int)(ppy + 3), (glowA << 24) | 0xBBCCFF);
            }
        }
    }

    private static void drawLine(GuiGraphics g, float x1, float y1, float x2, float y2, int alpha, int rgb) {
        int steps = (int)(Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)) / 1.5f);
        if (steps < 1) return;
        int col = (alpha << 24) | rgb;
        for (int i = 0; i <= steps; i++) {
            float tt = i / (float) steps;
            g.fill((int)(x1 + (x2 - x1) * tt), (int)(y1 + (y2 - y1) * tt),
                   (int)(x1 + (x2 - x1) * tt) + 1, (int)(y1 + (y2 - y1) * tt) + 1, col);
        }
    }

    private static void drawPlanetLeft(GuiGraphics g, Screen screen, float avX, float avY, long now) {
        float size  = screen.height * 1.1f;
        float half  = size * 0.5f;
        float cx    = -avX * 20f;
        float cy    = screen.height * 0.5f + (-avY * 20f);
        float sc    = size / PLANET_W;
        double t    = now / 1000.0;
        float pulse = 0.55f + 0.15f * (float) Math.sin(t * 0.8);
        int glowR   = (int)(half + 40);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        for (int r = glowR; r > 4; r -= 6) {
            float a = pulse * (1f - r / (float) glowR) * 0.22f;
            int   c = (Math.max(0, Math.min(255, (int)(a * 255))) << 24) | 0x9FA1D1;
            g.fill((int)(cx - r), (int)(cy - r), (int)(cx + r), (int)(cy + r), c);
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().mulPose(Axis.ZP.rotationDegrees(planetRot));
        g.pose().scale(sc, sc, 1f);
        g.pose().translate(-PLANET_W * 0.5f, -PLANET_H * 0.5f, 0);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped", "textures/environment/your_planet.png"),
               0, 0, 0, 0, PLANET_W, PLANET_H, PLANET_W, PLANET_H);
        g.pose().popPose();
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void drawEndRight(GuiGraphics g, Screen screen, float avX, float avY) {
        float size  = screen.height * 1.1f;
        float half  = size * 0.5f;
        float cx    = screen.width + (-avX * 20f);
        float cy    = screen.height * 0.5f + (-avY * 20f);
        float sc    = size / END_W;
        int glowR   = (int)(half + 50);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        for (int r = glowR; r > 4; r -= 6) {
            float a = 0.55f * (1f - r / (float) glowR) * 0.20f;
            int   c = (Math.max(0, Math.min(255, (int)(a * 255))) << 24) | 0x7722EE;
            g.fill((int)(cx - r), (int)(cy - r), (int)(cx + r), (int)(cy + r), c);
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().mulPose(Axis.ZP.rotationDegrees(endRot));
        g.pose().scale(sc, sc, 1f);
        g.pose().translate(-END_W * 0.5f, -END_H * 0.5f, 0);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped", "textures/environment/your_end.png"),
               0, 0, 0, 0, END_W, END_H, END_W, END_H);
        g.pose().popPose();
        float novaSc = (size * 1.1f) / NOVA_W;
        float novaCX = cx + (-avX * 5f);
        float novaCY = cy + (-avY * 5f);
        g.pose().pushPose();
        g.pose().translate(novaCX, novaCY, 0);
        g.pose().mulPose(Axis.ZP.rotationDegrees(novaRot));
        g.pose().scale(novaSc, novaSc, 1f);
        g.pose().translate(-NOVA_W * 0.5f, -NOVA_H * 0.5f, 0);
        RenderSystem.setShaderColor(1, 1, 1, 0.85f);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped", "textures/environment/your_nova.png"),
               0, 0, 0, 0, NOVA_W, NOVA_H, NOVA_W, NOVA_H);
        g.pose().popPose();
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void drawImageButtons(GuiGraphics g, int mx, int my, float partial, long now) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < imgButtons.size(); i++) {
            ImageButton ib  = imgButtons.get(i);
            boolean     hov = mx >= ib.getX() && mx <= ib.getX() + ib.getWidth()
                           && my >= ib.getY() && my <= ib.getY() + ib.getHeight();
            btnHover[i] = clamp01(btnHover[i] + (hov ? 0.08f : -0.06f));
            float h   = btnHover[i];
            float targetScale = 1f + h * 0.04f;
            btnScale[i] += (targetScale - btnScale[i]) * 0.15f;
            float sc  = btnScale[i];
            float bcx = ib.getX() + ib.getWidth()  * 0.5f;
            float bcy = ib.getY() + ib.getHeight() * 0.5f;
            float sx  = (float) ib.getWidth()  / ib.srcW * sc;
            float sy  = (float) ib.getHeight() / ib.srcH * sc;
            RenderSystem.setShaderColor(1f, 1f, 1f, 0.85f + h * 0.15f);
            g.pose().pushPose();
            g.pose().translate(bcx, bcy, 0);
            g.pose().scale(sx, sy, 1f);
            g.pose().translate(-ib.srcW * 0.5f, -ib.srcH * 0.5f, 0);
            g.blit(ib.tex, 0, 0, 0, 0, ib.srcW, ib.srcH, ib.srcW, ib.srcH);
            g.pose().popPose();
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void updateBreath() {
        breathScale += breathDir * BREATH_SPD;
        if (breathScale >= 1f + BREATH_MAX) { breathScale = 1f + BREATH_MAX; breathDir = -1f; }
        if (breathScale <= 1f - BREATH_MAX) { breathScale = 1f - BREATH_MAX; breathDir =  1f; }
    }

    public static void drawSpaceBg(GuiGraphics g, int sw, int sh, long now, float avX, float avY) {
        drawVGrad(g, 0, 0,      sw, sh / 2, 0xFF020008, 0xFF040012);
        drawVGrad(g, 0, sh / 2, sw, sh,     0xFF040012, 0xFF01000A);
        double t  = now / 20000.0;
        int    ba = (int)(18 + 10 * Math.sin(t));
        drawVGrad(g, 0, 0,          sw, sh / 3, (ba << 24) | 0x1A0040, 0x00000000);
        drawVGrad(g, 0, sh * 2 / 3, sw, sh,     0x00000000, (ba << 24) | 0x000030);

        double sec = now / 1000.0;
        for (Star s : stars) {
            s.angle += s.rotSpd;
            float px = s.x - avX * (10f + s.depth * 20f);
            float py = s.y - avY * (10f + s.depth * 20f);
            if (px < -4 || py < -4 || px > sw + 4 || py > sh + 4) continue;

            float tw        = 0.3f + 0.7f * (float) Math.sin(sec * s.twSpd + s.twPh);
            float edgeFade  = Math.min(1f, Math.min(Math.min(px, sw - px), Math.min(py, sh - py)) / 80f);
            float depthFade = 0.6f + 0.4f * (1f - s.depth);
            int   alpha     = Math.max(0, Math.min(255, (int)(s.alpha * tw * edgeFade * depthFade * 255)));
            if (alpha < 4) continue;

            float cs = 0.5f + 0.5f * (float) Math.sin(sec * s.cSpd + s.cPh);
            int r2   = lerp(s.cA >> 16 & 0xFF, s.cB >> 16 & 0xFF, cs);
            int g2   = lerp(s.cA >> 8  & 0xFF, s.cB >> 8  & 0xFF, cs);
            int b2   = lerp(s.cA       & 0xFF, s.cB       & 0xFF, cs);
            int col  = (alpha << 24) | (r2 << 16) | (g2 << 8) | b2;

            float hs = s.size * 0.5f;
            g.pose().pushPose();
            g.pose().translate(px, py, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees(s.angle));
            g.pose().translate(-hs, -hs, 0);
            g.fill(0, 0, (int) s.size, (int) s.size, col);
            g.pose().popPose();
        }
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void drawStarSpike(GuiGraphics g, int cx, int cy, int len, int dx, int dy, int baseCol) {
        int a = (baseCol >> 24) & 0xFF;
        int rgb = baseCol & 0x00FFFFFF;
        for (int i = 1; i <= len; i++) {
            float fade = 1f - (i / (float) len);
            fade = fade * fade;
            int alpha = (int)(a * fade);
            if (alpha < 2) break;
            g.fill(cx + dx * i, cy + dy * i, cx + dx * i + 1, cy + dy * i + 1, (alpha << 24) | rgb);
        }
    }

    private static void drawVGrad(GuiGraphics g, int x, int y, int x2, int y2, int tc, int bc) {
        var buf = g.bufferSource().getBuffer(net.minecraft.client.renderer.RenderType.gui());
        var mat = g.pose().last().pose();
        int aT=tc>>24&0xFF,rT=tc>>16&0xFF,gT=tc>>8&0xFF,bT=tc&0xFF;
        int aB=bc>>24&0xFF,rB=bc>>16&0xFF,gB=bc>>8&0xFF,bB=bc&0xFF;
        buf.vertex(mat,x, y2,0).color(rB,gB,bB,aB).uv(0,1).overlayCoords(0).uv2(0xF000F0).normal(0,0,1).endVertex();
        buf.vertex(mat,x2,y2,0).color(rB,gB,bB,aB).uv(1,1).overlayCoords(0).uv2(0xF000F0).normal(0,0,1).endVertex();
        buf.vertex(mat,x2,y, 0).color(rT,gT,bT,aT).uv(1,0).overlayCoords(0).uv2(0xF000F0).normal(0,0,1).endVertex();
        buf.vertex(mat,x, y, 0).color(rT,gT,bT,aT).uv(0,0).overlayCoords(0).uv2(0xF000F0).normal(0,0,1).endVertex();
        g.bufferSource().endBatch(net.minecraft.client.renderer.RenderType.gui());
    }

    private static int lerp(int a, int b, float t) { return (int)(a + (b - a) * t); }

    private static void drawLogo(GuiGraphics g, int sw, int sh, long now) {
        double t      = now / 1000.0;
        int    cx     = sw / 2;
        float  ox     = (float)(Math.sin(t * 0.37) * 4.5);
        float  oy     = (float)(Math.cos(t * 0.28) * 3.0);
        float  logoCY = 14f + LOGO_H * 0.5f;
        float  scaleX = (float) LOGO_W / LOGO_SRC_W;
        float  scaleY = (float) LOGO_H / LOGO_SRC_H;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        g.pose().pushPose();
        g.pose().translate(cx + ox, logoCY + oy, 0);
        g.pose().scale(breathScale * scaleX, breathScale * scaleY, 1);
        g.pose().translate(-LOGO_SRC_W * 0.5f, -LOGO_SRC_H * 0.5f, 0);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped", "textures/screens/sped.png"),
               0, 0, 0, 0, LOGO_SRC_W, LOGO_SRC_H, LOGO_SRC_W, LOGO_SRC_H);
        g.pose().popPose();
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void tickParticles(int sw, int sh) {
        float pcx = sw * 0.5f, pcy = sh * 0.5f;
        particles.removeIf(p -> p.life <= 0f);
        if (RNG.nextFloat() < 0.40f && particles.size() < 90) {
            double a   = RNG.nextDouble() * Math.PI * 2;
            float  r   = 122f + RNG.nextFloat() * 14f;
            float  px  = pcx + (float)(Math.cos(a) * r);
            float  py  = pcy + (float)(Math.sin(a) * r);
            float  spd = 0.30f + RNG.nextFloat() * 0.50f;
            float  vx  = (float)(Math.cos(a + Math.PI / 2) * spd);
            float  vy  = (float)(Math.sin(a + Math.PI / 2) * spd);
            int[] cols = {0x5500AA,0x8800EE,0xAA00FF,0x330055,0x180026,0x440077,0x7700CC};
            particles.add(new Particle(px, py, vx, vy,
                1.2f + RNG.nextFloat() * 2.0f, 1f,
                cols[RNG.nextInt(cols.length)],
                RNG.nextFloat() * 360f, (RNG.nextFloat() - 0.5f) * 7f, RNG.nextInt(3)));
        }
        for (Particle p : particles) {
            float dx = pcx - p.x, dy = pcy - p.y;
            float d  = (float) Math.sqrt(dx * dx + dy * dy);
            if (d > 0.01f) { float pull = d > 127f ? 0.015f : (d < 117f ? -0.010f : 0f); p.vx += dx/d*pull; p.vy += dy/d*pull; }
            p.x += p.vx; p.y += p.vy; p.vx *= 0.980f; p.vy *= 0.980f;
            p.rot += p.rotSpd; p.life -= 0.0032f; p.size *= 0.9992f;
        }
    }

    private static void drawParticles(GuiGraphics g, float avX, float avY) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        float ox = -avX * 5f, oy = -avY * 5f;
        for (Particle p : particles) {
            int a = Math.max(0,(int)(p.life*210)); int c=(a<<24)|p.color; float s=p.size; float h=s*0.35f;
            g.pose().pushPose();
            g.pose().translate(p.x+ox, p.y+oy, 0);
            g.pose().mulPose(Axis.ZP.rotationDegrees(p.rot));
            switch(p.type){
                case 0 -> g.fill((int)(-s/2),(int)(-s/2),(int)(s/2),(int)(s/2),c);
                case 1 -> { g.fill((int)(-s/2),(int)(-h/2),(int)(s/2),(int)(h/2),c); g.fill((int)(-h/2),(int)(-s/2),(int)(h/2),(int)(s/2),c); }
                default -> { g.fill((int)(-s/2),(int)(-h/2),0,(int)(h/2),c); g.fill(0,(int)(-s/2),(int)(s/2),(int)(h/2),c); }
            }
            g.pose().popPose();
        }
        RenderSystem.setShaderColor(1,1,1,1);
    }

    private static void tickComets(int sw, int sh) {
        comets.removeIf(c -> c.y > sh + 80);
        if (RNG.nextFloat() < 0.0022f) comets.add(new Comet(RNG.nextFloat()*sw,-30f,3f+RNG.nextFloat()*5f));
        for (Comet c : comets) c.y += c.spd;
    }

    private static void drawComets(GuiGraphics g, float avX, float avY) {
        float ox=-avX*3f, oy=-avY*3f;
        for (Comet c : comets) {
            int len=18+(int)(c.spd*3);
            for(int i=0;i<len;i++){
                int alpha=(int)((1f-i/(float)len)*140);
                g.fill((int)(c.x+ox),(int)(c.y+oy-i*2),(int)(c.x+ox)+1,(int)(c.y+oy-i*2+2),(alpha<<24)|0xBBCCFF);
            }
        }
    }

    @SubscribeEvent
    public static void onMouseClicked(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen) || !ClientMenuState.customMenu || introActive) return;
        Screen screen = event.getScreen();
        int mx = (int)event.getMouseX(), my = (int)event.getMouseY();
        int x = screen.width  - DESKPED_LOGO_W - 10;
        int y = screen.height - DESKPED_LOGO_H - 10;
        if (mx >= x && mx <= x + DESKPED_LOGO_W && my >= y && my <= y + DESKPED_LOGO_H) {
            net.minecraft.Util.getPlatform().openUri("https://discord.gg/WEHyDw9Bcb");
            event.setCanceled(true);
        }
    }

    private static void drawCornerLogos(GuiGraphics g, int sw, int sh) {
        int x = sw - DESKPED_LOGO_W - 10;
        int y = sh - DESKPED_LOGO_H - 10;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped","textures/gui/menu/deskpedlogo.png"),
               x, y, 0, 0, DESKPED_LOGO_W, DESKPED_LOGO_H, DESKPED_LOGO_W, DESKPED_LOGO_H);
        g.blit(ResourceLocation.fromNamespaceAndPath("sped","textures/gui/menu/deskpedforlogo.png"),
               x, y, 0, 0, DESKPED_FOR_W, DESKPED_FOR_H, DESKPED_FOR_W, DESKPED_FOR_H);
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private static void startMusic() {
        try {
            Minecraft mc=Minecraft.getInstance(); SoundManager sm=mc.getSoundManager();
            if(customMusic!=null){sm.stop(customMusic);customMusic=null;}
            customMusic=new StreamingMenuSound(ResourceLocation.fromNamespaceAndPath("sped","menu"));
            sm.play(customMusic);
        } catch(Exception e){e.printStackTrace();}
    }

    private static void stopMusic() {
        if(customMusic!=null){Minecraft.getInstance().getSoundManager().stop(customMusic);customMusic=null;}
    }

    static void nukeMusic() {
        try {
            Minecraft mc=Minecraft.getInstance();
            mc.getMusicManager().stopPlaying();
            for(SoundSource src:SoundSource.values()) if(src!=SoundSource.MASTER) mc.getSoundManager().stop(null,src);
        } catch(Exception ignored){}
    }

    private static void renderIntro(GuiGraphics g, Screen screen, long now) {
        long t=now-introStart;
        if(t>=INTRO_END_MS){introActive=false;Minecraft.getInstance().setScreen(new TitleScreen());return;}
        if(!stars.isEmpty()) drawSpaceBg(g,screen.width,screen.height,now,0f,0f);
        else g.fill(0,0,screen.width,screen.height,0xFF000000);
        float cx=screen.width*0.5f,cy=screen.height*0.5f;
        boolean launched=t>=INTRO_LAUNCH_MS;
        float lt=launched?clamp01((float)(t-INTRO_LAUNCH_MS)/(INTRO_END_MS-INTRO_LAUNCH_MS)):0f;
        float a1=clamp01(t<INTRO_LOGO1_MS?0f:(t-INTRO_LOGO1_MS)/1000f);
        float a2=clamp01(t<INTRO_LOGO2_MS?0f:(t-INTRO_LOGO2_MS)/1000f);
        float bY=launched?0f:(float)(Math.sin(t/1000.0*0.9)*4);
        float bX=launched?0f:(float)(Math.sin(t/1000.0*0.6)*6);
        float jY=launched?(float)(-(Math.sin(lt*Math.PI)*screen.height*0.18f)+lt*lt*screen.height*0.9f):0f;
        float sw2=launched?lt*lt*720f:(float)(Math.sin(t/1000.0*0.7)*5);
        float fl=clamp01((lt-0.55f)/0.45f);
        float lx=cx+bX,ly=cy+bY+jY;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA,GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        ResourceLocation r1=ResourceLocation.fromNamespaceAndPath("sped","textures/gui/menu/deskpedlogo.png");
        ResourceLocation r2=ResourceLocation.fromNamespaceAndPath("sped","textures/gui/menu/deskpedforlogo.png");
        if(a1>0f){g.pose().pushPose();g.pose().translate(lx,ly,0);g.pose().scale(2f,2f,1f);g.pose().mulPose(Axis.ZP.rotationDegrees(sw2));g.pose().translate(-DESKPED_LOGO_W*0.5f,-DESKPED_LOGO_H*0.5f,0);RenderSystem.setShaderColor(1,1,1,a1);g.blit(r1,0,0,0,0,DESKPED_LOGO_W,DESKPED_LOGO_H,DESKPED_LOGO_W,DESKPED_LOGO_H);g.pose().popPose();}
        if(a2>0f){g.pose().pushPose();g.pose().translate(lx,ly,0);g.pose().scale(2f,2f,1f);g.pose().mulPose(Axis.ZP.rotationDegrees(sw2));g.pose().translate(-DESKPED_FOR_W*0.5f,-DESKPED_FOR_H*0.5f,0);RenderSystem.setShaderColor(1,1,1,a2);g.blit(r2,0,0,0,0,DESKPED_FOR_W,DESKPED_FOR_H,DESKPED_FOR_W,DESKPED_FOR_H);g.pose().popPose();}
        RenderSystem.setShaderColor(1,1,1,1);
        if(fl>0f) g.fill(0,0,screen.width,screen.height,((int)(fl*255)<<24)|0xFFFFFF);
    }

    public static void triggerMusicStart(){nukeMusic();startMusic();}
    public static void triggerMusicStop(){stopMusic();}
    private static float clamp01(float v){return Math.max(0f,Math.min(1f,v));}

    static class Star {
        float x,y,size,alpha,depth,angle,rotSpd,twSpd,twPh,cSpd,cPh; int cA,cB;
        Star(float x,float y){
            this.x=x;this.y=y;
            depth=RNG.nextFloat(); size=1f+RNG.nextFloat()*1.3f; alpha=0.65f+RNG.nextFloat()*0.35f;
            angle=RNG.nextFloat()*360f; rotSpd=(RNG.nextBoolean()?1f:-1f)*(0.04f+RNG.nextFloat()*0.28f);
            twSpd=0.3f+RNG.nextFloat()*2.5f; twPh=RNG.nextFloat()*(float)(Math.PI*2);
            cSpd=0.08f+RNG.nextFloat()*0.5f; cPh=RNG.nextFloat()*(float)(Math.PI*2);
            int[][] pairs={{0xFFFFFF,0xEEDDFF},{0xFFFFFF,0xDDEEFF},{0xFFFFFF,0xFFCCFF},{0xFFFFFF,0xCCDDFF},{0xFFFFFF,0xFF99CC},{0xFFFFFF,0xFFFFFF},{0xFFEEFF,0xFFFFFF}};
            int[] p=pairs[RNG.nextInt(pairs.length)]; cA=p[0]; cB=p[1];
        }
    }

    static class Particle {
        float x,y,vx,vy,size,life,rot,rotSpd; int color,type;
        Particle(float x,float y,float vx,float vy,float sz,float life,int col,float rot,float rotSpd,int type){
            this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.size=sz;this.life=life;this.color=col;this.rot=rot;this.rotSpd=rotSpd;this.type=type;
        }
    }

    static class Comet{float x,y,spd;Comet(float x,float y,float spd){this.x=x;this.y=y;this.spd=spd;}}

    static class DeepObject {
        static final int TYPE_NEBULA=0, TYPE_GALAXY_SPIRAL=1, TYPE_GALAXY_RING=2,
                         TYPE_GALAXY_ELLIPTIC=3, TYPE_GALAXY_IRREGULAR=4, TYPE_CLUSTER=5;
        float x, y, radius, offset, phase, flat, rotDir, parallax;
        int   type, color, arms;
        float[] blobAngles, blobDists, blobSizes, rands;
        int clusterCount;

        DeepObject(float x, float y, int type, float radius, float offset, int color) {
            this.x=x; this.y=y; this.type=type; this.radius=radius; this.offset=offset; this.color=color;
            this.phase=0.25f+RNG.nextFloat()*1.0f;
            this.flat=0.25f+RNG.nextFloat()*0.75f;
            this.rotDir=(RNG.nextBoolean()?1f:-1f)*(0.3f+RNG.nextFloat()*1.0f);
            this.parallax=6f+RNG.nextFloat()*8f;

            if(type==TYPE_GALAXY_SPIRAL){ arms=2+RNG.nextInt(2); }
            else if(type==TYPE_GALAXY_IRREGULAR){
                arms=4+RNG.nextInt(4);
                blobAngles=new float[arms]; blobDists=new float[arms]; blobSizes=new float[arms];
                for(int i=0;i<arms;i++){
                    blobAngles[i]=RNG.nextFloat()*(float)(Math.PI*2);
                    blobDists[i]=0.25f+RNG.nextFloat()*0.65f;
                    blobSizes[i]=0.18f+RNG.nextFloat()*0.28f;
                }
            } else if(type==TYPE_CLUSTER){
                clusterCount=25+RNG.nextInt(40);
                rands=new float[clusterCount*3];
                for(int i=0;i<rands.length;i++) rands[i]=RNG.nextFloat();
            }
        }
    }

    static class Constellation {
        List<float[]> points; float pulseSpd, pulsePh;
        Constellation(List<float[]> points){
            this.points=points;
            this.pulseSpd=0.4f+RNG.nextFloat()*0.8f;
            this.pulsePh=RNG.nextFloat()*(float)(Math.PI*2);
        }
    }
}