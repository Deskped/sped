/*

Kuwma: Этот код переносит YourLine ->  SPED позволяя загружать миры YourLine с модом SPED без потери блоков, структур и мира!
Самое важное, если для вашего аддона код не нужен или вызывает ошибки:

ПРОПИШИТЕ ЧТОБЫ ОН НЕ ВЫПОЛНЯЛСЯ/ПРОПИШИТЕ ЧТОБЫ ОН ИГНОРИРОВАЛСЯ
^ я ПЕРВЫЙ раз работаю с MissingMappingsEventами и понятия не имею к чему они приведут вне мода!

Что ещё важно без этого кода мод работает в стандартном режиме,
он нужен для переноса миров с YourLine контентом на SPED

*/
package deskped.sped;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.MissingMappingsEvent;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class Legacyremap {
	private static final String OLD = "yourline";
	private static final String NEW = "sped";

	@SubscribeEvent
	public static void onMissingMappings(MissingMappingsEvent event) {
		remap(event, ForgeRegistries.Keys.BLOCKS, ForgeRegistries.BLOCKS);
		remap(event, ForgeRegistries.Keys.ITEMS, ForgeRegistries.ITEMS);
		remap(event, ForgeRegistries.Keys.BLOCK_ENTITY_TYPES, ForgeRegistries.BLOCK_ENTITY_TYPES);
		remap(event, ForgeRegistries.Keys.ENTITY_TYPES, ForgeRegistries.ENTITY_TYPES);
		remap(event, ForgeRegistries.Keys.ENCHANTMENTS, ForgeRegistries.ENCHANTMENTS);
		remap(event, ForgeRegistries.Keys.MOB_EFFECTS, ForgeRegistries.MOB_EFFECTS);
		remap(event, ForgeRegistries.Keys.POTIONS, ForgeRegistries.POTIONS);
		remap(event, ForgeRegistries.Keys.PARTICLE_TYPES, ForgeRegistries.PARTICLE_TYPES);
		remap(event, ForgeRegistries.Keys.SOUND_EVENTS, ForgeRegistries.SOUND_EVENTS);
		remap(event, ForgeRegistries.Keys.MENU_TYPES, ForgeRegistries.MENU_TYPES);
	}

	private static <T> void remap(MissingMappingsEvent event, ResourceKey<Registry<T>> key, IForgeRegistry<T> registry) {
		for (MissingMappingsEvent.Mapping<T> mapping : event.getMappings(key, OLD)) {
			ResourceLocation id = new ResourceLocation(NEW, mapping.getKey().getPath());
			if (registry.containsKey(id))
				mapping.remap(registry.getValue(id));
			else
				mapping.ignore();
		}
	}
}