package deskped.sped.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import deskped.sped.init.SpedModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements SpedModBiomes.SpedModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> sped_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.sped_dimensionTypeReference != null) {
			retval = SpedModBiomes.adaptSurfaceRule(retval, this.sped_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setspedDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.sped_dimensionTypeReference = dimensionType;
	}
}