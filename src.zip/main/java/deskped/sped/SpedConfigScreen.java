package deskped.sped;

import deskped.sped.client.CosmicBg;
import deskped.sped.ext.ExtLang;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SpedConfigScreen extends Screen {

    private static final int ACCENT = 0xFFB58CFF;
    private static final int TXT = 0xFFEDE7FF;

    private final Screen parent;
    private Button claimBtn;
    private Button blockBtn;
    private Button dynBtn;

    public SpedConfigScreen(Screen parent) {
        super(Component.literal("Sped"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 46;
        claimBtn = Button.builder(claimLabel(), b -> {
            SpedClientConfig.setClaimHud(!SpedClientConfig.CLAIM_HUD);
            b.setMessage(claimLabel());
        }).bounds(cx - 110, y, 220, 20).build();
        blockBtn = Button.builder(blockLabel(), b -> {
            SpedClientConfig.setBlockHud(!SpedClientConfig.BLOCK_HUD);
            b.setMessage(blockLabel());
        }).bounds(cx - 110, y + 26, 220, 20).build();
        dynBtn = Button.builder(dynLabel(), b -> {
            boolean v = !SpedClientConfig.DYNAMIC_LIGHT;
            SpedClientConfig.setDynamicLight(v);
            Minecraft mc = Minecraft.getInstance();
            if (mc.getConnection() != null && SpedPrefs.CHANNEL != null)
                SpedPrefs.CHANNEL.sendToServer(new DynLightPrefPacket(v));
            b.setMessage(dynLabel());
        }).bounds(cx - 110, y + 52, 220, 20).build();
        addRenderableWidget(claimBtn);
        addRenderableWidget(blockBtn);
        addRenderableWidget(dynBtn);
        addRenderableWidget(Button.builder(Component.literal(ExtLang.pick("\u0413\u043e\u0442\u043e\u0432\u043e", "Done")), b -> onClose())
                .bounds(cx - 75, y + 86, 150, 20).build());
    }

    private Component claimLabel() {
        return Component.literal(ExtLang.pick("\u00ab\u0412\u0430\u0448 \u043f\u0440\u0438\u0432\u0430\u0442\u00bb: ", "Claim HUD: ") + onOff(SpedClientConfig.CLAIM_HUD));
    }

    private Component blockLabel() {
        return Component.literal(ExtLang.pick("HUD \u0431\u043b\u043e\u043a\u043e\u0432: ", "Block HUD: ") + onOff(SpedClientConfig.BLOCK_HUD));
    }

    private Component dynLabel() {
        return Component.literal(ExtLang.pick("\u0414\u0438\u043d\u0430\u043c\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0441\u0432\u0435\u0442: ", "Dynamic light: ") + onOff(SpedClientConfig.DYNAMIC_LIGHT));
    }

    private static String onOff(boolean v) {
        return v ? ExtLang.pick("\u0412\u041a\u041b", "ON") : ExtLang.pick("\u0412\u042b\u041a\u041b", "OFF");
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        CosmicBg.render(g, this.width, this.height, System.currentTimeMillis());
        int cx = this.width / 2;
        int top = this.height / 2 - 78;
        g.fill(cx - 130, top, cx + 130, top + 186, 0xC00B0620);
        g.fill(cx - 130, top, cx + 130, top + 1, ACCENT);
        g.fill(cx - 130, top + 185, cx + 130, top + 186, 0x66B58CFF);
        String title = "Sped";
        g.drawString(this.font, title, cx - this.font.width(title) / 2, top + 12, ACCENT, false);
        String sub = ExtLang.pick("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "Settings");
        g.drawString(this.font, sub, cx - this.font.width(sub) / 2, top + 24, 0xFF9E96C8, false);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
