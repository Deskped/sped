package deskped.sped.block.entity;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.SidedInvWrapper;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import deskped.sped.block.CrafterBlock;
import deskped.sped.ext.CrafterRegistry;
import deskped.sped.world.inventory.CrafterMenu;

public class CrafterBlockEntity extends RandomizableContainerBlockEntity implements CraftingContainer, WorldlyContainer {
	public static final int SLOT_COUNT = 9;
	public static final int DATA_TRIGGERED = 9;
	public static final int NUM_DATA = 10;

	private static final int[] SLOTS = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8};

	private NonNullList<ItemStack> stacks = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
	private int craftingTicksRemaining = 0;
	private final int[] slotStates = new int[SLOT_COUNT];
	private int triggered = 0;
	private final LazyOptional<? extends IItemHandler>[] handlers = SidedInvWrapper.create(this, Direction.values());

	private final ContainerData containerData = new ContainerData() {
		@Override
		public int get(int index) {
			return index == DATA_TRIGGERED ? CrafterBlockEntity.this.triggered : CrafterBlockEntity.this.slotStates[index];
		}

		@Override
		public void set(int index, int value) {
			if (index == DATA_TRIGGERED)
				CrafterBlockEntity.this.triggered = value;
			else
				CrafterBlockEntity.this.slotStates[index] = value;
			CrafterBlockEntity.this.setChanged();
		}

		@Override
		public int getCount() {
			return NUM_DATA;
		}
	};

	public CrafterBlockEntity(BlockPos position, BlockState state) {
		super(CrafterRegistry.CRAFTER.get(), position, state);
	}

	public static void serverTick(Level level, BlockPos pos, BlockState state, CrafterBlockEntity crafter) {
		int left = crafter.craftingTicksRemaining - 1;
		if (left < 0)
			return;
		crafter.craftingTicksRemaining = left;
		if (left == 0)
			level.setBlock(pos, state.setValue(CrafterBlock.CRAFTING, false), 3);
	}

	public ContainerData getContainerData() {
		return this.containerData;
	}

	public void setCraftingTicksRemaining(int ticks) {
		this.craftingTicksRemaining = ticks;
	}

	public boolean isSlotDisabled(int slot) {
		return slot >= 0 && slot < SLOT_COUNT && this.slotStates[slot] == 1;
	}

	public void setSlotDisabled(int slot, boolean disabled) {
		if (slot < 0 || slot >= SLOT_COUNT)
			return;
		this.slotStates[slot] = disabled ? 1 : 0;
		this.setChanged();
	}

	public boolean isTriggered() {
		return this.triggered == 1;
	}

	public void setTriggered(boolean value) {
		this.triggered = value ? 1 : 0;
		this.setChanged();
	}

	public int getRedstoneSignal() {
		int signal = 0;
		for (int i = 0; i < this.getContainerSize(); i++)
			if (!this.getItem(i).isEmpty() || this.isSlotDisabled(i))
				signal++;
		return signal;
	}

	@Override
	public void load(CompoundTag compound) {
		super.load(compound);
		this.craftingTicksRemaining = compound.getInt("crafting_ticks_remaining");
		this.stacks = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
		if (!this.tryLoadLootTable(compound))
			ContainerHelper.loadAllItems(compound, this.stacks);
		for (int i = 0; i < SLOT_COUNT; i++)
			this.slotStates[i] = 0;
		for (int slot : compound.getIntArray("disabled_slots"))
			if (slot >= 0 && slot < SLOT_COUNT)
				this.slotStates[slot] = 1;
		this.triggered = compound.getBoolean("triggered") ? 1 : 0;
	}

	@Override
	public void saveAdditional(CompoundTag compound) {
		super.saveAdditional(compound);
		compound.putInt("crafting_ticks_remaining", this.craftingTicksRemaining);
		if (!this.trySaveLootTable(compound))
			ContainerHelper.saveAllItems(compound, this.stacks);
		List<Integer> disabled = new ArrayList<>();
		for (int i = 0; i < SLOT_COUNT; i++)
			if (this.isSlotDisabled(i))
				disabled.add(i);
		compound.putIntArray("disabled_slots", disabled);
		compound.putBoolean("triggered", this.isTriggered());
	}

	@Override
	public int getContainerSize() {
		return SLOT_COUNT;
	}

	@Override
	public int getWidth() {
		return 3;
	}

	@Override
	public int getHeight() {
		return 3;
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack stack : this.stacks)
			if (!stack.isEmpty())
				return false;
		return true;
	}

	@Override
	public NonNullList<ItemStack> getItems() {
		return this.stacks;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> items) {
		this.stacks = items;
	}

	@Override
	public void setItem(int slot, ItemStack stack) {
		if (!stack.isEmpty() && this.isSlotDisabled(slot))
			this.setSlotDisabled(slot, false);
		super.setItem(slot, stack);
	}

	@Override
	public void fillStackedContents(StackedContents contents) {
		for (ItemStack stack : this.stacks)
			contents.accountSimpleStack(stack);
	}

	@Override
	public boolean canPlaceItem(int slot, ItemStack stack) {
		if (this.isSlotDisabled(slot))
			return false;
		ItemStack current = this.stacks.get(slot);
		int count = current.getCount();
		if (current.isEmpty())
			return true;
		if (count >= current.getMaxStackSize())
			return false;
		return !this.smallerStackExist(count, current, slot) && ItemStack.isSameItemSameTags(current, stack);
	}

	private boolean smallerStackExist(int count, ItemStack current, int from) {
		for (int i = from + 1; i < SLOT_COUNT; i++) {
			if (this.isSlotDisabled(i))
				continue;
			ItemStack other = this.getItem(i);
			if (other.isEmpty() || other.getCount() < count && ItemStack.isSameItemSameTags(other, current))
				return true;
		}
		return false;
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return SLOTS;
	}

	@Override
	public boolean canPlaceItemThroughFace(int slot, ItemStack stack, @Nullable Direction direction) {
		return !this.isSlotDisabled(slot) && this.canPlaceItem(slot, stack);
	}

	@Override
	public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction direction) {
		return false;
	}

	@Override
	protected Component getDefaultName() {
		return Component.translatable("block.sped.crafter");
	}

	@Override
	protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return new CrafterMenu(id, inventory, this, this.containerData);
	}

	@Override
	public <T> LazyOptional<T> getCapability(Capability<T> capability, @Nullable Direction facing) {
		if (!this.remove && facing != null && capability == ForgeCapabilities.ITEM_HANDLER)
			return handlers[facing.ordinal()].cast();
		return super.getCapability(capability, facing);
	}

	@Override
	public void setRemoved() {
		super.setRemoved();
		for (LazyOptional<? extends IItemHandler> handler : handlers)
			handler.invalidate();
	}
}
