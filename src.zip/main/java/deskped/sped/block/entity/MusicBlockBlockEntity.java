package deskped.sped.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import deskped.sped.init.SpedBlockEntities;

public class MusicBlockBlockEntity extends BlockEntity {

	private String trackHash = "";
	private String trackName = "";
	private boolean playing = false;

	public MusicBlockBlockEntity(BlockPos position, BlockState state) {
		super(SpedBlockEntities.MUSIC_BLOCK.get(), position, state);
	}

	@Override
	public void load(CompoundTag tag) {
		super.load(tag);
		trackHash = tag.getString("TrackHash");
		trackName = tag.getString("TrackName");
		playing = tag.getBoolean("Playing");
	}

	@Override
	protected void saveAdditional(CompoundTag tag) {
		super.saveAdditional(tag);
		tag.putString("TrackHash", trackHash);
		tag.putString("TrackName", trackName);
		tag.putBoolean("Playing", playing);
	}

	@Override
	public CompoundTag getUpdateTag() {
		return saveWithoutMetadata();
	}

	@Override
	public ClientboundBlockEntityDataPacket getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public void onLoad() {
		super.onLoad();
		if (level != null && !level.isClientSide())
			playing = false;
	}

	public String getTrackHash() {
		return trackHash;
	}

	public String getTrackName() {
		return trackName;
	}

	public boolean isPlaying() {
		return playing;
	}

	public void update(String hash, String name, boolean playing) {
		this.trackHash = hash == null ? "" : hash;
		this.trackName = name == null ? "" : name;
		this.playing = playing;
		setChanged();
		if (level != null && !level.isClientSide())
			level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
	}
}
