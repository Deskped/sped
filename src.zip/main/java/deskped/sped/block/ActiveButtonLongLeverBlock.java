package deskped.sped.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import deskped.sped.procedures.ButtonPKMProcedure;
import deskped.sped.init.SpedModBlocks;

public class ActiveButtonLongLeverBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;

	public ActiveButtonLongLeverBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(5.55f, 42.5f).noCollission().noOcclusion().isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.BASEDRUM));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 0, 3, 11, 3, 13), box(7, 2, 7, 9, 19, 9), box(9.3, 20, 6.7, 10.9, 22.6, 9.3), box(6.7, 19, 6.7, 9.3, 20.5, 9.3), box(6.9, 19.5, 6.9, 9.1, 20.8, 9.1));
				case WALL -> Shapes.or(box(5, 3, 0, 11, 13, 3), box(7, 7, 2, 9, 9, 19), box(9.3, 6.7, 20, 10.9, 9.3, 22.6), box(6.7, 6.7, 19, 9.3, 9.3, 20.5), box(6.9, 6.9, 19.5, 9.1, 9.1, 20.8));
				case CEILING -> Shapes.or(box(5, 13, 3, 11, 16, 13), box(7, -3, 7, 9, 14, 9), box(5.1, -6.6, 6.7, 6.7, -4, 9.3), box(6.7, -4.5, 6.7, 9.3, -3, 9.3), box(6.9, -4.8, 6.9, 9.1, -3.5, 9.1));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(5, 0, 3, 11, 3, 13), box(7, 2, 7, 9, 19, 9), box(5.1, 20, 6.7, 6.7, 22.6, 9.3), box(6.7, 19, 6.7, 9.3, 20.5, 9.3), box(6.9, 19.5, 6.9, 9.1, 20.8, 9.1));
				case WALL -> Shapes.or(box(5, 3, 13, 11, 13, 16), box(7, 7, -3, 9, 9, 14), box(5.1, 6.7, -6.6, 6.7, 9.3, -4), box(6.7, 6.7, -4.5, 9.3, 9.3, -3), box(6.9, 6.9, -4.8, 9.1, 9.1, -3.5));
				case CEILING -> Shapes.or(box(5, 13, 3, 11, 16, 13), box(7, -3, 7, 9, 14, 9), box(9.3, -6.6, 6.7, 10.9, -4, 9.3), box(6.7, -4.5, 6.7, 9.3, -3, 9.3), box(6.9, -4.8, 6.9, 9.1, -3.5, 9.1));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(3, 0, 5, 13, 3, 11), box(7, 2, 7, 9, 19, 9), box(6.7, 20, 5.1, 9.3, 22.6, 6.7), box(6.7, 19, 6.7, 9.3, 20.5, 9.3), box(6.9, 19.5, 6.9, 9.1, 20.8, 9.1));
				case WALL -> Shapes.or(box(0, 3, 5, 3, 13, 11), box(2, 7, 7, 19, 9, 9), box(20, 6.7, 5.1, 22.6, 9.3, 6.7), box(19, 6.7, 6.7, 20.5, 9.3, 9.3), box(19.5, 6.9, 6.9, 20.8, 9.1, 9.1));
				case CEILING -> Shapes.or(box(3, 13, 5, 13, 16, 11), box(7, -3, 7, 9, 14, 9), box(6.7, -6.6, 9.3, 9.3, -4, 10.9), box(6.7, -4.5, 6.7, 9.3, -3, 9.3), box(6.9, -4.8, 6.9, 9.1, -3.5, 9.1));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(3, 0, 5, 13, 3, 11), box(7, 2, 7, 9, 19, 9), box(6.7, 20, 9.3, 9.3, 22.6, 10.9), box(6.7, 19, 6.7, 9.3, 20.5, 9.3), box(6.9, 19.5, 6.9, 9.1, 20.8, 9.1));
				case WALL -> Shapes.or(box(13, 3, 5, 16, 13, 11), box(-3, 7, 7, 14, 9, 9), box(-6.6, 6.7, 9.3, -4, 9.3, 10.9), box(-4.5, 6.7, 6.7, -3, 9.3, 9.3), box(-4.8, 6.9, 6.9, -3.5, 9.1, 9.1));
				case CEILING -> Shapes.or(box(3, 13, 5, 13, 16, 11), box(7, -3, 7, 9, 14, 9), box(6.7, -6.6, 5.1, 9.3, -4, 6.7), box(6.7, -4.5, 6.7, 9.3, -3, 9.3), box(6.9, -4.8, 6.9, 9.1, -3.5, 9.1));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACE, faceForDirection(context.getNearestLookingDirection())).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}

	@Override
	public boolean isSignalSource(BlockState state) {
		return true;
	}

	@Override
	public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
		return 10;
	}

	@Override
	public ItemStack getCloneItemStack(BlockState state, HitResult target, BlockGetter world, BlockPos pos, Player player) {
		return new ItemStack(SpedModBlocks.LONG_LEVER.get());
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		ButtonPKMProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}