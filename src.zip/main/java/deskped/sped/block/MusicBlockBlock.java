package deskped.sped.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import java.util.List;

import deskped.sped.block.entity.MusicBlockBlockEntity;
import deskped.sped.music.MusicNet;

public class MusicBlockBlock extends Block implements EntityBlock {
	public MusicBlockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(0.7f, 5f));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.sped.music_block.description_0"));
		list.add(Component.translatable("block.sped.music_block.description_1"));
		list.add(Component.translatable("block.sped.music_block.description_2"));
		list.add(Component.translatable("block.sped.music_block.description_3"));
		list.add(Component.translatable("block.sped.music_block.description_4"));
		list.add(Component.translatable("block.sped.music_block.description_5"));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new MusicBlockBlockEntity(pos, state);
	}

	@Override
	public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		if (world.isClientSide())
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.openScreen(pos));
		return InteractionResult.sidedSuccess(world.isClientSide());
	}

	@Override
	public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
		super.triggerEvent(state, world, pos, eventID, eventParam);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity != null && blockEntity.triggerEvent(eventID, eventParam);
	}

	@Override
	public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean isMoving) {
		if (!world.isClientSide() && world instanceof ServerLevel serverLevel && !state.is(newState.getBlock()))
			MusicNet.broadcastStopBlock(serverLevel, pos);
		super.onRemove(state, world, pos, newState, isMoving);
	}
}
