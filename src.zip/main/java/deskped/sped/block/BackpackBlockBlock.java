package deskped.sped.block;

import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import io.netty.buffer.Unpooled;

import deskped.sped.world.inventory.BackackMenu;
import deskped.sped.procedures.BackpackBlockPKMbreakProcedure;
import deskped.sped.block.entity.BackpackBlockBlockEntity;

public class BackpackBlockBlock extends Block implements EntityBlock {
	public static final DirectionProperty FACING = DirectionalBlock.FACING;

	public BackpackBlockBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOL).strength(0.5f, 2.5f).noCollission().noOcclusion().isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.CUSTOM_HEAD));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(3, 0, 8, 13, 6, 16), box(3, 6, 8, 13, 11, 16), box(5, 0, 6, 11, 3, 8), box(13, 0, 10, 15, 5, 14), box(1, 0, 10, 3, 5, 14), box(7, 1.9, 5.6, 9, 2.9, 6.6), box(14.3, 3.8, 11, 15.3, 4.8, 13),
					box(0.7, 3.8, 11, 1.7, 4.8, 13));
			case NORTH ->
				Shapes.or(box(3, 0, 0, 13, 6, 8), box(3, 6, 0, 13, 11, 8), box(5, 0, 8, 11, 3, 10), box(1, 0, 2, 3, 5, 6), box(13, 0, 2, 15, 5, 6), box(7, 1.9, 9.4, 9, 2.9, 10.4), box(0.7, 3.8, 3, 1.7, 4.8, 5), box(14.3, 3.8, 3, 15.3, 4.8, 5));
			case EAST -> Shapes.or(box(8, 0, 3, 16, 6, 13), box(8, 6, 3, 16, 11, 13), box(6, 0, 5, 8, 3, 11), box(10, 0, 1, 14, 5, 3), box(10, 0, 13, 14, 5, 15), box(5.6, 1.9, 7, 6.6, 2.9, 9), box(11, 3.8, 0.7, 13, 4.8, 1.7),
					box(11, 3.8, 14.3, 13, 4.8, 15.3));
			case WEST ->
				Shapes.or(box(0, 0, 3, 8, 6, 13), box(0, 6, 3, 8, 11, 13), box(8, 0, 5, 10, 3, 11), box(2, 0, 13, 6, 5, 15), box(2, 0, 1, 6, 5, 3), box(9.4, 1.9, 7, 10.4, 2.9, 9), box(3, 3.8, 14.3, 5, 4.8, 15.3), box(3, 3.8, 0.7, 5, 4.8, 1.7));
			case UP -> Shapes.or(box(3, 8, 0, 13, 16, 6), box(3, 8, 6, 13, 16, 11), box(5, 6, 0, 11, 8, 3), box(1, 10, 0, 3, 14, 5), box(13, 10, 0, 15, 14, 5), box(7, 5.6, 1.9, 9, 6.6, 2.9), box(0.7, 11, 3.8, 1.7, 13, 4.8),
					box(14.3, 11, 3.8, 15.3, 13, 4.8));
			case DOWN -> Shapes.or(box(3, 0, 10, 13, 8, 16), box(3, 0, 5, 13, 8, 10), box(5, 8, 13, 11, 10, 16), box(1, 2, 11, 3, 6, 16), box(13, 2, 11, 15, 6, 16), box(7, 9.4, 13.1, 9, 10.4, 14.1), box(0.7, 3, 11.2, 1.7, 5, 12.2),
					box(14.3, 3, 11.2, 15.3, 5, 12.2));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getClickedFace());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public ItemStack getCloneItemStack(BlockState state, HitResult target, BlockGetter world, BlockPos pos, Player player) {
		return ItemStack.EMPTY;
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		if (entity instanceof ServerPlayer player) {
			NetworkHooks.openScreen(player, new MenuProvider() {
				@Override
				public Component getDisplayName() {
					return Component.literal("Backpack");
				}

				@Override
				public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
					return new BackackMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(pos));
				}
			}, pos);
		}
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		BackpackBlockPKMbreakProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}

	@Override
	public MenuProvider getMenuProvider(BlockState state, Level worldIn, BlockPos pos) {
		BlockEntity tileEntity = worldIn.getBlockEntity(pos);
		return tileEntity instanceof MenuProvider menuProvider ? menuProvider : null;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new BackpackBlockBlockEntity(pos, state);
	}

	@Override
	public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
		super.triggerEvent(state, world, pos, eventID, eventParam);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity != null && blockEntity.triggerEvent(eventID, eventParam);
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState blockState, Level world, BlockPos pos) {
		BlockEntity tileentity = world.getBlockEntity(pos);
		if (tileentity instanceof BackpackBlockBlockEntity be)
			return AbstractContainerMenu.getRedstoneSignalFromContainer(be);
		else
			return 0;
	}
}