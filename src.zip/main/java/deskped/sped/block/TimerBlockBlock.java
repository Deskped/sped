package deskped.sped.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import java.util.List;

import deskped.sped.procedures.TimerBlockTikProcedure;

public class TimerBlockBlock extends Block {
	public TimerBlockBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(6.1f, 10f).instrument(NoteBlockInstrument.BASEDRUM));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("block.sped.timer_block.description_0"));
		list.add(Component.translatable("block.sped.timer_block.description_1"));
		list.add(Component.translatable("block.sped.timer_block.description_2"));
		list.add(Component.translatable("block.sped.timer_block.description_3"));
		list.add(Component.translatable("block.sped.timer_block.description_4"));
		list.add(Component.translatable("block.sped.timer_block.description_5"));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		world.scheduleTick(pos, this, 15);
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		TimerBlockTikProcedure.execute(world, x, y, z);
		world.scheduleTick(pos, this, 15);
	}
}