package deskped.sped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT)
class BlockNbtHudHandler {

    private static final int SHOW_TICKS  = 60;
    private static final int FADE_TICKS  = 20;
    private static final int TOTAL_TICKS = SHOW_TICKS + FADE_TICKS;

    private static String cachedName   = null;
    private static String shownBlockId = null;
    private static int    ticksVisible = 0;
    private static boolean done        = false;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!SpedClientConfig.BLOCK_HUD) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        HitResult hitResult = mc.hitResult;
        String blockId   = null;
        String blockName = null;

        if (hitResult != null && hitResult.getType() == HitResult.Type.BLOCK) {
            BlockPos pos     = ((BlockHitResult) hitResult).getBlockPos();
            Level level      = mc.level;
            BlockState state = level.getBlockState(pos);

            if (state.hasBlockEntity()) {
                BlockEntity be = level.getBlockEntity(pos);
                if (be != null) {
                    ResourceLocation rl = ForgeRegistries.BLOCKS.getKey(state.getBlock());
                    blockId   = rl != null ? rl.toString() : state.getBlock().getDescriptionId();
                    blockName = state.getBlock().getName().getString().toLowerCase();
                }
            }
        }

        if (blockId != null && !blockId.equals(shownBlockId)) {
            shownBlockId = blockId;
            cachedName   = blockName;
            ticksVisible = 0;
            done         = false;
        }

        if (!done && cachedName != null) {
            ticksVisible++;
            if (ticksVisible >= TOTAL_TICKS) {
                done = true;
            }
        }
    }

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;
        if (!SpedClientConfig.BLOCK_HUD) return;
        if (cachedName == null || done) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        float alpha = 1.0f;
        if (ticksVisible > SHOW_TICKS) {
            float progress = ticksVisible - SHOW_TICKS;
            alpha = 1.0f - (progress / FADE_TICKS);
            alpha = Math.max(0f, Math.min(1f, alpha));
        }

        int a = (int)(alpha * 255);
        if (a <= 0) return;

        GuiGraphics graphics = event.getGuiGraphics();
        int screenWidth      = mc.getWindow().getGuiScaledWidth();
        int screenHeight     = mc.getWindow().getGuiScaledHeight();

        String text    = cachedName;
        int textWidth  = mc.font.width(text);
        int textHeight = mc.font.lineHeight;
        int x          = (screenWidth - textWidth) / 2;
        int y          = screenHeight / 2 + 14;
        int pad        = 3;

        int bgAlpha = (int)(a * 0.45f);
        graphics.fill(x - pad, y - pad, x + textWidth + pad, y + textHeight + pad, bgAlpha << 24);
        graphics.drawString(mc.font, text, x, y, (a << 24) | 0xFFFFFF, false);
    }
}
