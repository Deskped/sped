package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ShipsClockItem extends Item {
	public ShipsClockItem() {
		super(new Item.Properties());
	}
}