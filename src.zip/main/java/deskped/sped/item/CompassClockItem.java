package deskped.sped.item;

import net.minecraft.world.item.Item;

public class CompassClockItem extends Item {
	public CompassClockItem() {
		super(new Item.Properties());
	}
}