package deskped.sped.item;

import net.minecraft.world.item.Item;

public class DigitalClockItem extends Item {
	public DigitalClockItem() {
		super(new Item.Properties());
	}
}