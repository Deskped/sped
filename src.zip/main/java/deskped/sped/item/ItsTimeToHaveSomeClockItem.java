package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ItsTimeToHaveSomeClockItem extends Item {
	public ItsTimeToHaveSomeClockItem() {
		super(new Item.Properties());
	}
}