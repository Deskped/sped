package deskped.sped.item;

import net.minecraft.world.item.Item;

public class HolographicClockItem extends Item {
	public HolographicClockItem() {
		super(new Item.Properties());
	}
}