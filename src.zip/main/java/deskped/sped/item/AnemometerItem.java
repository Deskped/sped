package deskped.sped.item;

import net.minecraft.world.item.Item;

public class AnemometerItem extends Item {
	public AnemometerItem() {
		super(new Item.Properties());
	}
}