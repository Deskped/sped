package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ResidenceClockItem extends Item {
	public ResidenceClockItem() {
		super(new Item.Properties());
	}
}