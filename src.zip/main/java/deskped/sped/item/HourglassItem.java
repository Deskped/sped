package deskped.sped.item;

import net.minecraft.world.item.Item;

public class HourglassItem extends Item {
	public HourglassItem() {
		super(new Item.Properties());
	}
}