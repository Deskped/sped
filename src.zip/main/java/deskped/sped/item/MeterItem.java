package deskped.sped.item;

import net.minecraft.world.item.Item;

public class MeterItem extends Item {
	public MeterItem() {
		super(new Item.Properties());
	}
}