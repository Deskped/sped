package deskped.sped.item;

import net.minecraft.world.item.Item;

public class SensorItem extends Item {
	public SensorItem() {
		super(new Item.Properties());
	}
}