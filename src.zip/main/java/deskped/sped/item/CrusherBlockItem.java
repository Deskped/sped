package deskped.sped.item;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import deskped.sped.block.CrusherBlock;

import java.util.function.Consumer;

public class CrusherBlockItem extends BlockItem {

    public CrusherBlockItem(CrusherBlock block, Properties properties) {
        super(block, properties);
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return deskped.sped.client.renderer.CrusherBEWLR.getInstance();
            }
        });
    }
}
