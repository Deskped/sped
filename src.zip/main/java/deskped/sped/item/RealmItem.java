package deskped.sped.item;

import deskped.sped.race.RaceMenuOpener;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class RealmItem extends Item {
	public RealmItem() {
		super(new Item.Properties().stacksTo(3).fireResistant());
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		if (!level.isClientSide() && player instanceof ServerPlayer sp) {
			RaceMenuOpener.open(sp, 2);
			level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 0.8f);
		}
		return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide());
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.sped.realm.description_0"));
		list.add(Component.translatable("item.sped.realm.description_1"));
		list.add(Component.translatable("item.sped.realm.description_2"));
		list.add(Component.translatable("item.sped.realm.description_3"));
		list.add(Component.translatable("item.sped.realm.description_4"));
		list.add(Component.translatable("item.sped.realm.description_5"));
	}
}
