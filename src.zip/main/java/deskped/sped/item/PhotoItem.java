package deskped.sped.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

public class PhotoItem extends Item {
	public PhotoItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.sped.photo.description_0"));
		list.add(Component.translatable("item.sped.photo.description_1"));
		list.add(Component.translatable("item.sped.photo.description_2"));
		list.add(Component.translatable("item.sped.photo.description_3"));
		list.add(Component.translatable("item.sped.photo.description_4"));
		list.add(Component.translatable("item.sped.photo.description_5"));
	}
}