package deskped.sped.item;

import net.minecraft.world.item.Item;

public class AquaClockItem extends Item {
	public AquaClockItem() {
		super(new Item.Properties());
	}
}