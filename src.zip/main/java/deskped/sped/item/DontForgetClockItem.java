package deskped.sped.item;

import net.minecraft.world.item.Item;

public class DontForgetClockItem extends Item {
	public DontForgetClockItem() {
		super(new Item.Properties());
	}
}