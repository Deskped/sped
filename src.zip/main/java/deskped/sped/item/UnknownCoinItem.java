package deskped.sped.item;

import net.minecraft.world.item.Item;

public class UnknownCoinItem extends Item {
	public UnknownCoinItem() {
		super(new Item.Properties());
	}
}