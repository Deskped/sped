package deskped.sped.item;

import net.minecraft.world.item.Item;

public class DemonClockItem extends Item {
	public DemonClockItem() {
		super(new Item.Properties());
	}
}