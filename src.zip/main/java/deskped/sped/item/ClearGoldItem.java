package deskped.sped.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ClearGoldItem extends Item {
	public ClearGoldItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}