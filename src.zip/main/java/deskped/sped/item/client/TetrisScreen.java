package deskped.sped.item.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import deskped.sped.SpedMod;
import deskped.sped.item.AdvancedClockCircuitItem;
import deskped.sped.network.TetrisScorePacket;

@OnlyIn(Dist.CLIENT)
public class TetrisScreen extends Screen {

	private static final int COLS = 10;
	private static final int ROWS = 20;
	private static final int CELL = 9;
	private static final int SCREEN_W = 240;
	private static final int SCREEN_H = 258;
	private static final long DAS = 150L;
	private static final long ARR = 40L;
	private static final long SOFT = 45L;
	private static final long LOCK_DELAY = 500L;

	private static final int[][][] SHAPES = {
			{{0, 1, 1, 1, 2, 1, 3, 1}, {2, 0, 2, 1, 2, 2, 2, 3}, {0, 2, 1, 2, 2, 2, 3, 2}, {1, 0, 1, 1, 1, 2, 1, 3}},
			{{0, 0, 0, 1, 1, 1, 2, 1}, {1, 0, 2, 0, 1, 1, 1, 2}, {0, 1, 1, 1, 2, 1, 2, 2}, {1, 0, 1, 1, 0, 2, 1, 2}},
			{{2, 0, 0, 1, 1, 1, 2, 1}, {1, 0, 1, 1, 1, 2, 2, 2}, {0, 1, 1, 1, 2, 1, 0, 2}, {0, 0, 1, 0, 1, 1, 1, 2}},
			{{1, 0, 2, 0, 1, 1, 2, 1}, {1, 0, 2, 0, 1, 1, 2, 1}, {1, 0, 2, 0, 1, 1, 2, 1}, {1, 0, 2, 0, 1, 1, 2, 1}},
			{{1, 0, 2, 0, 0, 1, 1, 1}, {1, 0, 1, 1, 2, 1, 2, 2}, {1, 1, 2, 1, 0, 2, 1, 2}, {0, 0, 0, 1, 1, 1, 1, 2}},
			{{1, 0, 0, 1, 1, 1, 2, 1}, {1, 0, 1, 1, 2, 1, 1, 2}, {0, 1, 1, 1, 2, 1, 1, 2}, {1, 0, 0, 1, 1, 1, 1, 2}},
			{{0, 0, 1, 0, 1, 1, 2, 1}, {2, 0, 1, 1, 2, 1, 1, 2}, {0, 1, 1, 1, 1, 2, 2, 2}, {1, 0, 0, 1, 1, 1, 0, 2}}
	};

	private static final int[][][] KICKS = {
			{{0, 0}, {-1, 0}, {-1, -1}, {0, 2}, {-1, 2}},
			{{0, 0}, {1, 0}, {1, 1}, {0, -2}, {1, -2}},
			{{0, 0}, {1, 0}, {1, -1}, {0, 2}, {1, 2}},
			{{0, 0}, {-1, 0}, {-1, 1}, {0, -2}, {-1, -2}}
	};

	private static final int[][][] KICKS_I = {
			{{0, 0}, {-2, 0}, {1, 0}, {-2, 1}, {1, -2}},
			{{0, 0}, {-1, 0}, {2, 0}, {-1, -2}, {2, 1}},
			{{0, 0}, {2, 0}, {-1, 0}, {2, -1}, {-1, 2}},
			{{0, 0}, {1, 0}, {-2, 0}, {1, 2}, {-2, -1}}
	};

	private static final int[] TONES = {0xFFEFEFEF, 0xFFB4B4B4, 0xFFD6D6D6, 0xFF9A9A9A, 0xFFC6C6C6, 0xFF868686, 0xFF747474};

	private final int[][] board = new int[ROWS][COLS];
	private final List<Integer> bag = new ArrayList<>();
	private final List<Integer> queue = new ArrayList<>();
	private final Random rng = new Random();
	private final boolean mainHand;

	private int guiLeft;
	private int guiTop;
	private int scanlineOffset;
	private final long openTime = System.currentTimeMillis();

	private int cur = -1;
	private int rot;
	private int px;
	private int py;
	private int hold = -1;
	private boolean holdUsed;
	private int score;
	private int lines;
	private int level = 1;
	private int best;
	private int combo = -1;
	private int state;
	private int moveDir;
	private int lockResets;
	private long dasTime;
	private long softTime;
	private long lastFall;
	private long lockStart;
	private long glowUntil;
	private long lastTime;
	private boolean helpShown;
	private boolean sent;

	private TetrisScreen(boolean mainHand, int best) {
		super(Component.literal("\u0422\u0435\u0442\u0440\u0438\u0441"));
		this.mainHand = mainHand;
		this.best = best;
		reset();
	}

	public static void open(boolean mainHand) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null)
			return;
		ItemStack stack = mc.player.getItemInHand(mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND);
		int best = 0;
		if (stack.getItem() instanceof AdvancedClockCircuitItem && stack.getTag() != null)
			best = stack.getTag().getCompound(AdvancedClockCircuitItem.TAG).getInt("Best");
		mc.setScreen(new TetrisScreen(mainHand, best));
	}

	@Override
	protected void init() {
		guiLeft = (this.width - SCREEN_W) / 2;
		guiTop = (this.height - SCREEN_H) / 2;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private void reset() {
		for (int y = 0; y < ROWS; y++)
			for (int x = 0; x < COLS; x++)
				board[y][x] = 0;
		bag.clear();
		queue.clear();
		hold = -1;
		holdUsed = false;
		score = 0;
		lines = 0;
		level = 1;
		combo = -1;
		state = 0;
		moveDir = 0;
		lockResets = 0;
		lockStart = 0L;
		sent = false;
		lastTime = System.currentTimeMillis();
		lastFall = lastTime;
		for (int i = 0; i < 5; i++)
			queue.add(next());
		spawn();
	}

	private int next() {
		if (bag.isEmpty()) {
			for (int i = 0; i < 7; i++)
				bag.add(i);
			Collections.shuffle(bag, rng);
		}
		return bag.remove(bag.size() - 1);
	}

	private void spawn() {
		cur = queue.remove(0);
		queue.add(next());
		rot = 0;
		px = 3;
		py = 0;
		holdUsed = false;
		lockStart = 0L;
		lockResets = 0;
		lastFall = System.currentTimeMillis();
		if (collides(cur, rot, px, py)) {
			state = 2;
			sound(SoundEvents.ANVIL_LAND, 0.5F);
			finish();
		}
	}

	private boolean collides(int type, int r, int ox, int oy) {
		int[] s = SHAPES[type][r & 3];
		for (int i = 0; i < 8; i += 2) {
			int x = ox + s[i];
			int y = oy + s[i + 1];
			if (x < 0 || x >= COLS || y >= ROWS)
				return true;
			if (y >= 0 && board[y][x] != 0)
				return true;
		}
		return false;
	}

	private boolean move(int dx) {
		if (collides(cur, rot, px + dx, py))
			return false;
		px += dx;
		touch();
		return true;
	}

	private void touch() {
		if (lockStart != 0L && lockResets < 15) {
			lockStart = System.currentTimeMillis();
			lockResets++;
		}
	}

	private boolean step() {
		if (collides(cur, rot, px, py + 1))
			return false;
		py++;
		return true;
	}

	private void rotate() {
		int nr = (rot + 1) & 3;
		int[][] table = cur == 0 ? KICKS_I[rot] : KICKS[rot];
		for (int[] k : table) {
			int nx = px + k[0];
			int ny = py + k[1];
			if (!collides(cur, nr, nx, ny)) {
				rot = nr;
				px = nx;
				py = ny;
				touch();
				sound(SoundEvents.UI_BUTTON_CLICK.value(), 0.35F);
				return;
			}
		}
	}

	private void hardDrop() {
		int d = 0;
		while (step())
			d++;
		score += d * 2;
		lock();
	}

	private void swapHold() {
		if (holdUsed)
			return;
		int h = hold;
		hold = cur;
		if (h == -1) {
			cur = queue.remove(0);
			queue.add(next());
		} else {
			cur = h;
		}
		rot = 0;
		px = 3;
		py = 0;
		holdUsed = true;
		lockStart = 0L;
		lockResets = 0;
		if (collides(cur, rot, px, py)) {
			state = 2;
			finish();
		}
	}

	private void lock() {
		int[] s = SHAPES[cur][rot];
		for (int i = 0; i < 8; i += 2) {
			int x = px + s[i];
			int y = py + s[i + 1];
			if (y >= 0 && y < ROWS && x >= 0 && x < COLS)
				board[y][x] = cur + 1;
		}
		clearLines();
		if (state == 0)
			spawn();
	}

	private void clearLines() {
		int cleared = 0;
		for (int y = ROWS - 1; y >= 0; y--) {
			boolean full = true;
			for (int x = 0; x < COLS; x++) {
				if (board[y][x] == 0) {
					full = false;
					break;
				}
			}
			if (!full)
				continue;
			cleared++;
			for (int yy = y; yy > 0; yy--)
				System.arraycopy(board[yy - 1], 0, board[yy], 0, COLS);
			for (int x = 0; x < COLS; x++)
				board[0][x] = 0;
			y++;
		}
		if (cleared == 0) {
			combo = -1;
			sound(SoundEvents.STONE_PLACE, 0.4F);
			return;
		}
		combo++;
		int base = cleared == 1 ? 100 : cleared == 2 ? 300 : cleared == 3 ? 500 : 800;
		score += base * level;
		if (combo > 0)
			score += 50 * combo * level;
		lines += cleared;
		int nl = 1 + lines / 10;
		if (nl > level) {
			level = nl;
			sound(SoundEvents.PLAYER_LEVELUP, 0.4F);
		}
		glowUntil = System.currentTimeMillis() + 180L;
		sound(cleared == 4 ? SoundEvents.EXPERIENCE_ORB_PICKUP : SoundEvents.LEVER_CLICK, cleared == 4 ? 0.7F : 0.5F);
	}

	private long interval() {
		double s = Math.pow(0.8D - (level - 1) * 0.007D, level - 1);
		return Math.max(30L, (long) (s * 1000.0D));
	}

	private void finish() {
		if (sent)
			return;
		sent = true;
		if (score > best) {
			best = score;
			SpedMod.PACKET_HANDLER.sendToServer(new TetrisScorePacket(score, mainHand));
		}
	}

	private void sound(SoundEvent e, float vol) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.getSoundManager() != null)
			mc.getSoundManager().play(SimpleSoundInstance.forUI(e, 1.0F, vol));
	}

	private boolean down(int key) {
		return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key);
	}

	private void update() {
		long now = System.currentTimeMillis();
		if (now - lastTime > 2000L)
			lastFall = now;
		lastTime = now;
		if (state != 0)
			return;
		int dir = 0;
		if (down(GLFW.GLFW_KEY_LEFT) || down(GLFW.GLFW_KEY_A))
			dir -= 1;
		if (down(GLFW.GLFW_KEY_RIGHT) || down(GLFW.GLFW_KEY_D))
			dir += 1;
		if (dir == 0) {
			moveDir = 0;
		} else if (dir != moveDir) {
			moveDir = dir;
			move(dir);
			dasTime = now + DAS;
		} else if (now >= dasTime) {
			move(dir);
			dasTime = now + ARR;
		}
		if (down(GLFW.GLFW_KEY_DOWN) || down(GLFW.GLFW_KEY_S)) {
			if (now >= softTime) {
				if (step())
					score += 1;
				softTime = now + SOFT;
			}
		} else {
			softTime = 0L;
		}
		if (collides(cur, rot, px, py + 1)) {
			if (lockStart == 0L)
				lockStart = now;
			if (now - lockStart >= LOCK_DELAY)
				lock();
		} else {
			lockStart = 0L;
			if (now - lastFall >= interval()) {
				lastFall = now;
				step();
			}
		}
	}

	@Override
	public boolean keyPressed(int key, int scan, int mods) {
		if (key == GLFW.GLFW_KEY_ESCAPE) {
			finish();
			onClose();
			return true;
		}
		if (key == GLFW.GLFW_KEY_H) {
			helpShown = !helpShown;
			return true;
		}
		if (key == GLFW.GLFW_KEY_R) {
			finish();
			reset();
			return true;
		}
		if (state == 2)
			return true;
		if (key == GLFW.GLFW_KEY_P) {
			state = state == 1 ? 0 : 1;
			if (state == 0) {
				lastFall = System.currentTimeMillis();
				lockStart = 0L;
			}
			return true;
		}
		if (state != 0)
			return true;
		if (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W || key == GLFW.GLFW_KEY_X) {
			rotate();
			return true;
		}
		if (key == GLFW.GLFW_KEY_SPACE) {
			hardDrop();
			sound(SoundEvents.STONE_PLACE, 0.6F);
			return true;
		}
		if (key == GLFW.GLFW_KEY_C || key == GLFW.GLFW_KEY_LEFT_SHIFT) {
			swapHold();
			return true;
		}
		return true;
	}

	@Override
	public void onClose() {
		finish();
		super.onClose();
	}

	@Override
	public void renderBackground(GuiGraphics g) {
		g.fill(0, 0, this.width, this.height, 0xE8080808);
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		long now = System.currentTimeMillis();
		scanlineOffset = (int) ((now / 40) % 4);
		update();
		renderBackground(g);
		drawPanel(g);
		drawTopBar(g, now);
		drawField(g, now);
		drawSide(g);
		drawBottomBar(g);
		if (helpShown)
			drawHelp(g);
		drawScanlines(g);
		drawGlitch(g, now);
		super.render(g, mouseX, mouseY, partialTick);
	}

	private void drawPanel(GuiGraphics g) {
		int x = guiLeft;
		int y = guiTop;
		int w = SCREEN_W;
		int h = SCREEN_H;
		g.fill(x, y, x + w, y + h, 0xFF111111);
		g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF161616);
		for (int i = 0; i < w; i += 3)
			g.fill(x + i, y, x + i + 1, y + h, 0x04FFFFFF);
		g.fill(x, y, x + w, y + 2, 0xFFE0E0E0);
		g.fill(x, y + h - 2, x + w, y + h, 0xFFE0E0E0);
		g.fill(x, y, x + 2, y + h, 0xFFE0E0E0);
		g.fill(x + w - 2, y, x + w, y + h, 0xFFE0E0E0);
		g.fill(x + 2, y + 2, x + w - 2, y + 4, 0x80888888);
		g.fill(x + 2, y + h - 4, x + w - 2, y + h - 2, 0x80888888);
		g.fill(x + 2, y + 2, x + 4, y + h - 2, 0x40888888);
		g.fill(x + w - 4, y + 2, x + w - 2, y + h - 2, 0x40888888);
	}

	private void drawTopBar(GuiGraphics g, long now) {
		int x = guiLeft;
		int y = guiTop;
		g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 28, 0xFF0D0D0D);
		g.fill(x + 4, y + 6, x + SCREEN_W - 4, y + 8, 0xFFCCCCCC);
		g.fill(x + 4, y + 26, x + SCREEN_W - 4, y + 28, 0xFFCCCCCC);
		g.fill(x + 4, y + 8, x + 6, y + 26, 0xFF888888);
		g.fill(x + SCREEN_W - 6, y + 8, x + SCREEN_W - 4, y + 26, 0xFF888888);
		g.drawString(font, Component.literal("\u0422\u0415\u0422\u0420\u0418\u0421"), x + 12, y + 12, 0xFFFFFFFF, false);
		long elapsed = (now - openTime) / 600;
		String rec = elapsed % 2 == 0 ? "\u25cf REC" : "  REC";
		g.drawString(font, Component.literal(rec), x + SCREEN_W - 56, y + 12, 0xFFDDDDDD, false);
		g.fill(x + 4, y + 30, x + SCREEN_W - 4, y + 31, 0xFF555555);
		String left = "\u041e\u0427\u041a\u0418: " + score + (combo > 0 ? "   x" + (combo + 1) : "");
		g.drawString(font, Component.literal(left), x + 8, y + 34, 0xFFCCCCCC, false);
		String right = "\u0420\u0415\u041a\u041e\u0420\u0414: " + best;
		int rw = font.width(right);
		g.drawString(font, Component.literal(right), x + SCREEN_W - rw - 8, y + 34, 0xFFAAAAAA, false);
		g.fill(x + 4, y + 44, x + SCREEN_W - 4, y + 45, 0xFF444444);
	}

	private void drawField(GuiGraphics g, long now) {
		int bx = guiLeft + 8;
		int by = guiTop + 50;
		int bw = COLS * CELL;
		int bh = ROWS * CELL;
		g.fill(bx - 2, by - 2, bx + bw + 2, by + bh + 2, 0xFF0D0D0D);
		int frame = now < glowUntil ? 0xFFFFFFFF : 0xFF555555;
		g.fill(bx - 2, by - 2, bx + bw + 2, by - 1, frame);
		g.fill(bx - 2, by + bh + 1, bx + bw + 2, by + bh + 2, frame);
		g.fill(bx - 2, by - 2, bx - 1, by + bh + 2, frame);
		g.fill(bx + bw + 1, by - 2, bx + bw + 2, by + bh + 2, frame);
		for (int x = 1; x < COLS; x++)
			g.fill(bx + x * CELL, by, bx + x * CELL + 1, by + bh, 0x10FFFFFF);
		for (int y = 1; y < ROWS; y++)
			g.fill(bx, by + y * CELL, bx + bw, by + y * CELL + 1, 0x10FFFFFF);
		for (int y = 0; y < ROWS; y++)
			for (int x = 0; x < COLS; x++)
				if (board[y][x] != 0)
					cell(g, bx + x * CELL, by + y * CELL, CELL, TONES[board[y][x] - 1]);
		if (cur >= 0 && state != 2) {
			int gy = py;
			while (!collides(cur, rot, px, gy + 1))
				gy++;
			int[] s = SHAPES[cur][rot];
			for (int i = 0; i < 8; i += 2) {
				int cx = px + s[i];
				int cy = gy + s[i + 1];
				if (cy >= 0)
					ghost(g, bx + cx * CELL, by + cy * CELL, CELL);
			}
			for (int i = 0; i < 8; i += 2) {
				int cx = px + s[i];
				int cy = py + s[i + 1];
				if (cy >= 0)
					cell(g, bx + cx * CELL, by + cy * CELL, CELL, TONES[cur]);
			}
		}
		if (state == 1)
			overlay(g, bx, by, bw, bh, "\u041f\u0410\u0423\u0417\u0410", "P \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c");
		if (state == 2)
			overlay(g, bx, by, bw, bh, "\u041a\u041e\u041d\u0415\u0426", "R \u0437\u0430\u043d\u043e\u0432\u043e");
	}

	private void drawSide(GuiGraphics g) {
		int x = guiLeft + 8 + COLS * CELL + 10;
		int w = SCREEN_W - (x - guiLeft) - 8;
		int y = guiTop + 50;
		label(g, "\u041e\u0427\u0415\u0420\u0415\u0414\u042c", x, y, w);
		y += 12;
		for (int i = 0; i < 3; i++) {
			slot(g, x, y, w, 26, false);
			preview(g, queue.get(i), x, y, w, 26);
			y += 28;
		}
		y += 6;
		label(g, "\u0421\u041b\u0415\u0414.", x, y, w);
		y += 12;
		slot(g, x, y, w, 26, holdUsed);
		if (hold >= 0)
			preview(g, hold, x, y, w, 26);
		y += 34;
		g.drawString(font, Component.literal("\u041b\u0418\u041d\u0418\u0418"), x, y, 0xFF888888, false);
		String lv = String.valueOf(lines);
		g.drawString(font, Component.literal(lv), x + w - font.width(lv), y, 0xFFFFFFFF, false);
		y += 12;
		g.drawString(font, Component.literal("\u0423\u0420\u041e\u0412\u0415\u041d\u042c"), x, y, 0xFF888888, false);
		String lvl = String.valueOf(level);
		g.drawString(font, Component.literal(lvl), x + w - font.width(lvl), y, 0xFFFFFFFF, false);
		y += 14;
		int barW = w;
		int barH = 3;
		float pct = (lines % 10) / 10.0F;
		g.fill(x, y, x + barW, y + barH, 0xFF222222);
		g.fill(x, y, x + 1, y + barH, 0xFF666666);
		g.fill(x + barW - 1, y, x + barW, y + barH, 0xFF666666);
		int filled = (int) ((barW - 2) * pct);
		if (filled > 0) {
			g.fill(x + 1, y, x + 1 + filled, y + barH, 0xFF888888);
			g.fill(x + 1, y, x + 1 + filled, y + 1, 0x40FFFFFF);
		}
	}

	private void label(GuiGraphics g, String text, int x, int y, int w) {
		g.drawString(font, Component.literal(text), x, y, 0xFF999999, false);
		int tw = font.width(text);
		if (tw + 4 < w)
			g.fill(x + tw + 4, y + 3, x + w, y + 4, 0xFF333333);
	}

	private void slot(GuiGraphics g, int x, int y, int w, int h, boolean dim) {
		g.fill(x, y, x + w, y + h, dim ? 0xFF101010 : 0xFF131313);
		g.fill(x, y, x + w, y + 1, dim ? 0xFF333333 : 0xFF555555);
		g.fill(x, y + h - 1, x + w, y + h, 0xFF2A2A2A);
		g.fill(x, y, x + 1, y + h, 0xFF2A2A2A);
		g.fill(x + w - 1, y, x + w, y + h, 0xFF2A2A2A);
	}

	private void preview(GuiGraphics g, int type, int x, int y, int w, int h) {
		int[] s = SHAPES[type][0];
		int minX = 9;
		int maxX = -9;
		int minY = 9;
		int maxY = -9;
		for (int i = 0; i < 8; i += 2) {
			minX = Math.min(minX, s[i]);
			maxX = Math.max(maxX, s[i]);
			minY = Math.min(minY, s[i + 1]);
			maxY = Math.max(maxY, s[i + 1]);
		}
		int c = 6;
		int pw = (maxX - minX + 1) * c;
		int ph = (maxY - minY + 1) * c;
		int ox = x + (w - pw) / 2;
		int oy = y + (h - ph) / 2;
		for (int i = 0; i < 8; i += 2)
			cell(g, ox + (s[i] - minX) * c, oy + (s[i + 1] - minY) * c, c, TONES[type]);
	}

	private void cell(GuiGraphics g, int x, int y, int size, int tone) {
		g.fill(x, y, x + size, y + size, tone);
		g.fill(x + 1, y + 1, x + size - 1, y + size - 1, dim(tone, 0.72F));
		g.fill(x, y, x + size, y + 1, 0x60FFFFFF);
		g.fill(x, y, x + 1, y + size, 0x40FFFFFF);
		g.fill(x, y + size - 1, x + size, y + size, 0x50000000);
		g.fill(x + size - 1, y, x + size, y + size, 0x50000000);
	}

	private void ghost(GuiGraphics g, int x, int y, int size) {
		g.fill(x, y, x + size, y + size, 0x14FFFFFF);
		g.fill(x, y, x + size, y + 1, 0x50FFFFFF);
		g.fill(x, y + size - 1, x + size, y + size, 0x50FFFFFF);
		g.fill(x, y, x + 1, y + size, 0x50FFFFFF);
		g.fill(x + size - 1, y, x + size, y + size, 0x50FFFFFF);
	}

	private int dim(int color, float k) {
		int a = color >>> 24;
		int r = (int) (((color >> 16) & 0xFF) * k);
		int gg = (int) (((color >> 8) & 0xFF) * k);
		int b = (int) ((color & 0xFF) * k);
		return (a << 24) | (r << 16) | (gg << 8) | b;
	}

	private void overlay(GuiGraphics g, int bx, int by, int bw, int bh, String a, String b) {
		g.fill(bx, by, bx + bw, by + bh, 0xD0080808);
		g.fill(bx, by + bh / 2 - 18, bx + bw, by + bh / 2 - 17, 0xFF888888);
		g.fill(bx, by + bh / 2 + 16, bx + bw, by + bh / 2 + 17, 0xFF888888);
		g.drawCenteredString(font, Component.literal(a), bx + bw / 2, by + bh / 2 - 10, 0xFFFFFFFF);
		g.drawCenteredString(font, Component.literal(b), bx + bw / 2, by + bh / 2 + 4, 0xFF999999);
	}

	private void drawBottomBar(GuiGraphics g) {
		int y = guiTop + SCREEN_H - 24;
		g.fill(guiLeft + 4, y, guiLeft + SCREEN_W - 4, y + 1, 0xFF444444);
		String status = state == 0 ? "\u0417\u0410\u041f\u0418\u0421\u042c" : state == 1 ? "\u041f\u0410\u0423\u0417\u0410" : "\u0421\u0422\u041e\u041f";
		g.drawString(font, Component.literal("\u0420\u0415\u0416\u0418\u041c: " + status), guiLeft + 10, y + 8, 0xFF888888, false);
		String hint = "H \u0421\u041f\u0420\u0410\u0412\u041a\u0410";
		g.drawString(font, Component.literal(hint), guiLeft + SCREEN_W - font.width(hint) - 10, y + 8, 0xFF666666, false);
	}

	private void drawHelp(GuiGraphics g) {
		String[][] rows = {
				{"A D", "\u0434\u0432\u0438\u0433\u0430\u0442\u044c"},
				{"W", "\u043f\u043e\u0432\u0435\u0440\u043d\u0443\u0442\u044c"},
				{"S", "\u0443\u0441\u043a\u043e\u0440\u0438\u0442\u044c"},
				{"SPACE", "\u0441\u043a\u0438\u043d\u0443\u0442\u044c \u0441\u0440\u0430\u0437\u0443"},
				{"C", "\u0441\u043b\u0435\u0434."},
				{"P", "\u043f\u0430\u0443\u0437\u0430"},
				{"R", "\u0437\u0430\u043d\u043e\u0432\u043e"},
				{"ESC", "\u0432\u044b\u0445\u043e\u0434"}
		};
		int w = 150;
		int h = rows.length * 12 + 22;
		int x = guiLeft + (SCREEN_W - w) / 2;
		int y = guiTop + (SCREEN_H - h) / 2;
		g.fill(x, y, x + w, y + h, 0xF00D0D0D);
		g.fill(x, y, x + w, y + 1, 0xFFCCCCCC);
		g.fill(x, y + h - 1, x + w, y + h, 0xFFCCCCCC);
		g.fill(x, y, x + 1, y + h, 0xFF888888);
		g.fill(x + w - 1, y, x + w, y + h, 0xFF888888);
		g.drawString(font, Component.literal("\u0423\u041f\u0420\u0410\u0412\u041b\u0415\u041d\u0418\u0415"), x + 8, y + 7, 0xFFFFFFFF, false);
		g.fill(x + 6, y + 18, x + w - 6, y + 19, 0xFF444444);
		for (int i = 0; i < rows.length; i++) {
			int ry = y + 23 + i * 12;
			g.drawString(font, Component.literal(rows[i][0]), x + 8, ry, 0xFFCCCCCC, false);
			g.drawString(font, Component.literal(rows[i][1]), x + 62, ry, 0xFF888888, false);
		}
	}

	private void drawScanlines(GuiGraphics g) {
		for (int row = scanlineOffset; row < SCREEN_H; row += 4)
			g.fill(guiLeft + 2, guiTop + row, guiLeft + SCREEN_W - 2, guiTop + row + 1, 0x12000000);
	}

	private void drawGlitch(GuiGraphics g, long now) {
		long seed = now / 3000;
		Random r = new Random(seed);
		if (r.nextInt(3) != 0)
			return;
		int count = r.nextInt(3) + 1;
		for (int i = 0; i < count; i++) {
			int gy = guiTop + r.nextInt(SCREEN_H);
			int gh = r.nextInt(3) + 1;
			int shift = r.nextInt(5) - 2;
			g.fill(guiLeft + shift + 2, gy, guiLeft + SCREEN_W + shift - 2, gy + gh, 0x18FF0000);
			g.fill(guiLeft - shift + 2, gy, guiLeft + SCREEN_W - shift - 2, gy + gh, 0x180000FF);
			g.fill(guiLeft + 2, gy, guiLeft + SCREEN_W - 2, gy + gh, 0x10FFFFFF);
		}
		if (r.nextInt(5) == 0) {
			int ny = guiTop + (int) ((seed * 37) % SCREEN_H);
			g.fill(guiLeft + 2, ny, guiLeft + SCREEN_W - 2, ny + 2, 0x20FFFFFF);
		}
	}
}