package deskped.sped.item.client;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

import deskped.sped.SpedMod;
import deskped.sped.item.WandItem;
import deskped.sped.network.WandSpellsPacket;
import deskped.sped.voice.client.ui.Ui;

@OnlyIn(Dist.CLIENT)
public class WandSpellScreen extends Screen {

	private static final int ACCENT = 0x3FE0D6;
	private static final int W = 320;
	private static final int H = 238;
	private static final int DRAWER_H = 118;
	private static final long DUR = 170L;

	private static final String[][] ICONS = {
			{"...........", ".##.....##.", "..##...##..", "...##.##...", "....###....", ".....#.....", "....###....", "...##.##...", "..##...##..", ".##.....##.", "..........."},
			{"...........", "....###....", "....###....", "....###....", ".#########.", ".#########.", ".#########.", "....###....", "....###....", "....###....", "..........."},
			{".....#.....", ".....#.....", "....##.....", "....###....", "...####....", "...#####...", "..#######..", "..#######..", "...#####...", "....###....", "..........."},
			{"...........", ".....#.....", "..#..#..#..", "...#.#.#...", "....###....", ".#########.", "....###....", "...#.#.#...", "..#..#..#..", ".....#.....", "..........."},
			{"...........", "......##...", ".....##....", "....##.....", "...#####...", ".....##....", "....##.....", "...##......", "..##.......", ".##........", "..........."},
			{"...........", ".....#.....", "....###....", "...#####...", "..#######..", ".#########.", "....###....", "....###....", "....###....", "....###....", "..........."},
			{"...........", "...........", "...#...#...", "..#.....#..", ".#.......#.", "#.........#", ".#.......#.", "..#.....#..", "...#...#...", "...........", "..........."},
			{"...........", "...........", ".#.......#.", "..#.....#..", "...#...#...", "....#.#....", "...#...#...", "..#.....#..", ".#.......#.", "...........", "..........."},
			{"...........", ".#########.", ".#....#..#.", ".#...#...#.", ".#....#..#.", ".#...#...#.", ".#..#....#.", ".#...#...#.", ".#....#..#.", ".#########.", "..........."},
			{".....#.....", "...........", "..#.....#..", "....###....", "...#####...", "#..#####..#", "...#####...", "....###....", "..#.....#..", "...........", ".....#....."},
			{"...........", ".###...###.", "..###.###..", "...##.##...", ".....#.....", ".....#.....", ".....#.....", ".....#.....", "..#######..", ".#########.", "..........."},
			{"...........", "...........", ".#....#....", "..#....#...", "...#....#..", "....#....#.", "...#....#..", "..#....#...", ".#....#....", "...........", "..........."},
			{"...........", "..##...##..", ".####.####.", ".#########.", ".#########.", ".#########.", "..#######..", "...#####...", "....###....", ".....#.....", "..........."},
			{"...........", "....###....", "....###....", "....###....", "...........", ".#########.", "...........", "..#######..", "...........", "...#####...", "..........."},
			{"...........", "...#####...", "..#######..", "..##.#.##..", "..#######..", "..#######..", "..#######..", "..#######..", "..#.#.#.#..", "...........", "..........."},
			{"...........", "....###....", ".....#.....", ".....#.....", "....#.#....", "...#...#...", "..#.....#..", ".#..#.#..#.", ".#.#####.#.", ".#########.", "..........."},
			{"...........", "....###....", "....###....", ".....#.....", "..#######..", ".....#.....", ".....#.....", "....#.#....", "...#...#...", "..#.....#..", "..........."},
			{"...........", "...........", "......#....", ".......#...", "........#..", ".#########.", "........#..", ".......#...", "......#....", "...........", "..........."},
			{"...........", "...#####...", "..#.....#..", ".#.......#.", ".#...#...#.", ".#..###..#.", ".#...#...#.", ".#.......#.", "..#.....#..", "...#####...", "..........."},
			{"...........", "........##.", "........##.", "........##.", ".....##.##.", ".....##.##.", ".....##.##.", "..##.##.##.", "..##.##.##.", "..##.##.##.", "..........."},
			{"...........", "...#####...", ".##.....##.", ".#..###..#.", ".#.#...#.#.", ".#.#.#.#.#.", ".#.#...#.#.", ".#..###..#.", ".##.....##.", "...#####...", "..........."},
			{"...........", "...#####...", ".##.....##.", ".#..#....#.", ".#..#....#.", ".#..####.#.", ".#.......#.", ".#.......#.", ".##.....##.", "...#####...", "..........."},
			{"...........", "...#####...", ".#########.", "...........", ".#.#.#.#.#.", ".#.#.#.#.#.", ".#.#.#.#.#.", ".#.#.#.#.#.", ".#.......#.", ".#.......#.", "..#######.."}
	};

	private static final int TRASH = 22;

	private final InteractionHand hand;
	private final Slot[] slots = new Slot[WandItem.MAX_SLOTS];
	private final boolean ru;
	private final List<Anim> anims = new ArrayList<>();
	private int cur;
	private boolean loaded;
	private int x0;
	private int y0;
	private int comboStartX;
	private int comboY;
	private int gridX;
	private int gridY;
	private int formStartX;
	private int formY;
	private int modStartX;
	private int modY;
	private boolean drawerOpen;
	private float drawerT;
	private long lastMs;
	private EditBox nameBox;
	private List<Component> tip;

	private final String[] fxRu = {"\u0423\u0440\u043e\u043d", "\u041b\u0435\u0447\u0435\u043d\u0438\u0435", "\u041e\u0433\u043e\u043d\u044c", "\u041c\u043e\u0440\u043e\u0437", "\u041c\u043e\u043b\u043d\u0438\u044f", "\u0412\u0437\u043b\u0451\u0442", "\u0422\u043e\u043b\u0447\u043e\u043a", "\u041f\u0440\u0438\u0442\u044f\u0436\u0435\u043d\u0438\u0435", "\u0420\u0430\u0437\u043b\u043e\u043c", "\u0421\u0432\u0435\u0442", "\u0420\u043e\u0441\u0442", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "\u0420\u0435\u0433\u0435\u043d\u0435\u0440\u0430\u0446\u0438\u044f", "\u041b\u0435\u0432\u0438\u0442\u0430\u0446\u0438\u044f", "\u041d\u0435\u0432\u0438\u0434\u0438\u043c\u043e\u0441\u0442\u044c", "\u042f\u0434"};
	private final String[] fxEn = {"Damage", "Heal", "Fire", "Frost", "Lightning", "Launch", "Push", "Pull", "Break", "Light", "Grow", "Speed", "Regen", "Levitate", "Invis", "Poison"};
	private final String[] fxDescRu = {"\u041c\u0430\u0433\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0443\u0440\u043e\u043d \u0446\u0435\u043b\u0438", "\u041b\u0435\u0447\u0438\u0442 \u0446\u0435\u043b\u044c, \u0432\u0440\u0435\u0434\u0438\u0442 \u043d\u0435\u0436\u0438\u0442\u0438", "\u041f\u043e\u0434\u0436\u0438\u0433\u0430\u0435\u0442 \u0446\u0435\u043b\u044c \u0438\u043b\u0438 \u0431\u043b\u043e\u043a", "\u0417\u0430\u043c\u043e\u0440\u0430\u0436\u0438\u0432\u0430\u0435\u0442 \u0438 \u0437\u0430\u043c\u0435\u0434\u043b\u044f\u0435\u0442", "\u0411\u044c\u0451\u0442 \u043c\u043e\u043b\u043d\u0438\u0435\u0439", "\u041f\u043e\u0434\u0431\u0440\u0430\u0441\u044b\u0432\u0430\u0435\u0442 \u0432\u0432\u0435\u0440\u0445", "\u041e\u0442\u0442\u0430\u043b\u043a\u0438\u0432\u0430\u0435\u0442 \u043e\u0442 \u0432\u0430\u0441", "\u041f\u0440\u0438\u0442\u044f\u0433\u0438\u0432\u0430\u0435\u0442 \u043a \u0432\u0430\u043c", "\u041b\u043e\u043c\u0430\u0435\u0442 \u0431\u043b\u043e\u043a", "\u0421\u0442\u0430\u0432\u0438\u0442 \u043d\u0435\u0432\u0438\u0434\u0438\u043c\u044b\u0439 \u0441\u0432\u0435\u0442", "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0440\u043e\u0441\u0442 \u0440\u0430\u0441\u0442\u0435\u043d\u0438\u0439", "\u0414\u0430\u0451\u0442 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "\u0414\u0430\u0451\u0442 \u0440\u0435\u0433\u0435\u043d\u0435\u0440\u0430\u0446\u0438\u044e", "\u0414\u0430\u0451\u0442 \u043b\u0435\u0432\u0438\u0442\u0430\u0446\u0438\u044e", "\u0414\u0430\u0451\u0442 \u043d\u0435\u0432\u0438\u0434\u0438\u043c\u043e\u0441\u0442\u044c", "\u041e\u0442\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0446\u0435\u043b\u044c"};
	private final String[] fxDescEn = {"Magic damage to the target", "Heals target, harms undead", "Ignites target or block", "Freezes and slows", "Strikes lightning", "Launches upward", "Pushes away from you", "Pulls toward you", "Breaks the block", "Places invisible light", "Grows plants", "Grants speed", "Grants regeneration", "Grants levitation", "Grants invisibility", "Poisons the target"};
	private final String[] formRu = {"\u041d\u0430 \u0441\u0435\u0431\u044f", "\u041b\u0443\u0447", "\u0412\u043e\u043b\u043d\u0430"};
	private final String[] formEn = {"Self", "Ray", "Wave"};
	private final String[] formDescRu = {"\u042d\u0444\u0444\u0435\u043a\u0442\u044b \u043d\u0430 \u0441\u0435\u0431\u044f", "\u041b\u0443\u0447 \u0434\u043e 30 \u0431\u043b\u043e\u043a\u043e\u0432", "\u0412\u043e\u043b\u043d\u0430 \u0432\u043e\u043a\u0440\u0443\u0433 \u0432\u0430\u0441"};
	private final String[] formDescEn = {"Effects on yourself", "Beam up to 30 blocks", "Wave around you"};
	private final String[] modRu = {"\u0421\u0438\u043b\u0430", "\u0420\u0430\u0434\u0438\u0443\u0441", "\u0412\u0440\u0435\u043c\u044f"};
	private final String[] modEn = {"Power", "Radius", "Time"};
	private final String[] modDescRu = {"\u0411\u043e\u043b\u044c\u0448\u0435 \u0443\u0440\u043e\u043d\u0430 \u0438 \u044d\u0444\u0444\u0435\u043a\u0442\u043e\u0432", "\u0428\u0438\u0440\u0435 \u0432\u043e\u043b\u043d\u0430", "\u0414\u043e\u043b\u044c\u0448\u0435 \u044d\u0444\u0444\u0435\u043a\u0442\u044b"};
	private final String[] modDescEn = {"More damage and effects", "Wider wave", "Longer effects"};
	private final int[] modId = {WandItem.ID_POWER, WandItem.ID_RADIUS, WandItem.ID_TIME};

	public static void open(boolean mainHand) {
		Minecraft.getInstance().setScreen(new WandSpellScreen(mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND));
	}

	public WandSpellScreen(InteractionHand hand) {
		super(Component.literal("Wand"));
		this.hand = hand;
		this.ru = Minecraft.getInstance().getLanguageManager().getSelected().startsWith("ru");
		for (int i = 0; i < slots.length; i++)
			slots[i] = new Slot();
	}

	private void load() {
		if (loaded || minecraft == null || minecraft.player == null)
			return;
		loaded = true;
		lastMs = Util.getMillis();
		ItemStack stack = minecraft.player.getItemInHand(hand);
		CompoundTag data = stack.getTagElement(WandItem.TAG);
		if (data == null)
			return;
		cur = Math.max(0, Math.min(WandItem.MAX_SLOTS - 1, data.getInt("Active")));
		ListTag list = data.getList("Slots", Tag.TAG_COMPOUND);
		for (int i = 0; i < Math.min(slots.length, list.size()); i++) {
			CompoundTag c = list.getCompound(i);
			Slot s = slots[i];
			s.name = c.getString("Name");
			s.form = Math.max(0, Math.min(2, c.getInt("Form")));
			s.chain.clear();
			for (int id : c.getIntArray("Chain"))
				if (valid(id) && s.chain.size() < WandItem.MAX_CHAIN)
					s.chain.add(id);
		}
	}

	private boolean valid(int id) {
		return (id >= 0 && id < WandItem.FX_COUNT) || id == WandItem.ID_POWER || id == WandItem.ID_RADIUS || id == WandItem.ID_TIME;
	}

	@Override
	protected void init() {
		load();
		if (nameBox != null)
			commit();
		x0 = (width - W) / 2;
		y0 = (height - H) / 2;
		comboStartX = x0 + 33;
		comboY = y0 + 48;
		gridX = x0 + 51;
		gridY = y0 + 120;
		formStartX = x0 + 119;
		formY = y0 + 82;
		modStartX = x0 + 119;
		modY = y0 + 184;
		nameBox = new EditBox(font, x0 + 85, y0 + 22, 150, 16, Component.empty());
		nameBox.setMaxLength(24);
		nameBox.setHint(Component.literal(ru ? "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435" : "Name"));
		nameBox.setValue(slots[cur].name);
		addRenderableWidget(nameBox);
		addRenderableWidget(new Ui.FlatButton(x0 + 228, y0 + 212, 80, 16, Component.literal(ru ? "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c" : "Save"), b -> {
			commit();
			SpedMod.PACKET_HANDLER.sendToServer(new WandSpellsPacket(buildTag()));
			onClose();
		}));
	}

	private void commit() {
		slots[cur].name = nameBox.getValue();
	}

	private CompoundTag buildTag() {
		CompoundTag root = new CompoundTag();
		root.putInt("Active", cur);
		ListTag list = new ListTag();
		for (Slot s : slots) {
			CompoundTag c = new CompoundTag();
			c.putString("Name", s.name);
			c.putInt("Form", s.form);
			int[] a = new int[s.chain.size()];
			for (int i = 0; i < a.length; i++)
				a[i] = s.chain.get(i);
			c.putIntArray("Chain", a);
			list.add(c);
		}
		root.put("Slots", list);
		return root;
	}

	private int count(Slot s, int id) {
		int n = 0;
		for (int v : s.chain)
			if (v == id)
				n++;
		return n;
	}

	private int chainCellX(int index) {
		return comboStartX + 26 * (index + 1);
	}

	private int gridPosX(int id) {
		if (id < WandItem.FX_COUNT)
			return gridX + (id % 8) * 28;
		for (int i = 0; i < 3; i++)
			if (modId[i] == id)
				return modStartX + i * 30;
		return gridX;
	}

	private int gridPosY(int id) {
		if (id < WandItem.FX_COUNT)
			return gridY + (id / 8) * 28;
		return modY;
	}

	private void addIcon(int id) {
		Slot s = slots[cur];
		if (s.chain.size() >= WandItem.MAX_CHAIN)
			return;
		if (id >= WandItem.FX_COUNT && count(s, id) >= 3)
			return;
		s.chain.add(id);
		anims.add(new Anim(id, gridPosX(id) + 5, gridPosY(id) + 5, chainCellX(s.chain.size() - 1) + 4, comboY + 4, false));
		click();
	}

	private void removeIcon(int index) {
		Slot s = slots[cur];
		if (index < 0 || index >= s.chain.size())
			return;
		int id = s.chain.remove(index);
		anims.add(new Anim(id, chainCellX(index) + 4, comboY + 4, gridPosX(id) + 5, gridPosY(id) + 5, true));
		click();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
		tip = null;
		long now = Util.getMillis();
		float dt = Math.min(80L, now - lastMs) / 1000.0F;
		lastMs = now;
		float target = drawerOpen ? 1.0F : 0.0F;
		if (drawerT < target)
			drawerT = Math.min(target, drawerT + dt * 6.0F);
		else if (drawerT > target)
			drawerT = Math.max(target, drawerT - dt * 6.0F);
		anims.removeIf(a -> now - a.start > DUR);
		renderBackground(g);
		Ui.panel(g, x0, y0, W, H);
		Ui.stars(g, x0, y0, W, H, 883L);
		Slot s = slots[cur];
		int col = 0xFF000000 | ACCENT;
		g.drawCenteredString(font, ru ? "\u0417\u0430\u043a\u043b\u0438\u043d\u0430\u043d\u0438\u044f" : "Spells", x0 + 160, y0 + 7, Ui.TEXT);
		boolean drawerBusy = drawerT > 0.01F;
		int handleY = y0 + Math.round(DRAWER_H * drawerT);
		g.drawString(font, ru ? "\u041a\u043e\u043c\u0431\u0438\u043d\u0430\u0446\u0438\u044f" : "Combination", x0 + 12, comboY - 10, Ui.DIM);
		boolean hovForm = !drawerBusy && hover(mouseX, mouseY, comboStartX, comboY, 20, 20);
		cell(g, comboStartX, comboY, 20, 20, true, hovForm);
		icon(g, 16 + s.form, comboStartX + 4, comboY + 4, col);
		if (hovForm)
			tip = List.of(name(ru ? formRu[s.form] : formEn[s.form]), dim(ru ? formDescRu[s.form] : formDescEn[s.form]), dim(ru ? "\u041a\u043b\u0438\u043a: \u0441\u043c\u0435\u043d\u0438\u0442\u044c \u0444\u043e\u0440\u043c\u0443" : "Click: change form"));
		for (int i = 0; i < WandItem.MAX_CHAIN; i++) {
			int cx = chainCellX(i);
			arrow(g, cx - 6, comboY + 8);
			boolean hov = !drawerBusy && hover(mouseX, mouseY, cx, comboY, 20, 20);
			if (i < s.chain.size()) {
				int id = s.chain.get(i);
				boolean flying = animActive(id, cx + 4, comboY + 4, false);
				cell(g, cx, comboY, 20, 20, true, hov);
				if (!flying)
					icon(g, id, cx + 4, comboY + 4, col);
				if (hov)
					tip = List.of(name(label(id)), dim(desc(id)), dim(ru ? "\u041a\u043b\u0438\u043a: \u0443\u0431\u0440\u0430\u0442\u044c" : "Click: remove"));
			} else {
				dashed(g, cx, comboY, 20, 20);
			}
		}
		g.drawString(font, ru ? "\u0424\u043e\u0440\u043c\u0430" : "Form", x0 + 12, formY - 10, Ui.DIM);
		for (int i = 0; i < 3; i++) {
			int cx = formStartX + i * 30;
			boolean hov = !drawerBusy && hover(mouseX, mouseY, cx, formY, 22, 22);
			cell(g, cx, formY, 22, 22, s.form == i, hov);
			icon(g, 16 + i, cx + 5, formY + 5, s.form == i ? col : (hov ? 0xFF000000 | Ui.TEXT : 0xFF000000 | Ui.DIM));
			if (hov)
				tip = List.of(name(ru ? formRu[i] : formEn[i]), dim(ru ? formDescRu[i] : formDescEn[i]));
		}
		g.drawString(font, (ru ? "\u042d\u0444\u0444\u0435\u043a\u0442\u044b " : "Effects ") + s.chain.size() + "/" + WandItem.MAX_CHAIN, x0 + 12, gridY - 10, Ui.DIM);
		for (int i = 0; i < WandItem.FX_COUNT; i++) {
			int cx = gridX + (i % 8) * 28;
			int cy = gridY + (i / 8) * 28;
			int n = count(s, i);
			boolean hov = !drawerBusy && hover(mouseX, mouseY, cx, cy, 22, 22);
			cell(g, cx, cy, 22, 22, n > 0, hov);
			icon(g, i, cx + 5, cy + 5, n > 0 ? col : (hov ? 0xFF000000 | Ui.TEXT : 0xFF000000 | Ui.DIM));
			if (n > 0)
				badge(g, cx + 15, cy - 1, n);
			if (hov)
				tip = List.of(name(ru ? fxRu[i] : fxEn[i]), dim(ru ? fxDescRu[i] : fxDescEn[i]), dim(ru ? "\u041a\u043b\u0438\u043a: \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c" : "Click: add"));
		}
		for (int i = 0; i < 3; i++) {
			int cx = modStartX + i * 30;
			int id = modId[i];
			int n = count(s, id);
			boolean hov = !drawerBusy && hover(mouseX, mouseY, cx, modY, 22, 22);
			cell(g, cx, modY, 22, 22, n > 0, hov);
			icon(g, 19 + i, cx + 5, modY + 5, n > 0 ? col : (hov ? 0xFF000000 | Ui.TEXT : 0xFF000000 | Ui.DIM));
			if (n > 0)
				badge(g, cx + 15, modY - 1, n);
			if (hov)
				tip = List.of(name(ru ? modRu[i] : modEn[i]), dim(ru ? modDescRu[i] : modDescEn[i]), dim(ru ? "\u0423\u0440\u043e\u0432\u0435\u043d\u044c: " + n + "/3, \u043a\u043b\u0438\u043a: \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c" : "Level: " + n + "/3, click: add"));
		}
		boolean hovTrash = !drawerBusy && hover(mouseX, mouseY, x0 + 12, y0 + 212, 22, 16);
		cell(g, x0 + 12, y0 + 212, 22, 16, false, hovTrash);
		icon(g, TRASH, x0 + 17, y0 + 214, hovTrash ? 0xFFFF5566 : 0xFF000000 | Ui.DIM);
		if (hovTrash)
			tip = List.of(name(ru ? "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c" : "Clear"));
		for (Anim a : anims)
			drawAnim(g, a, now, col);
		super.render(g, mouseX, mouseY, partial);
		if (drawerBusy)
			renderDrawer(g, mouseX, mouseY, handleY);
		drawHandle(g, mouseX, mouseY, handleY);
		if (tip != null)
			g.renderComponentTooltip(font, tip, mouseX, mouseY);
	}

	private void renderDrawer(GuiGraphics g, int mouseX, int mouseY, int handleY) {
		int top = handleY - DRAWER_H;
		g.enableScissor(x0 + 1, y0 + 1, x0 + W - 1, handleY);
		g.fill(x0 + 1, top, x0 + W - 1, handleY, 0xF00A1120);
		g.fill(x0 + 1, handleY - 1, x0 + W - 1, handleY, Ui.LINE);
		Ui.stars(g, x0 + 1, top, W - 2, DRAWER_H, 512L);
		g.drawString(font, ru ? "\u0421\u043b\u043e\u0442\u044b \u0437\u0430\u043a\u043b\u0438\u043d\u0430\u043d\u0438\u0439" : "Spell slots", x0 + 12, top + 6, Ui.TEXT);
		for (int i = 0; i < WandItem.MAX_SLOTS; i++) {
			int cardX = x0 + 12 + (i % 5) * 60;
			int cardY = top + 18 + (i / 5) * 48;
			boolean hov = hover(mouseX, mouseY, cardX, cardY, 56, 44) && mouseY < handleY;
			cell(g, cardX, cardY, 56, 44, i == cur, hov);
			g.drawString(font, String.valueOf(i + 1), cardX + 3, cardY + 3, i == cur ? Ui.CYAN : Ui.DIM);
			Slot sl = slots[i];
			String nm = sl.name.isEmpty() ? "" : sl.name;
			if (!nm.isEmpty())
				g.drawString(font, font.plainSubstrByWidth(nm, 40), cardX + 13, cardY + 3, Ui.TEXT);
			int mc = 0xFF000000 | ACCENT;
			icon(g, 16 + sl.form, cardX + 4, cardY + 20, mc);
			int shown = Math.min(3, sl.chain.size());
			for (int k = 0; k < shown; k++)
				icon(g, sl.chain.get(k), cardX + 16 + k * 12, cardY + 20, mc);
			if (sl.chain.size() > shown)
				g.drawString(font, "+", cardX + 16 + shown * 12, cardY + 20, Ui.DIM);
		}
		g.disableScissor();
	}

	private void drawHandle(GuiGraphics g, int mouseX, int mouseY, int handleY) {
		int hw = 46;
		int hx = x0 + (W - hw) / 2;
		int hy = handleY - 9;
		boolean hov = hover(mouseX, mouseY, hx, hy, hw, 11);
		g.fill(hx, hy, hx + hw, hy + 11, hov ? 0x40000000 | ACCENT : 0xF00A1120);
		g.fill(hx, hy, hx + hw, hy + 1, Ui.LINE);
		g.fill(hx, hy + 10, hx + hw, hy + 11, Ui.LINE_DIM);
		g.fill(hx, hy, hx + 1, hy + 11, Ui.LINE_DIM);
		g.fill(hx + hw - 1, hy, hx + hw, hy + 11, Ui.LINE_DIM);
		int cx = hx + hw / 2;
		int cy = hy + 5;
		int c = hov ? Ui.CYAN : Ui.TEXT;
		if (drawerOpen) {
			g.fill(cx - 3, cy + 1, cx - 2, cy + 2, c);
			g.fill(cx - 2, cy, cx - 1, cy + 1, c);
			g.fill(cx - 1, cy - 1, cx + 1, cy, c);
			g.fill(cx + 1, cy, cx + 2, cy + 1, c);
			g.fill(cx + 2, cy + 1, cx + 3, cy + 2, c);
		} else {
			g.fill(cx - 3, cy - 1, cx - 2, cy, c);
			g.fill(cx - 2, cy, cx - 1, cy + 1, c);
			g.fill(cx - 1, cy + 1, cx + 1, cy + 2, c);
			g.fill(cx + 1, cy, cx + 2, cy + 1, c);
			g.fill(cx + 2, cy - 1, cx + 3, cy, c);
		}
	}

	private boolean animActive(int id, int tx, int ty, boolean out) {
		for (Anim a : anims)
			if (a.id == id && a.out == out && Math.abs(a.tx - tx) < 2 && Math.abs(a.ty - ty) < 2)
				return true;
		return false;
	}

	private void drawAnim(GuiGraphics g, Anim a, long now, int col) {
		float p = Math.min(1.0F, (now - a.start) / (float) DUR);
		float e = 1.0F - (1.0F - p) * (1.0F - p) * (1.0F - p);
		float x = a.sx + (a.tx - a.sx) * e;
		float y = a.sy + (a.ty - a.sy) * e;
		float sc = a.out ? 1.0F - 0.4F * e : 1.3F - 0.3F * e;
		int alpha = a.out ? (int) (255 - 180 * e) : 255;
		int c = (alpha << 24) | (col & 0xFFFFFF);
		g.pose().pushPose();
		g.pose().translate(x + 5.5F, y + 5.5F, 0);
		g.pose().scale(sc, sc, 1);
		g.pose().translate(-5.5F, -5.5F, 0);
		icon(g, a.id, 0, 0, c);
		g.pose().popPose();
	}

	private String label(int id) {
		if (id < WandItem.FX_COUNT)
			return ru ? fxRu[id] : fxEn[id];
		for (int i = 0; i < 3; i++)
			if (modId[i] == id)
				return ru ? modRu[i] : modEn[i];
		return "";
	}

	private String desc(int id) {
		if (id < WandItem.FX_COUNT)
			return ru ? fxDescRu[id] : fxDescEn[id];
		for (int i = 0; i < 3; i++)
			if (modId[i] == id)
				return ru ? modDescRu[i] : modDescEn[i];
		return "";
	}

	private Component name(String text) {
		return Component.literal(text).withStyle(Style.EMPTY.withColor(ACCENT));
	}

	private Component dim(String text) {
		return Component.literal(text).withStyle(Style.EMPTY.withColor(0x7C8CB0));
	}

	private void badge(GuiGraphics g, int x, int y, int n) {
		g.fill(x - 1, y - 1, x + 7, y + 8, 0xFF060913);
		g.drawString(font, String.valueOf(n), x, y, 0xFF000000 | ACCENT);
	}

	private void icon(GuiGraphics g, int id, int x, int y, int color) {
		String[] rows = ICONS[id];
		for (int r = 0; r < rows.length; r++) {
			String row = rows[r];
			for (int c = 0; c < row.length(); c++)
				if (row.charAt(c) == '#')
					g.fill(x + c, y + r, x + c + 1, y + r + 1, color);
		}
	}

	private void cell(GuiGraphics g, int x, int y, int w, int h, boolean sel, boolean hov) {
		if (sel)
			g.fill(x, y, x + w, y + h, 0x503FE0D6);
		else if (hov)
			g.fill(x, y, x + w, y + h, 0x263FE0D6);
		else
			g.fill(x, y, x + w, y + h, 0x28101B33);
		int bc = sel ? (0xFF000000 | ACCENT) : Ui.LINE_DIM;
		g.fill(x, y, x + w, y + 1, bc);
		g.fill(x, y + h - 1, x + w, y + h, bc);
		g.fill(x, y, x + 1, y + h, bc);
		g.fill(x + w - 1, y, x + w, y + h, bc);
	}

	private void dashed(GuiGraphics g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, 0x14101B33);
		for (int dx = 0; dx < w; dx += 4) {
			int len = Math.min(2, w - dx);
			g.fill(x + dx, y, x + dx + len, y + 1, Ui.LINE_DIM);
			g.fill(x + dx, y + h - 1, x + dx + len, y + h, Ui.LINE_DIM);
		}
		for (int dy = 0; dy < h; dy += 4) {
			int len = Math.min(2, h - dy);
			g.fill(x, y + dy, x + 1, y + dy + len, Ui.LINE_DIM);
			g.fill(x + w - 1, y + dy, x + w, y + dy + len, Ui.LINE_DIM);
		}
	}

	private void arrow(GuiGraphics g, int x, int y) {
		g.fill(x, y, x + 3, y + 1, Ui.DIM);
		g.fill(x + 1, y - 1, x + 2, y, Ui.DIM);
		g.fill(x + 1, y + 1, x + 2, y + 2, Ui.DIM);
	}

	private boolean hover(int mx, int my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		int handleY = y0 + Math.round(DRAWER_H * drawerT);
		int hw = 46;
		int hx = x0 + (W - hw) / 2;
		if (hover((int) mx, (int) my, hx, handleY - 9, hw, 11)) {
			drawerOpen = !drawerOpen;
			if (drawerOpen)
				setFocused(null);
			click();
			return true;
		}
		if (drawerT > 0.5F) {
			int top = handleY - DRAWER_H;
			for (int i = 0; i < WandItem.MAX_SLOTS; i++) {
				int cardX = x0 + 12 + (i % 5) * 60;
				int cardY = top + 18 + (i / 5) * 48;
				if (hover((int) mx, (int) my, cardX, cardY, 56, 44) && my < handleY) {
					commit();
					cur = i;
					nameBox.setValue(slots[cur].name);
					anims.clear();
					drawerOpen = false;
					click();
					return true;
				}
			}
			return true;
		}
		if (super.mouseClicked(mx, my, button))
			return true;
		if (button != 0)
			return false;
		Slot s = slots[cur];
		if (hover((int) mx, (int) my, comboStartX, comboY, 20, 20)) {
			s.form = (s.form + 1) % 3;
			click();
			return true;
		}
		for (int i = 0; i < s.chain.size(); i++) {
			if (hover((int) mx, (int) my, chainCellX(i), comboY, 20, 20)) {
				removeIcon(i);
				return true;
			}
		}
		for (int i = 0; i < 3; i++) {
			if (hover((int) mx, (int) my, formStartX + i * 30, formY, 22, 22)) {
				s.form = i;
				click();
				return true;
			}
		}
		for (int i = 0; i < WandItem.FX_COUNT; i++) {
			int cx = gridX + (i % 8) * 28;
			int cy = gridY + (i / 8) * 28;
			if (hover((int) mx, (int) my, cx, cy, 22, 22)) {
				addIcon(i);
				return true;
			}
		}
		for (int i = 0; i < 3; i++) {
			if (hover((int) mx, (int) my, modStartX + i * 30, modY, 22, 22)) {
				addIcon(modId[i]);
				return true;
			}
		}
		if (hover((int) mx, (int) my, x0 + 12, y0 + 212, 22, 16)) {
			s.chain.clear();
			anims.clear();
			click();
			return true;
		}
		return false;
	}

	private void click() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null)
			mc.player.playSound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 0.25F, 1.6F);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@OnlyIn(Dist.CLIENT)
	private static class Slot {
		String name = "";
		int form = 1;
		final List<Integer> chain = new ArrayList<>();
	}

	@OnlyIn(Dist.CLIENT)
	private static class Anim {
		final int id;
		final float sx;
		final float sy;
		final float tx;
		final float ty;
		final boolean out;
		final long start = Util.getMillis();

		Anim(int id, int sx, int sy, int tx, int ty, boolean out) {
			this.id = id;
			this.sx = sx;
			this.sy = sy;
			this.tx = tx;
			this.ty = ty;
			this.out = out;
		}
	}
}