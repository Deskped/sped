package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ChildhoodClockItem extends Item {
	public ChildhoodClockItem() {
		super(new Item.Properties());
	}
}