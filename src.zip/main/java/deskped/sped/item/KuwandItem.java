package deskped.sped.item;

import net.minecraft.world.item.Item;

public class KuwandItem extends Item {
	public KuwandItem() {
		super(new Item.Properties().stacksTo(1));
	}
}