package deskped.sped.item;

import deskped.sped.init.SpedModParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WandItem extends Item {

	public static final String TAG = "sped_spells";
	public static final int MAX_SLOTS = 10;
	public static final int MAX_CHAIN = 9;
	public static final int FX_COUNT = 16;
	public static final int ID_POWER = 19;
	public static final int ID_RADIUS = 20;
	public static final int ID_TIME = 21;

	public WandItem() {
		super(new Item.Properties().stacksTo(1));
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (player.isShiftKeyDown()) {
			if (level.isClientSide) {
				boolean main = hand == InteractionHand.MAIN_HAND;
				DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.item.client.WandSpellScreen.open(main));
			}
			return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
		}
		if (level instanceof ServerLevel server) {
			CompoundTag spell = activeSpell(stack);
			if (spell != null && hasEffect(spell.getIntArray("Chain"))) {
				cast(server, player, spell);
				player.getCooldowns().addCooldown(this, 8);
			}
		}
		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
	}

	@Nullable
	public static CompoundTag activeSpell(ItemStack stack) {
		CompoundTag data = stack.getTagElement(TAG);
		if (data == null)
			return null;
		ListTag slots = data.getList("Slots", Tag.TAG_COMPOUND);
		int active = data.getInt("Active");
		if (active < 0 || active >= slots.size())
			return null;
		return slots.getCompound(active);
	}

	public static boolean hasEffect(int[] chain) {
		for (int id : chain)
			if (id >= 0 && id < FX_COUNT)
				return true;
		return false;
	}

	private void cast(ServerLevel level, Player player, CompoundTag spell) {
		int form = spell.getInt("Form");
		int[] chain = spell.getIntArray("Chain");
		List<Integer> effects = new ArrayList<>();
		int pw = 0;
		int rd = 0;
		int du = 0;
		for (int id : chain) {
			if (id >= 0 && id < FX_COUNT)
				effects.add(id);
			else if (id == ID_POWER)
				pw++;
			else if (id == ID_RADIUS)
				rd++;
			else if (id == ID_TIME)
				du++;
		}
		pw = Math.min(3, pw);
		rd = Math.min(3, rd);
		du = Math.min(3, du);
		SimpleParticleType main = SpedModParticleTypes.ROD.get();
		SimpleParticleType spark = SpedModParticleTypes.RLSTA.get();
		SimpleParticleType dark = SpedModParticleTypes.DARKROD.get();
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.PLAYERS, 0.6F, 1.3F);
		Vec3 eye = player.getEyePosition();
		Vec3 dir = player.getLookAngle();
		if (form == 0) {
			level.sendParticles(dark, player.getX(), player.getY() + 1.0D, player.getZ(), 26, 0.5D, 0.7D, 0.5D, 0.02D);
			level.sendParticles(spark, player.getX(), player.getY() + 1.0D, player.getZ(), 10, 0.4D, 0.6D, 0.4D, 0.0D);
			for (int id : effects)
				apply(id, level, player, player, player.blockPosition(), Direction.UP, pw, du);
		} else if (form == 1) {
			double range = 30.0D;
			Vec3 end = eye.add(dir.scale(range));
			BlockHitResult bhr = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
			double best = bhr.getType() == HitResult.Type.MISS ? range : bhr.getLocation().distanceTo(eye);
			LivingEntity hit = null;
			AABB sweep = player.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0D);
			for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sweep, e -> e != player && e.isAlive() && !e.isSpectator())) {
				Optional<Vec3> clip = e.getBoundingBox().inflate(0.3D).clip(eye, end);
				if (clip.isPresent()) {
					double d = clip.get().distanceTo(eye);
					if (d < best) {
						best = d;
						hit = e;
					}
				}
			}
			Vec3 point = eye.add(dir.scale(best));
			for (double t = 1.2D; t < best; t += 0.55D) {
				Vec3 p = eye.add(dir.scale(t));
				level.sendParticles(main, p.x, p.y, p.z, 1, 0.02D, 0.02D, 0.02D, 0.0D);
			}
			level.sendParticles(spark, point.x, point.y, point.z, 12, 0.22D, 0.22D, 0.22D, 0.02D);
			BlockPos pos;
			Direction face;
			if (hit != null) {
				pos = hit.blockPosition();
				face = Direction.UP;
			} else if (bhr.getType() == HitResult.Type.BLOCK) {
				pos = bhr.getBlockPos();
				face = bhr.getDirection();
			} else {
				pos = BlockPos.containing(point);
				face = Direction.UP;
			}
			for (int id : effects)
				apply(id, level, player, hit, pos, face, pw, du);
		} else {
			double r = 4.0D + rd * 2.0D;
			for (int a = 0; a < 72; a++) {
				double ang = a * Math.PI / 36.0D;
				level.sendParticles(main, player.getX() + Math.cos(ang) * r, player.getY() + 0.15D, player.getZ() + Math.sin(ang) * r, 1, 0.04D, 0.08D, 0.04D, 0.0D);
			}
			List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(r), e -> e != player && e.isAlive() && !e.isSpectator() && e.distanceTo(player) <= r);
			for (LivingEntity t : targets)
				level.sendParticles(spark, t.getX(), t.getY() + 1.0D, t.getZ(), 6, 0.3D, 0.5D, 0.3D, 0.0D);
			for (int id : effects) {
				for (LivingEntity t : targets)
					apply(id, level, player, t, t.blockPosition(), Direction.UP, pw, du);
				if (isGround(id)) {
					for (int k = 0; k < 8; k++) {
						double ang = k * Math.PI / 4.0D;
						int dx = (int) Math.round(Math.cos(ang) * r);
						int dz = (int) Math.round(Math.sin(ang) * r);
						apply(id, level, player, null, surface(level, player.blockPosition(), dx, dz), Direction.UP, pw, du);
					}
				}
			}
		}
	}

	private boolean isGround(int id) {
		return id == 2 || id == 8 || id == 9 || id == 10;
	}

	private BlockPos surface(ServerLevel level, BlockPos base, int dx, int dz) {
		for (int yy = 2; yy >= -3; yy--) {
			BlockPos p = base.offset(dx, yy, dz);
			if (!level.getBlockState(p).isAir())
				return p;
		}
		return base.offset(dx, -1, dz);
	}

	private void apply(int id, ServerLevel level, Player caster, @Nullable LivingEntity target, BlockPos pos, Direction face, int pw, int du) {
		int ticks = 200 + du * 200;
		switch (id) {
			case 0 -> {
				if (target != null && target != caster)
					target.hurt(level.damageSources().indirectMagic(caster, caster), 5.0F + pw * 3.0F);
			}
			case 1 -> {
				if (target != null) {
					if (target.isInvertedHealAndHarm())
						target.hurt(level.damageSources().indirectMagic(caster, caster), 5.0F + pw * 3.0F);
					else
						target.heal(5.0F + pw * 3.0F);
				}
			}
			case 2 -> {
				if (target != null && target != caster) {
					target.setSecondsOnFire(4 + du * 4);
				} else if (target == null) {
					BlockPos fp = level.getBlockState(pos).canBeReplaced() ? pos : pos.relative(face);
					if (level.isEmptyBlock(fp) && BaseFireBlock.canBePlacedAt(level, fp, face))
						level.setBlockAndUpdate(fp, BaseFireBlock.getState(level, fp));
				}
			}
			case 3 -> {
				if (target != null) {
					target.setTicksFrozen(Math.max(target.getTicksFrozen(), 300 + du * 200));
					target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, pw));
					target.clearFire();
				}
			}
			case 4 -> {
				LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
				if (bolt != null) {
					bolt.moveTo(target != null ? target.position() : Vec3.atBottomCenterOf(pos.relative(face)));
					if (caster instanceof ServerPlayer sp)
						bolt.setCause(sp);
					level.addFreshEntity(bolt);
				}
			}
			case 5 -> {
				if (target != null) {
					Vec3 v = target.getDeltaMovement();
					target.setDeltaMovement(v.x, 0.9D + pw * 0.4D, v.z);
					target.hurtMarked = true;
				}
			}
			case 6 -> {
				if (target != null && target != caster) {
					Vec3 v = target.position().subtract(caster.position()).normalize().scale(1.0D + pw * 0.5D);
					target.setDeltaMovement(v.x, 0.4D, v.z);
					target.hurtMarked = true;
				}
			}
			case 7 -> {
				if (target != null && target != caster) {
					Vec3 v = caster.position().subtract(target.position()).normalize().scale(1.0D + pw * 0.5D);
					target.setDeltaMovement(v.x, 0.2D, v.z);
					target.hurtMarked = true;
				}
			}
			case 8 -> {
				if (target == null) {
					BlockState st = level.getBlockState(pos);
					if (!st.isAir() && st.getDestroySpeed(level, pos) >= 0.0F)
						level.destroyBlock(pos, true, caster);
				}
			}
			case 9 -> {
				BlockPos lp = target != null ? target.blockPosition() : (level.getBlockState(pos).canBeReplaced() ? pos : pos.relative(face));
				if (level.getBlockState(lp).canBeReplaced())
					level.setBlockAndUpdate(lp, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 15));
			}
			case 10 -> {
				if (target == null) {
					if (BoneMealItem.growCrop(new ItemStack(Items.BONE_MEAL), level, pos) || BoneMealItem.growWaterPlant(new ItemStack(Items.BONE_MEAL), level, pos, face))
						level.levelEvent(1505, pos, 0);
				}
			}
			case 11 -> {
				if (target != null)
					target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, ticks, pw));
			}
			case 12 -> {
				if (target != null)
					target.addEffect(new MobEffectInstance(MobEffects.REGENERATION, ticks, pw));
			}
			case 13 -> {
				if (target != null)
					target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60 + du * 60, pw));
			}
			case 14 -> {
				if (target != null)
					target.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, ticks, 0));
			}
			case 15 -> {
				if (target != null && target != caster)
					target.addEffect(new MobEffectInstance(MobEffects.POISON, ticks, pw));
			}
		}
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> list, TooltipFlag flag) {
		CompoundTag data = stack.getTagElement(TAG);
		if (data == null)
			return;
		ListTag slots = data.getList("Slots", Tag.TAG_COMPOUND);
		int active = data.getInt("Active");
		int filled = 0;
		for (int i = 0; i < slots.size(); i++)
			if (hasEffect(slots.getCompound(i).getIntArray("Chain")))
				filled++;
		if (active >= 0 && active < slots.size()) {
			CompoundTag s = slots.getCompound(active);
			if (hasEffect(s.getIntArray("Chain"))) {
				String n = s.getString("Name");
				if (n.isEmpty())
					n = String.valueOf(active + 1);
				list.add(Component.literal("\u25c6 " + n).withStyle(Style.EMPTY.withColor(0x3FE0D6)));
			}
		}
		list.add(Component.literal(filled + " / " + MAX_SLOTS).withStyle(Style.EMPTY.withColor(0x7C8CB0)));
	}
}