package deskped.sped.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

public class CameraBlockItem extends BlockItem {

	public CameraBlockItem(Block block, Properties properties) {
		super(block, properties);
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Player player = context.getPlayer();
		if (player == null || player.isShiftKeyDown())
			return super.useOn(context);
		if (context.getHand() != InteractionHand.MAIN_HAND)
			return InteractionResult.PASS;
		return snap(context.getLevel(), player);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (hand != InteractionHand.MAIN_HAND || player.isShiftKeyDown())
			return InteractionResultHolder.pass(stack);
		return new InteractionResultHolder<>(snap(level, player), stack);
	}

	private InteractionResult snap(Level level, Player player) {
		player.getCooldowns().addCooldown(this, 40);
		if (level.isClientSide)
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.client.PhotoClientCapture.begin());
		return InteractionResult.sidedSuccess(level.isClientSide);
	}
}
