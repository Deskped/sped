package deskped.sped.item;

import net.minecraft.world.item.Item;

public class SundialItem extends Item {
	public SundialItem() {
		super(new Item.Properties());
	}
}