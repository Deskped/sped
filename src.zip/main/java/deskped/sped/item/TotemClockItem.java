package deskped.sped.item;

import net.minecraft.world.item.Item;

public class TotemClockItem extends Item {
	public TotemClockItem() {
		super(new Item.Properties());
	}
}