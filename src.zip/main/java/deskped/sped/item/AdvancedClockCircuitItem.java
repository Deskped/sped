package deskped.sped.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import javax.annotation.Nullable;
import java.util.List;

public class AdvancedClockCircuitItem extends Item {

	public static final String TAG = "sped_tetris";

	public AdvancedClockCircuitItem() {
		super(new Item.Properties());
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (level.isClientSide) {
			boolean main = hand == InteractionHand.MAIN_HAND;
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.item.client.TetrisScreen.open(main));
		}
		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
		int best = stack.getTag() != null ? stack.getTag().getCompound(TAG).getInt("Best") : 0;
		tooltip.add(Component.literal("\u0420\u0435\u043a\u043e\u0440\u0434: " + best));
	}
}
