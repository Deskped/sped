package deskped.sped.item;

import net.minecraft.world.item.Item;

public class OkClockItem extends Item {
	public OkClockItem() {
		super(new Item.Properties());
	}
}