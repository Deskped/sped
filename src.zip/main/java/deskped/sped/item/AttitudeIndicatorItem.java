package deskped.sped.item;

import net.minecraft.world.item.Item;

public class AttitudeIndicatorItem extends Item {
	public AttitudeIndicatorItem() {
		super(new Item.Properties());
	}
}