package deskped.sped.item;

import net.minecraft.world.item.Item;

public class WallClockItem extends Item {
	public WallClockItem() {
		super(new Item.Properties());
	}
}