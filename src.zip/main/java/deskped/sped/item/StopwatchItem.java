package deskped.sped.item;

import net.minecraft.world.item.Item;

public class StopwatchItem extends Item {
	public StopwatchItem() {
		super(new Item.Properties());
	}
}