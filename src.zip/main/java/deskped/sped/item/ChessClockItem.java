package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ChessClockItem extends Item {
	public ChessClockItem() {
		super(new Item.Properties());
	}
}