package deskped.sped.item;

import net.minecraft.world.item.Item;

public class RadioItem extends Item {
	public RadioItem() {
		super(new Item.Properties());
	}
}