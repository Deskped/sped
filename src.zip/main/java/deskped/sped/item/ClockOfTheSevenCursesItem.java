package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ClockOfTheSevenCursesItem extends Item {
	public ClockOfTheSevenCursesItem() {
		super(new Item.Properties());
	}
}