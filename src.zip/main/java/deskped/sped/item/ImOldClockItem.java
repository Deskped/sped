package deskped.sped.item;

import net.minecraft.world.item.Item;

public class ImOldClockItem extends Item {
	public ImOldClockItem() {
		super(new Item.Properties());
	}
}