package deskped.sped.item;

import net.minecraft.world.item.Item;

public class WristwatchItem extends Item {
	public WristwatchItem() {
		super(new Item.Properties());
	}
}