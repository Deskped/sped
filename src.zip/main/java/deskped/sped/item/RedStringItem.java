package deskped.sped.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.network.chat.Component;

import java.util.List;

import deskped.sped.block.BoltBlock;
import deskped.sped.redstring.StringManager;

public class RedStringItem extends Item {
	public RedStringItem() {
		super(new Item.Properties());
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		BlockState state = level.getBlockState(context.getClickedPos());
		if (!(state.getBlock() instanceof BoltBlock)) {
			return InteractionResult.PASS;
		}
		if (!level.isClientSide && level instanceof ServerLevel serverLevel && context.getPlayer() instanceof ServerPlayer serverPlayer) {
			StringManager.tryConnect(serverPlayer, serverLevel, context.getClickedPos());
		}
		return InteractionResult.sidedSuccess(level.isClientSide);
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.sped.red_string.description_0"));
		list.add(Component.translatable("item.sped.red_string.description_1"));
		list.add(Component.translatable("item.sped.red_string.description_2"));
		list.add(Component.translatable("item.sped.red_string.description_3"));
		list.add(Component.translatable("item.sped.red_string.description_4"));
		list.add(Component.translatable("item.sped.red_string.description_5"));
	}
}
