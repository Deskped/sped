package deskped.sped.item;

import net.minecraft.world.item.Item;

public class AlarmClockItem extends Item {
	public AlarmClockItem() {
		super(new Item.Properties());
	}
}