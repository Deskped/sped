package deskped.sped.item;

import net.minecraft.world.item.Item;

public class FallenClockItem extends Item {
	public FallenClockItem() {
		super(new Item.Properties());
	}
}