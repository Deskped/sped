package deskped.sped.item;

import net.minecraft.world.item.Item;

public class MechanicalCraneScalesItem extends Item {
	public MechanicalCraneScalesItem() {
		super(new Item.Properties());
	}
}