package deskped.sped.music;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Collection;
import java.util.Locale;

@Mod.EventBusSubscriber(modid = "sped")
public class MusicCommands {

	@SubscribeEvent
	public static void register(RegisterCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("sped")
				.then(Commands.literal("playsound")
						.requires(src -> src.hasPermission(2))
						.then(Commands.argument("targets", EntityArgument.players())
								.then(Commands.argument("file", StringArgumentType.greedyString())
										.suggests((ctx, builder) -> SharedSuggestionProvider.suggest(MusicServer.fileNames(ctx.getSource().getServer()), builder))
										.executes(ctx -> play(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), StringArgumentType.getString(ctx, "file"))))))
				.then(Commands.literal("stopsound")
						.requires(src -> src.hasPermission(2))
						.then(Commands.argument("targets", EntityArgument.players())
								.executes(ctx -> stop(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"))))));
	}

	private static int play(CommandSourceStack src, Collection<ServerPlayer> targets, String file) {
		boolean ru = isRu(src);
		String[] track = MusicServer.resolve(src.getServer(), file.trim());
		if (track == null) {
			src.sendFailure(Component.literal(ru ? "\u0424\u0430\u0439\u043B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D" : "File not found"));
			return 0;
		}
		for (ServerPlayer p : targets)
			MusicNet.sendTo(p, new MusicNet.PlayS2C(false, BlockPos.ZERO, track[0], track[1]));
		int count = targets.size();
		src.sendSuccess(() -> Component.literal((ru ? "\u0412\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0443\u0449\u0435\u043D\u043E: " : "Playback started: ") + count), true);
		return count;
	}

	private static int stop(CommandSourceStack src, Collection<ServerPlayer> targets) {
		boolean ru = isRu(src);
		for (ServerPlayer p : targets)
			MusicNet.sendTo(p, new MusicNet.StopS2C(true, BlockPos.ZERO));
		int count = targets.size();
		src.sendSuccess(() -> Component.literal((ru ? "\u0412\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E: " : "Playback stopped: ") + count), true);
		return count;
	}

	private static boolean isRu(CommandSourceStack src) {
		return src.getEntity() instanceof ServerPlayer sp && sp.getLanguage() != null && sp.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
	}
}
