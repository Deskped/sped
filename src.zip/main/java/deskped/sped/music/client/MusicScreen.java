package deskped.sped.music.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import deskped.sped.music.MusicNet;
import deskped.sped.voice.client.ui.Ui;

@OnlyIn(Dist.CLIENT)
public class MusicScreen extends Screen {

	private final BlockPos pos;
	private final String trackName;
	private final boolean playing;

	public MusicScreen(BlockPos pos, String trackName, boolean playing) {
		super(Component.literal("\u041C\u0443\u0437\u044B\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0431\u043B\u043E\u043A"));
		this.pos = pos;
		this.trackName = trackName == null ? "" : trackName;
		this.playing = playing;
	}

	@Override
	protected void init() {
		int x = width / 2 - 100;
		int y = height / 2 - 10;
		addRenderableWidget(Button.builder(Component.literal("\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0444\u0430\u0439\u043B (.ogg / .wav)"), b -> pick()).bounds(x, y, 200, 20).build());
		addRenderableWidget(Button.builder(Component.literal("\u041F\u0440\u043E\u0438\u0433\u0440\u0430\u0442\u044C"), b -> send(true)).bounds(x, y + 24, 98, 20).build());
		addRenderableWidget(Button.builder(Component.literal("\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C"), b -> send(false)).bounds(x + 102, y + 24, 98, 20).build());
		addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(x, height - 28, 200, 20).build());
	}

	private void pick() {
		onClose();
		MusicClient.pickAndUpload(pos);
	}

	private void send(boolean play) {
		MusicNet.sendToServer(new MusicNet.BlockActionC2S(pos, play));
		onClose();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
		String name = trackName.isEmpty() ? "\u043D\u0435\u0442" : trackName;
		if (name.length() > 40)
			name = name.substring(0, 40) + "...";
		g.drawCenteredString(font, "\u0424\u0430\u0439\u043B: " + name, width / 2, height / 2 - 46, trackName.isEmpty() ? Ui.DIM : Ui.TEXT);
		String status = playing
				? "\u0421\u0435\u0439\u0447\u0430\u0441 \u0438\u0433\u0440\u0430\u0435\u0442"
				: "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E";
		g.drawCenteredString(font, status, width / 2, height / 2 - 32, playing ? Ui.GREEN : Ui.DIM);
		super.render(g, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
