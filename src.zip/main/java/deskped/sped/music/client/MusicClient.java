package deskped.sped.music.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.openal.AL10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import deskped.sped.SpedMod;
import deskped.sped.block.entity.MusicBlockBlockEntity;
import deskped.sped.music.MusicNet;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT)
public class MusicClient {

	private static final int UPLOAD_CHUNKS_PER_TICK = 4;

	private static final Map<BlockPos, MusicStream> blockStreams = new HashMap<>();
	private static MusicStream globalStream;
	private static Object lastLevel;

	private static final Map<String, byte[]> memCache = new LinkedHashMap<>(16, 0.75f, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
			return size() > 6;
		}
	};
	private static final Map<String, Download> downloads = new HashMap<>();
	private static final Map<String, List<MusicNet.PlayS2C>> pending = new HashMap<>();
	private static final Set<String> requested = new HashSet<>();
	private static ClientUpload upload;
	private static boolean picking;

	public static void openScreen(BlockPos pos) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null)
			return;
		BlockEntity be = mc.level.getBlockEntity(pos);
		if (be instanceof MusicBlockBlockEntity music)
			mc.setScreen(new MusicScreen(pos, music.getTrackName(), music.isPlaying()));
	}

	public static void onPlay(MusicNet.PlayS2C msg) {
		byte[] data = cached(msg.hash);
		if (data != null) {
			startPlayback(msg, data);
			return;
		}
		pending.computeIfAbsent(msg.hash, k -> new ArrayList<>()).add(msg);
		if (requested.add(msg.hash))
			MusicNet.sendToServer(new MusicNet.RequestC2S(msg.hash));
	}

	public static void onStop(MusicNet.StopS2C msg) {
		if (msg.all)
			stopAll();
		else
			stopBlock(msg.pos);
	}

	public static void onUploadAck(MusicNet.UploadAckS2C msg) {
		if (!msg.message.isEmpty())
			message(msg.message);
		if (msg.done)
			upload = null;
		else if (msg.needUpload && upload != null)
			upload.active = true;
	}

	public static void onDataStart(MusicNet.DataStartS2C msg) {
		if (msg.size <= 0 || msg.size > MusicNet.MAX_SIZE) {
			requested.remove(msg.hash);
			pending.remove(msg.hash);
			return;
		}
		downloads.put(msg.hash, new Download(msg.size));
	}

	public static void onDataChunk(MusicNet.DataChunkS2C msg) {
		Download d = downloads.get(msg.hash);
		if (d == null)
			return;
		d.buf.write(msg.data, 0, msg.data.length);
		if (d.buf.size() < d.size)
			return;
		downloads.remove(msg.hash);
		requested.remove(msg.hash);
		byte[] data = d.buf.toByteArray();
		if (data.length == d.size && MusicNet.sha1Hex(data).equals(msg.hash)) {
			memCache.put(msg.hash, data);
			diskWrite(msg.hash, data);
			List<MusicNet.PlayS2C> list = pending.remove(msg.hash);
			if (list != null) {
				for (MusicNet.PlayS2C p : list)
					startPlayback(p, data);
			}
		} else {
			pending.remove(msg.hash);
		}
	}

	private static byte[] cached(String hash) {
		byte[] data = memCache.get(hash);
		if (data != null)
			return data;
		try {
			Path path = cacheDir().resolve(hash);
			if (Files.isRegularFile(path) && Files.size(path) <= MusicNet.MAX_SIZE) {
				data = Files.readAllBytes(path);
				memCache.put(hash, data);
				return data;
			}
		} catch (Exception ignored) {
		}
		return null;
	}

	private static Path cacheDir() {
		return Minecraft.getInstance().gameDirectory.toPath().resolve("sped_music_cache");
	}

	private static void diskWrite(String hash, byte[] data) {
		try {
			Files.createDirectories(cacheDir());
			Files.write(cacheDir().resolve(hash), data);
		} catch (Exception ignored) {
		}
	}

	private static void startPlayback(MusicNet.PlayS2C msg, byte[] data) {
		MusicStream stream;
		if (msg.block) {
			stopBlock(msg.pos);
			stream = new MusicStream(msg.pos.immutable());
			blockStreams.put(msg.pos.immutable(), stream);
		} else {
			stopGlobal();
			stream = new MusicStream(null);
			globalStream = stream;
		}
		String name = msg.name;
		Thread thread = new Thread(() -> {
			Decoded decoded = decode(data);
			Minecraft.getInstance().execute(() -> {
				if (stream.closed)
					return;
				if (decoded == null) {
					message("\u041E\u0448\u0438\u0431\u043A\u0430 \u0434\u0435\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F");
					removeStream(stream);
				} else {
					stream.start(decoded);
					if (!name.isEmpty())
						message("\u25B6 " + name);
				}
			});
		}, "sped-music-decode");
		thread.setDaemon(true);
		thread.start();
	}

	private static void removeStream(MusicStream stream) {
		stream.close();
		if (stream.pos != null)
			blockStreams.remove(stream.pos, stream);
		else if (globalStream == stream)
			globalStream = null;
	}

	private static void stopBlock(BlockPos pos) {
		MusicStream s = blockStreams.remove(pos);
		if (s != null)
			s.close();
	}

	private static void stopGlobal() {
		if (globalStream != null) {
			globalStream.close();
			globalStream = null;
		}
	}

	public static void stopAll() {
		for (MusicStream s : blockStreams.values())
			s.close();
		blockStreams.clear();
		stopGlobal();
	}

	public static void pickAndUpload(BlockPos pos) {
		if (picking)
			return;
		picking = true;
		Thread thread = new Thread(() -> {
			String path = null;
			try (MemoryStack stack = MemoryStack.stackPush()) {
				PointerBuffer filters = stack.mallocPointer(2);
				filters.put(stack.UTF8("*.ogg"));
				filters.put(stack.UTF8("*.wav"));
				filters.flip();
				path = TinyFileDialogs.tinyfd_openFileDialog("OGG/WAV", null, filters, "OGG/WAV", false);
			} catch (Throwable ignored) {
			}
			byte[] raw = null;
			String fileName = null;
			if (path != null) {
				int i = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
				fileName = i >= 0 ? path.substring(i + 1) : path;
				try {
					raw = Files.readAllBytes(Path.of(path));
				} catch (Exception ignored) {
				}
			}
			byte[] finalRaw = raw;
			String finalName = fileName;
			boolean chosen = path != null;
			Minecraft.getInstance().execute(() -> {
				picking = false;
				if (chosen)
					accept(pos, finalName, finalRaw);
			});
		}, "sped-music-pick");
		thread.setDaemon(true);
		thread.start();
	}

	private static void accept(BlockPos pos, String name, byte[] data) {
		if (data == null || data.length == 0) {
			message("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0444\u0430\u0439\u043B");
			return;
		}
		if (!MusicNet.validExt(name)) {
			message("\u0422\u043E\u043B\u044C\u043A\u043E .ogg \u0438 .wav");
			return;
		}
		if (data.length > MusicNet.MAX_SIZE) {
			message("\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 (\u043C\u0430\u043A\u0441 16 \u041C\u0411)");
			return;
		}
		String hash = MusicNet.sha1Hex(data);
		if (hash.isEmpty()) {
			message("\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438");
			return;
		}
		String trimmed = name.length() > 48 ? name.substring(0, 48) : name;
		memCache.put(hash, data);
		diskWrite(hash, data);
		upload = new ClientUpload(trimmed, data, hash);
		MusicNet.sendToServer(new MusicNet.UploadBeginC2S(pos, trimmed, data.length, hash));
		message("\u0424\u0430\u0439\u043B \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F");
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.level != lastLevel) {
			lastLevel = mc.level;
			for (MusicStream s : blockStreams.values())
				s.close();
			blockStreams.clear();
			if (mc.level == null)
				stopGlobal();
		}
		if (upload != null && upload.active) {
			for (int i = 0; i < UPLOAD_CHUNKS_PER_TICK && upload != null && upload.offset < upload.data.length; i++) {
				int end = Math.min(upload.offset + MusicNet.CHUNK, upload.data.length);
				MusicNet.sendToServer(new MusicNet.UploadChunkC2S(Arrays.copyOfRange(upload.data, upload.offset, end)));
				upload.offset = end;
			}
		}
		Iterator<Map.Entry<BlockPos, MusicStream>> it = blockStreams.entrySet().iterator();
		while (it.hasNext()) {
			MusicStream s = it.next().getValue();
			s.tick();
			if (s.finished()) {
				s.close();
				it.remove();
			}
		}
		if (globalStream != null) {
			globalStream.tick();
			if (globalStream.finished()) {
				globalStream.close();
				globalStream = null;
			}
		}
	}

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		stopAll();
		downloads.clear();
		pending.clear();
		requested.clear();
		upload = null;
	}

	private static Decoded decode(byte[] data) {
		if (data.length > 4 && data[0] == 'O' && data[1] == 'g' && data[2] == 'g' && data[3] == 'S')
			return decodeOgg(data);
		if (data.length > 4 && data[0] == 'R' && data[1] == 'I' && data[2] == 'F' && data[3] == 'F')
			return decodeWav(data);
		return null;
	}

	private static Decoded decodeOgg(byte[] data) {
		ByteBuffer mem = MemoryUtil.memAlloc(data.length);
		long decoder = 0L;
		try {
			mem.put(data).flip();
			try (MemoryStack stack = MemoryStack.stackPush()) {
				IntBuffer err = stack.mallocInt(1);
				decoder = STBVorbis.stb_vorbis_open_memory(mem, err, null);
				if (decoder == 0L)
					return null;
				STBVorbisInfo info = STBVorbisInfo.malloc(stack);
				STBVorbis.stb_vorbis_get_info(decoder, info);
				int channels = info.channels();
				int rate = info.sample_rate();
				if (channels < 1 || channels > 2 || rate <= 0)
					return null;
				int frames = STBVorbis.stb_vorbis_stream_length_in_samples(decoder);
				if (frames <= 0 || (long) frames * channels * 2L > 200000000L)
					return null;
				ByteBuffer out = BufferUtils.createByteBuffer(frames * channels * 2);
				ShortBuffer pcm = out.asShortBuffer();
				int decodedFrames = STBVorbis.stb_vorbis_get_samples_short_interleaved(decoder, channels, pcm);
				if (decodedFrames <= 0)
					return null;
				out.limit(decodedFrames * channels * 2);
				return new Decoded(out, channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, rate);
			}
		} catch (Throwable t) {
			return null;
		} finally {
			if (decoder != 0L)
				STBVorbis.stb_vorbis_close(decoder);
			MemoryUtil.memFree(mem);
		}
	}

	private static Decoded decodeWav(byte[] data) {
		try (AudioInputStream in = AudioSystem.getAudioInputStream(new BufferedInputStream(new ByteArrayInputStream(data)))) {
			AudioFormat base = in.getFormat();
			int channels = base.getChannels();
			float rate = base.getSampleRate();
			if (channels < 1 || channels > 2 || rate <= 0)
				return null;
			AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, rate, 16, channels, channels * 2, rate, false);
			try (AudioInputStream conv = AudioSystem.getAudioInputStream(target, in)) {
				byte[] pcm = conv.readAllBytes();
				if (pcm.length == 0)
					return null;
				ByteBuffer out = BufferUtils.createByteBuffer(pcm.length);
				out.put(pcm).flip();
				return new Decoded(out, channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, (int) rate);
			}
		} catch (Throwable t) {
			return null;
		}
	}

	private static float baseVolume() {
		Minecraft mc = Minecraft.getInstance();
		return mc.options.getSoundSourceVolume(SoundSource.MASTER) * mc.options.getSoundSourceVolume(SoundSource.RECORDS);
	}

	private static void message(String text) {
		Minecraft mc = Minecraft.getInstance();
		mc.execute(() -> {
			if (mc.player != null)
				mc.player.displayClientMessage(Component.literal(text), true);
		});
	}

	private static class Download {
		final int size;
		final ByteArrayOutputStream buf = new ByteArrayOutputStream();

		Download(int size) {
			this.size = size;
		}
	}

	private static class ClientUpload {
		final String name;
		final byte[] data;
		final String hash;
		int offset;
		boolean active;

		ClientUpload(String name, byte[] data, String hash) {
			this.name = name;
			this.data = data;
			this.hash = hash;
		}
	}

	private static class Decoded {
		final ByteBuffer pcm;
		final int format;
		final int rate;

		Decoded(ByteBuffer pcm, int format, int rate) {
			this.pcm = pcm;
			this.format = format;
			this.rate = rate;
		}
	}

	@OnlyIn(Dist.CLIENT)
	private static class MusicStream {

		private final BlockPos pos;
		private int source = -1;
		private int buffer = -1;
		private boolean started;
		private boolean closed;

		MusicStream(BlockPos pos) {
			this.pos = pos;
		}

		void start(Decoded decoded) {
			int src = AL10.alGenSources();
			if (AL10.alGetError() != AL10.AL_NO_ERROR)
				return;
			source = src;
			buffer = AL10.alGenBuffers();
			AL10.alBufferData(buffer, decoded.format, decoded.pcm, decoded.rate);
			AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
			AL10.alSourcef(source, AL10.AL_ROLLOFF_FACTOR, 0.0f);
			AL10.alSourcef(source, AL10.AL_PITCH, 1.0f);
			if (pos == null) {
				AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
				AL10.alSource3f(source, AL10.AL_POSITION, 0.0f, 0.0f, 0.0f);
			} else {
				AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
				AL10.alSource3f(source, AL10.AL_POSITION, pos.getX() + 0.5f, pos.getY() + 0.5f, pos.getZ() + 0.5f);
			}
			applyGain();
			AL10.alSourcePlay(source);
			started = true;
			AL10.alGetError();
		}

		void tick() {
			if (closed || !started)
				return;
			applyGain();
			AL10.alGetError();
		}

		private void applyGain() {
			float gain = baseVolume();
			if (pos != null) {
				Vec3 cam;
				try {
					cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
				} catch (Exception e) {
					cam = Vec3.ZERO;
				}
				float dx = (float) (cam.x - (pos.getX() + 0.5d));
				float dy = (float) (cam.y - (pos.getY() + 0.5d));
				float dz = (float) (cam.z - (pos.getZ() + 0.5d));
				float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
				float fall = 1.0f - d / MusicNet.BLOCK_RANGE;
				if (fall < 0.0f)
					fall = 0.0f;
				gain *= fall;
			}
			if (gain > 2.0f)
				gain = 2.0f;
			AL10.alSourcef(source, AL10.AL_GAIN, gain);
		}

		boolean finished() {
			if (closed)
				return true;
			if (!started)
				return false;
			return AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) != AL10.AL_PLAYING;
		}

		void close() {
			if (closed)
				return;
			closed = true;
			try {
				if (source != -1) {
					AL10.alSourceStop(source);
					AL10.alSourcei(source, AL10.AL_BUFFER, 0);
					AL10.alDeleteSources(source);
				}
				if (buffer != -1)
					AL10.alDeleteBuffers(buffer);
				AL10.alGetError();
			} catch (Exception ignored) {
			}
			source = -1;
			buffer = -1;
		}
	}
}
