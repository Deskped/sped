package deskped.sped.music;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.storage.LevelResource;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

import deskped.sped.SpedMod;
import deskped.sped.block.entity.MusicBlockBlockEntity;

@Mod.EventBusSubscriber(modid = SpedMod.MODID)
public class MusicServer {

	private static final int CHUNKS_PER_TICK = 4;

	private static final Map<UUID, Upload> uploads = new HashMap<>();
	private static final Map<UUID, ArrayDeque<Object>> outbox = new HashMap<>();
	private static final Map<String, Path> hashIndex = new HashMap<>();
	private static final Map<String, byte[]> fileCache = new LinkedHashMap<>(8, 0.75f, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
			return size() > 4;
		}
	};

	private static Path dir(MinecraftServer server) {
		Path dir = server.getWorldPath(LevelResource.ROOT).resolve("sped_music");
		try {
			Files.createDirectories(dir);
		} catch (Exception ignored) {
		}
		return dir;
	}

	private static void scan(MinecraftServer server) {
		hashIndex.clear();
		try (Stream<Path> files = Files.list(dir(server))) {
			files.forEach(path -> {
				if (!Files.isRegularFile(path))
					return;
				String name = path.getFileName().toString();
				if (!MusicNet.validExt(name))
					return;
				String base = name.substring(0, name.length() - 4).toLowerCase(Locale.ROOT);
				if (MusicNet.validHash(base)) {
					hashIndex.put(base, path);
				} else {
					try {
						byte[] data = Files.readAllBytes(path);
						if (data.length > 0 && data.length <= MusicNet.MAX_SIZE)
							hashIndex.put(MusicNet.sha1Hex(data), path);
					} catch (Exception ignored) {
					}
				}
			});
		} catch (Exception ignored) {
		}
	}

	private static byte[] load(MinecraftServer server, String hash) {
		byte[] cached = fileCache.get(hash);
		if (cached != null)
			return cached;
		Path path = hashIndex.get(hash);
		if (path == null || !Files.exists(path)) {
			scan(server);
			path = hashIndex.get(hash);
		}
		if (path == null)
			return null;
		try {
			byte[] data = Files.readAllBytes(path);
			if (data.length == 0 || data.length > MusicNet.MAX_SIZE)
				return null;
			fileCache.put(hash, data);
			return data;
		} catch (Exception e) {
			return null;
		}
	}

	public static List<String> fileNames(MinecraftServer server) {
		List<String> names = new ArrayList<>();
		try (Stream<Path> files = Files.list(dir(server))) {
			files.forEach(path -> {
				String name = path.getFileName().toString();
				if (Files.isRegularFile(path) && MusicNet.validExt(name))
					names.add(name);
			});
		} catch (Exception ignored) {
		}
		return names;
	}

	public static String[] resolve(MinecraftServer server, String arg) {
		if (arg == null || arg.isEmpty() || arg.contains("/") || arg.contains("\\") || arg.contains(".."))
			return null;
		Path path = dir(server).resolve(arg);
		if (Files.isRegularFile(path) && MusicNet.validExt(arg)) {
			String base = arg.substring(0, arg.length() - 4).toLowerCase(Locale.ROOT);
			String hash;
			if (MusicNet.validHash(base)) {
				hash = base;
				hashIndex.put(hash, path);
			} else {
				try {
					byte[] data = Files.readAllBytes(path);
					if (data.length == 0 || data.length > MusicNet.MAX_SIZE)
						return null;
					hash = MusicNet.sha1Hex(data);
					hashIndex.put(hash, path);
					fileCache.put(hash, data);
				} catch (Exception e) {
					return null;
				}
			}
			return new String[] { hash, trim(arg) };
		}
		String low = arg.toLowerCase(Locale.ROOT);
		if (MusicNet.validHash(low) && load(server, low) != null)
			return new String[] { low, low.substring(0, 8) };
		return null;
	}

	public static void handleAction(ServerPlayer sender, MusicNet.BlockActionC2S msg) {
		ServerLevel level = sender.serverLevel();
		if (!level.isLoaded(msg.pos))
			return;
		if (sender.distanceToSqr(msg.pos.getX() + 0.5d, msg.pos.getY() + 0.5d, msg.pos.getZ() + 0.5d) > 64.0d)
			return;
		BlockEntity be = level.getBlockEntity(msg.pos);
		if (!(be instanceof MusicBlockBlockEntity music))
			return;
		if (msg.play) {
			String hash = music.getTrackHash();
			if (hash.isEmpty()) {
				sender.displayClientMessage(Component.literal("\u0422\u0440\u0435\u043A \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D"), true);
				return;
			}
			if (load(sender.server, hash) == null) {
				sender.displayClientMessage(Component.literal("\u0424\u0430\u0439\u043B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D"), true);
				return;
			}
			music.update(hash, music.getTrackName(), true);
			MusicNet.broadcastNear(level, msg.pos, new MusicNet.PlayS2C(true, msg.pos, hash, music.getTrackName()));
		} else {
			music.update(music.getTrackHash(), music.getTrackName(), false);
			MusicNet.broadcastStopBlock(level, msg.pos);
		}
	}

	public static void handleBegin(ServerPlayer sender, MusicNet.UploadBeginC2S msg) {
		ServerLevel level = sender.serverLevel();
		if (!level.isLoaded(msg.pos))
			return;
		if (sender.distanceToSqr(msg.pos.getX() + 0.5d, msg.pos.getY() + 0.5d, msg.pos.getZ() + 0.5d) > 64.0d)
			return;
		if (!(level.getBlockEntity(msg.pos) instanceof MusicBlockBlockEntity))
			return;
		if (msg.size <= 0 || msg.size > MusicNet.MAX_SIZE) {
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u0424\u0430\u0439\u043B \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439"));
			return;
		}
		if (!MusicNet.validHash(msg.hash) || !MusicNet.validExt(msg.name)) {
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438"));
			return;
		}
		String name = trim(msg.name);
		if (load(sender.server, msg.hash) != null) {
			bind(level, msg.pos, msg.hash, name);
			uploads.remove(sender.getUUID());
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u0422\u0440\u0435\u043A \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D: " + name));
			return;
		}
		uploads.put(sender.getUUID(), new Upload(level, msg.pos, name, msg.size, msg.hash));
		MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(true, false, ""));
	}

	public static void handleChunk(ServerPlayer sender, MusicNet.UploadChunkC2S msg) {
		Upload u = uploads.get(sender.getUUID());
		if (u == null)
			return;
		u.buf.write(msg.data, 0, msg.data.length);
		if (u.buf.size() > u.size) {
			uploads.remove(sender.getUUID());
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438"));
			return;
		}
		if (u.buf.size() < u.size)
			return;
		uploads.remove(sender.getUUID());
		byte[] data = u.buf.toByteArray();
		if (!MusicNet.sha1Hex(data).equals(u.hash)) {
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438"));
			return;
		}
		String ext = u.name.toLowerCase(Locale.ROOT).endsWith(".wav") ? ".wav" : ".ogg";
		Path path = dir(sender.server).resolve(u.hash + ext);
		try {
			Files.write(path, data);
		} catch (Exception e) {
			MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438"));
			return;
		}
		hashIndex.put(u.hash, path);
		fileCache.put(u.hash, data);
		bind(u.level, u.pos, u.hash, u.name);
		MusicNet.sendTo(sender, new MusicNet.UploadAckS2C(false, true, "\u0422\u0440\u0435\u043A \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D: " + u.name));
	}

	public static void handleRequest(ServerPlayer sender, String hash) {
		if (!MusicNet.validHash(hash))
			return;
		byte[] data = load(sender.server, hash);
		if (data == null)
			return;
		ArrayDeque<Object> queue = outbox.computeIfAbsent(sender.getUUID(), k -> new ArrayDeque<>());
		queue.add(new MusicNet.DataStartS2C(hash, data.length));
		int offset = 0;
		while (offset < data.length) {
			int end = Math.min(offset + MusicNet.CHUNK, data.length);
			byte[] chunk = new byte[end - offset];
			System.arraycopy(data, offset, chunk, 0, chunk.length);
			queue.add(new MusicNet.DataChunkS2C(hash, chunk));
			offset = end;
		}
	}

	private static void bind(ServerLevel level, BlockPos pos, String hash, String name) {
		if (level == null || !level.isLoaded(pos))
			return;
		if (level.getBlockEntity(pos) instanceof MusicBlockBlockEntity music)
			music.update(hash, name, music.isPlaying());
	}

	private static String trim(String name) {
		return name.length() > 48 ? name.substring(0, 48) : name;
	}

	@SubscribeEvent
	public static void onServerTick(TickEvent.ServerTickEvent event) {
		if (event.phase != TickEvent.Phase.END || outbox.isEmpty())
			return;
		MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
		if (server == null)
			return;
		Iterator<Map.Entry<UUID, ArrayDeque<Object>>> it = outbox.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, ArrayDeque<Object>> entry = it.next();
			ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
			if (player == null) {
				it.remove();
				continue;
			}
			ArrayDeque<Object> queue = entry.getValue();
			for (int i = 0; i < CHUNKS_PER_TICK && !queue.isEmpty(); i++)
				MusicNet.sendTo(player, queue.poll());
			if (queue.isEmpty())
				it.remove();
		}
	}

	@SubscribeEvent
	public static void onLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
		uploads.remove(event.getEntity().getUUID());
		outbox.remove(event.getEntity().getUUID());
	}

	private static class Upload {
		final ServerLevel level;
		final BlockPos pos;
		final String name;
		final int size;
		final String hash;
		final ByteArrayOutputStream buf = new ByteArrayOutputStream();

		Upload(ServerLevel level, BlockPos pos, String name, int size, String hash) {
			this.level = level;
			this.pos = pos;
			this.name = name;
			this.size = size;
			this.hash = hash;
		}
	}
}
