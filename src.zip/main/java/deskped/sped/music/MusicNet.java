package deskped.sped.music;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.security.MessageDigest;
import java.util.Locale;
import java.util.function.Supplier;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class MusicNet {

	public static final float BLOCK_RANGE = 48.0f;
	public static final double BROADCAST_RANGE = 64.0d;
	public static final int MAX_SIZE = 16 * 1024 * 1024;
	public static final int CHUNK = 28000;

	private static final String VERSION = "2";
	public static SimpleChannel CHANNEL;

	@SubscribeEvent
	public static void onCommonSetup(FMLCommonSetupEvent event) {
		if (CHANNEL != null)
			return;
		CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SpedMod.MODID, "music"), () -> VERSION, VERSION::equals, VERSION::equals);
		int id = 0;
		CHANNEL.registerMessage(id++, BlockActionC2S.class, BlockActionC2S::encode, BlockActionC2S::decode, BlockActionC2S::handle);
		CHANNEL.registerMessage(id++, UploadBeginC2S.class, UploadBeginC2S::encode, UploadBeginC2S::decode, UploadBeginC2S::handle);
		CHANNEL.registerMessage(id++, UploadChunkC2S.class, UploadChunkC2S::encode, UploadChunkC2S::decode, UploadChunkC2S::handle);
		CHANNEL.registerMessage(id++, RequestC2S.class, RequestC2S::encode, RequestC2S::decode, RequestC2S::handle);
		CHANNEL.registerMessage(id++, UploadAckS2C.class, UploadAckS2C::encode, UploadAckS2C::decode, UploadAckS2C::handle);
		CHANNEL.registerMessage(id++, DataStartS2C.class, DataStartS2C::encode, DataStartS2C::decode, DataStartS2C::handle);
		CHANNEL.registerMessage(id++, DataChunkS2C.class, DataChunkS2C::encode, DataChunkS2C::decode, DataChunkS2C::handle);
		CHANNEL.registerMessage(id++, PlayS2C.class, PlayS2C::encode, PlayS2C::decode, PlayS2C::handle);
		CHANNEL.registerMessage(id++, StopS2C.class, StopS2C::encode, StopS2C::decode, StopS2C::handle);
	}

	public static void sendToServer(Object msg) {
		if (CHANNEL != null)
			CHANNEL.sendToServer(msg);
	}

	public static void sendTo(ServerPlayer player, Object msg) {
		if (CHANNEL != null)
			CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
	}

	public static void broadcastNear(ServerLevel level, BlockPos pos, Object msg) {
		double cx = pos.getX() + 0.5d;
		double cy = pos.getY() + 0.5d;
		double cz = pos.getZ() + 0.5d;
		for (ServerPlayer p : level.players()) {
			if (p.distanceToSqr(cx, cy, cz) <= BROADCAST_RANGE * BROADCAST_RANGE)
				sendTo(p, msg);
		}
	}

	public static void broadcastStopBlock(ServerLevel level, BlockPos pos) {
		broadcastNear(level, pos, new StopS2C(false, pos));
	}

	public static boolean validHash(String hash) {
		if (hash == null || hash.length() != 40)
			return false;
		for (int i = 0; i < hash.length(); i++) {
			char c = hash.charAt(i);
			if ((c < '0' || c > '9') && (c < 'a' || c > 'f'))
				return false;
		}
		return true;
	}

	public static boolean validExt(String name) {
		if (name == null)
			return false;
		String low = name.toLowerCase(Locale.ROOT);
		return low.endsWith(".ogg") || low.endsWith(".wav");
	}

	public static String sha1Hex(byte[] data) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			byte[] digest = md.digest(data);
			StringBuilder sb = new StringBuilder(digest.length * 2);
			for (byte b : digest) {
				sb.append(Character.forDigit((b >> 4) & 0xF, 16));
				sb.append(Character.forDigit(b & 0xF, 16));
			}
			return sb.toString();
		} catch (Exception e) {
			return "";
		}
	}

	public static class BlockActionC2S {
		public final BlockPos pos;
		public final boolean play;

		public BlockActionC2S(BlockPos pos, boolean play) {
			this.pos = pos;
			this.play = play;
		}

		public static void encode(BlockActionC2S msg, FriendlyByteBuf buf) {
			buf.writeBlockPos(msg.pos);
			buf.writeBoolean(msg.play);
		}

		public static BlockActionC2S decode(FriendlyByteBuf buf) {
			return new BlockActionC2S(buf.readBlockPos(), buf.readBoolean());
		}

		public static void handle(BlockActionC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					MusicServer.handleAction(sender, msg);
			});
			c.setPacketHandled(true);
		}
	}

	public static class UploadBeginC2S {
		public final BlockPos pos;
		public final String name;
		public final int size;
		public final String hash;

		public UploadBeginC2S(BlockPos pos, String name, int size, String hash) {
			this.pos = pos;
			this.name = name;
			this.size = size;
			this.hash = hash;
		}

		public static void encode(UploadBeginC2S msg, FriendlyByteBuf buf) {
			buf.writeBlockPos(msg.pos);
			buf.writeUtf(msg.name, 64);
			buf.writeInt(msg.size);
			buf.writeUtf(msg.hash, 64);
		}

		public static UploadBeginC2S decode(FriendlyByteBuf buf) {
			return new UploadBeginC2S(buf.readBlockPos(), buf.readUtf(64), buf.readInt(), buf.readUtf(64));
		}

		public static void handle(UploadBeginC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					MusicServer.handleBegin(sender, msg);
			});
			c.setPacketHandled(true);
		}
	}

	public static class UploadChunkC2S {
		public final byte[] data;

		public UploadChunkC2S(byte[] data) {
			this.data = data;
		}

		public static void encode(UploadChunkC2S msg, FriendlyByteBuf buf) {
			buf.writeByteArray(msg.data);
		}

		public static UploadChunkC2S decode(FriendlyByteBuf buf) {
			return new UploadChunkC2S(buf.readByteArray(CHUNK + 64));
		}

		public static void handle(UploadChunkC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					MusicServer.handleChunk(sender, msg);
			});
			c.setPacketHandled(true);
		}
	}

	public static class RequestC2S {
		public final String hash;

		public RequestC2S(String hash) {
			this.hash = hash;
		}

		public static void encode(RequestC2S msg, FriendlyByteBuf buf) {
			buf.writeUtf(msg.hash, 64);
		}

		public static RequestC2S decode(FriendlyByteBuf buf) {
			return new RequestC2S(buf.readUtf(64));
		}

		public static void handle(RequestC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					MusicServer.handleRequest(sender, msg.hash);
			});
			c.setPacketHandled(true);
		}
	}

	public static class UploadAckS2C {
		public final boolean needUpload;
		public final boolean done;
		public final String message;

		public UploadAckS2C(boolean needUpload, boolean done, String message) {
			this.needUpload = needUpload;
			this.done = done;
			this.message = message == null ? "" : message;
		}

		public static void encode(UploadAckS2C msg, FriendlyByteBuf buf) {
			buf.writeBoolean(msg.needUpload);
			buf.writeBoolean(msg.done);
			buf.writeUtf(msg.message, 200);
		}

		public static UploadAckS2C decode(FriendlyByteBuf buf) {
			return new UploadAckS2C(buf.readBoolean(), buf.readBoolean(), buf.readUtf(200));
		}

		public static void handle(UploadAckS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.onUploadAck(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class DataStartS2C {
		public final String hash;
		public final int size;

		public DataStartS2C(String hash, int size) {
			this.hash = hash;
			this.size = size;
		}

		public static void encode(DataStartS2C msg, FriendlyByteBuf buf) {
			buf.writeUtf(msg.hash, 64);
			buf.writeInt(msg.size);
		}

		public static DataStartS2C decode(FriendlyByteBuf buf) {
			return new DataStartS2C(buf.readUtf(64), buf.readInt());
		}

		public static void handle(DataStartS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.onDataStart(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class DataChunkS2C {
		public final String hash;
		public final byte[] data;

		public DataChunkS2C(String hash, byte[] data) {
			this.hash = hash;
			this.data = data;
		}

		public static void encode(DataChunkS2C msg, FriendlyByteBuf buf) {
			buf.writeUtf(msg.hash, 64);
			buf.writeByteArray(msg.data);
		}

		public static DataChunkS2C decode(FriendlyByteBuf buf) {
			return new DataChunkS2C(buf.readUtf(64), buf.readByteArray(CHUNK + 64));
		}

		public static void handle(DataChunkS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.onDataChunk(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class PlayS2C {
		public final boolean block;
		public final BlockPos pos;
		public final String hash;
		public final String name;

		public PlayS2C(boolean block, BlockPos pos, String hash, String name) {
			this.block = block;
			this.pos = pos;
			this.hash = hash;
			this.name = name == null ? "" : name;
		}

		public static void encode(PlayS2C msg, FriendlyByteBuf buf) {
			buf.writeBoolean(msg.block);
			buf.writeBlockPos(msg.pos);
			buf.writeUtf(msg.hash, 64);
			buf.writeUtf(msg.name, 64);
		}

		public static PlayS2C decode(FriendlyByteBuf buf) {
			return new PlayS2C(buf.readBoolean(), buf.readBlockPos(), buf.readUtf(64), buf.readUtf(64));
		}

		public static void handle(PlayS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.onPlay(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class StopS2C {
		public final boolean all;
		public final BlockPos pos;

		public StopS2C(boolean all, BlockPos pos) {
			this.all = all;
			this.pos = pos;
		}

		public static void encode(StopS2C msg, FriendlyByteBuf buf) {
			buf.writeBoolean(msg.all);
			buf.writeBlockPos(msg.pos);
		}

		public static StopS2C decode(FriendlyByteBuf buf) {
			return new StopS2C(buf.readBoolean(), buf.readBlockPos());
		}

		public static void handle(StopS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.music.client.MusicClient.onStop(msg));
			ctx.get().setPacketHandled(true);
		}
	}
}
