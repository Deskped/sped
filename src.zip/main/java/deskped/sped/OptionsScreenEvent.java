package deskped.sped;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.sped.menu.SpedMenu;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE, modid = "sped")
@OnlyIn(Dist.CLIENT)
public class OptionsScreenEvent {

	@SubscribeEvent
	public static void onOptionsInit(ScreenEvent.Init.Post event) {
		Screen screen = event.getScreen();
		if (!(screen instanceof OptionsScreen))
			return;

		boolean ru = Minecraft.getInstance().options.languageCode.startsWith("ru");
		event.addListener(Button.builder(Component.literal(label(ru)), b -> {
			SpedMenu.setCustomMenu(!SpedMenu.customMenu);
			b.setMessage(Component.literal(label(ru)));
		}).bounds(6, screen.height - 26, 150, 20).build());
	}

	private static String label(boolean ru) {
		if (ru)
			return "\u041c\u0435\u043d\u044e SPED: " + (SpedMenu.customMenu ? "\u0414\u0430" : "\u041d\u0435\u0442");
		return "SPED menu: " + (SpedMenu.customMenu ? "On" : "Off");
	}
}
