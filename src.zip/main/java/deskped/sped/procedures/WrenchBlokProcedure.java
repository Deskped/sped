package deskped.sped.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;

public class WrenchBlokProcedure {

    private static final Direction[] HORIZONTAL_CYCLE = {
        Direction.SOUTH, Direction.WEST, Direction.NORTH, Direction.EAST
    };

    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null) return;

        BlockPos pos = BlockPos.containing(x, y, z);
        BlockState bs = world.getBlockState(pos);
        ItemStack heldItem = entity instanceof LivingEntity le ? le.getMainHandItem() : ItemStack.EMPTY;

        Direction newDir;

        if (entity.isShiftKeyDown()) {
            Direction current = getCurrentFacing(bs);
            newDir = current == Direction.UP ? Direction.DOWN : Direction.UP;
        } else {
            newDir = getNextHorizontal(getCurrentFacing(bs));
        }

        boolean applied = applyDirection(world, pos, bs, newDir);

        if (applied) {
            spawnParticles(world, pos, bs);
            playWrenchSound(world, pos, newDir);
            world.levelEvent(2001, pos, Block.getId(world.getBlockState(pos)));

            if (entity instanceof ServerPlayer player) {
                heldItem.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(p.getUsedItemHand()));
            }
        }
    }

    private static Direction getCurrentFacing(BlockState bs) {
        Property<?> prop = bs.getBlock().getStateDefinition().getProperty("facing");
        if (prop instanceof DirectionProperty dp) {
            return bs.getValue(dp);
        }
        Property<?> axisProp = bs.getBlock().getStateDefinition().getProperty("axis");
        if (axisProp instanceof EnumProperty<?> ap) {
            Object axisVal = bs.getValue(ap);
            if (axisVal == Direction.Axis.X) return Direction.EAST;
            if (axisVal == Direction.Axis.Z) return Direction.SOUTH;
            if (axisVal == Direction.Axis.Y) return Direction.UP;
        }
        return Direction.SOUTH;
    }

    private static Direction getNextHorizontal(Direction current) {
        for (int i = 0; i < HORIZONTAL_CYCLE.length; i++) {
            if (HORIZONTAL_CYCLE[i] == current) {
                return HORIZONTAL_CYCLE[(i + 1) % HORIZONTAL_CYCLE.length];
            }
        }
        return Direction.SOUTH;
    }

    private static boolean applyDirection(LevelAccessor world, BlockPos pos, BlockState bs, Direction dir) {
        Property<?> prop = bs.getBlock().getStateDefinition().getProperty("facing");
        if (prop instanceof DirectionProperty dp && dp.getPossibleValues().contains(dir)) {
            world.setBlock(pos, bs.setValue(dp, dir), 3);
            return true;
        }
        Property<?> axisProp = bs.getBlock().getStateDefinition().getProperty("axis");
        if (axisProp instanceof EnumProperty ap && ap.getPossibleValues().contains(dir.getAxis())) {
            world.setBlock(pos, bs.setValue(ap, dir.getAxis()), 3);
            return true;
        }
        return false;
    }

    private static void spawnParticles(LevelAccessor world, BlockPos pos, BlockState bs) {
        if (world instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(
                new BlockParticleOption(ParticleTypes.BLOCK, bs),
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                12, 0.3, 0.3, 0.3, 0.05
            );
            serverLevel.sendParticles(
                ParticleTypes.CRIT,
                pos.getX() + 0.5, pos.getY() + 0.7, pos.getZ() + 0.5,
                6, 0.2, 0.1, 0.2, 0.1
            );
        }
    }

    private static void playWrenchSound(LevelAccessor world, BlockPos pos, Direction dir) {
        if (world instanceof ServerLevel serverLevel) {
            float pitch = switch (dir) {
                case UP    -> 1.4f;
                case DOWN  -> 0.6f;
                case NORTH -> 0.8f;
                case SOUTH -> 0.9f;
                case WEST  -> 1.0f;
                case EAST  -> 1.1f;
            };
            serverLevel.playSound(null, pos, SoundEvents.AXE_SCRAPE, SoundSource.BLOCKS, 1.0f, pitch);
            serverLevel.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.3f, 1.8f);
        }
    }
}