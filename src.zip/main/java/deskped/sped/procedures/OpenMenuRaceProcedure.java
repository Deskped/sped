package deskped.sped.procedures;

import net.minecraft.world.entity.Entity;

public class OpenMenuRaceProcedure {

    public static void execute(Entity entity) {
    }
}
