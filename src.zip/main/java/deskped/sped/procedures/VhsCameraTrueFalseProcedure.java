package deskped.sped.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import deskped.sped.init.SpedModBlocks;

public class VhsCameraTrueFalseProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (SpedModBlocks.CAMERA.get().asItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
			return true;
		}
		return false;
	}
}