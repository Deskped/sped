package deskped.sped.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.client.Minecraft;

import deskped.sped.network.SpedModVariables;
import deskped.sped.init.SpedModItems;
import deskped.sped.SpedMod;

public class TeleportEyeProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.getServer() != null) {
				_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
						_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "function yourline:teleporteffect");
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("sped:item_crystal_eye")), SoundSource.MASTER, (float) 0.3, 1);
			} else {
				_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("sped:item_crystal_eye")), SoundSource.MASTER, (float) 0.3, 1, false);
			}
		}
		if (entity instanceof Player _player) {
			ItemStack _stktoremove = new ItemStack(SpedModItems.CRYSTAL_EYE.get());
			_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
		}
		if (world.isClientSide())
			Minecraft.getInstance().gameRenderer.displayItemActivation(new ItemStack(SpedModItems.CRYSTAL_EYE.get()));
		{
			Entity _ent = entity;
			_ent.teleportTo(entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).x, entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).y,
					entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).z);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).x,
						entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).y, entity.getCapability(SpedModVariables.PLAYER_VARIABLES).orElseGet(SpedModVariables.PlayerVariables::new).z,
						_ent.getYRot(), _ent.getXRot());
		}
		{
			Entity _ent = entity;
			if (!_ent.level().isClientSide() && _ent.getServer() != null) {
				_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
						_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:slow_falling 3 0 true");
			}
		}
		SpedMod.queueServerWork(20, () -> {
			{
				Entity _ent = entity;
				if (!_ent.level().isClientSide() && _ent.getServer() != null) {
					_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
							_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "function yourline:teleporteffect");
				}
			}
		});
	}
}