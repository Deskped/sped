package deskped.sped.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

import deskped.sped.network.SpedModVariables;
import deskped.sped.init.SpedModBlocks;

public class LuckOfBoomProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		SpedModVariables.MapVariables.get(world).luckofboom = Mth.nextInt(RandomSource.create(), 0, 100);
		SpedModVariables.MapVariables.get(world).markSyncDirty();
		if (SpedModBlocks.POWDER_BARREL.get() == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock()) {
			if (SpedModVariables.MapVariables.get(world).luckofboom < 12) {
				PowderBarrelBOOMProcedure.execute(world, x, y, z);
			} else {
				UnluckboomProcedure.execute(world, x, y, z);
			}
		} else if (SpedModBlocks.TN_TCASING.get() == (world.getBlockState(BlockPos.containing(x, y, z))).getBlock()) {
			if (SpedModVariables.MapVariables.get(world).luckofboom < 15) {
				if (world instanceof Level _level && !_level.isClientSide())
					_level.explode(null, x, y, z, 6, Level.ExplosionInteraction.TNT);
			} else {
				UnluckboomProcedure.execute(world, x, y, z);
			}
		}
	}
}