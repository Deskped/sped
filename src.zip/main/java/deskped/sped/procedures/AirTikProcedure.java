package deskped.sped.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import deskped.sped.block.AirBlock;

import java.util.List;

public class AirTikProcedure {
    public static void execute() {
    }

    public static void execute(Level world, BlockPos pos, BlockState blockstate, int redstoneSignal) {
        if (world.isClientSide())
            return;

        Direction facing = blockstate.getValue(AirBlock.FACING);
        int fx = facing.getStepX();
        int fy = facing.getStepY();
        int fz = facing.getStepZ();

        double cx = pos.getX() + 0.5;
        double cy = pos.getY() + 0.5;
        double cz = pos.getZ() + 0.5;

        double range = redstoneSignal;
        double pad = 1.5;

        double minX = cx + (fx < 0 ? -range : fx == 0 ? -pad : 0);
        double minY = cy + (fy < 0 ? -range : fy == 0 ? -pad : 0);
        double minZ = cz + (fz < 0 ? -range : fz == 0 ? -pad : 0);
        double maxX = cx + (fx > 0 ? range : fx == 0 ? pad : 0);
        double maxY = cy + (fy > 0 ? range : fy == 0 ? pad : 0);
        double maxZ = cz + (fz > 0 ? range : fz == 0 ? pad : 0);

        AABB area = new AABB(minX, minY, minZ, maxX, maxY, maxZ);

        Vec3 from = new Vec3(
            cx + fx * 1.0,
            cy + fy * 1.0,
            cz + fz * 1.0
        );

        List<Entity> entities = world.getEntities(null, area);

        for (Entity entity : entities) {
            if (entity instanceof Player player && player.isCreative())
                continue;

            Vec3 to = entity.position().add(0, entity.getBbHeight() / 2.0, 0);
            HitResult hit = world.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, entity));

            if (hit.getType() != HitResult.Type.BLOCK) {
                Vec3 current = entity.getDeltaMovement();
                entity.setDeltaMovement(
                    fx != 0 ? fx * 0.5 : current.x * 0.8,
                    fy != 0 ? fy * 0.5 : current.y,
                    fz != 0 ? fz * 0.5 : current.z * 0.8
                );
                entity.hurtMarked = true;
            }
        }
    }
}