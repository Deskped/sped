package deskped.sped.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.List;

public class CrusherVklProcedure {

    public static void execute(LevelAccessor world, double x, double y, double z) {
        if (world.isClientSide()) return;

        BlockPos crusherPos = BlockPos.containing(x, y, z);
        BlockEntity crusherBE = world.getBlockEntity(crusherPos);
        BlockState crusherBS = world.getBlockState(crusherPos);

        if (crusherBE != null) {
            crusherBE.getPersistentData().putBoolean("on", true);
        }
        if (world instanceof Level _level) {
            _level.sendBlockUpdated(crusherPos, crusherBS, crusherBS, 3);
        }

        Direction facing = getBlockDirection(world, crusherPos);
        BlockPos targetPos = crusherPos.relative(facing);
        BlockState targetState = world.getBlockState(targetPos);

        if (targetState.isAir() || !targetState.getFluidState().isEmpty()) return;

        world.playSound(null, targetPos,
                targetState.getSoundType().getBreakSound(),
                SoundSource.BLOCKS,
                1.0f, 0.8f + world.getRandom().nextFloat() * 0.4f);

        world.playSound(null, crusherPos,
                SoundEvents.IRON_GOLEM_ATTACK,
                SoundSource.BLOCKS,
                0.6f, 0.5f + world.getRandom().nextFloat() * 0.3f);

        if (world instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(
                    new BlockParticleOption(ParticleTypes.BLOCK, targetState),
                    targetPos.getX() + 0.5, targetPos.getY() + 0.5, targetPos.getZ() + 0.5,
                    20, 0.3, 0.3, 0.3, 0.05
            );

            List<ItemStack> drops = Block.getDrops(
                    targetState,
                    serverLevel,
                    targetPos,
                    world.getBlockEntity(targetPos)
            );

            world.destroyBlock(targetPos, false);

            if (crusherBE instanceof BaseContainerBlockEntity container) {
                for (ItemStack drop : drops) {
                    insertItemIntoContainer(container, drop);
                    if (!drop.isEmpty()) {
                        spawnItemEntity(world, crusherPos, drop);
                    }
                }
            } else {
                for (ItemStack drop : drops) {
                    spawnItemEntity(world, crusherPos, drop);
                }
            }
        }
    }

    private static void insertItemIntoContainer(BaseContainerBlockEntity container, ItemStack stack) {
        for (int i = 0; i < container.getContainerSize(); i++) {
            if (stack.isEmpty()) break;
            ItemStack slot = container.getItem(i);
            if (slot.isEmpty()) {
                container.setItem(i, stack.copy());
                stack.setCount(0);
            } else if (ItemStack.isSameItemSameTags(slot, stack)
                    && slot.getCount() < slot.getMaxStackSize()) {
                int space = slot.getMaxStackSize() - slot.getCount();
                int transfer = Math.min(space, stack.getCount());
                slot.grow(transfer);
                stack.shrink(transfer);
            }
        }
    }

    private static void spawnItemEntity(LevelAccessor world, BlockPos pos, ItemStack stack) {
        if (world instanceof Level level) {
            ItemEntity ie = new ItemEntity(level,
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    stack.copy());
            ie.setPickUpDelay(10);
            level.addFreshEntity(ie);
        }
    }

    private static Direction getBlockDirection(LevelAccessor world, BlockPos pos) {
        BlockState blockState = world.getBlockState(pos);
        Property<?> property = blockState.getBlock().getStateDefinition().getProperty("facing");
        if (property != null && blockState.getValue(property) instanceof Direction direction)
            return direction;
        else if (blockState.hasProperty(BlockStateProperties.AXIS))
            return Direction.fromAxisAndDirection(
                    blockState.getValue(BlockStateProperties.AXIS),
                    Direction.AxisDirection.POSITIVE);
        else if (blockState.hasProperty(BlockStateProperties.HORIZONTAL_AXIS))
            return Direction.fromAxisAndDirection(
                    blockState.getValue(BlockStateProperties.HORIZONTAL_AXIS),
                    Direction.AxisDirection.POSITIVE);
        return Direction.NORTH;
    }
}