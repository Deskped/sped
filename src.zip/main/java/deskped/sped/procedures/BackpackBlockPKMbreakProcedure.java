package deskped.sped.procedures;

import deskped.sped.block.entity.BackpackBlockBlockEntity;
import deskped.sped.init.SpedModItems;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;

public class BackpackBlockPKMbreakProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (!(entity instanceof Player player) || !player.isShiftKeyDown()) {
			return;
		}

		BlockPos pos = BlockPos.containing(x, y, z);
		BlockEntity be = world.getBlockEntity(pos);

		ItemStack backpack = new ItemStack(SpedModItems.BACKPACK.get());

		if (be instanceof BackpackBlockBlockEntity backpackBe) {
			backpack.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
				if (handler instanceof IItemHandlerModifiable modifiable) {
					int limit = Math.min(modifiable.getSlots(), backpackBe.getContainerSize());

					for (int i = 0; i < limit; i++) {
						modifiable.setStackInSlot(i, backpackBe.getItem(i).copy());
					}
				}
			});
		}

		ItemHandlerHelper.giveItemToPlayer(player, backpack);
		world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
	}
}