package deskped.sped.procedures;

import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;

public class BlockplacerPlaceProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if (world instanceof Level level && level.isClientSide()) {
			return;
		}

		BlockPos pos = BlockPos.containing(x, y, z);
		Direction facing = Direction.NORTH;

		if (blockstate.hasProperty(BlockStateProperties.FACING)) {
			facing = blockstate.getValue(BlockStateProperties.FACING);
		} else if (blockstate.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
			facing = blockstate.getValue(BlockStateProperties.HORIZONTAL_FACING);
		}

		BlockPos targetPos = pos.relative(facing);
		BlockEntity blockEntity = world.getBlockEntity(pos);

		if (blockEntity == null || !world.isEmptyBlock(targetPos)) {
			return;
		}

		blockEntity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(handler -> {
			for (int slot = 0; slot < handler.getSlots(); slot++) {
				ItemStack stack = handler.getStackInSlot(slot);
				if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
					continue;
				}

				world.getBlockState(targetPos).getBlock().defaultBlockState();
				world.setBlock(targetPos, blockItem.getBlock().defaultBlockState(), 3);
				handler.extractItem(slot, 1, false);
				break;
			}
		});
	}
}