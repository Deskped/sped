package deskped.sped.procedures;

import deskped.sped.block.entity.BackpackBlockBlockEntity;
import deskped.sped.init.SpedModBlocks;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;

public class BackpackPKMBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null || !(world instanceof Level level) || level.isClientSide()) {
			return;
		}

		BlockPos placePos = BlockPos.containing(x, y + 1, z);
		if (!level.isEmptyBlock(placePos)) {
			return;
		}

		BlockState state = SpedModBlocks.BACKPACK_BLOCK.get().defaultBlockState();
		state = applyFacing(state, entity.getDirection().getOpposite());
		level.setBlock(placePos, state, 3);

		BlockEntity blockEntity = level.getBlockEntity(placePos);
		if (blockEntity instanceof BackpackBlockBlockEntity backpackBe && entity instanceof LivingEntity living) {
			ItemStack held = living.getMainHandItem();
			held.getCapability(ForgeCapabilities.ITEM_HANDLER).ifPresent(handler -> {
				int limit = Math.min(handler.getSlots(), backpackBe.getContainerSize());
				for (int i = 0; i < limit; i++) {
					backpackBe.setItem(i, handler.getStackInSlot(i).copy());
				}
				backpackBe.setChanged();
				level.sendBlockUpdated(placePos, backpackBe.getBlockState(), backpackBe.getBlockState(), 3);
			});
			held.shrink(1);
		}

		level.playSound(null, placePos, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
	}

	private static BlockState applyFacing(BlockState state, Direction direction) {
		Property<?> property = state.getBlock().getStateDefinition().getProperty("facing");
		if (property instanceof DirectionProperty dp && dp.getPossibleValues().contains(direction)) {
			return state.setValue(dp, direction);
		}

		property = state.getBlock().getStateDefinition().getProperty("horizontal_facing");
		if (property instanceof DirectionProperty dp && dp.getPossibleValues().contains(direction)) {
			return state.setValue(dp, direction);
		}

		property = state.getBlock().getStateDefinition().getProperty("axis");
		if (property instanceof EnumProperty<?> ap && ap.getPossibleValues().contains(direction.getAxis())) {
			return state.setValue((EnumProperty) ap, direction.getAxis());
		}

		return state;
	}
}