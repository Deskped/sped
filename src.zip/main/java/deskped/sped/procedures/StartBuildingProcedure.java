package deskped.sped.procedures;

import net.minecraft.world.entity.Entity;

import deskped.sped.builder.AssemblerHook;

public class StartBuildingProcedure {

	public static void execute() {
		AssemblerHook.start();
	}

	public static void execute(Entity entity) {
		AssemblerHook.start(entity);
	}
}
