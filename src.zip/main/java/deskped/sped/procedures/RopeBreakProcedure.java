package deskped.sped.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import deskped.sped.init.SpedModBlocks;

public class RopeBreakProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (!(SpedModBlocks.ROPE.get() == (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock()) && !world.getBlockState(BlockPos.containing(x, y + 1, z)).canOcclude()) {
			world.destroyBlock(BlockPos.containing(x, y, z), false);
		}
	}
}