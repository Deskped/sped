package deskped.sped.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import deskped.sped.init.SpedModBlocks;

public class WinchActiveProcedure {
    public static void execute(LevelAccessor world, double x, double y, double z) {
        BlockPos cursor = BlockPos.containing(x, y - 1, z);
        int limit = 256;
        while (limit-- > 0 && world.isEmptyBlock(cursor) && cursor.getY() > world.getMinBuildHeight()) {
            world.setBlock(cursor, SpedModBlocks.ROPE.get().defaultBlockState(), 3);
            cursor = cursor.below();
        }
    }
}