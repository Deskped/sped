package deskped.sped;

import deskped.sped.network.SkinSyncPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber
public class SkinStore {

	private static final int MAX_BYTES = 30000;
	private static final Map<UUID, Long> COOLDOWN = new ConcurrentHashMap<>();
	private static final Map<UUID, Long> REQUESTS = new ConcurrentHashMap<>();

	public static Path directory(MinecraftServer server) throws IOException {
		Path dir = server.getWorldPath(LevelResource.ROOT).resolve("sped_skins");
		Files.createDirectories(dir);
		return dir;
	}

	public static void receive(ServerPlayer player, int type, boolean slim, byte[] data) {
		MinecraftServer server = player.getServer();
		if (server == null || (type != 0 && type != 1))
			return;
		long now = System.currentTimeMillis();
		Long last = COOLDOWN.get(player.getUUID());
		if (last != null && now - last < 1500L)
			return;
		COOLDOWN.put(player.getUUID(), now);
		try {
			Path dir = directory(server);
			String base = player.getUUID().toString();
			Path png = dir.resolve(type == 1 ? base + ".cape.png" : base + ".png");
			Path marker = dir.resolve(base + ".slim");
			if (data == null || data.length == 0) {
				Files.deleteIfExists(png);
				if (type == 0)
					Files.deleteIfExists(marker);
				SpedMod.LOGGER.info("[sped skins] {} reset type {}", player.getGameProfile().getName(), type);
				broadcast(new SkinSyncPacket(player.getUUID(), type, false, new byte[0]));
				return;
			}
			if (data.length > MAX_BYTES || !validate(type, data))
				return;
			Files.write(png, data);
			if (type == 0) {
				if (slim) {
					if (!Files.exists(marker))
						Files.createFile(marker);
				} else {
					Files.deleteIfExists(marker);
				}
			}
			SpedMod.LOGGER.info("[sped skins] {} saved type {} {} bytes to {}", player.getGameProfile().getName(), type, data.length, png);
			broadcast(new SkinSyncPacket(player.getUUID(), type, slim, data));
		} catch (IOException e) {
			SpedMod.LOGGER.error("[sped skins] save failed", e);
		}
	}

	public static void onRequest(ServerPlayer requester) {
		MinecraftServer server = requester.getServer();
		if (server == null)
			return;
		long now = System.currentTimeMillis();
		Long last = REQUESTS.get(requester.getUUID());
		if (last != null && now - last < 2000L)
			return;
		REQUESTS.put(requester.getUUID(), now);
		SpedMod.LOGGER.info("[sped skins] request from {}", requester.getGameProfile().getName());
		for (ServerPlayer online : server.getPlayerList().getPlayers()) {
			sendStored(server, online.getUUID(), requester);
			if (online != requester)
				sendStored(server, requester.getUUID(), online);
		}
	}

	private static boolean validate(int type, byte[] data) {
		if (data.length < 8 || (data[0] & 0xFF) != 0x89 || data[1] != 0x50 || data[2] != 0x4E || data[3] != 0x47)
			return false;
		try {
			BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
			if (img == null)
				return false;
			int w = img.getWidth();
			int h = img.getHeight();
			if (type == 1)
				return w == h * 2 && w >= 64 && w <= 256;
			return (w == 64 && h == 32) || (w == h && w >= 64 && w <= 256);
		} catch (IOException e) {
			return false;
		}
	}

	private static void broadcast(SkinSyncPacket packet) {
		SpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), packet);
	}

	private static void sendStored(MinecraftServer server, UUID owner, ServerPlayer target) {
		try {
			Path dir = directory(server);
			String base = owner.toString();
			Path skin = dir.resolve(base + ".png");
			if (Files.isRegularFile(skin) && Files.size(skin) <= MAX_BYTES) {
				boolean slim = Files.exists(dir.resolve(base + ".slim"));
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> target), new SkinSyncPacket(owner, 0, slim, Files.readAllBytes(skin)));
			}
			Path cape = dir.resolve(base + ".cape.png");
			if (Files.isRegularFile(cape) && Files.size(cape) <= MAX_BYTES)
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> target), new SkinSyncPacket(owner, 1, false, Files.readAllBytes(cape)));
		} catch (IOException e) {
			SpedMod.LOGGER.error("[sped skins] sync failed", e);
		}
	}

	@SubscribeEvent
	public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
		COOLDOWN.remove(event.getEntity().getUUID());
		REQUESTS.remove(event.getEntity().getUUID());
	}
}
