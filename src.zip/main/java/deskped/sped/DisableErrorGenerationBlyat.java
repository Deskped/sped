package deskped.sped;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.filter.RegexFilter;
import org.apache.logging.log4j.core.Filter;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DisableErrorGenerationBlyat {
	public DisableErrorGenerationBlyat() {
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		try {
			LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
			Configuration cfg = ctx.getConfiguration();
			RegexFilter filter = RegexFilter.createFilter("Detected setBlock in a far chunk.*", null, null, Filter.Result.DENY, Filter.Result.NEUTRAL);
			Logger logger = ctx.getLogger("minecraft.Util");
			logger.addFilter(filter);
			ctx.updateLoggers();
		} catch (Throwable ignored) {
		}
	}
}