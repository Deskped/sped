package deskped.sped.race;

import deskped.sped.world.inventory.MenuRaceMenu;
import io.netty.buffer.Unpooled;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraftforge.network.NetworkHooks;

public class RaceMenuOpener {
	public static void open(ServerPlayer player, int mode) {
		NetworkHooks.openScreen(player, new MenuProvider() {
			@Override
			public Component getDisplayName() {
				return Component.literal("MenuRace");
			}

			@Override
			public AbstractContainerMenu createMenu(int id, Inventory inventory, Player p) {
				FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
				buf.writeBlockPos(player.blockPosition());
				buf.writeInt(mode);
				return new MenuRaceMenu(id, inventory, buf);
			}
		}, buf -> {
			buf.writeBlockPos(player.blockPosition());
			buf.writeInt(mode);
		});
	}
}