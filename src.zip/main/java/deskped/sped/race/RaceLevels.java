package deskped.sped.race;

import deskped.sped.SpedMod;
import deskped.sped.network.RaceLevelsPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class RaceLevels {
	public static final String TAG = "sped_race_xp";
	public static final int XP_PER_LEVEL = 10;
	public static final int MAX_LEVEL = 3000;
	private static final Map<UUID, int[]> CACHE = new HashMap<>();

	public static int xp(Player player, RaceAttribute attr) {
		if (player.level().isClientSide)
			return readXp(player, attr);
		int[] cached = CACHE.get(player.getUUID());
		if (cached == null) {
			cached = new int[RaceAttribute.values().length];
			for (RaceAttribute a : RaceAttribute.values())
				cached[a.ordinal()] = readXp(player, a);
			CACHE.put(player.getUUID(), cached);
		}
		return cached[attr.ordinal()];
	}

	private static int readXp(Player player, RaceAttribute attr) {
		CompoundTag data = player.getPersistentData();
		if (!data.contains(TAG))
			return 0;
		return data.getCompound(TAG).getInt(attr.name());
	}

	public static int level(int xp) {
		return Math.min(MAX_LEVEL, xp / XP_PER_LEVEL);
	}

	public static int level(Player player, RaceAttribute attr) {
		return level(xp(player, attr));
	}

	public static int toNext(int xp) {
		if (level(xp) >= MAX_LEVEL)
			return 0;
		return XP_PER_LEVEL - xp % XP_PER_LEVEL;
	}

	public static int buffs(int level) {
		return level >= 1000 ? 3 : level >= 300 ? 2 : 1;
	}

	public static int debuffs(int level) {
		return level >= 3000 ? 1 : level >= 1300 ? 2 : 3;
	}

	public static int buffUnlockLevel(int idx) {
		return idx == 2 ? 1000 : idx == 1 ? 300 : 0;
	}

	public static int debuffOffLevel(int idx) {
		return idx == 2 ? 1300 : idx == 1 ? 3000 : -1;
	}

	public static boolean buff(Player player, RaceAttribute attr, int idx) {
		return RaceData.has(player, attr) && idx < buffs(level(player, attr));
	}

	public static boolean debuff(Player player, RaceAttribute attr, int idx) {
		return RaceData.has(player, attr) && idx < debuffs(level(player, attr));
	}

	public static void addXp(ServerPlayer player, int amount) {
		if (amount <= 0)
			return;
		Set<RaceAttribute> races = RaceData.get(player);
		if (races.isEmpty())
			return;
		CompoundTag data = player.getPersistentData();
		CompoundTag tag = data.getCompound(TAG);
		int max = MAX_LEVEL * XP_PER_LEVEL;
		for (RaceAttribute a : races)
			tag.putInt(a.name(), Math.min(max, tag.getInt(a.name()) + amount));
		data.put(TAG, tag);
		invalidate(player.getUUID());
		sync(player);
	}

	public static void invalidate(UUID id) {
		CACHE.remove(id);
	}

	public static void sync(ServerPlayer player) {
		Map<String, Integer> map = new HashMap<>();
		for (RaceAttribute a : RaceAttribute.values()) {
			int xp = xp(player, a);
			if (xp > 0)
				map.put(a.name(), xp);
		}
		SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new RaceLevelsPacket(map));
	}
}
