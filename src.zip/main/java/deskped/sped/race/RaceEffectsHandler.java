package deskped.sped.race;

import deskped.sped.SpedMod;
import deskped.sped.network.RaceHudPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.BrushItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RaceEffectsHandler {

	private static final Map<UUID, State> STATES = new HashMap<>();
	private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
	private static final int T3 = 3600;
	private static final int T33 = 39600;

	private static class State {
		int wingFly, wingLock;
		int dragFly, dragCd;
		int netherTicks;
		int waterTicks;
		int druidDim;
		int ancientDecay;
		int arachSky;
		int amphTimer;
		int airNoSky;
		int demonNoKill;
		int enderCd;
		int fieryScan;
		int lavaScan;
		boolean lavaNear = true;
		boolean wasSneak;
		int lastSneakTick = -100;
		boolean hudActive;
		final List<Snowball> snowballs = new ArrayList<>();
	}

	private static State st(Player p) {
		return STATES.computeIfAbsent(p.getUUID(), k -> new State());
	}

	private static boolean bf(Player p, RaceAttribute a, int i) {
		return RaceLevels.buff(p, a, i);
	}

	private static boolean db(Player p, RaceAttribute a, int i) {
		return RaceLevels.debuff(p, a, i);
	}

	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		if (!(event.player instanceof ServerPlayer player))
			return;
		if (!player.isAlive() || player.isSpectator())
			return;
		State s = st(player);
		Set<RaceAttribute> r = RaceData.get(player);
		if (r.isEmpty())
			return;
		ServerLevel level = player.serverLevel();
		RandomSource rnd = level.random;
		BlockPos pos = player.blockPosition();
		boolean sky = level.canSeeSky(pos.above());
		boolean creative = player.isCreative();
		int tc = player.tickCount;

		boolean winged = r.contains(RaceAttribute.WINGED);
		boolean dragon = r.contains(RaceAttribute.DRAGON);
		boolean amph = r.contains(RaceAttribute.AMPHIBIAN);

		if (!creative && (winged || dragon || amph)) {
			boolean wantFly = false;
			if (winged) {
				if (s.wingLock > 0)
					s.wingLock--;
				if (player.getAbilities().flying)
					s.wingFly++;
				else if (player.onGround() && s.wingFly > 0)
					s.wingFly = Math.max(0, s.wingFly - 2);
				boolean skyOk = sky || !db(player, RaceAttribute.WINGED, 1);
				if (s.wingLock == 0 && skyOk && s.wingFly < T3)
					wantFly = true;
			}
			if (dragon) {
				if (s.dragCd > 0) {
					s.dragCd--;
					if (s.dragCd == 0)
						s.dragFly = 0;
				} else {
					if (player.getAbilities().flying) {
						s.dragFly++;
						if (s.dragFly >= T33)
							s.dragCd = T33;
					}
					if (s.dragCd == 0)
						wantFly = true;
				}
			}
			if (amph && bf(player, RaceAttribute.AMPHIBIAN, 1) && player.isEyeInFluid(FluidTags.WATER))
				wantFly = true;
			if (player.getAbilities().mayfly != wantFly) {
				player.getAbilities().mayfly = wantFly;
				if (!wantFly)
					player.getAbilities().flying = false;
				player.onUpdateAbilities();
			}
		}

		if (player.getAbilities().flying) {
			if (winged && tc % 30 == 0)
				level.playSound(null, pos, SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 0.35f, 1.1f);
			if (dragon && tc % 40 == 0)
				level.playSound(null, pos, SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 0.3f, 1f);
		}

		if (r.contains(RaceAttribute.HUMAN)) {
			if (db(player, RaceAttribute.HUMAN, 1) && player.isEyeInFluid(FluidTags.WATER) && !player.hasEffect(MobEffects.WATER_BREATHING))
				player.setAirSupply(player.getAirSupply() - 4);
			if (db(player, RaceAttribute.HUMAN, 2)) {
				if (level.dimension() == Level.NETHER) {
					s.netherTicks++;
					if (s.netherTicks > 6000 && tc % 20 == 0)
						player.hurt(player.damageSources().magic(), 4.0f);
				} else if (s.netherTicks > 0)
					s.netherTicks = Math.max(0, s.netherTicks - 2);
			} else
				s.netherTicks = 0;
		}

		if (winged)
			unequip(player, EquipmentSlot.CHEST);

		if (r.contains(RaceAttribute.DRUID)) {
			for (EquipmentSlot slot : ARMOR)
				unequip(player, slot);
			if (bf(player, RaceAttribute.DRUID, 1) && player.isShiftKeyDown() && tc % 10 == 0) {
				BlockPos below = pos.below();
				BlockState bs = level.getBlockState(below);
				if (bs.getBlock() instanceof BonemealableBlock b && b.isValidBonemealTarget(level, below, bs, false)) {
					b.performBonemeal(level, rnd, below, bs);
					level.levelEvent(1505, below, 0);
				}
				BlockState at = level.getBlockState(pos);
				if (at.getBlock() instanceof BonemealableBlock b2 && b2.isValidBonemealTarget(level, pos, at, false)) {
					b2.performBonemeal(level, rnd, pos, at);
					level.levelEvent(1505, pos, 0);
				}
			}
			if (db(player, RaceAttribute.DRUID, 1) && level.dimension() != Level.OVERWORLD) {
				s.druidDim++;
				if (s.druidDim >= T3) {
					s.druidDim = 0;
					player.hurt(player.damageSources().magic(), 4.0f);
				}
			} else
				s.druidDim = 0;
			if (bf(player, RaceAttribute.DRUID, 2) && tc % 40 == 0)
				for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(24)))
					if (mob.getTarget() == player && !mob.getType().is(Tags.EntityTypes.BOSSES))
						mob.setTarget(null);
		}

		if (r.contains(RaceAttribute.DWARF)) {
			if (bf(player, RaceAttribute.DWARF, 2) && tc % 10 == 0)
				player.getFoodData().setFoodLevel(20);
			if (player.isInWater()) {
				s.waterTicks++;
				if (s.waterTicks > 1200) {
					Vec3 dm = player.getDeltaMovement();
					player.setDeltaMovement(dm.x * 0.6, Math.min(dm.y, -0.4), dm.z * 0.6);
					player.hurtMarked = true;
				}
			} else
				s.waterTicks = 0;
		}

		if (r.contains(RaceAttribute.ANCIENT) && db(player, RaceAttribute.ANCIENT, 1)) {
			s.ancientDecay++;
			if (s.ancientDecay >= 1200) {
				s.ancientDecay = 0;
				damageAllItems(player, 333);
				level.playSound(null, pos, SoundEvents.ITEM_BREAK, SoundSource.PLAYERS, 0.6f, 0.7f);
			}
		}

		if (r.contains(RaceAttribute.GOBLIN)) {
			eff(player, MobEffects.MOVEMENT_SPEED, 1, tc);
			if (bf(player, RaceAttribute.GOBLIN, 2) && !sky)
				effLong(player, MobEffects.NIGHT_VISION, 0, tc);
			unequip(player, EquipmentSlot.HEAD);
			unequip(player, EquipmentSlot.CHEST);
			unequip(player, EquipmentSlot.FEET);
			if (db(player, RaceAttribute.GOBLIN, 1) && tc % 60 == 0)
				stripEnchants(player);
		}

		if (r.contains(RaceAttribute.FIERY)) {
			if (player.isInWaterOrRain() && tc % 10 == 0) {
				player.hurt(player.damageSources().drown(), 6.0f);
				level.sendParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1, player.getZ(), 4, 0.3, 0.4, 0.3, 0.01);
				if (tc % 20 == 0)
					level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.PLAYERS, 0.5f, 1f);
			}
			if (db(player, RaceAttribute.FIERY, 1) && level.dimension() == Level.OVERWORLD && level.isNight() && tc % 40 == 0 && level.getBrightness(LightLayer.BLOCK, pos) <= 0)
				player.hurt(player.damageSources().freeze(), 2.0f);
			if (db(player, RaceAttribute.FIERY, 2)) {
				s.fieryScan++;
				if (s.fieryScan >= 200) {
					s.fieryScan = 0;
					boolean water = sampleBlocks(level, pos, 33, 80, rnd, b -> b.getFluidState().is(FluidTags.WATER));
					if (!water) {
						for (int i = 0; i < 3; i++) {
							BlockPos p2 = randomPos(pos, 33, rnd);
							if (level.isEmptyBlock(p2) && level.getBlockState(p2.below()).isFaceSturdy(level, p2.below(), Direction.UP)) {
								level.setBlockAndUpdate(p2, Blocks.FIRE.defaultBlockState());
								level.sendParticles(ParticleTypes.FLAME, p2.getX() + 0.5, p2.getY() + 0.5, p2.getZ() + 0.5, 8, 0.3, 0.3, 0.3, 0.02);
								level.playSound(null, p2, SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS, 0.8f, 1f);
							}
						}
					}
				}
			}
		}

		if (r.contains(RaceAttribute.ARACHNID)) {
			boolean climbOk = armorEmpty(player) || !db(player, RaceAttribute.ARACHNID, 2);
			if (player.horizontalCollision && climbOk) {
				Vec3 dm = player.getDeltaMovement();
				player.setDeltaMovement(dm.x, 0.2, dm.z);
				player.fallDistance = 0;
				player.hurtMarked = true;
			}
			if (db(player, RaceAttribute.ARACHNID, 1) && sky) {
				s.arachSky++;
				if (s.arachSky >= T3) {
					s.arachSky = 0;
					inv(player, MobEffects.BLINDNESS, 1200, 0);
					level.playSound(null, pos, SoundEvents.SPIDER_AMBIENT, SoundSource.PLAYERS, 0.8f, 0.8f);
				}
			}
		}

		if (r.contains(RaceAttribute.LIZARD)) {
			if (level.getBlockState(pos.below()).is(BlockTags.SAND))
				eff(player, MobEffects.MOVEMENT_SPEED, 19, tc);
			if (bf(player, RaceAttribute.LIZARD, 2))
				eff(player, MobEffects.JUMP, 1, tc);
			if (tc % 10 == 0 && level.isRainingAt(pos))
				inv(player, MobEffects.MOVEMENT_SLOWDOWN, 60, 1);
			if (db(player, RaceAttribute.LIZARD, 1) && !armorEmpty(player))
				eff(player, MobEffects.MOVEMENT_SLOWDOWN, 0, tc);
			if (db(player, RaceAttribute.LIZARD, 2))
				player.getFoodData().addExhaustion(0.01f);
		}

		if (r.contains(RaceAttribute.WATERMAN)) {
			if (player.isEyeInFluid(FluidTags.WATER))
				player.setAirSupply(player.getMaxAirSupply());
			if (bf(player, RaceAttribute.WATERMAN, 1))
				effLong(player, MobEffects.CONDUIT_POWER, 0, tc);
			if (level.dimension() == Level.NETHER && tc % 20 == 0)
				player.hurt(player.damageSources().magic(), 5.0f);
			if (db(player, RaceAttribute.WATERMAN, 1) && !player.isInWater())
				eff(player, MobEffects.DIG_SLOWDOWN, 0, tc);
		}

		if (amph) {
			s.amphTimer++;
			if (s.amphTimer >= T3) {
				s.amphTimer = 0;
				inv(player, MobEffects.WATER_BREATHING, 1200, 0);
				level.playSound(null, pos, SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.PLAYERS, 0.6f, 1.2f);
			}
			boolean eye = player.isEyeInFluid(FluidTags.WATER);
			if (eye) {
				if (bf(player, RaceAttribute.AMPHIBIAN, 2))
					effLong(player, MobEffects.NIGHT_VISION, 0, tc);
				if (db(player, RaceAttribute.AMPHIBIAN, 1) && !player.hasEffect(MobEffects.WATER_BREATHING) && !r.contains(RaceAttribute.WATERMAN))
					player.setAirSupply(player.getAirSupply() - 6);
			}
		}

		if (r.contains(RaceAttribute.ICY)) {
			for (BlockPos p2 : BlockPos.betweenClosed(pos.offset(-2, -1, -2), pos.offset(2, -1, 2))) {
				BlockState bs = level.getBlockState(p2);
				if (bs.getBlock() == Blocks.WATER && level.getFluidState(p2).isSource()) {
					BlockPos ip = p2.immutable();
					level.setBlockAndUpdate(ip, Blocks.FROSTED_ICE.defaultBlockState());
					level.sendParticles(ParticleTypes.SNOWFLAKE, ip.getX() + 0.5, ip.getY() + 1.1, ip.getZ() + 0.5, 2, 0.25, 0.1, 0.25, 0.01);
					if (tc % 40 == 0)
						level.playSound(null, ip, SoundEvents.POWDER_SNOW_PLACE, SoundSource.PLAYERS, 0.4f, 1.2f);
				}
			}
			if (bf(player, RaceAttribute.ICY, 1)) {
				Iterator<Snowball> it = s.snowballs.iterator();
				while (it.hasNext()) {
					Snowball sb = it.next();
					if (!sb.isAlive()) {
						it.remove();
						continue;
					}
					if (sb.tickCount > 2) {
						Vec3 d = sb.getDeltaMovement();
						BlockPos sp = d.lengthSqr() > 0.001 ? BlockPos.containing(sb.position().subtract(d.normalize().scale(1.5))) : sb.blockPosition();
						if (level.isEmptyBlock(sp))
							level.setBlockAndUpdate(sp, Blocks.SNOW_BLOCK.defaultBlockState());
					}
				}
			} else if (!s.snowballs.isEmpty())
				s.snowballs.clear();
			if (bf(player, RaceAttribute.ICY, 2)) {
				if (tc % 10 == 0)
					auraIcy(level, pos, rnd);
				if (tc % 40 == 0)
					for (Entity e : level.getEntities(player, player.getBoundingBox().inflate(33)))
						if (e.isOnFire())
							e.clearFire();
			}
			if ((player.isOnFire() || player.isInLava()) && tc % 10 == 0)
				player.hurt(player.damageSources().onFire(), 6.0f);
			if (db(player, RaceAttribute.ICY, 2) && player.isInWater() && tc % 20 == 0)
				player.hurt(player.damageSources().drown(), 1.0f);
		}

		if (r.contains(RaceAttribute.LAVA)) {
			if (bf(player, RaceAttribute.LAVA, 1))
				effLong(player, MobEffects.FIRE_RESISTANCE, 0, tc);
			if (player.isInLava()) {
				Vec3 dm = player.getDeltaMovement();
				player.setDeltaMovement(dm.x, Math.max(dm.y, 0.12), dm.z);
				player.fallDistance = 0;
				player.hurtMarked = true;
			} else {
				BlockPos below = BlockPos.containing(player.getX(), player.getY() - 0.1, player.getZ());
				if (level.getFluidState(below).is(FluidTags.LAVA) && player.getDeltaMovement().y <= 0) {
					Vec3 dm = player.getDeltaMovement();
					player.setDeltaMovement(dm.x, 0, dm.z);
					player.fallDistance = 0;
					player.setOnGround(true);
					player.hurtMarked = true;
					if (tc % 20 == 0) {
						level.sendParticles(ParticleTypes.SMOKE, player.getX(), player.getY() + 0.1, player.getZ(), 3, 0.2, 0.05, 0.2, 0.01);
						level.playSound(null, pos, SoundEvents.LAVA_POP, SoundSource.PLAYERS, 0.3f, 1f);
					}
				}
			}
			if (player.isInWater() && tc % 10 == 0) {
				player.hurt(player.damageSources().drown(), 6.0f);
				level.sendParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY() + 1, player.getZ(), 5, 0.3, 0.4, 0.3, 0.01);
			}
			if (db(player, RaceAttribute.LAVA, 1)) {
				s.lavaScan++;
				if (s.lavaScan >= 100) {
					s.lavaScan = 0;
					s.lavaNear = player.isInLava() || sampleBlocks(level, pos, 33, 100, rnd, b -> b.getFluidState().is(FluidTags.LAVA));
				}
				if (!s.lavaNear && tc % 40 == 0)
					player.hurt(player.damageSources().magic(), 2.0f);
			}
		}

		if (r.contains(RaceAttribute.DEMON) && db(player, RaceAttribute.DEMON, 1)) {
			s.demonNoKill++;
			if (s.demonNoKill >= T3) {
				s.demonNoKill = 0;
				inv(player, MobEffects.DIG_SLOWDOWN, 1200, 0);
				level.playSound(null, pos, SoundEvents.BLAZE_AMBIENT, SoundSource.PLAYERS, 0.5f, 0.7f);
			}
		}

		if (r.contains(RaceAttribute.SKELETON)) {
			if (tc % 20 == 0)
				repairAllItems(player);
			ItemStack main = player.getMainHandItem();
			if (bf(player, RaceAttribute.SKELETON, 1) && (main.getItem() instanceof BowItem || main.getItem() instanceof CrossbowItem || main.getItem() instanceof TridentItem))
				eff(player, MobEffects.DAMAGE_BOOST, 4, tc);
			if (bf(player, RaceAttribute.SKELETON, 2))
				player.setAirSupply(player.getMaxAirSupply());
			if (db(player, RaceAttribute.SKELETON, 1) && tc % 20 == 0 && level.dimension() == Level.OVERWORLD && level.isDay() && sky && !level.isRaining())
				player.setSecondsOnFire(3);
		}

		if (r.contains(RaceAttribute.AIR)) {
			if (player.isOnFire())
				player.hurt(player.damageSources().onFire(), 10000f);
			if (bf(player, RaceAttribute.AIR, 2)) {
				if (tc % 10 == 0)
					auraAir(level, pos, rnd);
				if (tc % 40 == 0)
					for (Entity e : level.getEntities(player, player.getBoundingBox().inflate(33)))
						if (e.isOnFire())
							e.clearFire();
			}
			if (db(player, RaceAttribute.AIR, 1) && !sky) {
				s.airNoSky++;
				if (s.airNoSky >= T3) {
					s.airNoSky = 0;
					inv(player, MobEffects.MOVEMENT_SLOWDOWN, 1200, 0);
				}
			} else
				s.airNoSky = 0;
		}

		if (r.contains(RaceAttribute.ENDERMAN)) {
			if (s.enderCd > 0)
				s.enderCd--;
			boolean sneak = player.isShiftKeyDown();
			if (sneak && !s.wasSneak) {
				if (tc - s.lastSneakTick <= 8 && s.enderCd == 0) {
					HitResult hit = player.pick(64, 1f, false);
					if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult bhr) {
						Vec3 from = player.position();
						BlockPos tp = bhr.getBlockPos().relative(bhr.getDirection());
						player.teleportTo(tp.getX() + 0.5, tp.getY(), tp.getZ() + 0.5);
						level.sendParticles(ParticleTypes.PORTAL, from.x, from.y + 1, from.z, 30, 0.4, 0.8, 0.4, 0.1);
						level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 30, 0.4, 0.8, 0.4, 0.1);
						level.playSound(null, tp, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1f);
						s.enderCd = T3;
					}
				}
				s.lastSneakTick = tc;
			}
			s.wasSneak = sneak;
			if (db(player, RaceAttribute.ENDERMAN, 1) && player.isInWaterOrRain() && tc % 10 == 0)
				player.hurt(player.damageSources().drown(), 6.0f);
			if (db(player, RaceAttribute.ENDERMAN, 2) && tc % 20 == 0)
				for (ServerPlayer other : level.players()) {
					if (other == player || other.isSpectator() || other.distanceToSqr(player) > 48 * 48)
						continue;
					Vec3 to = player.getEyePosition().subtract(other.getEyePosition()).normalize();
					if (other.getViewVector(1f).dot(to) > 0.995 && other.hasLineOfSight(player)) {
						randomTeleport(player, 33);
						break;
					}
				}
		}

		if (dragon) {
			if (db(player, RaceAttribute.DRAGON, 1) && player.isInWater()) {
				eff(player, MobEffects.DIG_SLOWDOWN, 0, tc);
				eff(player, MobEffects.MOVEMENT_SLOWDOWN, 0, tc);
			}
			for (EquipmentSlot slot : ARMOR)
				unequip(player, slot);
			if (bf(player, RaceAttribute.DRAGON, 2) && tc % 20 == 0)
				for (PathfinderMob mob : level.getEntitiesOfClass(PathfinderMob.class, player.getBoundingBox().inflate(12))) {
					Vec3 away = mob.position().subtract(player.position());
					if (away.lengthSqr() < 0.01)
						continue;
					Vec3 target = mob.position().add(away.normalize().scale(8));
					mob.getNavigation().moveTo(target.x, mob.getY(), target.z, 1.4);
				}
		}

		if (tc % 20 == 0) {
			List<String[]> hud = new ArrayList<>();
			if (winged) {
				if (player.getAbilities().flying && s.wingFly < T3)
					hud.add(new String[]{"WINGED", "0", String.valueOf((T3 - s.wingFly) / 20)});
				else if (s.wingFly > 40)
					hud.add(new String[]{"WINGED", "1", String.valueOf(s.wingFly / 40 + 1)});
			}
			if (dragon) {
				if (s.dragCd > 0)
					hud.add(new String[]{"DRAGON", "1", String.valueOf(s.dragCd / 20 + 1)});
				else if (player.getAbilities().flying)
					hud.add(new String[]{"DRAGON", "0", String.valueOf((T33 - s.dragFly) / 20)});
			}
			if (r.contains(RaceAttribute.ENDERMAN) && s.enderCd > 0)
				hud.add(new String[]{"ENDERMAN", "1", String.valueOf(s.enderCd / 20 + 1)});
			if (amph) {
				MobEffectInstance wb = player.getEffect(MobEffects.WATER_BREATHING);
				if (wb != null)
					hud.add(new String[]{"AMPH", "0", String.valueOf(wb.getDuration() / 20)});
				else
					hud.add(new String[]{"AMPH", "1", String.valueOf((T3 - s.amphTimer) / 20 + 1)});
			}
			if (r.contains(RaceAttribute.DEMON)) {
				MobEffectInstance dig = player.getEffect(MobEffects.DIG_SLOWDOWN);
				if (dig != null)
					hud.add(new String[]{"DEMON_FATIGUE", "1", String.valueOf(dig.getDuration() / 20)});
			}
			if (r.contains(RaceAttribute.ARACHNID)) {
				MobEffectInstance bl = player.getEffect(MobEffects.BLINDNESS);
				if (bl != null)
					hud.add(new String[]{"ARACH_BLIND", "1", String.valueOf(bl.getDuration() / 20)});
			}
			if (r.contains(RaceAttribute.AIR)) {
				MobEffectInstance sl = player.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
				if (sl != null)
					hud.add(new String[]{"AIR_SLOW", "1", String.valueOf(sl.getDuration() / 20)});
			}
			boolean active = !hud.isEmpty();
			if (active || s.hudActive)
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new RaceHudPacket(hud));
			s.hudActive = active;
		}
	}

	private static void auraIcy(ServerLevel level, BlockPos pos, RandomSource rnd) {
		int fx = 0;
		for (BlockPos p2 : BlockPos.betweenClosed(pos.offset(-6, -4, -6), pos.offset(6, 4, 6))) {
			BlockState bs = level.getBlockState(p2);
			if (bs.is(BlockTags.FIRE)) {
				BlockPos ip = p2.immutable();
				level.removeBlock(ip, false);
				if (fx++ < 5)
					level.sendParticles(ParticleTypes.SMOKE, ip.getX() + 0.5, ip.getY() + 0.5, ip.getZ() + 0.5, 4, 0.2, 0.2, 0.2, 0.01);
			} else if (bs.getBlock() == Blocks.LAVA) {
				BlockPos ip = p2.immutable();
				level.setBlockAndUpdate(ip, Blocks.OBSIDIAN.defaultBlockState());
				if (fx++ < 5) {
					level.sendParticles(ParticleTypes.LARGE_SMOKE, ip.getX() + 0.5, ip.getY() + 1, ip.getZ() + 0.5, 5, 0.3, 0.3, 0.3, 0.01);
					level.playSound(null, ip, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.5f, 0.9f);
				}
			}
		}
		for (int i = 0; i < 80; i++) {
			BlockPos p2 = randomPos(pos, 33, rnd);
			BlockState bs = level.getBlockState(p2);
			if (bs.is(BlockTags.FIRE))
				level.removeBlock(p2, false);
			else if (bs.getBlock() == Blocks.LAVA)
				level.setBlockAndUpdate(p2, Blocks.OBSIDIAN.defaultBlockState());
		}
	}

	private static void auraAir(ServerLevel level, BlockPos pos, RandomSource rnd) {
		int fx = 0;
		for (BlockPos p2 : BlockPos.betweenClosed(pos.offset(-6, -4, -6), pos.offset(6, 4, 6))) {
			if (level.getBlockState(p2).is(BlockTags.FIRE)) {
				BlockPos ip = p2.immutable();
				level.removeBlock(ip, false);
				if (fx++ < 5)
					level.sendParticles(ParticleTypes.CLOUD, ip.getX() + 0.5, ip.getY() + 0.5, ip.getZ() + 0.5, 3, 0.2, 0.2, 0.2, 0.01);
			}
		}
		for (int i = 0; i < 100; i++) {
			BlockPos p2 = randomPos(pos, 33, rnd);
			if (level.getBlockState(p2).is(BlockTags.FIRE))
				level.removeBlock(p2, false);
		}
	}

	@SubscribeEvent
	public static void onEntityJoin(EntityJoinLevelEvent event) {
		if (event.getLevel().isClientSide)
			return;
		if (event.getEntity() instanceof Snowball sb && sb.getOwner() instanceof Player p && RaceData.has(p, RaceAttribute.ICY) && RaceLevels.buff(p, RaceAttribute.ICY, 1)) {
			List<Snowball> list = st(p).snowballs;
			if (list.size() < 40)
				list.add(sb);
		}
	}

	@SubscribeEvent
	public static void onAttack(LivingAttackEvent event) {
		if (event.getEntity().level().isClientSide)
			return;
		DamageSource src = event.getSource();
		if (event.getEntity() instanceof Player victim) {
			Set<RaceAttribute> r = RaceData.get(victim);
			if (!r.isEmpty()) {
				if (r.contains(RaceAttribute.ENDERMAN) && src.is(DamageTypeTags.IS_PROJECTILE)) {
					event.setCanceled(true);
					randomTeleport(victim, 33);
					return;
				}
				if (r.contains(RaceAttribute.FIERY) && src.is(DamageTypeTags.IS_FIRE) && !src.is(DamageTypes.LAVA)) {
					if (!src.is(DamageTypes.HOT_FLOOR) || bf(victim, RaceAttribute.FIERY, 1)) {
						event.setCanceled(true);
						return;
					}
				}
				if (r.contains(RaceAttribute.DRAGON) && bf(victim, RaceAttribute.DRAGON, 1) && src.is(DamageTypeTags.IS_FIRE)) {
					event.setCanceled(true);
					return;
				}
				if (r.contains(RaceAttribute.ANCIENT) && bf(victim, RaceAttribute.ANCIENT, 2) && src.getEntity() instanceof Player ap && ap != victim
						&& !RaceData.has(ap, RaceAttribute.HUMAN) && fullNetherite(victim) && onStone(victim)
						&& !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
					event.setCanceled(true);
					return;
				}
				if (r.contains(RaceAttribute.DRUID) && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && natureNear(victim)) {
					event.setCanceled(true);
					return;
				}
			}
		}
		if (src.getEntity() instanceof Player attacker && src.getDirectEntity() == attacker && !src.is(DamageTypeTags.IS_PROJECTILE)) {
			Set<RaceAttribute> ar = RaceData.get(attacker);
			if (ar.contains(RaceAttribute.SKELETON)) {
				event.setCanceled(true);
				return;
			}
			if (ar.contains(RaceAttribute.DWARF) && db(attacker, RaceAttribute.DWARF, 1) && !(attacker.getMainHandItem().getItem() instanceof PickaxeItem))
				event.setCanceled(true);
		}
	}

	@SubscribeEvent
	public static void onHurt(LivingHurtEvent event) {
		LivingEntity victim = event.getEntity();
		if (victim.level().isClientSide)
			return;
		float amount = event.getAmount();
		DamageSource src = event.getSource();

		if (src.getEntity() instanceof Player attacker) {
			Set<RaceAttribute> ar = RaceData.get(attacker);
			if (!ar.isEmpty()) {
				boolean melee = src.getDirectEntity() == attacker && !src.is(DamageTypeTags.IS_PROJECTILE);
				if (melee) {
					if (ar.contains(RaceAttribute.HUMAN) && bf(attacker, RaceAttribute.HUMAN, 2))
						amount *= 1.4f;
					if (ar.contains(RaceAttribute.DRUID) && db(attacker, RaceAttribute.DRUID, 2))
						amount /= 1.3f;
					if (ar.contains(RaceAttribute.LIZARD) && bf(attacker, RaceAttribute.LIZARD, 1))
						amount *= 3f;
					if (ar.contains(RaceAttribute.DEMON))
						amount *= 2f;
					if (ar.contains(RaceAttribute.AMPHIBIAN) && db(attacker, RaceAttribute.AMPHIBIAN, 2))
						amount /= 1.2f;
					if (ar.contains(RaceAttribute.ARACHNID) && bf(attacker, RaceAttribute.ARACHNID, 1) && attacker.isShiftKeyDown()) {
						BlockPos wp = victim.blockPosition();
						if (victim.level().isEmptyBlock(wp)) {
							victim.level().setBlockAndUpdate(wp, Blocks.COBWEB.defaultBlockState());
							victim.level().playSound(null, wp, SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 0.7f, 0.8f);
						}
					}
					if (ar.contains(RaceAttribute.LAVA) && bf(attacker, RaceAttribute.LAVA, 2)) {
						victim.setSecondsOnFire(5);
						if (victim.level() instanceof ServerLevel sl)
							sl.sendParticles(ParticleTypes.FLAME, victim.getX(), victim.getY() + 1, victim.getZ(), 8, 0.3, 0.4, 0.3, 0.02);
					}
					if (ar.contains(RaceAttribute.FIERY) && bf(attacker, RaceAttribute.FIERY, 2) && victim.isOnFire())
						victim.hurt(attacker.damageSources().playerAttack(attacker), 100000f);
				}
				if (ar.contains(RaceAttribute.DRAGON) && db(attacker, RaceAttribute.DRAGON, 2))
					amount /= 3f;
				if (ar.contains(RaceAttribute.GOBLIN) && bf(attacker, RaceAttribute.GOBLIN, 1) && victim instanceof Player vp && RaceData.has(vp, RaceAttribute.HUMAN))
					amount *= 7f;
			}
		}

		if (victim instanceof Player p) {
			Set<RaceAttribute> r = RaceData.get(p);
			if (!r.isEmpty()) {
				if (r.contains(RaceAttribute.HUMAN) && src.is(DamageTypeTags.IS_FIRE))
					amount *= 8f;
				if (r.contains(RaceAttribute.DWARF) && db(p, RaceAttribute.DWARF, 2) && p.level().canSeeSky(p.blockPosition().above()))
					amount *= 2f;
				if (r.contains(RaceAttribute.ANCIENT) && db(p, RaceAttribute.ANCIENT, 2) && src.getEntity() instanceof Player ap && RaceData.has(ap, RaceAttribute.HUMAN))
					amount = Math.max(amount, p.getMaxHealth() / 3f + 0.5f);
				if (r.contains(RaceAttribute.DEMON) && db(p, RaceAttribute.DEMON, 2) && src.getEntity() instanceof LivingEntity le && le.getMainHandItem().is(Items.GOLDEN_SWORD))
					amount *= 33f;
				if (r.contains(RaceAttribute.SKELETON) && db(p, RaceAttribute.SKELETON, 2))
					amount *= 1.4f;
				if (r.contains(RaceAttribute.ICY) && db(p, RaceAttribute.ICY, 1) && src.getEntity() != null && !iceNear(p))
					amount *= 3f;
				if (r.contains(RaceAttribute.AMPHIBIAN) && src.getEntity() instanceof Player ap2 && ap2 != p && !RaceData.has(ap2, RaceAttribute.AMPHIBIAN))
					amount *= 7f;
				if (r.contains(RaceAttribute.LAVA) && db(p, RaceAttribute.LAVA, 2) && src.getDirectEntity() instanceof Snowball)
					amount = Math.max(amount, 12f);
				if (r.contains(RaceAttribute.AIR))
					amount *= 0.67f;
				if (r.contains(RaceAttribute.WINGED) && db(p, RaceAttribute.WINGED, 2)) {
					State s = st(p);
					s.wingLock = 60;
					if (!p.isCreative() && p.getAbilities().flying) {
						p.getAbilities().flying = false;
						p.getAbilities().mayfly = false;
						p.onUpdateAbilities();
					}
				}
			}
		}
		event.setAmount(amount);
	}

	@SubscribeEvent
	public static void onDamage(LivingDamageEvent event) {
		if (event.getEntity() instanceof Player p && !p.level().isClientSide && RaceData.has(p, RaceAttribute.AIR) && db(p, RaceAttribute.AIR, 2)) {
			float half = p.getHealth() * 0.55f;
			if (event.getAmount() < half)
				event.setAmount(half);
		}
	}

	@SubscribeEvent
	public static void onFall(LivingFallEvent event) {
		if (!(event.getEntity() instanceof Player p) || p.level().isClientSide)
			return;
		Set<RaceAttribute> r = RaceData.get(p);
		if (r.isEmpty())
			return;
		if (r.contains(RaceAttribute.WINGED) && bf(p, RaceAttribute.WINGED, 1))
			event.setCanceled(true);
		if (r.contains(RaceAttribute.AIR) && bf(p, RaceAttribute.AIR, 1)) {
			event.setCanceled(true);
			if (event.getDistance() > 3) {
				inv(p, MobEffects.REGENERATION, 1200, 1);
				if (p.level() instanceof ServerLevel sl) {
					sl.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 12, 0.4, 0.1, 0.4, 0.02);
					sl.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 1.4f);
				}
			}
		}
		if (r.contains(RaceAttribute.ENDERMAN) && bf(p, RaceAttribute.ENDERMAN, 2)) {
			event.setCanceled(true);
			if (event.getDistance() > 3)
				randomTeleport(p, 33);
		}
	}

	@SubscribeEvent
	public static void onKnockback(LivingKnockBackEvent event) {
		if (event.getEntity() instanceof Player p && !p.level().isClientSide && RaceData.has(p, RaceAttribute.DWARF) && bf(p, RaceAttribute.DWARF, 1))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onTarget(LivingChangeTargetEvent event) {
		if (event.getNewTarget() instanceof Player p && !p.level().isClientSide && RaceData.has(p, RaceAttribute.DRUID) && RaceLevels.buff(p, RaceAttribute.DRUID, 2)
				&& !event.getEntity().getType().is(Tags.EntityTypes.BOSSES))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onHeal(LivingHealEvent event) {
		if (!(event.getEntity() instanceof Player p) || p.level().isClientSide)
			return;
		Set<RaceAttribute> r = RaceData.get(p);
		if (r.contains(RaceAttribute.DEMON))
			event.setCanceled(true);
		else if (r.contains(RaceAttribute.WATERMAN) && db(p, RaceAttribute.WATERMAN, 2) && !p.hasEffect(MobEffects.REGENERATION))
			event.setCanceled(true);
	}

	@SubscribeEvent
	public static void onEffectApplicable(MobEffectEvent.Applicable event) {
		if (event.getEntity() instanceof Player p && RaceData.has(p, RaceAttribute.DEMON)
				&& event.getEffectInstance().getEffect() == MobEffects.REGENERATION)
			event.setResult(Event.Result.DENY);
	}

	@SubscribeEvent
	public static void onDeath(LivingDeathEvent event) {
		if (event.getSource().getEntity() instanceof Player killer && !killer.level().isClientSide
				&& RaceData.has(killer, RaceAttribute.DEMON)) {
			st(killer).demonNoKill = 0;
			if (!bf(killer, RaceAttribute.DEMON, 2))
				return;
			Level lvl = event.getEntity().level();
			if (lvl.random.nextFloat() < 0.33f) {
				Block outbreak = ForgeRegistries.BLOCKS.getValue(new ResourceLocation("sped", "outbreak"));
				BlockPos bp = event.getEntity().blockPosition();
				if (outbreak != null && outbreak != Blocks.AIR && (lvl.isEmptyBlock(bp) || lvl.getBlockState(bp).canBeReplaced())) {
					lvl.setBlockAndUpdate(bp, outbreak.defaultBlockState());
					if (lvl instanceof ServerLevel sl) {
						sl.sendParticles(ParticleTypes.FLAME, bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 25, 0.4, 0.4, 0.4, 0.03);
						sl.playSound(null, bp, SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.8f, 0.8f);
					}
				}
			}
		}
	}

	@SubscribeEvent
	public static void onWake(PlayerWakeUpEvent event) {
		Player p = event.getEntity();
		if (!p.level().isClientSide && RaceData.has(p, RaceAttribute.HUMAN) && bf(p, RaceAttribute.HUMAN, 1)) {
			repairAllItems(p);
			p.level().playSound(null, p.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 0.4f, 1.4f);
		}
	}

	@SubscribeEvent
	public static void onXp(PlayerXpEvent.PickupXp event) {
		Player p = event.getEntity();
		if (p.level().isClientSide)
			return;
		if (p instanceof ServerPlayer sp && event.getOrb() != null)
			RaceLevels.addXp(sp, event.getOrb().getValue());
		if (RaceData.has(p, RaceAttribute.DEMON) && bf(p, RaceAttribute.DEMON, 1)) {
			inv(p, MobEffects.DAMAGE_BOOST, 1200, 1);
			inv(p, MobEffects.DAMAGE_RESISTANCE, 1200, 1);
			if (p.level() instanceof ServerLevel sl) {
				sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 8, 0.3, 0.4, 0.3, 0.02);
				sl.playSound(null, p.blockPosition(), SoundEvents.BLAZE_AMBIENT, SoundSource.PLAYERS, 0.4f, 1.2f);
			}
		}
	}

	@SubscribeEvent
	public static void onEat(LivingEntityUseItemEvent.Finish event) {
		if (event.getEntity() instanceof Player p && !p.level().isClientSide && RaceData.has(p, RaceAttribute.ARACHNID)) {
			ItemStack item = event.getItem();
			if (item.isEdible() && !item.is(Items.SPIDER_EYE))
				p.hurt(p.damageSources().magic(), 8.0f);
		}
	}

	@SubscribeEvent
	public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
		Player p = event.getEntity();
		Set<RaceAttribute> r = RaceData.get(p);
		if (r.isEmpty())
			return;
		float speed = event.getNewSpeed();
		if (r.contains(RaceAttribute.ENDERMAN) && bf(p, RaceAttribute.ENDERMAN, 1))
			speed = Math.max(speed, 1.0E7f);
		if (r.contains(RaceAttribute.WATERMAN) && bf(p, RaceAttribute.WATERMAN, 2) && p.isEyeInFluid(FluidTags.WATER))
			speed = Math.max(speed * 50f, 1.0E6f);
		if (r.contains(RaceAttribute.ARACHNID) && bf(p, RaceAttribute.ARACHNID, 2) && event.getState().is(Blocks.COBWEB))
			speed = Math.max(speed, 1.0E6f);
		event.setNewSpeed(speed);
	}

	@SubscribeEvent
	public static void onBreak(BlockEvent.BreakEvent event) {
		Player p = event.getPlayer();
		if (p == null || p.isCreative() || !(event.getLevel() instanceof ServerLevel level))
			return;
		Set<RaceAttribute> r = RaceData.get(p);
		if (r.isEmpty())
			return;
		BlockState state = event.getState();
		BlockPos pos = event.getPos();
		if (r.contains(RaceAttribute.ENDERMAN)) {
			event.setCanceled(true);
			level.removeBlock(pos, false);
			if (!state.requiresCorrectToolForDrops() || p.hasCorrectToolForDrops(state)) {
				ItemStack drop = new ItemStack(state.getBlock());
				if (!drop.isEmpty())
					Block.popResource(level, pos, drop);
			}
			return;
		}
		if (r.contains(RaceAttribute.DWARF)) {
			ItemStack tool = p.getMainHandItem();
			if (state.is(Tags.Blocks.ORES) && EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) == 0
					&& (!state.requiresCorrectToolForDrops() || p.hasCorrectToolForDrops(state))) {
				List<ItemStack> drops = Block.getDrops(state, level, pos, level.getBlockEntity(pos), p, tool);
				for (int i = 0; i < 9; i++)
					for (ItemStack d : drops)
						Block.popResource(level, pos, d.copy());
				level.playSound(null, pos, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.4f, 0.8f);
			}
		}
	}

	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		Player p = event.getEntity();
		Level lvl = event.getLevel();
		if (lvl.isClientSide || event.getHand() != InteractionHand.MAIN_HAND)
			return;
		Set<RaceAttribute> r = RaceData.get(p);
		if (r.isEmpty())
			return;
		BlockPos pos = event.getPos();
		BlockState state = lvl.getBlockState(pos);
		ItemStack held = p.getMainHandItem();

		if (r.contains(RaceAttribute.ANCIENT)) {
			if (state.is(Blocks.GOLD_BLOCK) && held.isEmpty()) {
				lvl.setBlockAndUpdate(pos, Blocks.ANCIENT_DEBRIS.defaultBlockState());
				lvl.playSound(null, pos, SoundEvents.ANCIENT_DEBRIS_PLACE, SoundSource.BLOCKS, 1f, 1f);
				event.setCanceled(true);
				event.setCancellationResult(InteractionResult.SUCCESS);
				return;
			}
			if (bf(p, RaceAttribute.ANCIENT, 1) && state.is(Blocks.ANCIENT_DEBRIS) && held.getItem() instanceof BrushItem) {
				lvl.setBlockAndUpdate(pos, Blocks.NETHERITE_BLOCK.defaultBlockState());
				lvl.playSound(null, pos, SoundEvents.NETHERITE_BLOCK_PLACE, SoundSource.BLOCKS, 1f, 1f);
				held.hurtAndBreak(16, p, pl -> pl.broadcastBreakEvent(InteractionHand.MAIN_HAND));
				event.setCanceled(true);
				event.setCancellationResult(InteractionResult.SUCCESS);
			}
		}
	}

	@SubscribeEvent
	public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
		if (!event.getLevel().isClientSide && RaceData.has(event.getEntity(), RaceAttribute.GOBLIN)
				&& db(event.getEntity(), RaceAttribute.GOBLIN, 2) && event.getTarget() instanceof Merchant) {
			event.setCanceled(true);
			event.setCancellationResult(InteractionResult.FAIL);
		}
	}

	@SubscribeEvent
	public static void onClone(PlayerEvent.Clone event) {
		if (event.getOriginal().getPersistentData().contains(RaceData.TAG))
			event.getEntity().getPersistentData().putString(RaceData.TAG, event.getOriginal().getPersistentData().getString(RaceData.TAG));
		if (event.getOriginal().getPersistentData().contains("sped_death_mode"))
			event.getEntity().getPersistentData().putInt("sped_death_mode", event.getOriginal().getPersistentData().getInt("sped_death_mode"));
		if (event.getOriginal().getPersistentData().contains(RaceLevels.TAG))
			event.getEntity().getPersistentData().put(RaceLevels.TAG, event.getOriginal().getPersistentData().getCompound(RaceLevels.TAG).copy());
		RaceData.invalidate(event.getEntity().getUUID());
		RaceLevels.invalidate(event.getEntity().getUUID());
	}

	@SubscribeEvent
	public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
		if (event.getEntity() instanceof ServerPlayer sp) {
			RaceData.invalidate(sp.getUUID());
			RaceLevels.invalidate(sp.getUUID());
			RaceData.sync(sp);
		}
	}

	@SubscribeEvent
	public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
		if (event.getEntity() instanceof ServerPlayer sp)
			RaceData.sync(sp);
	}

	@SubscribeEvent
	public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (event.getEntity() instanceof ServerPlayer sp)
			RaceData.sync(sp);
	}

	@SubscribeEvent
	public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
		STATES.remove(event.getEntity().getUUID());
		RaceData.invalidate(event.getEntity().getUUID());
		RaceLevels.invalidate(event.getEntity().getUUID());
	}

	private static void inv(LivingEntity e, MobEffect effect, int dur, int amp) {
		e.addEffect(new MobEffectInstance(effect, dur, amp, false, false, false));
	}

	private static void eff(Player p, MobEffect effect, int amp, int tc) {
		if (tc % 10 == 0 || p.getEffect(effect) == null)
			p.addEffect(new MobEffectInstance(effect, 60, amp, false, false, false));
	}

	private static void effLong(Player p, MobEffect effect, int amp, int tc) {
		if (tc % 100 == 0 || p.getEffect(effect) == null)
			p.addEffect(new MobEffectInstance(effect, 410, amp, false, false, false));
	}

	private static void unequip(Player p, EquipmentSlot slot) {
		ItemStack stack = p.getItemBySlot(slot);
		if (!stack.isEmpty()) {
			p.setItemSlot(slot, ItemStack.EMPTY);
			p.getInventory().placeItemBackInInventory(stack);
		}
	}

	private static boolean armorEmpty(Player p) {
		for (EquipmentSlot slot : ARMOR)
			if (!p.getItemBySlot(slot).isEmpty())
				return false;
		return true;
	}

	private static boolean fullNetherite(Player p) {
		return p.getItemBySlot(EquipmentSlot.HEAD).is(Items.NETHERITE_HELMET)
				&& p.getItemBySlot(EquipmentSlot.CHEST).is(Items.NETHERITE_CHESTPLATE)
				&& p.getItemBySlot(EquipmentSlot.LEGS).is(Items.NETHERITE_LEGGINGS)
				&& p.getItemBySlot(EquipmentSlot.FEET).is(Items.NETHERITE_BOOTS);
	}

	private static boolean onStone(Player p) {
		BlockState below = p.level().getBlockState(p.blockPosition().below());
		return below.is(Tags.Blocks.STONE) || below.is(Tags.Blocks.COBBLESTONE)
				|| below.is(BlockTags.BASE_STONE_OVERWORLD) || below.is(BlockTags.BASE_STONE_NETHER);
	}

	private static boolean natureNear(Player p) {
		Level lvl = p.level();
		BlockPos base = p.blockPosition();
		for (BlockPos bp : BlockPos.betweenClosed(base.offset(-1, -1, -1), base.offset(1, 1, 1))) {
			BlockState st = lvl.getBlockState(bp);
			if (st.is(BlockTags.LEAVES) || st.is(BlockTags.FLOWERS) || st.is(BlockTags.CROPS) || st.is(BlockTags.SAPLINGS)
					|| st.is(Blocks.GRASS) || st.is(Blocks.TALL_GRASS) || st.is(Blocks.FERN) || st.is(Blocks.LARGE_FERN)
					|| st.is(Blocks.VINE) || st.is(Blocks.MOSS_BLOCK) || st.is(Blocks.MOSS_CARPET)
					|| st.is(Blocks.DIRT) || st.is(Blocks.COARSE_DIRT) || st.is(Blocks.ROOTED_DIRT) || st.is(Blocks.PODZOL))
				return true;
		}
		return false;
	}

	private static boolean iceNear(Player p) {
		Level lvl = p.level();
		BlockPos base = p.blockPosition();
		for (BlockPos bp : BlockPos.betweenClosed(base.offset(-4, -2, -4), base.offset(4, 2, 4))) {
			BlockState st = lvl.getBlockState(bp);
			if (st.is(BlockTags.ICE) || st.is(BlockTags.SNOW))
				return true;
		}
		return false;
	}

	private static boolean sampleBlocks(ServerLevel lvl, BlockPos center, int radius, int samples, RandomSource rnd, Predicate<BlockState> pred) {
		for (int i = 0; i < samples; i++) {
			BlockPos bp = center.offset(rnd.nextInt(radius * 2 + 1) - radius, rnd.nextInt(radius) - radius / 2, rnd.nextInt(radius * 2 + 1) - radius);
			if (pred.test(lvl.getBlockState(bp)))
				return true;
		}
		return false;
	}

	private static BlockPos randomPos(BlockPos center, int radius, RandomSource rnd) {
		return center.offset(rnd.nextInt(radius * 2 + 1) - radius, rnd.nextInt(radius) - radius / 2, rnd.nextInt(radius * 2 + 1) - radius);
	}

	private static void randomTeleport(Player p, int radius) {
		if (!(p.level() instanceof ServerLevel sl))
			return;
		Vec3 from = p.position();
		RandomSource rnd = sl.random;
		for (int i = 0; i < 16; i++) {
			double x = p.getX() + (rnd.nextDouble() - 0.5) * radius * 2;
			double z = p.getZ() + (rnd.nextDouble() - 0.5) * radius * 2;
			double y = p.getY() + (rnd.nextInt(radius) - radius / 2);
			if (p.randomTeleport(x, y, z, false)) {
				sl.sendParticles(ParticleTypes.PORTAL, from.x, from.y + 1, from.z, 30, 0.4, 0.8, 0.4, 0.1);
				sl.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 30, 0.4, 0.8, 0.4, 0.1);
				sl.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1f);
				return;
			}
		}
	}

	private static void repairAllItems(Player p) {
		for (ItemStack stack : allItems(p))
			if (stack.isDamaged())
				stack.setDamageValue(0);
	}

	private static void damageAllItems(Player p, int amount) {
		for (ItemStack stack : allItems(p)) {
			if (!stack.isDamageableItem())
				continue;
			int d = stack.getDamageValue() + amount;
			if (d >= stack.getMaxDamage())
				stack.shrink(1);
			else
				stack.setDamageValue(d);
		}
	}

	private static void stripEnchants(Player p) {
		for (ItemStack stack : allItems(p)) {
			if (stack.hasTag()) {
				stack.removeTagKey("Enchantments");
				stack.removeTagKey("StoredEnchantments");
			}
		}
	}

	private static List<ItemStack> allItems(Player p) {
		List<ItemStack> list = new ArrayList<>(p.getInventory().items);
		list.addAll(p.getInventory().armor);
		list.addAll(p.getInventory().offhand);
		return list;
	}
}
