package deskped.sped.race;

public enum RaceGroup {
	FOREST("\u041b\u0435\u0441", "Forest", 0x4CAF50, 0),
	MOUNTAINS("\u0413\u043e\u0440\u044b", "Mountains", 0xB0BEC5, 10),
	DESERT("\u041f\u0443\u0441\u0442\u044b\u043d\u044f", "Desert", 0xFFB300, 20),
	OCEAN("\u041e\u043a\u0435\u0430\u043d", "Ocean", 0x29B6F6, 30),
	NETHER("\u041d\u0435\u0437\u0435\u0440", "Nether", 0xEF5350, 40),
	END("\u041a\u0440\u0430\u0439", "End", 0xAB47BC, 50);

	public final String nameRu;
	public final String nameEn;
	public final int color;
	public final int reqLevel;

	RaceGroup(String nameRu, String nameEn, int color, int reqLevel) {
		this.nameRu = nameRu;
		this.nameEn = nameEn;
		this.color = color;
		this.reqLevel = reqLevel;
	}

	public String title(boolean ru) {
		return ru ? nameRu : nameEn;
	}
}
