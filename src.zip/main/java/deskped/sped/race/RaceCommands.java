package deskped.sped.race;

import deskped.sped.PortalSkyState;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

@Mod.EventBusSubscriber(modid = "sped")
public class RaceCommands {
	@SubscribeEvent
	public static void register(RegisterCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("sped")
				.then(Commands.literal("change")
						.requires(src -> src.hasPermission(2))
						.executes(ctx -> {
							ServerPlayer player = ctx.getSource().getPlayerOrException();
							RaceMenuOpener.open(player, 2);
							return 1;
						}))
				.then(Commands.literal("portal")
						.requires(src -> src.hasPermission(2))
						.then(Commands.literal("open").executes(ctx -> setPortal(ctx.getSource(), true)))
						.then(Commands.literal("close").executes(ctx -> setPortal(ctx.getSource(), false)))));
	}

	private static int setPortal(CommandSourceStack src, boolean open) {
		PortalSkyState state = PortalSkyState.get(src.getServer());
		state.setOpen(open);
		PortalSkyState.broadcast(src.getServer(), src.getEntity() instanceof ServerPlayer sp ? sp : null);
		boolean ru = src.getEntity() instanceof ServerPlayer sp && sp.getLanguage() != null && sp.getLanguage().toLowerCase(Locale.ROOT).startsWith("ru");
		String msg = open ? (ru ? "\u041f\u043e\u0440\u0442\u0430\u043b \u043e\u0442\u043a\u0440\u044b\u0442" : "Portal opened") : (ru ? "\u041f\u043e\u0440\u0442\u0430\u043b \u0437\u0430\u043a\u0440\u044b\u0442" : "Portal closed");
		src.sendSuccess(() -> Component.literal(msg), true);
		return 1;
	}
}