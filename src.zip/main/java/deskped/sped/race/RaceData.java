package deskped.sped.race;

import deskped.sped.SpedMod;
import deskped.sped.network.RaceSyncPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class RaceData {
	public static final String TAG = "sped_races";
	private static final Map<UUID, Set<RaceAttribute>> CACHE = new HashMap<>();

	public static Set<RaceAttribute> get(Player player) {
		if (player.level().isClientSide)
			return parse(player);
		Set<RaceAttribute> cached = CACHE.get(player.getUUID());
		if (cached != null)
			return cached;
		Set<RaceAttribute> set = parse(player);
		CACHE.put(player.getUUID(), set);
		return set;
	}

	private static Set<RaceAttribute> parse(Player player) {
		Set<RaceAttribute> set = EnumSet.noneOf(RaceAttribute.class);
		CompoundTag data = player.getPersistentData();
		if (!data.contains(TAG))
			return set;
		for (String s : data.getString(TAG).split(",")) {
			if (s.isEmpty())
				continue;
			try {
				set.add(RaceAttribute.valueOf(s));
			} catch (IllegalArgumentException ignored) {
			}
		}
		return set;
	}

	public static boolean has(Player player, RaceAttribute attr) {
		return get(player).contains(attr);
	}

	public static void set(Player player, Set<RaceAttribute> attrs) {
		StringBuilder sb = new StringBuilder();
		for (RaceAttribute a : attrs) {
			if (sb.length() > 0)
				sb.append(",");
			sb.append(a.name());
		}
		player.getPersistentData().putString(TAG, sb.toString());
		invalidate(player.getUUID());
		if (player instanceof ServerPlayer sp)
			sync(sp);
	}

	public static void invalidate(UUID id) {
		CACHE.remove(id);
	}

	public static void sync(ServerPlayer player) {
		List<String> names = new ArrayList<>();
		for (RaceAttribute a : get(player))
			names.add(a.name());
		SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new RaceSyncPacket(names));
		RaceLevels.sync(player);
	}
}
