package deskped.sped.cleanup;

import deskped.sped.SpedMod;
import deskped.sped.network.ItemCleanupPacket;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.entity.EntityTypeTest;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.List;

@Mod.EventBusSubscriber(modid = SpedMod.MODID)
public class ItemCleanupManager {

	public static final int INTERVAL_TICKS = 33 * 60 * 20;
	public static final int WARN_TICKS = 60 * 20;
	public static final int DONE_TICKS = 60 * 20;

	private static int ticksLeft = INTERVAL_TICKS;
	private static int doneTicksLeft = 0;

	@SubscribeEvent
	public static void onServerStarted(ServerStartedEvent event) {
		ticksLeft = INTERVAL_TICKS;
		doneTicksLeft = 0;
	}

	@SubscribeEvent
	public static void onServerTick(TickEvent.ServerTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
		if (server == null)
			return;

		if (doneTicksLeft > 0) {
			doneTicksLeft--;
			if (doneTicksLeft <= 0)
				broadcast(ItemCleanupPacket.MODE_HIDDEN, 0);
		}

		ticksLeft--;

		if (ticksLeft <= 0) {
			trigger(server);
			return;
		}

		if (ticksLeft <= WARN_TICKS && ticksLeft % 20 == 0)
			broadcast(ItemCleanupPacket.MODE_COUNTDOWN, ticksLeft);
	}

	@SubscribeEvent
	public static void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
		if (!(event.getEntity() instanceof ServerPlayer player))
			return;
		int mode = ItemCleanupPacket.MODE_HIDDEN;
		int ticks = 0;
		if (doneTicksLeft > 0) {
			mode = ItemCleanupPacket.MODE_DONE;
			ticks = doneTicksLeft;
		} else if (ticksLeft <= WARN_TICKS) {
			mode = ItemCleanupPacket.MODE_COUNTDOWN;
			ticks = ticksLeft;
		}
		final int fMode = mode;
		final int fTicks = ticks;
		SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new ItemCleanupPacket(fMode, fTicks));
	}

	public static int trigger(MinecraftServer server) {
		int removed = clearItems(server);
		ticksLeft = INTERVAL_TICKS;
		doneTicksLeft = DONE_TICKS;
		broadcast(ItemCleanupPacket.MODE_DONE, DONE_TICKS);
		return removed;
	}

	private static int clearItems(MinecraftServer server) {
		int removed = 0;
		for (ServerLevel level : server.getAllLevels()) {
			List<? extends ItemEntity> items = level.getEntities(EntityTypeTest.<Entity, ItemEntity>forClass(ItemEntity.class), ItemEntity::isAlive);
			for (ItemEntity item : items) {
				item.discard();
				removed++;
			}
		}
		return removed;
	}

	private static void broadcast(int mode, int ticks) {
		SpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new ItemCleanupPacket(mode, ticks));
	}
}
