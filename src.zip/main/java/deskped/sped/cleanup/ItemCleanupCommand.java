package deskped.sped.cleanup;

import com.mojang.brigadier.CommandDispatcher;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped")
public class ItemCleanupCommand {

	@SubscribeEvent
	public static void onRegisterCommands(RegisterCommandsEvent event) {
		CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
		dispatcher.register(Commands.literal("sped")
				.then(Commands.literal("itemdelete")
						.requires(src -> src.hasPermission(2))
						.executes(ctx -> {
							int removed = ItemCleanupManager.trigger(ctx.getSource().getServer());
							ctx.getSource().sendSuccess(() -> Component.literal("Удалено предметов: " + removed), true);
							return 1;
						})));
	}
}
