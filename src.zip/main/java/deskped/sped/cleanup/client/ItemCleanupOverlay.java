package deskped.sped.cleanup.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ItemCleanupOverlay implements IGuiOverlay {

	private static final int PAD = 5;
	private static final int ICON_W = 10;
	private static final int ICON_H = 12;
	private static final int GAP = 5;
	private static final int WARN_TICKS = 60 * 20;

	@Override
	public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui)
			return;

		int mode = ItemCleanupState.mode();
		if (mode == ItemCleanupState.MODE_HIDDEN)
			return;

		boolean done = mode == ItemCleanupState.MODE_DONE;
		int ticks = Math.max(0, ItemCleanupState.ticks());

		float mul = 1.0f;
		if (done && ticks < 20)
			mul = ticks / 20.0f;
		if (mul <= 0.02f)
			return;

		boolean ru = isRussian();
		String label = done
				? (ru ? "Предметы в мире очищены" : "World items cleared")
				: (ru ? "Удаление предметов" : "Item cleanup");

		int seconds = (ticks + 19) / 20;
		String timer = done ? "" : (seconds / 60) + ":" + String.format("%02d", seconds % 60);

		int labelW = mc.font.width(label);
		int timerW = done ? 0 : mc.font.width(timer);
		int textW = Math.max(labelW, timerW);

		int panelW = PAD * 2 + ICON_W + GAP + textW;
		int panelH = done ? PAD * 2 + ICON_H : PAD * 2 + 27;

		int x0 = screenWidth - panelW - 4;
		int y0 = screenHeight - panelH - 4;
		if (x0 < screenWidth / 2 + 95)
			y0 = screenHeight - panelH - 26;

		int accent = done ? 0x8CE99A : accentFor(seconds);

		g.fill(x0, y0, x0 + panelW, y0 + panelH, color(0x000000, 0xA6, mul));
		g.fill(x0, y0, x0 + panelW, y0 + 1, color(0xFFFFFF, 0x22, mul));
		g.fill(x0, y0 + panelH - 1, x0 + panelW, y0 + panelH, color(0xFFFFFF, 0x22, mul));
		g.fill(x0 + panelW - 1, y0, x0 + panelW, y0 + panelH, color(0xFFFFFF, 0x22, mul));
		g.fill(x0, y0, x0 + 2, y0 + panelH, color(accent, 0xFF, mul));

		int iconX = x0 + PAD;
		int iconY = y0 + PAD + ((done ? ICON_H : 21) - ICON_H) / 2;
		trashIcon(g, iconX, iconY, color(accent, 0xFF, mul));

		int textX = x0 + PAD + ICON_W + GAP;
		if (done) {
			g.drawString(mc.font, label, textX, y0 + (panelH - 8) / 2, color(0xE8FFE8, 0xFF, mul), false);
		} else {
			g.drawString(mc.font, label, textX, y0 + PAD, color(0xFFFFFF, 0xFF, mul), false);
			g.drawString(mc.font, timer, textX, y0 + PAD + 12, color(accent, 0xFF, mul), false);

			int barX = x0 + PAD;
			int barY = y0 + panelH - PAD - 2;
			int barW = panelW - PAD * 2;
			int fillW = Math.round(barW * Math.min(1.0f, ticks / (float) WARN_TICKS));
			g.fill(barX, barY, barX + barW, barY + 2, color(0xFFFFFF, 0x2E, mul));
			if (fillW > 0)
				g.fill(barX, barY, barX + fillW, barY + 2, color(accent, 0xFF, mul));
		}
	}

	private static int accentFor(int seconds) {
		if (seconds <= 10)
			return 0xFF5555;
		if (seconds <= 30)
			return 0xFFB347;
		return 0x7ADCFF;
	}

	private static void trashIcon(GuiGraphics g, int x, int y, int color) {
		g.fill(x + 4, y, x + 7, y + 1, color);
		g.fill(x + 1, y + 1, x + 10, y + 3, color);
		g.fill(x + 2, y + 3, x + 3, y + 12, color);
		g.fill(x + 8, y + 3, x + 9, y + 12, color);
		g.fill(x + 2, y + 11, x + 9, y + 12, color);
		g.fill(x + 4, y + 5, x + 5, y + 10, color);
		g.fill(x + 6, y + 5, x + 7, y + 10, color);
	}

	private static int color(int rgb, int baseAlpha, float mul) {
		int a = (int) (baseAlpha * mul);
		if (a < 8)
			a = 8;
		if (a > 255)
			a = 255;
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	private static boolean isRussian() {
		try {
			String lang = Minecraft.getInstance().getLanguageManager().getSelected();
			return lang != null && lang.startsWith("ru");
		} catch (Exception e) {
			return false;
		}
	}

	@SubscribeEvent
	public static void registerOverlay(RegisterGuiOverlaysEvent event) {
		event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "sped_item_cleanup", new ItemCleanupOverlay());
	}
}
