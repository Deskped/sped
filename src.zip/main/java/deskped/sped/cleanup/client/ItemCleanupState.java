package deskped.sped.cleanup.client;

public class ItemCleanupState {

	public static final int MODE_HIDDEN = 0;
	public static final int MODE_COUNTDOWN = 1;
	public static final int MODE_DONE = 2;

	private static volatile int mode = MODE_HIDDEN;
	private static volatile int ticks = 0;

	public static void set(int newMode, int newTicks) {
		mode = newMode;
		ticks = newMode == MODE_HIDDEN ? 0 : Math.max(0, newTicks);
	}

	public static void tick() {
		if (mode == MODE_HIDDEN)
			return;
		if (ticks > 0)
			ticks--;
		if (ticks <= 0 && mode == MODE_DONE)
			mode = MODE_HIDDEN;
	}

	public static void reset() {
		mode = MODE_HIDDEN;
		ticks = 0;
	}

	public static int mode() {
		return mode;
	}

	public static int ticks() {
		return ticks;
	}
}
