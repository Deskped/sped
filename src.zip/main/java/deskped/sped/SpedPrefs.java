package deskped.sped;

import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class SpedPrefs {

    private static final String VERSION = "1";
    public static SimpleChannel CHANNEL;

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        if (CHANNEL != null)
            return;
        CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SpedMod.MODID, "prefs"),
                () -> VERSION, VERSION::equals, VERSION::equals);
        CHANNEL.registerMessage(0, DynLightPrefPacket.class, DynLightPrefPacket::encode, DynLightPrefPacket::decode, DynLightPrefPacket::handle);
    }
}
