package deskped.sped;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.math.Axis;

@Mod.EventBusSubscriber(modid = "sped", value = Dist.CLIENT)
public class NewSkyDay {

    private static final ResourceLocation CUSTOM_SUN =
            new ResourceLocation("sped", "textures/environment/your_start.png");

    @SubscribeEvent
    public static void onRenderSky(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;

        long time = level.getDayTime() % 24000;

        if (time >= 11800 && time <= 23200) return;

        float alpha;
        if (time < 2000) {
            alpha = time / 2000f;
        } else if (time > 10000) {
            alpha = (11800 - time) / 1800f;
        } else {
            alpha = 1f;
        }
        alpha = Math.min(Math.max(alpha, 0f), 1f);

        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();

        float rotation = (level.getGameTime() % 360000L) / 100f;
        poseStack.mulPose(Axis.YP.rotationDegrees(rotation));

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, CUSTOM_SUN);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1F, 1F, 1F, alpha);

        float sunSize = 120F;
        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.getBuilder();
        buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        buffer.vertex(poseStack.last().pose(), -sunSize, 100F, -sunSize).uv(0F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  sunSize, 100F, -sunSize).uv(1F, 0F).endVertex();
        buffer.vertex(poseStack.last().pose(),  sunSize, 100F,  sunSize).uv(1F, 1F).endVertex();
        buffer.vertex(poseStack.last().pose(), -sunSize, 100F,  sunSize).uv(0F, 1F).endVertex();
        tesselator.end();

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();

        poseStack.popPose();
    }
}