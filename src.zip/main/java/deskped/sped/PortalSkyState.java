package deskped.sped;

import deskped.sped.network.PortalStatePacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

public class PortalSkyState extends SavedData {
	private static final String NAME = "sped_portal";
	private boolean open = true;

	public static PortalSkyState get(MinecraftServer server) {
		return server.overworld().getDataStorage().computeIfAbsent(PortalSkyState::load, PortalSkyState::new, NAME);
	}

	private static PortalSkyState load(CompoundTag tag) {
		PortalSkyState s = new PortalSkyState();
		s.open = !tag.contains("open") || tag.getBoolean("open");
		return s;
	}

	@Override
	public CompoundTag save(CompoundTag tag) {
		tag.putBoolean("open", open);
		return tag;
	}

	public boolean isOpen() {
		return open;
	}

	public void setOpen(boolean v) {
		open = v;
		setDirty();
	}

	public static void broadcast(MinecraftServer server) {
		broadcast(server, null);
	}

	public static void broadcast(MinecraftServer server, ServerPlayer origin) {
		boolean open = get(server).isOpen();
		if (origin != null && !open)
			SpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new PortalStatePacket(open, true, origin.getX(), origin.getY(), origin.getZ()));
		else
			SpedMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new PortalStatePacket(open, false, 0, 0, 0));
	}

	@Mod.EventBusSubscriber(modid = "sped")
	public static class Events {
		@SubscribeEvent
		public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
			if (event.getEntity() instanceof ServerPlayer sp && sp.getServer() != null)
				SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> sp), new PortalStatePacket(get(sp.getServer()).isOpen(), false, 0, 0, 0));
		}
	}
}