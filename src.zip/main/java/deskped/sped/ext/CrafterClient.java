package deskped.sped.ext;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

import net.minecraft.client.gui.screens.MenuScreens;

import deskped.sped.SpedMod;
import deskped.sped.client.gui.CrafterScreen;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CrafterClient {

	@SubscribeEvent
	public static void clientSetup(FMLClientSetupEvent event) {
		event.enqueueWork(() -> MenuScreens.register(CrafterRegistry.CRAFTER_MENU.get(), CrafterScreen::new));
	}
}
