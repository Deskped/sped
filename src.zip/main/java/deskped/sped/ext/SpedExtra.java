package deskped.sped.ext;

import deskped.sped.SpedClientConfig;
import deskped.sped.enchantment.AutosmeltEnchantment;
import deskped.sped.enchantment.DecapitatorEnchantment;
import deskped.sped.init.SpedModEnchantments;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.enchantment.Enchantment;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.RegistryObject;

public class SpedExtra {

    public static final RegistryObject<Enchantment> AUTOSMELT = SpedModEnchantments.REGISTRY.register("autosmelt", AutosmeltEnchantment::new);
    public static final RegistryObject<Enchantment> DECAPITATOR = SpedModEnchantments.REGISTRY.register("decapitator", DecapitatorEnchantment::new);

    public static void init(IEventBus bus) {
        SpedFeaturesConfig.register();
        SpedClientConfig.register();
    }
}
