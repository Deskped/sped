package deskped.sped.ext;

import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.RegistryObject;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntityType;

import deskped.sped.block.entity.CrafterBlockEntity;
import deskped.sped.init.SpedModBlockEntities;
import deskped.sped.init.SpedModBlocks;
import deskped.sped.init.SpedModMenus;
import deskped.sped.world.inventory.CrafterMenu;

public class CrafterRegistry {

	public static final RegistryObject<BlockEntityType<CrafterBlockEntity>> CRAFTER = SpedModBlockEntities.REGISTRY.register("crafter",
			() -> BlockEntityType.Builder.of(CrafterBlockEntity::new, SpedModBlocks.CRAFTER.get()).build(null));

	public static final RegistryObject<MenuType<CrafterMenu>> CRAFTER_MENU = SpedModMenus.REGISTRY.register("crafter",
			() -> IForgeMenuType.create(CrafterMenu::new));

	public static void init() {
	}
}
