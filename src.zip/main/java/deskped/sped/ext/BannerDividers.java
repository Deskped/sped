package deskped.sped.ext;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import deskped.sped.deco.DecoReg;
import deskped.sped.gold.GoldReg;
import deskped.sped.init.SpedModTabs;
import deskped.sped.init.SpedModBlocks;
import deskped.sped.init.SpedModItems;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = "sped", bus = Mod.EventBusSubscriber.Bus.MOD)
public class BannerDividers {
    public static final String KEY = "ylbanner";
    public static final String TYPE = "yltype";
    private static final String UID = "yluid";
    private static int counter = 0;

    private static Item goldHead = null;
    private static Item machineHead = null;

    public static int role(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(KEY) ? tag.getInt(KEY) : 0;
    }

    public static int bannerType(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TYPE) ? tag.getInt(TYPE) : 0;
    }

    private static int sectionBanner(ItemStack stack) {
        Item item = stack.getItem();
        if (machineHead != null ? item == machineHead : item == SpedModBlocks.CRAFTER.get().asItem())
            return 0;
        if (goldHead != null && item == goldHead)
            return 7;
        if (item == SpedModItems.KUWAND.get())
            return 5;
        return -1;
    }

    private static List<Item> goldSection() {
        List<Item> order = new ArrayList<>();
        order.add(SpedModBlocks.GLOW_SAND.get().asItem());
        order.add(SpedModBlocks.GLOW_SANDSTONE.get().asItem());
        order.add(GoldReg.SIEVE.get().asItem());
        order.add(GoldReg.ENRICHER.get().asItem());
        order.add(SpedModItems.CLEAR_GOLD.get());
        order.add(GoldReg.GOLD_PLATE.get());
        order.add(GoldReg.SLAG.get());
        order.add(GoldReg.SLAG_BLOCK.get().asItem());
        order.add(SpedModItems.UNKNOWN_COIN.get());
        order.add(GoldReg.SOUVENIR_COIN.get());
        order.add(GoldReg.LOCKED_CHEST.get().asItem());
        order.add(GoldReg.GOLDEN_GLASSES.get());
        order.add(GoldReg.GOLDEN_STEAK.get());
        order.add(GoldReg.GOLDEN_ARROW.get());
        order.add(GoldReg.GOLDEN_SHIELD.get());
        order.add(GoldReg.SWIFT_BOOTS_DIAMOND.get());
        order.add(GoldReg.SWIFT_BOOTS_NETHERITE.get());
        order.add(GoldReg.GOLDEN_COW_SPAWN_EGG.get());
        return order;
    }

    private static void pull(List<ItemStack> stacks, List<CreativeModeTab.TabVisibility> vis, List<Item> order,
            List<ItemStack> outStacks, List<CreativeModeTab.TabVisibility> outVis) {
        for (Item item : order) {
            for (int i = 0; i < stacks.size(); i++) {
                if (stacks.get(i).getItem() == item) {
                    outStacks.add(stacks.remove(i));
                    outVis.add(vis.remove(i));
                    break;
                }
            }
        }
    }

    private static void regroup(List<ItemStack> stacks, List<CreativeModeTab.TabVisibility> vis) {
        goldHead = null;
        machineHead = null;
        List<ItemStack> machineDeco = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> machineDecoVis = new ArrayList<>();
        List<ItemStack> goldDeco = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> goldDecoVis = new ArrayList<>();
        List<ItemStack> goldMain = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> goldMainVis = new ArrayList<>();
        pull(stacks, vis, DecoReg.items(DecoReg.MACHINES), machineDeco, machineDecoVis);
        pull(stacks, vis, DecoReg.items(DecoReg.GOLD), goldDeco, goldDecoVis);
        pull(stacks, vis, goldSection(), goldMain, goldMainVis);

        int atGold = stacks.size();
        for (int i = 0; i < stacks.size(); i++) {
            if (stacks.get(i).getItem() == SpedModItems.KUWAND.get()) {
                atGold = i;
                break;
            }
        }
        stacks.addAll(atGold, goldMain);
        vis.addAll(atGold, goldMainVis);
        stacks.addAll(atGold, goldDeco);
        vis.addAll(atGold, goldDecoVis);
        if (!goldDeco.isEmpty())
            goldHead = goldDeco.get(0).getItem();
        else if (!goldMain.isEmpty())
            goldHead = goldMain.get(0).getItem();

        int atMachines = 0;
        for (int i = 0; i < stacks.size(); i++) {
            if (stacks.get(i).getItem() == SpedModBlocks.CRAFTER.get().asItem()) {
                atMachines = i;
                break;
            }
        }
        stacks.addAll(atMachines, machineDeco);
        vis.addAll(atMachines, machineDecoVis);
        if (!machineDeco.isEmpty())
            machineHead = machineDeco.get(0).getItem();
    }

    private static ItemStack marker(int kind, int type) {
        ItemStack stack = new ItemStack(Items.PAPER);
        CompoundTag tag = new CompoundTag();
        tag.putInt(KEY, kind);
        tag.putInt(TYPE, type);
        tag.putInt(UID, counter++);
        stack.setTag(tag);
        return stack;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBuild(BuildCreativeModeTabContentsEvent event) {
        if (event.getTab() != SpedModTabs.RPED.get())
            return;
        var entries = event.getEntries();
        List<ItemStack> all = new ArrayList<>();
        List<ItemStack> stacks = new ArrayList<>();
        List<CreativeModeTab.TabVisibility> vis = new ArrayList<>();
        for (var e : entries) {
            all.add(e.getKey());
            if (role(e.getKey()) == 0) {
                stacks.add(e.getKey());
                vis.add(e.getValue());
            }
        }
        for (ItemStack s : all)
            entries.remove(s);
        regroup(stacks, vis);
        int col = 0;
        for (int i = 0; i < stacks.size(); i++) {
            int type = sectionBanner(stacks.get(i));
            if (type >= 0) {
                while (col != 0) {
                    entries.put(marker(2, 0), CreativeModeTab.TabVisibility.PARENT_TAB_ONLY);
                    col = (col + 1) % 9;
                }
                for (int c = 0; c < 9; c++)
                    entries.put(marker(1, type), CreativeModeTab.TabVisibility.PARENT_TAB_ONLY);
            }
            entries.put(stacks.get(i), vis.get(i));
            col = (col + 1) % 9;
        }
    }
}
