package deskped.sped.ext;

import deskped.sped.SpedMod;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class SpedFeaturesConfig {

    public static final ForgeConfigSpec SPEC;
    private static final ForgeConfigSpec.BooleanValue DYNAMIC_LIGHT_VALUE;
    private static final ForgeConfigSpec.BooleanValue BLOCK_HUD_VALUE;

    public static boolean DYNAMIC_LIGHT = true;
    public static boolean BLOCK_HUD = true;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("features");
        DYNAMIC_LIGHT_VALUE = builder.comment("Dynamic light from held items").define("dynamic_light", true);
        BLOCK_HUD_VALUE = builder.comment("Block name hint when looking at blocks").define("block_hud", true);
        builder.pop();
        SPEC = builder.build();
    }

    public static void register() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SPEC, "sped-features.toml");
    }

    @SubscribeEvent
    public static void onLoad(ModConfigEvent event) {
        if (event.getConfig().getSpec() == SPEC) {
            DYNAMIC_LIGHT = DYNAMIC_LIGHT_VALUE.get();
            BLOCK_HUD = BLOCK_HUD_VALUE.get();
        }
    }
}
