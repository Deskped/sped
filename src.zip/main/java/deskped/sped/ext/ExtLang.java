package deskped.sped.ext;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;

public final class ExtLang {

    private ExtLang() {
    }

    public static boolean ru() {
        return FMLEnvironment.dist == Dist.CLIENT && ClientLangHolder.ru();
    }

    public static String pick(String rus, String eng) {
        return ru() ? rus : eng;
    }
}
