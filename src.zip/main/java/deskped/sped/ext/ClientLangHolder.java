package deskped.sped.ext;

import net.minecraft.client.Minecraft;

final class ClientLangHolder {

    private ClientLangHolder() {
    }

    static boolean ru() {
        try {
            String lang = Minecraft.getInstance().getLanguageManager().getSelected();
            return lang != null && lang.startsWith("ru");
        } catch (Throwable t) {
            return false;
        }
    }
}
