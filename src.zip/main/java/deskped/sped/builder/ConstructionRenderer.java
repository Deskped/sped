package deskped.sped.builder;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD, modid = "sped")
public class ConstructionRenderer extends EntityRenderer<ConstructionEntity> {

	public ConstructionRenderer(EntityRendererProvider.Context ctx) {
		super(ctx);
		this.shadowRadius = 1.0f;
	}

	@SubscribeEvent
	public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(BuilderReg.CONSTRUCTION.get(), ConstructionRenderer::new);
	}

	@Override
	public void render(ConstructionEntity entity, float yaw, float partial, PoseStack pose, MultiBufferSource buffer, int light) {
		BlockRenderDispatcher blocks = Minecraft.getInstance().getBlockRenderer();
		float rot = Mth.lerp(partial, entity.yRotO, entity.getYRot());
		float pitch = Mth.lerp(partial, entity.tiltPitchO, entity.tiltPitch);
		float roll = Mth.lerp(partial, entity.tiltRollO, entity.tiltRoll);
		pose.pushPose();
		pose.mulPose(Axis.YP.rotationDegrees(-rot + 90.0f));
		pose.mulPose(Axis.XP.rotationDegrees(pitch));
		pose.mulPose(Axis.ZP.rotationDegrees(roll));
		for (ConstructionEntity.Cell c : entity.cells()) {
			pose.pushPose();
			pose.translate(c.col - 0.5D, c.row, -0.5D);
			blocks.renderSingleBlock(c.state, pose, buffer, light, OverlayTexture.NO_OVERLAY);
			pose.popPose();
		}
		pose.popPose();
		super.render(entity, yaw, partial, pose, buffer, light);
	}

	@Override
	public ResourceLocation getTextureLocation(ConstructionEntity entity) {
		return TextureAtlas.LOCATION_BLOCKS;
	}
}
