package deskped.sped.builder;

import deskped.sped.SpedMod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, modid = "sped")
public class BuilderNet {

	public static final int GRID = 8;

	public static final int OPEN_BUILD = 0;
	public static final int SEND_GRID = 1;
	public static final int DRIVE = 2;
	public static final int DISBAND = 3;
	public static final int START_DRIVE = 4;
	public static final int END_DRIVE = 5;
	public static final int DETONATE = 6;

	private final int action;
	private final int[] grid;
	private final float a;
	private final float b;
	private final int entityId;

	public BuilderNet(int action, int[] grid, float a, float b, int entityId) {
		this.action = action;
		this.grid = grid == null ? new int[0] : grid;
		this.a = a;
		this.b = b;
		this.entityId = entityId;
	}

	public BuilderNet(FriendlyByteBuf buf) {
		this.action = buf.readVarInt();
		int n = buf.readVarInt();
		this.grid = new int[n];
		for (int i = 0; i < n; i++)
			grid[i] = buf.readVarInt();
		this.a = buf.readFloat();
		this.b = buf.readFloat();
		this.entityId = buf.readVarInt();
	}

	public static void buffer(BuilderNet msg, FriendlyByteBuf buf) {
		buf.writeVarInt(msg.action);
		buf.writeVarInt(msg.grid.length);
		for (int v : msg.grid)
			buf.writeVarInt(v);
		buf.writeFloat(msg.a);
		buf.writeFloat(msg.b);
		buf.writeVarInt(msg.entityId);
	}

	public static void handler(BuilderNet msg, Supplier<NetworkEvent.Context> ctx) {
		NetworkEvent.Context c = ctx.get();
		c.enqueueWork(() -> {
			if (c.getDirection().getReceptionSide().isServer()) {
				ServerPlayer sp = c.getSender();
				if (sp == null)
					return;
				switch (msg.action) {
					case SEND_GRID -> spawn(sp, msg.grid, msg.a);
					case DRIVE -> {
						Entity e = sp.level().getEntity(msg.entityId);
						if (e instanceof ConstructionEntity ce && sp.getUUID().equals(ce.owner()))
							ce.setDrive(msg.a, msg.b);
					}
					case DETONATE -> {
						Entity e = sp.level().getEntity(msg.entityId);
						if (e instanceof ConstructionEntity ce && sp.getUUID().equals(ce.owner())) {
							ce.detonate();
							send(sp, new BuilderNet(END_DRIVE, null, 0, 0, 0));
						}
					}
					case DISBAND -> {
						Entity e = sp.level().getEntity(msg.entityId);
						if (e instanceof ConstructionEntity ce && sp.getUUID().equals(ce.owner())) {
							ce.discard();
							send(sp, new BuilderNet(END_DRIVE, null, 0, 0, 0));
						}
					}
					default -> {
					}
				}
			} else {
				DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientBuilder.handle(msg.action, msg.entityId));
			}
		});
		c.setPacketHandled(true);
	}

	private static void spawn(ServerPlayer sp, int[] grid, float yaw) {
		Level level = sp.level();
		List<ConstructionEntity.Cell> cells = new ArrayList<>();
		java.util.Map<net.minecraft.world.item.Item, Integer> need = new java.util.HashMap<>();
		for (int row = 0; row < GRID; row++) {
			for (int col = 0; col < GRID; col++) {
				int id = grid.length > row * GRID + col ? grid[row * GRID + col] : 0;
				if (id <= 0)
					continue;
				net.minecraft.world.item.Item item = net.minecraft.world.item.Item.byId(id);
				Block b = Block.byItem(item);
				if (b == net.minecraft.world.level.block.Blocks.AIR)
					continue;
				need.merge(item, 1, Integer::sum);
				cells.add(new ConstructionEntity.Cell(col - GRID / 2, GRID - 1 - row, BlockOrient.of(b)));
			}
		}
		if (cells.isEmpty())
			return;

		int minRow = Integer.MAX_VALUE;
		int minCol = Integer.MAX_VALUE;
		int maxCol = Integer.MIN_VALUE;
		for (ConstructionEntity.Cell c : cells) {
			minRow = Math.min(minRow, c.row);
			minCol = Math.min(minCol, c.col);
			maxCol = Math.max(maxCol, c.col);
		}
		int shiftCol = (minCol + maxCol) / 2;
		List<ConstructionEntity.Cell> fixed = new ArrayList<>();
		for (ConstructionEntity.Cell c : cells)
			fixed.add(new ConstructionEntity.Cell(c.col - shiftCol, c.row - minRow, c.state));
		cells = fixed;

		for (java.util.Map.Entry<net.minecraft.world.item.Item, Integer> e : need.entrySet())
			if (count(sp, e.getKey()) < e.getValue()) {
				sp.displayClientMessage(net.minecraft.network.chat.Component.literal(
						"\u041d\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u043e\u0432"), true);
				return;
			}
		for (java.util.Map.Entry<net.minecraft.world.item.Item, Integer> e : need.entrySet())
			take(sp, e.getKey(), e.getValue());

		ConstructionEntity ent = new ConstructionEntity(BuilderReg.CONSTRUCTION.get(), level);
		ent.setCells(cells);
		ent.setOwner(sp.getUUID());
		double rad = Math.toRadians(yaw);
		Vec3 fwd = new Vec3(-Math.sin(rad), 0.0D, Math.cos(rad)).normalize();
		Vec3 at = sp.position().add(fwd.scale(9.0D));
		double groundY = Math.floor(sp.getY());
		for (int probe = 0; probe < 12; probe++) {
			net.minecraft.core.BlockPos bp = net.minecraft.core.BlockPos.containing(at.x, groundY - 1, at.z);
			if (!level.getBlockState(bp).getCollisionShape(level, bp).isEmpty())
				break;
			groundY -= 1.0D;
		}
		ent.setPos(at.x, groundY, at.z);
		ent.setYRot(yaw + 90.0f);
		level.addFreshEntity(ent);
		send(sp, new BuilderNet(START_DRIVE, null, 0, 0, ent.getId()));
	}

	private static int count(ServerPlayer sp, net.minecraft.world.item.Item item) {
		int n = 0;
		for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
			net.minecraft.world.item.ItemStack st = sp.getInventory().getItem(i);
			if (st.getItem() == item)
				n += st.getCount();
		}
		return n;
	}

	private static void take(ServerPlayer sp, net.minecraft.world.item.Item item, int amount) {
		for (int i = 0; i < sp.getInventory().getContainerSize() && amount > 0; i++) {
			net.minecraft.world.item.ItemStack st = sp.getInventory().getItem(i);
			if (st.getItem() != item)
				continue;
			int t = Math.min(amount, st.getCount());
			st.shrink(t);
			amount -= t;
		}
		sp.getInventory().setChanged();
	}

	public static void constructionDamaged(ConstructionEntity ent) {
		if (ent.owner() == null)
			return;
		ServerPlayer sp = (ServerPlayer) ent.level().getServer().getPlayerList().getPlayer(ent.owner());
		if (sp != null)
			send(sp, new BuilderNet(END_DRIVE, null, 0, 0, 0));
	}

	public static void send(ServerPlayer sp, BuilderNet msg) {
		SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> sp), msg);
	}

	public static void toServer(BuilderNet msg) {
		SpedMod.PACKET_HANDLER.sendToServer(msg);
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		SpedMod.addNetworkMessage(BuilderNet.class, BuilderNet::buffer, BuilderNet::new, BuilderNet::handler);
	}
}
