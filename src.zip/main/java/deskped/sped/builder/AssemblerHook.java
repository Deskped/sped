package deskped.sped.builder;

import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped")
public class AssemblerHook {

	private static ServerPlayer last;
	private static long lastAt;

	@SubscribeEvent
	public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
		if (event.getLevel().isClientSide())
			return;
		if (event.getEntity() instanceof ServerPlayer sp) {
			last = sp;
			lastAt = sp.level().getGameTime();
		}
	}

	public static void start() {
		ServerPlayer sp = last;
		if (sp == null || sp.isRemoved())
			return;
		if (sp.level().getGameTime() - lastAt > 200L)
			return;
		BuilderNet.send(sp, new BuilderNet(BuilderNet.OPEN_BUILD, null, 0, 0, 0));
	}

	public static void start(net.minecraft.world.entity.Entity entity) {
		if (entity instanceof ServerPlayer sp) {
			BuilderNet.send(sp, new BuilderNet(BuilderNet.OPEN_BUILD, null, 0, 0, 0));
			return;
		}
		start();
	}
}
