package deskped.sped.builder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class BuildCamera {

	private static final int ANCHOR_ID = Integer.MAX_VALUE - 7;

	private static ConstructionEntity anchor;

	private BuildCamera() {
	}

	public static void enter() {
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null || mc.player == null)
			return;
		leave();

		Vec3 centre = BuildSession.origin
				.add(BuildSession.right.scale(BuildSession.G / 2.0D))
				.add(BuildSession.up.scale(BuildSession.G / 2.0D));
		Vec3 back = BuildSession.normal.scale(BuildSession.DIST * 0.75D);
		Vec3 camPos = centre.add(back);

		ConstructionEntity e = new ConstructionEntity(BuilderReg.CONSTRUCTION.get(), level);
		e.setPos(camPos.x, camPos.y, camPos.z);
		Vec3 dir = centre.subtract(camPos).normalize();
		float yaw = (float) (Math.toDegrees(Math.atan2(-dir.x, dir.z)));
		float pitch = (float) (-Math.toDegrees(Math.asin(dir.y)));
		e.setYRot(yaw);
		e.setXRot(pitch);
		e.yRotO = yaw;
		e.xRotO = pitch;
		e.xo = e.getX();
		e.yo = e.getY();
		e.zo = e.getZ();
		e.setId(ANCHOR_ID);
		e.setNoGravity(true);
		e.setInvisible(true);

		level.putNonPlayerEntity(ANCHOR_ID, e);
		anchor = e;
		mc.setCameraEntity(e);
	}

	public static void leave() {
		Minecraft mc = Minecraft.getInstance();
		if (anchor != null && mc.level != null)
			mc.level.removeEntity(ANCHOR_ID, Entity.RemovalReason.DISCARDED);
		anchor = null;
		if (mc.player != null)
			mc.setCameraEntity(mc.player);
	}

	public static boolean active() {
		return anchor != null;
	}

	public static void follow(ConstructionEntity target) {
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		if (level == null || target == null)
			return;
		if (anchor == null) {
			anchor = new ConstructionEntity(BuilderReg.CONSTRUCTION.get(), level);
			anchor.setId(ANCHOR_ID);
			anchor.setNoGravity(true);
			anchor.setInvisible(true);
			level.putNonPlayerEntity(ANCHOR_ID, anchor);
			mc.setCameraEntity(anchor);
		}
		float viewYaw = target.getYRot() - 90.0f;
		double rad = Math.toRadians(viewYaw);
		double fx = -Math.sin(rad);
		double fz = Math.cos(rad);
		double back = 5.0D + target.bodyWidth() * 0.6D;
		double lift = 2.0D + target.bodyHeight() * 0.7D;

		anchor.xo = anchor.getX();
		anchor.yo = anchor.getY();
		anchor.zo = anchor.getZ();
		anchor.yRotO = anchor.getYRot();
		anchor.xRotO = anchor.getXRot();
		anchor.setPos(target.getX() - fx * back, target.getY() + lift, target.getZ() - fz * back);
		anchor.setYRot(viewYaw);
		anchor.setXRot(14.0f + target.tiltPitch * 0.5f);
		if (mc.getCameraEntity() != anchor)
			mc.setCameraEntity(anchor);
	}
}