package deskped.sped.builder;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClientBuilder {

	public static int drivingId = -1;

	private ClientBuilder() {
	}

	public static void handle(int action, int entityId) {
		Minecraft mc = Minecraft.getInstance();
		switch (action) {
			case BuilderNet.OPEN_BUILD -> {
				BuildSession.begin();
				BuildMusic.play("music_building_contraptions");
				BuildCamera.enter();
				mc.setScreen(new BuildScreen());
			}
			case BuilderNet.START_DRIVE -> {
				BuildSession.end();
				BuildMusic.play("music_south_hamerica");
				BuildCamera.leave();
				drivingId = entityId;
				Entity e = mc.level != null ? mc.level.getEntity(entityId) : null;
				if (e != null)
					mc.setCameraEntity(e);
				mc.setScreen(new DriveScreen());
			}
			case BuilderNet.END_DRIVE -> stop();
			default -> {
			}
		}
	}

	public static void stop() {
		Minecraft mc = Minecraft.getInstance();
		BuildSession.end();
		BuildMusic.stop();
		BuildCamera.leave();
		drivingId = -1;
		if (mc.player != null)
			mc.setCameraEntity(mc.player);
		if (mc.screen instanceof DriveScreen)
			mc.setScreen(null);
	}
}
