package deskped.sped.builder;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public final class BlockOrient {

	private BlockOrient() {
	}

	public static BlockState of(Block block) {
		return of(block.defaultBlockState());
	}

	public static BlockState of(BlockState st) {
		try {
			if (st.hasProperty(BlockStateProperties.HORIZONTAL_FACING))
				st = st.setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
			else if (st.hasProperty(BlockStateProperties.FACING))
				st = st.setValue(BlockStateProperties.FACING, Direction.SOUTH);
			if (st.hasProperty(BlockStateProperties.AXIS))
				st = st.setValue(BlockStateProperties.AXIS, Direction.Axis.X);
			else if (st.hasProperty(BlockStateProperties.HORIZONTAL_AXIS))
				st = st.setValue(BlockStateProperties.HORIZONTAL_AXIS, Direction.Axis.X);
		} catch (Exception ignored) {
		}
		return st;
	}
}
