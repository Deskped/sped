package deskped.sped.builder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ConstructionSound extends AbstractTickableSoundInstance {

	private final ConstructionEntity target;

	public ConstructionSound(ConstructionEntity target) {
		super(SoundEvents.MINECART_RIDING, SoundSource.NEUTRAL, SoundInstance.createUnseededRandom());
		this.target = target;
		this.looping = true;
		this.delay = 0;
		this.volume = 0.0f;
	}

	@Override
	public void tick() {
		if (target == null || target.isRemoved()) {
			stop();
			return;
		}
		this.x = target.getX();
		this.y = target.getY();
		this.z = target.getZ();
		double speed = target.getDeltaMovement().horizontalDistance();
		this.volume = (float) Math.min(0.75D, speed * 2.4D);
		this.pitch = 0.85f + (float) Math.min(0.4D, speed * 0.9D);
	}

	public static void attach(ConstructionEntity e) {
		Minecraft.getInstance().getSoundManager().play(new ConstructionSound(e));
	}
}
