package deskped.sped.builder;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.network.NetworkHooks;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ConstructionEntity extends Entity implements IEntityAdditionalSpawnData {

	public static class Cell {
		public final int col, row;
		public final BlockState state;

		public Cell(int col, int row, BlockState state) {
			this.col = col;
			this.row = row;
			this.state = state;
		}
	}

	private List<Cell> cells = new ArrayList<>();
	private UUID constructionId = UUID.randomUUID();
	private UUID ownerId;

	private float widthB = 1.0f;
	private float heightB = 1.0f;
	private int engines;
	private int wheels;

	public float tiltPitch;
	public float tiltRoll;
	public float tiltPitchO;
	public float tiltRollO;

	private int explosives;
	private int detonators;
	private float driveF;
	private float driveT;

	public ConstructionEntity(EntityType<ConstructionEntity> type, Level level) {
		super(type, level);
		this.blocksBuilding = false;
	}

	public boolean hasDetonator() {
		return detonators > 0;
	}

	public void detonate() {
		if (level().isClientSide || detonators <= 0)
			return;
		float power = 3.0f + detonators * 2.0f + explosives * 1.0f;
		level().explode(this, getX(), getY() + heightB * 0.5D, getZ(), power, Level.ExplosionInteraction.TNT);
		damaged();
	}

	public int wheelCount() {
		return wheels;
	}

	public float bodyWidth() {
		return widthB;
	}

	public float bodyHeight() {
		return heightB;
	}

	public List<Cell> cells() {
		return cells;
	}

	public UUID constructionId() {
		return constructionId;
	}

	public void setOwner(UUID id) {
		this.ownerId = id;
	}

	public UUID owner() {
		return ownerId;
	}

	public void setCells(List<Cell> list) {
		this.cells = new ArrayList<>(list);
		recount();
	}

	public void setDrive(float forward, float turn) {
		this.driveF = forward;
		this.driveT = turn;
	}

	private void recount() {
		engines = 0;
		wheels = 0;
		explosives = 0;
		detonators = 0;
		int minC = 0, maxC = 0, maxR = 0;
		for (Cell c : cells) {
			String id = String.valueOf(net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(c.state.getBlock()));
			if (id.equals("sped:fan"))
				engines++;
			else if (id.equals("sped:screw") || id.contains("wheel"))
				wheels++;
			if (isExplosive(c.state, id))
				explosives++;
			if (id.equals("sped:tn_tcasing") || id.contains("tntcasing"))
				detonators++;
			minC = Math.min(minC, c.col);
			maxC = Math.max(maxC, c.col);
			maxR = Math.max(maxR, c.row);
		}
		widthB = Math.max(1.0f, maxC - minC + 1);
		heightB = Math.max(1.0f, maxR + 1);
		refreshDimensions();
	}

	@Override
	public EntityDimensions getDimensions(Pose pose) {
		return EntityDimensions.scalable(widthB, heightB);
	}

	@Override
	public void tick() {
		super.tick();
		if (cells.isEmpty()) {
			if (!level().isClientSide)
				discard();
			return;
		}

		Vec3 dm = getDeltaMovement();
		double drag = onGround() ? 0.80D : 0.96D;
		dm = new Vec3(dm.x * drag, dm.y - 0.055D, dm.z * drag);

		if (driveT != 0.0f && wheels > 0)
			setYRot(getYRot() - driveT * (2.8f + wheels * 0.25f));
		if (driveF != 0.0f && wheels > 0) {
			double power = 0.014D * wheels + 0.010D * engines;
			double rad = Math.toRadians(getYRot());
			dm = dm.add(-Math.sin(rad) * driveF * power, 0.0D, Math.cos(rad) * driveF * power);
		}

		double speed = dm.horizontalDistance();
		if (speed > 0.60D)
			dm = new Vec3(dm.x * (0.60D / speed), dm.y, dm.z * (0.60D / speed));

		double wanted = dm.horizontalDistance();
		setDeltaMovement(dm);
		move(MoverType.SELF, getDeltaMovement());
		updateTilt();

		if (horizontalCollision && wanted > 0.10D && driveF != 0.0f) {
			frontalImpact();
			if (isRemoved())
				return;
		}
		if (verticalCollisionBelow && Math.abs(getDeltaMovement().y) < 0.01D)
			setDeltaMovement(getDeltaMovement().x, 0.0D, getDeltaMovement().z);
	}

	private static boolean isExplosive(BlockState st, String id) {
		if (st.getBlock() instanceof net.minecraft.world.level.block.TntBlock)
			return true;
		String path = id.toLowerCase(java.util.Locale.ROOT);
		return path.contains("tnt") || path.contains("dynamite") || path.contains("explos")
				|| path.contains("powder_barrel") || path.contains("bomb") || path.contains("charge");
	}

	private void frontalImpact() {
		if (explosives <= 0 || level().isClientSide)
			return;
		float chance = Math.min(0.95f, 0.35f + explosives * 0.12f);
		if (random.nextFloat() > chance)
			return;
		float power = 2.0f + explosives * 1.4f;
		level().explode(this, getX(), getY() + heightB * 0.5D, getZ(), power, Level.ExplosionInteraction.TNT);
		damaged();
	}

	private void updateTilt() {
		tiltPitchO = tiltPitch;
		tiltRollO = tiltRoll;
		double rad = Math.toRadians(getYRot());
		double fx = -Math.sin(rad);
		double fz = Math.cos(rad);
		double rx = fz;
		double rz = -fx;
		double reach = Math.max(1.0D, widthB * 0.5D);

		double front = groundAt(getX() + fx * reach, getZ() + fz * reach);
		double back = groundAt(getX() - fx * reach, getZ() - fz * reach);
		double left = groundAt(getX() - rx * reach, getZ() - rz * reach);
		double rightG = groundAt(getX() + rx * reach, getZ() + rz * reach);

		float wantPitch = (float) Math.toDegrees(Math.atan2(front - back, reach * 2.0D));
		float wantRoll = (float) Math.toDegrees(Math.atan2(rightG - left, reach * 2.0D));
		wantPitch = Math.max(-45.0f, Math.min(45.0f, wantPitch));
		wantRoll = Math.max(-45.0f, Math.min(45.0f, wantRoll));

		tiltPitch += (wantPitch - tiltPitch) * 0.18f;
		tiltRoll += (wantRoll - tiltRoll) * 0.18f;
	}

	private double groundAt(double x, double z) {
		net.minecraft.core.BlockPos.MutableBlockPos c = new net.minecraft.core.BlockPos.MutableBlockPos();
		int top = (int) Math.floor(getY() + 3.0D);
		int bottom = (int) Math.floor(getY() - 6.0D);
		for (int y = top; y >= bottom; y--) {
			c.set((int) Math.floor(x), y, (int) Math.floor(z));
			if (!level().getBlockState(c).getCollisionShape(level(), c).isEmpty())
				return y + 1.0D;
		}
		return getY();
	}

	public void damaged() {
		if (!level().isClientSide)
			BuilderNet.constructionDamaged(this);
		discard();
	}

	@Override
	public boolean hurt(DamageSource source, float amount) {
		if (!level().isClientSide)
			damaged();
		return true;
	}

	@Override
	public boolean isPickable() {
		return !isRemoved();
	}

	@Override
	public boolean canBeCollidedWith() {
		return false;
	}

	@Override
	protected void defineSynchedData() {
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
		cells = new ArrayList<>();
		ListTag list = tag.getList("Cells", 10);
		for (int i = 0; i < list.size(); i++) {
			CompoundTag t = list.getCompound(i);
			cells.add(new Cell(t.getInt("c"), t.getInt("r"), Block.stateById(t.getInt("s"))));
		}
		if (tag.hasUUID("Cid"))
			constructionId = tag.getUUID("Cid");
		if (tag.hasUUID("Own"))
			ownerId = tag.getUUID("Own");
		recount();
	}

	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
		ListTag list = new ListTag();
		for (Cell c : cells) {
			CompoundTag t = new CompoundTag();
			t.putInt("c", c.col);
			t.putInt("r", c.row);
			t.putInt("s", Block.getId(c.state));
			list.add(t);
		}
		tag.put("Cells", list);
		tag.putUUID("Cid", constructionId);
		if (ownerId != null)
			tag.putUUID("Own", ownerId);
	}

	@Override
	public void writeSpawnData(FriendlyByteBuf buf) {
		buf.writeVarInt(cells.size());
		for (Cell c : cells) {
			buf.writeVarInt(c.col);
			buf.writeVarInt(c.row);
			buf.writeVarInt(Block.getId(c.state));
		}
	}

	@Override
	public void readSpawnData(FriendlyByteBuf buf) {
		cells = new ArrayList<>();
		int n = buf.readVarInt();
		for (int i = 0; i < n; i++)
			cells.add(new Cell(buf.readVarInt(), buf.readVarInt(), Block.stateById(buf.readVarInt())));
		recount();
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}
}
