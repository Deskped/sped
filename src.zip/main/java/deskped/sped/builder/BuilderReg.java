package deskped.sped.builder;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class BuilderReg {

	public static final DeferredRegister<EntityType<?>> ENTITIES =
			DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "sped");

	public static final RegistryObject<EntityType<ConstructionEntity>> CONSTRUCTION =
			ENTITIES.register("construction", () -> EntityType.Builder
					.<ConstructionEntity>of(ConstructionEntity::new, MobCategory.MISC)
					.sized(1.0f, 1.0f)
					.clientTrackingRange(12)
					.updateInterval(1)
					.setShouldReceiveVelocityUpdates(true)
					.build("construction"));

	public static void register(IEventBus bus) {
		ENTITIES.register(bus);
	}
}
