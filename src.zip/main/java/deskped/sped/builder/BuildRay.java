package deskped.sped.builder;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class BuildRay {

	private BuildRay() {
	}

	public static int pick(double mouseX, double mouseY, int screenW, int screenH) {
		Minecraft mc = Minecraft.getInstance();
		Camera cam = mc.gameRenderer.getMainCamera();
		if (!cam.isInitialized() || screenW <= 0 || screenH <= 0)
			return -1;

		double fov = Math.toRadians(mc.options.fov().get());
		double tan = Math.tan(fov / 2.0D);
		double aspect = (double) screenW / (double) screenH;

		double ndcX = (2.0D * mouseX / screenW) - 1.0D;
		double ndcY = 1.0D - (2.0D * mouseY / screenH);

		Vec3 fwd = new Vec3(cam.getLookVector());
		Vec3 upv = new Vec3(cam.getUpVector());
		Vec3 rgt = new Vec3(cam.getLeftVector()).reverse();

		Vec3 dir = fwd.add(rgt.scale(ndcX * tan * aspect)).add(upv.scale(ndcY * tan)).normalize();
		Vec3 eye = cam.getPosition();

		Vec3 n = BuildSession.normal;
		double denom = dir.dot(n);
		if (Math.abs(denom) < 1.0E-6D)
			return -1;
		double t = BuildSession.origin.subtract(eye).dot(n) / denom;
		if (t <= 0.0D || t > 128.0D)
			return -1;

		Vec3 hit = eye.add(dir.scale(t));
		Vec3 local = hit.subtract(BuildSession.origin);
		double u = local.dot(BuildSession.right);
		double v = local.dot(BuildSession.up);
		if (u < 0.0D || v < 0.0D || u >= BuildSession.G || v >= BuildSession.G)
			return -1;

		int col = (int) u;
		int row = BuildSession.G - 1 - (int) v;
		return row * BuildSession.G + col;
	}
}
