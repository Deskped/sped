package deskped.sped.builder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BuildScreen extends Screen {

	private int barX, barY;

	public BuildScreen() {
		super(Component.literal("\u041a\u043e\u043d\u0441\u0442\u0440\u0443\u043a\u0442\u043e\u0440"));
	}

	@Override
	protected void init() {
		barY = height - 26;
		barX = Math.max(80, width / 2 - Math.max(1, BuildSession.palette.size()) * 22 / 2);
		addRenderableWidget(Button.builder(Component.literal("\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c"),
				b -> java.util.Arrays.fill(BuildSession.cells, null))
				.bounds(6, height - 26, 70, 20).build());
		addRenderableWidget(Button.builder(Component.literal("\u0421\u043e\u0431\u0440\u0430\u0442\u044c"),
				b -> BuilderNet.toServer(new BuilderNet(BuilderNet.SEND_GRID, BuildSession.toItemIds(),
						BuildSession.yaw, 0.0f, 0)))
				.bounds(width - 76, height - 26, 70, 20).build());
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		BuildSession.hoverCell = BuildRay.pick(mx, my, width, height);

		for (int i = 0; i < BuildSession.palette.size(); i++) {
			ItemStack st = BuildSession.palette.get(i);
			int x = barX + i * 22;
			int left = BuildSession.remaining(st.getItem());
			g.fill(x, barY, x + 20, barY + 20, 0xFF373737);
			g.fill(x + 1, barY + 1, x + 19, barY + 19, 0xFF8B8B8B);
			if (i == BuildSession.selected)
				g.fill(x + 1, barY + 1, x + 19, barY + 19, 0x80FFFFFF);
			g.renderItem(st, x + 2, barY + 2);
			ItemStack shown = st.copy();
			shown.setCount(Math.max(0, left));
			g.renderItemDecorations(font, shown, x + 2, barY + 2);
			boolean blocked = left <= 0
					|| (BuildSession.isDetonator(st.getItem()) && BuildSession.detonatorsPlaced() >= 1);
			if (blocked)
				g.fill(x + 1, barY + 1, x + 19, barY + 19, 0x99AA0000);
		}

		String hint = "\u041b\u041a\u041c \u0441\u0442\u0430\u0432\u0438\u0442, \u041f\u041a\u041c \u0443\u0431\u0438\u0440\u0430\u0435\u0442";
		g.drawCenteredString(font, hint, width / 2, barY - 13, 0xFFFFFFFF);
		super.render(g, mx, my, partial);
	}



	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		for (int i = 0; i < BuildSession.palette.size(); i++)
			if (inside(mx, my, barX + i * 22, barY, 20, 20)) {
				BuildSession.selected = i;
				return true;
			}

		int cell = BuildRay.pick(mx, my, width, height);
		if (cell >= 0) {
			if (button == 1) {
				BuildSession.cells[cell] = null;
			} else if (BuildSession.selected < BuildSession.palette.size()) {
				ItemStack st = BuildSession.palette.get(BuildSession.selected);
				boolean limited = BuildSession.isDetonator(st.getItem()) && BuildSession.detonatorsPlaced() >= 1;
				if (BuildSession.cells[cell] == null && BuildSession.remaining(st.getItem()) > 0 && !limited)
					BuildSession.cells[cell] = st.getItem();
			}
			return true;
		}
		return super.mouseClicked(mx, my, button);
	}

	private static boolean inside(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	@Override
	public void onClose() {
		BuildSession.end();
		BuildMusic.stop();
		BuildCamera.leave();
		super.onClose();
	}
}
