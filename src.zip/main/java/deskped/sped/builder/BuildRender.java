package deskped.sped.builder;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(value = Dist.CLIENT, modid = "sped")
public class BuildRender {

	@SubscribeEvent
	public static void onRenderLevel(RenderLevelStageEvent event) {
		if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS)
			return;
		if (!BuildSession.active)
			return;

		Minecraft mc = Minecraft.getInstance();
		Vec3 cam = event.getCamera().getPosition();
		PoseStack pose = event.getPoseStack();
		MultiBufferSource.BufferSource src = mc.renderBuffers().bufferSource();

		pose.pushPose();
		pose.translate(-cam.x, -cam.y, -cam.z);

		VertexConsumer quads = src.getBuffer(RenderType.debugQuads());
		Matrix4f m = pose.last().pose();
		double inset = 0.10D;
		for (int row = 0; row < BuildSession.G; row++) {
			for (int col = 0; col < BuildSession.G; col++) {
				int idx = row * BuildSession.G + col;
				boolean hot = idx == BuildSession.hoverCell;
				float al = hot ? 0.55f : 0.32f;
				float lum = hot ? 0.22f : 0.0f;
				Vec3 p0 = BuildSession.cellCorner(col, row).add(BuildSession.right.scale(inset))
						.add(BuildSession.up.scale(-inset));
				Vec3 p1 = BuildSession.cellCorner(col + 1, row).add(BuildSession.right.scale(-inset))
						.add(BuildSession.up.scale(-inset));
				Vec3 p2 = BuildSession.cellCorner(col + 1, row + 1).add(BuildSession.right.scale(-inset))
						.add(BuildSession.up.scale(inset));
				Vec3 p3 = BuildSession.cellCorner(col, row + 1).add(BuildSession.right.scale(inset))
						.add(BuildSession.up.scale(inset));
				quad(quads, m, p0, p1, p2, p3, lum, al);
			}
		}
		src.endBatch(RenderType.debugQuads());

		int light = 15728880;
		for (int i = 0; i < BuildSession.cells.length; i++) {
			if (BuildSession.cells[i] == null)
				continue;
			Block b = Block.byItem(BuildSession.cells[i]);
			Vec3 c = BuildSession.cellCentre(i);
			pose.pushPose();
			pose.translate(c.x - 0.5D, c.y - 0.5D, c.z - 0.5D);
			mc.getBlockRenderer().renderSingleBlock(BlockOrient.of(b), pose, src, light, OverlayTexture.NO_OVERLAY);
			pose.popPose();
		}

		if (BuildSession.hoverCell >= 0 && BuildSession.cells[BuildSession.hoverCell] == null
				&& BuildSession.selected < BuildSession.palette.size()) {
			ItemStack sel = BuildSession.palette.get(BuildSession.selected);
			if (BuildSession.remaining(sel.getItem()) > 0) {
				Block b = Block.byItem(sel.getItem());
				Vec3 c = BuildSession.cellCentre(BuildSession.hoverCell);
				pose.pushPose();
				pose.translate(c.x - 0.5D, c.y - 0.5D, c.z - 0.5D);
				pose.scale(0.92f, 0.92f, 0.92f);
				mc.getBlockRenderer().renderSingleBlock(BlockOrient.of(b), pose, src, light, OverlayTexture.NO_OVERLAY);
				pose.popPose();
			}
		}

		src.endBatch();
		pose.popPose();
	}

	private static void quad(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, Vec3 c, Vec3 d,
			float lum, float alpha) {
		vc.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(lum, lum, lum, alpha).endVertex();
		vc.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(lum, lum, lum, alpha).endVertex();
		vc.vertex(m, (float) c.x, (float) c.y, (float) c.z).color(lum, lum, lum, alpha).endVertex();
		vc.vertex(m, (float) d.x, (float) d.y, (float) d.z).color(lum, lum, lum, alpha).endVertex();
	}
}