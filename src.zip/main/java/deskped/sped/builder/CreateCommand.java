package deskped.sped.builder;

import com.mojang.brigadier.Command;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "sped")
public class CreateCommand {

	@SubscribeEvent
	public static void register(RegisterCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("sped")
				.then(Commands.literal("create")
						.requires(s -> s.hasPermission(2))
						.executes(ctx -> {
							ServerPlayer sp = ctx.getSource().getPlayer();
							if (sp == null) {
								ctx.getSource().sendFailure(Component.literal("\u0422\u043e\u043b\u044c\u043a\u043e \u0434\u043b\u044f \u0438\u0433\u0440\u043e\u043a\u0430"));
								return 0;
							}
							BuilderNet.send(sp, new BuilderNet(BuilderNet.OPEN_BUILD, null, 0, 0, 0));
							return Command.SINGLE_SUCCESS;
						})));
	}
}
