package deskped.sped.builder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@OnlyIn(Dist.CLIENT)
public final class BuildSession {

	public static final int G = 8;
	public static final double DIST = 9.0D;

	public static boolean active;
	public static Vec3 origin = Vec3.ZERO;
	public static Vec3 right = new Vec3(1, 0, 0);
	public static Vec3 up = new Vec3(0, 1, 0);
	public static Vec3 normal = new Vec3(0, 0, 1);
	public static float yaw;

	public static final Item[] cells = new Item[G * G];
	public static final List<ItemStack> palette = new ArrayList<>();
	public static int selected = 0;
	public static int hoverCell = -1;

	private BuildSession() {
	}

	public static void begin() {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer p = mc.player;
		if (p == null)
			return;

		yaw = p.getYRot();
		double rad = Math.toRadians(yaw);
		Vec3 forward = new Vec3(-Math.sin(rad), 0.0D, Math.cos(rad)).normalize();
		normal = forward.reverse();
		right = new Vec3(forward.z, 0.0D, -forward.x).normalize();
		up = new Vec3(0.0D, 1.0D, 0.0D);

		Vec3 centre = p.position().add(forward.scale(DIST));
		origin = new Vec3(centre.x, Math.floor(p.getY()) + 1.0D, centre.z)
				.subtract(right.scale(G / 2.0D));

		java.util.Arrays.fill(cells, null);
		selected = 0;
		hoverCell = -1;
		rebuildPalette();
		active = true;
	}

	public static void end() {
		active = false;
		java.util.Arrays.fill(cells, null);
		palette.clear();
		hoverCell = -1;
	}

	public static void rebuildPalette() {
		palette.clear();
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null)
			return;
		Map<Item, Integer> have = new LinkedHashMap<>();
		for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
			ItemStack st = mc.player.getInventory().getItem(i);
			if (st.isEmpty())
				continue;
			Block b = Block.byItem(st.getItem());
			if (b == Blocks.AIR)
				continue;
			have.merge(st.getItem(), st.getCount(), Integer::sum);
		}
		for (Map.Entry<Item, Integer> e : have.entrySet()) {
			ItemStack st = new ItemStack(e.getKey());
			st.setCount(Math.min(99, e.getValue()));
			palette.add(st);
		}
		if (selected >= palette.size())
			selected = 0;
	}

	public static boolean isDetonator(Item item) {
		String id = String.valueOf(net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item));
		return id.equals("sped:tn_tcasing") || id.contains("tntcasing");
	}

	public static int detonatorsPlaced() {
		int n = 0;
		for (Item c : cells)
			if (c != null && isDetonator(c))
				n++;
		return n;
	}

	public static boolean inventoryHasDetonator() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null)
			return false;
		for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
			ItemStack st = mc.player.getInventory().getItem(i);
			if (!st.isEmpty() && isDetonator(st.getItem()))
				return true;
		}
		return false;
	}

	public static int owned(Item item) {
		for (ItemStack st : palette)
			if (st.getItem() == item)
				return st.getCount();
		return 0;
	}

	public static int placed(Item item) {
		int n = 0;
		for (Item c : cells)
			if (c == item)
				n++;
		return n;
	}

	public static int remaining(Item item) {
		return owned(item) - placed(item);
	}

	public static Vec3 cellCentre(int index) {
		int col = index % G;
		int row = index / G;
		return origin.add(right.scale(col + 0.5D)).add(up.scale(G - 1 - row + 0.5D));
	}

	public static Vec3 cellCorner(int col, int row) {
		return origin.add(right.scale(col)).add(up.scale(G - row));
	}

	public static int[] toItemIds() {
		int[] out = new int[G * G];
		for (int i = 0; i < cells.length; i++)
			out[i] = cells[i] == null ? 0 : Item.getId(cells[i]);
		return out;
	}
}
