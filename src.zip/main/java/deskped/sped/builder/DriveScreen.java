package deskped.sped.builder;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class DriveScreen extends Screen {

	private boolean soundOn;
	private boolean canBoom;

	public DriveScreen() {
		super(Component.literal("\u0423\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435"));
	}

	@Override
	protected void init() {
		addRenderableWidget(Button.builder(Component.literal("\u0420\u0430\u0437\u043e\u0431\u0440\u0430\u0442\u044c"),
				b -> BuilderNet.toServer(new BuilderNet(BuilderNet.DISBAND, null, 0, 0, ClientBuilder.drivingId)))
				.bounds(width - 110, 10, 100, 20).build());
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void tick() {
		if (ClientBuilder.drivingId < 0) {
			onClose();
			return;
		}
		Minecraft mc = Minecraft.getInstance();
		if (mc.level != null) {
			net.minecraft.world.entity.Entity target = mc.level.getEntity(ClientBuilder.drivingId);
			if (target instanceof ConstructionEntity ce) {
				BuildCamera.follow(ce);
				canBoom = ce.hasDetonator() || BuildSession.inventoryHasDetonator();
				if (!soundOn) {
					soundOn = true;
					ConstructionSound.attach(ce);
				}
			}
		}
		long win = mc.getWindow().getWindow();
		float f = 0.0f, t = 0.0f;
		if (InputConstants.isKeyDown(win, InputConstants.KEY_W))
			f += 1.0f;
		if (InputConstants.isKeyDown(win, InputConstants.KEY_S))
			f -= 1.0f;
		if (InputConstants.isKeyDown(win, InputConstants.KEY_A))
			t += 1.0f;
		if (InputConstants.isKeyDown(win, InputConstants.KEY_D))
			t -= 1.0f;
		BuilderNet.toServer(new BuilderNet(BuilderNet.DRIVE, null, f, t, ClientBuilder.drivingId));
	}

	@Override
	public void render(GuiGraphics g, int mx, int my, float partial) {
		g.drawString(font, "W / S \u0445\u043e\u0434,  A / D \u043f\u043e\u0432\u043e\u0440\u043e\u0442",
				12, height - 20, 0xFFFFFFFF, true);
		super.render(g, mx, my, partial);
	}


	@Override
	public void onClose() {
		ClientBuilder.stop();
	}

	@Override
	public boolean keyPressed(int key, int scan, int mods) {
		if (key == com.mojang.blaze3d.platform.InputConstants.KEY_SPACE && canBoom) {
			BuilderNet.toServer(new BuilderNet(BuilderNet.DETONATE, null, 0, 0, ClientBuilder.drivingId));
			return true;
		}
		return super.keyPressed(key, scan, mods);
	}
}
