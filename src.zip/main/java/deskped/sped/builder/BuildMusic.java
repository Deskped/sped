package deskped.sped.builder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class BuildMusic {

	private static Loop current;

	private BuildMusic() {
	}

	@OnlyIn(Dist.CLIENT)
	private static class Loop extends AbstractSoundInstance {
		Loop(ResourceLocation id) {
			super(id, SoundSource.MASTER, SoundInstance.createUnseededRandom());
			this.looping = true;
			this.delay = 0;
			this.volume = 1.0f;
			this.pitch = 1.0f;
			this.attenuation = Attenuation.NONE;
			this.relative = true;
		}

		@Override
		public boolean canPlaySound() {
			return true;
		}

		@Override
		public boolean canStartSilent() {
			return true;
		}
	}

	public static void play(String name) {
		stop();
		try {
			current = new Loop(new ResourceLocation("sped", name));
			Minecraft.getInstance().getSoundManager().play(current);
		} catch (Exception ignored) {
		}
	}

	public static void stop() {
		if (current != null) {
			Minecraft.getInstance().getSoundManager().stop(current);
			current = null;
		}
	}
}
