package deskped.sped.gold;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

import java.util.List;

public class LockedChestBlock extends BaseEntityBlock {

	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public LockedChestBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(-1.0f, 3600000.0f).pushReaction(PushReaction.BLOCK));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public RenderShape getRenderShape(BlockState state) {
		return RenderShape.MODEL;
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	@Override
	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	@Override
	public BlockState mirror(BlockState state, Mirror mirror) {
		return state.rotate(mirror.getRotation(state.getValue(FACING)));
	}

	@Override
	public void appendHoverText(ItemStack stack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("block.sped.locked_chest.description_" + i));
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new LockedChestBlockEntity(pos, state);
	}

	@Override
	public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
		if (!level.isClientSide && placer instanceof Player player && level.getBlockEntity(pos) instanceof LockedChestBlockEntity be)
			be.setOwner(player.getUUID());
	}

	@Override
	public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		if (level.isClientSide)
			return InteractionResult.SUCCESS;
		if (!(level.getBlockEntity(pos) instanceof LockedChestBlockEntity be))
			return InteractionResult.PASS;
		if (!(player instanceof ServerPlayer serverPlayer))
			return InteractionResult.PASS;
		boolean master = be.isOwner(player) || player.hasPermissions(2);
		if (!be.hasCode()) {
			if (master) {
				GoldNetwork.openCodeScreen(serverPlayer, pos, true);
			} else {
				player.displayClientMessage(Component.translatable("message.sped.locked_chest.no_code"), true);
			}
			return InteractionResult.CONSUME;
		}
		if (master && player.isShiftKeyDown()) {
			GoldNetwork.openCodeScreen(serverPlayer, pos, true);
			return InteractionResult.CONSUME;
		}
		if (master) {
			open(serverPlayer, be);
			return InteractionResult.CONSUME;
		}
		GoldNetwork.openCodeScreen(serverPlayer, pos, false);
		return InteractionResult.CONSUME;
	}

	public static void open(ServerPlayer player, LockedChestBlockEntity be) {
		player.openMenu(be);
		player.level().playSound(null, be.getBlockPos(), SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 0.5f, 1.4f);
	}

	@Override
	public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
		if (!state.is(newState.getBlock())) {
			if (level.getBlockEntity(pos) instanceof LockedChestBlockEntity be) {
				Containers.dropContents(level, pos, be);
				level.updateNeighbourForOutputSignal(pos, this);
			}
			super.onRemove(state, level, pos, newState, moving);
		}
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
		if (level.getBlockEntity(pos) instanceof LockedChestBlockEntity be)
			return net.minecraft.world.inventory.AbstractContainerMenu.getRedstoneSignalFromContainer(be);
		return 0;
	}
}
