package deskped.sped.gold;

import deskped.sped.SpedMod;

import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class GoldReg {

	public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SpedMod.MODID);
	public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SpedMod.MODID);
	public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SpedMod.MODID);
	public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpedMod.MODID);
	public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, SpedMod.MODID);
	public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, SpedMod.MODID);

	public static final RegistryObject<Block> SIEVE = BLOCKS.register("sieve", SieveBlock::new);
	public static final RegistryObject<Block> LOCKED_CHEST = BLOCKS.register("locked_chest", LockedChestBlock::new);
	public static final RegistryObject<Block> ENRICHER = BLOCKS.register("enricher", EnricherBlock::new);
	public static final RegistryObject<Block> SLAG_BLOCK = BLOCKS.register("slag_block", SlagBlock::new);

	public static final RegistryObject<Item> SIEVE_ITEM = ITEMS.register("sieve", () -> new BlockItem(SIEVE.get(), new Item.Properties()));
	public static final RegistryObject<Item> LOCKED_CHEST_ITEM = ITEMS.register("locked_chest", () -> new BlockItem(LOCKED_CHEST.get(), new Item.Properties().rarity(Rarity.UNCOMMON)));

	public static final RegistryObject<Item> ENRICHER_ITEM = ITEMS.register("enricher", () -> new BlockItem(ENRICHER.get(), new Item.Properties()));
	public static final RegistryObject<Item> SLAG_BLOCK_ITEM = ITEMS.register("slag_block", () -> new BlockItem(SLAG_BLOCK.get(), new Item.Properties()));

	public static final RegistryObject<Item> SLAG = ITEMS.register("slag", SlagItem::new);
	public static final RegistryObject<Item> GOLD_PLATE = ITEMS.register("gold_plate", GoldPlateItem::new);
	public static final RegistryObject<Item> SOUVENIR_COIN = ITEMS.register("souvenir_coin", SouvenirCoinItem::new);
	public static final RegistryObject<Item> GOLDEN_GLASSES = ITEMS.register("golden_glasses", GoldenGlassesItem::new);
	public static final RegistryObject<Item> GOLDEN_STEAK = ITEMS.register("golden_steak", GoldenSteakItem::new);
	public static final RegistryObject<Item> GOLDEN_ARROW = ITEMS.register("golden_arrow", GoldenArrowItem::new);
	public static final RegistryObject<Item> GOLDEN_SHIELD = ITEMS.register("golden_shield", GoldenShieldItem::new);
	public static final RegistryObject<Item> SWIFT_BOOTS_DIAMOND = ITEMS.register("swift_boots_diamond", () -> new SwiftBootsItem(ArmorMaterials.DIAMOND, "swift_boots_diamond"));
	public static final RegistryObject<Item> SWIFT_BOOTS_NETHERITE = ITEMS.register("swift_boots_netherite", () -> new SwiftBootsItem(ArmorMaterials.NETHERITE, "swift_boots_netherite"));

	public static final RegistryObject<EntityType<GoldenArrowEntity>> GOLDEN_ARROW_ENTITY = ENTITIES.register("golden_arrow",
			() -> EntityType.Builder.<GoldenArrowEntity>of(GoldenArrowEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).clientTrackingRange(4).updateInterval(20).build("golden_arrow"));

	public static final RegistryObject<EntityType<GoldenCowEntity>> GOLDEN_COW = ENTITIES.register("golden_cow",
			() -> EntityType.Builder.<GoldenCowEntity>of(GoldenCowEntity::new, MobCategory.CREATURE).sized(0.9f, 1.4f).clientTrackingRange(10).build("golden_cow"));

	public static final RegistryObject<Item> GOLDEN_COW_SPAWN_EGG = ITEMS.register("golden_cow_spawn_egg",
			GoldenCowSpawnEggItem::new);

	public static final RegistryObject<BlockEntityType<LockedChestBlockEntity>> LOCKED_CHEST_BE = BLOCK_ENTITIES.register("locked_chest",
			() -> BlockEntityType.Builder.of(LockedChestBlockEntity::new, LOCKED_CHEST.get()).build(null));

	public static final RegistryObject<BlockEntityType<EnricherBlockEntity>> ENRICHER_BE = BLOCK_ENTITIES.register("enricher",
			() -> BlockEntityType.Builder.of(EnricherBlockEntity::new, ENRICHER.get()).build(null));

	public static final RegistryObject<RecipeSerializer<?>> SMELTING_COUNTED = RECIPE_SERIALIZERS.register("smelting_counted", CountedSmeltingRecipe.Serializer::new);

	public static final RegistryObject<Feature<NoneFeatureConfiguration>> SAND_QUARRY = FEATURES.register("sand_quarry", SandQuarryFeature::new);

	public static void register(IEventBus bus) {
		BLOCKS.register(bus);
		ITEMS.register(bus);
		BLOCK_ENTITIES.register(bus);
		ENTITIES.register(bus);
		RECIPE_SERIALIZERS.register(bus);
		FEATURES.register(bus);
		GoldNetwork.register();
	}

	public static net.minecraft.world.item.Item glowSandItem() {
		return deskped.sped.init.SpedModBlocks.GLOW_SAND.get().asItem();
	}

	public static net.minecraft.world.item.Item glowSandstoneItem() {
		return deskped.sped.init.SpedModBlocks.GLOW_SANDSTONE.get().asItem();
	}

	public static net.minecraft.world.item.Item unknownCoin() {
		return deskped.sped.init.SpedModItems.UNKNOWN_COIN.get();
	}

	public static net.minecraft.world.item.Item clearGold() {
		return deskped.sped.init.SpedModItems.CLEAR_GOLD.get();
	}
}
