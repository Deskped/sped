package deskped.sped.gold;

import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class SwiftBootsItem extends ArmorItem {

	private final String key;

	public SwiftBootsItem(ArmorMaterial material, String key) {
		super(material, ArmorItem.Type.BOOTS, new Item.Properties());
		this.key = key;
	}

	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		if (!level.isClientSide)
			player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 260, 0, false, false, false));
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("item.sped." + this.key + ".description_" + i));
	}
}
