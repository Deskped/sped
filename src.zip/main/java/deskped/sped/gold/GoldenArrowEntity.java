package deskped.sped.gold;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GoldenArrowEntity extends AbstractArrow {

	public GoldenArrowEntity(EntityType<? extends GoldenArrowEntity> type, Level level) {
		super(type, level);
		this.setBaseDamage(3.5D);
	}

	public GoldenArrowEntity(Level level, double x, double y, double z) {
		super(GoldReg.GOLDEN_ARROW_ENTITY.get(), x, y, z, level);
		this.setBaseDamage(3.5D);
	}

	public GoldenArrowEntity(Level level, LivingEntity shooter) {
		super(GoldReg.GOLDEN_ARROW_ENTITY.get(), shooter, level);
		this.setBaseDamage(3.5D);
	}

	@Override
	protected ItemStack getPickupItem() {
		return new ItemStack(GoldReg.GOLDEN_ARROW.get());
	}
}
