package deskped.sped.gold.client;

import deskped.sped.gold.GoldenArrowEntity;

import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public class GoldenArrowRenderer extends ArrowRenderer<GoldenArrowEntity> {

	private static final ResourceLocation TEXTURE = new ResourceLocation("sped", "textures/entity/golden_arrow.png");

	public GoldenArrowRenderer(EntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public ResourceLocation getTextureLocation(GoldenArrowEntity entity) {
		return TEXTURE;
	}
}
