package deskped.sped.gold.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ShieldModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class GoldenShieldRenderer extends BlockEntityWithoutLevelRenderer {

	private static final ResourceLocation TEXTURE = new ResourceLocation("sped", "textures/entity/golden_shield.png");
	private static GoldenShieldRenderer instance;

	private ShieldModel model;

	public GoldenShieldRenderer() {
		super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
	}

	public static GoldenShieldRenderer get() {
		if (instance == null)
			instance = new GoldenShieldRenderer();
		return instance;
	}

	@Override
	public void onResourceManagerReload(ResourceManager manager) {
		this.model = new ShieldModel(Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.SHIELD));
	}

	@Override
	public void renderByItem(ItemStack stack, ItemDisplayContext context, PoseStack pose, MultiBufferSource buffer, int light, int overlay) {
		if (this.model == null)
			this.model = new ShieldModel(Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.SHIELD));
		pose.pushPose();
		pose.scale(1.0f, -1.0f, -1.0f);
		VertexConsumer consumer = buffer.getBuffer(RenderType.entitySolid(TEXTURE));
		this.model.renderToBuffer(pose, consumer, light, overlay, 1.0f, 1.0f, 1.0f, 1.0f);
		pose.popPose();
	}
}
