package deskped.sped.gold.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public class GoldClientHooks {

	public static void openCodeScreen(BlockPos pos, boolean setMode) {
		Minecraft.getInstance().setScreen(new LockedChestCodeScreen(pos, setMode));
	}
}
