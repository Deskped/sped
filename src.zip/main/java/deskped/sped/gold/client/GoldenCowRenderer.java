package deskped.sped.gold.client;

import deskped.sped.gold.GoldenCowEntity;

import net.minecraft.client.model.CowModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GoldenCowRenderer extends MobRenderer<GoldenCowEntity, CowModel<GoldenCowEntity>> {

	private static final ResourceLocation TEXTURE = new ResourceLocation("sped", "textures/entity/golden_cow.png");

	public GoldenCowRenderer(EntityRendererProvider.Context context) {
		super(context, new CowModel<>(context.bakeLayer(ModelLayers.COW)), 0.7f);
	}

	@Override
	public ResourceLocation getTextureLocation(GoldenCowEntity entity) {
		return TEXTURE;
	}
}
