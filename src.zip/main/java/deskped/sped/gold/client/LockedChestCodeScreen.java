package deskped.sped.gold.client;

import deskped.sped.SpedMod;
import deskped.sped.gold.GoldNetwork;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public class LockedChestCodeScreen extends Screen {

	private final BlockPos pos;
	private final boolean setMode;
	private EditBox input;

	public LockedChestCodeScreen(BlockPos pos, boolean setMode) {
		super(Component.translatable(setMode ? "gui.sped.locked_chest.set" : "gui.sped.locked_chest.enter"));
		this.pos = pos;
		this.setMode = setMode;
	}

	@Override
	protected void init() {
		super.init();
		int cx = this.width / 2;
		int cy = this.height / 2;
		this.input = new EditBox(this.font, cx - 80, cy - 10, 160, 20, Component.translatable("gui.sped.locked_chest.code"));
		this.input.setMaxLength(16);
		this.input.setValue("");
		this.addRenderableWidget(this.input);
		this.setInitialFocus(this.input);
		this.addRenderableWidget(Button.builder(Component.translatable("gui.sped.locked_chest.confirm"), b -> submit()).bounds(cx - 80, cy + 18, 78, 20).build());
		this.addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), b -> this.onClose()).bounds(cx + 2, cy + 18, 78, 20).build());
	}

	private void submit() {
		String code = this.input.getValue().trim();
		if (code.isEmpty())
			return;
		SpedMod.PACKET_HANDLER.sendToServer(new GoldNetwork.SubmitCode(this.pos, code, this.setMode));
		this.onClose();
	}

	@Override
	public boolean keyPressed(int key, int scan, int modifiers) {
		if (key == 257 || key == 335) {
			submit();
			return true;
		}
		return super.keyPressed(key, scan, modifiers);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partial) {
		this.renderBackground(graphics);
		graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 34, 0xFFD24A);
		super.render(graphics, mouseX, mouseY, partial);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
