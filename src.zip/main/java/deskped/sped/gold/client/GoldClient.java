package deskped.sped.gold.client;

import deskped.sped.SpedMod;
import deskped.sped.gold.GoldReg;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class GoldClient {

	@SubscribeEvent
	public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(GoldReg.GOLDEN_COW.get(), GoldenCowRenderer::new);
		event.registerEntityRenderer(GoldReg.GOLDEN_ARROW_ENTITY.get(), GoldenArrowRenderer::new);
	}
}
