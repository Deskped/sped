package deskped.sped.gold;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

public class EnricherBlockEntity extends BlockEntity {

	public static final int WORK_TIME = 120;
	public static final float CLEAN_CHANCE = 0.33f;

	private int progress;

	public EnricherBlockEntity(BlockPos pos, BlockState state) {
		super(GoldReg.ENRICHER_BE.get(), pos, state);
	}

	@Override
	public void load(CompoundTag tag) {
		super.load(tag);
		this.progress = tag.getInt("Progress");
	}

	@Override
	protected void saveAdditional(CompoundTag tag) {
		super.saveAdditional(tag);
		tag.putInt("Progress", this.progress);
	}

	public static void serverTick(Level level, BlockPos pos, BlockState state, EnricherBlockEntity be) {
		BlockPos input = pos.above();
		boolean hasInput = level.getBlockState(input).is(Blocks.GOLD_BLOCK);
		if (!hasInput) {
			if (be.progress != 0) {
				be.progress = 0;
				be.setChanged();
			}
			setWorking(level, pos, state, false);
			return;
		}
		setWorking(level, pos, state, true);
		be.progress++;
		if (be.progress % 8 == 0 && level instanceof ServerLevel server) {
			server.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5, pos.getY() + 1.05, pos.getZ() + 0.5, 3, 0.25, 0.05, 0.25, 0.01);
			server.playSound(null, pos, SoundEvents.BLASTFURNACE_FIRE_CRACKLE, SoundSource.BLOCKS, 0.35f, 0.8f + level.random.nextFloat() * 0.2f);
		}
		if (be.progress < WORK_TIME)
			return;
		be.progress = 0;
		be.setChanged();
		level.removeBlock(input, false);
		boolean clean = level.random.nextFloat() < CLEAN_CHANCE;
		ItemStack result = clean ? new ItemStack(GoldReg.clearGold()) : new ItemStack(GoldReg.SLAG.get());
		output(level, pos, result);
		level.playSound(null, pos, clean ? SoundEvents.PLAYER_LEVELUP : SoundEvents.LAVA_EXTINGUISH, SoundSource.BLOCKS, 0.6f, clean ? 1.6f : 1.0f);
		if (level instanceof ServerLevel server)
			server.sendParticles(clean ? ParticleTypes.END_ROD : ParticleTypes.LARGE_SMOKE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 12, 0.3, 0.2, 0.3, 0.02);
	}

	private static void setWorking(Level level, BlockPos pos, BlockState state, boolean working) {
		if (state.hasProperty(EnricherBlock.WORKING) && state.getValue(EnricherBlock.WORKING) != working)
			level.setBlock(pos, state.setValue(EnricherBlock.WORKING, working), 3);
	}

	private static void output(Level level, BlockPos pos, ItemStack stack) {
		BlockEntity below = level.getBlockEntity(pos.below());
		if (below != null) {
			IItemHandler handler = below.getCapability(ForgeCapabilities.ITEM_HANDLER, Direction.UP).orElse(null);
			if (handler != null) {
				stack = ItemHandlerHelper.insertItem(handler, stack, false);
				if (stack.isEmpty())
					return;
			}
		}
		ItemEntity entity = new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, stack);
		entity.setDeltaMovement(0, 0.12, 0);
		entity.setDefaultPickUpDelay();
		level.addFreshEntity(entity);
	}
}
