package deskped.sped.gold;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class SouvenirCoinItem extends Item {

	public SouvenirCoinItem() {
		super(new Item.Properties().rarity(Rarity.RARE).stacksTo(64));
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("item.sped.souvenir_coin.description_" + i));
	}
}
