package deskped.sped.gold;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

import java.util.List;

public class GoldenGlassesItem extends ArmorItem {

	public GoldenGlassesItem() {
		super(MATERIAL, ArmorItem.Type.HELMET, new Item.Properties());
	}

	@Override
	public void onArmorTick(ItemStack stack, Level level, Player player) {
		if (!level.isClientSide)
			player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 260, 0, false, false, false));
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("item.sped.golden_glasses.description_" + i));
	}

	public static final ArmorMaterial MATERIAL = new ArmorMaterial() {
		@Override
		public int getDurabilityForType(ArmorItem.Type type) {
			return 165;
		}

		@Override
		public int getDefenseForType(ArmorItem.Type type) {
			return 1;
		}

		@Override
		public int getEnchantmentValue() {
			return 25;
		}

		@Override
		public SoundEvent getEquipSound() {
			return SoundEvents.ARMOR_EQUIP_GOLD;
		}

		@Override
		public Ingredient getRepairIngredient() {
			return Ingredient.of(Items.GOLD_INGOT);
		}

		@Override
		public String getName() {
			return "sped:glasses";
		}

		@Override
		public float getToughness() {
			return 0.0f;
		}

		@Override
		public float getKnockbackResistance() {
			return 0.0f;
		}
	};
}
