package deskped.sped.gold;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.util.RandomSource;

import java.util.List;

public class SieveBlock extends Block {

	private static final VoxelShape SHAPE = Shapes.or(box(0, 0, 0, 16, 2, 16), box(0, 2, 0, 2, 12, 16), box(14, 2, 0, 16, 12, 16), box(2, 2, 0, 14, 12, 2), box(2, 2, 14, 14, 12, 16));

	public SieveBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.SCAFFOLDING).strength(1.6f, 3f).noOcclusion());
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public void appendHoverText(ItemStack stack, BlockGetter level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("block.sped.sieve.description_" + i));
	}

	@Override
	public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		ItemStack held = player.getItemInHand(hand);
		if (!isSiftable(held))
			return InteractionResult.PASS;
		if (level.isClientSide)
			return InteractionResult.SUCCESS;
		RandomSource rnd = level.getRandom();
		boolean glow = held.is(GoldReg.glowSandItem());
		if (!player.getAbilities().instabuild)
			held.shrink(1);
		level.playSound(null, pos, SoundEvents.SAND_BREAK, SoundSource.BLOCKS, 0.7f, 0.9f + rnd.nextFloat() * 0.3f);
		for (ItemStack drop : roll(rnd, glow))
			spawn(level, pos, drop);
		return InteractionResult.CONSUME;
	}

	private static java.util.List<ItemStack> roll(RandomSource rnd, boolean glow) {
		java.util.List<ItemStack> out = new java.util.ArrayList<>();
		if (glow) {
			int nuggets = 2 + rnd.nextInt(3);
			out.add(new ItemStack(Items.GOLD_NUGGET, nuggets));
			if (rnd.nextFloat() < 0.10f)
				out.add(new ItemStack(GoldReg.unknownCoin()));
		} else {
			if (rnd.nextFloat() < 0.06f)
				out.add(new ItemStack(GoldReg.unknownCoin()));
			if (rnd.nextFloat() < 0.10f)
				out.add(new ItemStack(Items.GOLD_NUGGET));
			if (rnd.nextFloat() < 0.20f)
				out.add(new ItemStack(Items.FLINT));
			if (rnd.nextFloat() < 0.12f)
				out.add(new ItemStack(Items.CLAY_BALL));
		}
		return out;
	}

	private static void spawn(Level level, BlockPos pos, ItemStack stack) {
		if (stack.isEmpty())
			return;
		ItemEntity entity = new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.9, pos.getZ() + 0.5, stack);
		entity.setDeltaMovement(0, 0.05, 0);
		entity.setDefaultPickUpDelay();
		level.addFreshEntity(entity);
	}

	public static boolean isSiftable(ItemStack stack) {
		return stack.is(Items.SAND) || stack.is(Items.RED_SAND) || stack.is(GoldReg.glowSandItem());
	}
}
