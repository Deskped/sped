package deskped.sped.gold;

import deskped.sped.SpedMod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

public class GoldNetwork {

	public static void register() {
		SpedMod.addNetworkMessage(OpenCodeScreen.class, OpenCodeScreen::encode, OpenCodeScreen::decode, OpenCodeScreen::handle);
		SpedMod.addNetworkMessage(SubmitCode.class, SubmitCode::encode, SubmitCode::decode, SubmitCode::handle);
	}

	public static void openCodeScreen(ServerPlayer player, BlockPos pos, boolean setMode) {
		SpedMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> player), new OpenCodeScreen(pos, setMode));
	}

	public static class OpenCodeScreen {
		public final BlockPos pos;
		public final boolean setMode;

		public OpenCodeScreen(BlockPos pos, boolean setMode) {
			this.pos = pos;
			this.setMode = setMode;
		}

		public static void encode(OpenCodeScreen msg, FriendlyByteBuf buf) {
			buf.writeBlockPos(msg.pos);
			buf.writeBoolean(msg.setMode);
		}

		public static OpenCodeScreen decode(FriendlyByteBuf buf) {
			return new OpenCodeScreen(buf.readBlockPos(), buf.readBoolean());
		}

		public static void handle(OpenCodeScreen msg, java.util.function.Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context context = ctx.get();
			context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.gold.client.GoldClientHooks.openCodeScreen(msg.pos, msg.setMode)));
			context.setPacketHandled(true);
		}
	}

	public static class SubmitCode {
		public final BlockPos pos;
		public final String code;
		public final boolean setMode;

		public SubmitCode(BlockPos pos, String code, boolean setMode) {
			this.pos = pos;
			this.code = code;
			this.setMode = setMode;
		}

		public static void encode(SubmitCode msg, FriendlyByteBuf buf) {
			buf.writeBlockPos(msg.pos);
			buf.writeUtf(msg.code, 32);
			buf.writeBoolean(msg.setMode);
		}

		public static SubmitCode decode(FriendlyByteBuf buf) {
			return new SubmitCode(buf.readBlockPos(), buf.readUtf(32), buf.readBoolean());
		}

		public static void handle(SubmitCode msg, java.util.function.Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context context = ctx.get();
			context.enqueueWork(() -> {
				if (context.getDirection() != NetworkDirection.PLAY_TO_SERVER)
					return;
				ServerPlayer player = context.getSender();
				if (player == null)
					return;
				if (!player.level().isLoaded(msg.pos) || player.distanceToSqr(msg.pos.getX() + 0.5, msg.pos.getY() + 0.5, msg.pos.getZ() + 0.5) > 64.0)
					return;
				if (!(player.level().getBlockEntity(msg.pos) instanceof LockedChestBlockEntity be))
					return;
				boolean master = be.isOwner(player) || player.hasPermissions(2);
				if (msg.setMode) {
					if (!master)
						return;
					String code = msg.code == null ? "" : msg.code.trim();
					if (code.isEmpty())
						return;
					be.setCode(code);
					player.displayClientMessage(Component.translatable("message.sped.locked_chest.code_set", code), false);
					return;
				}
				if (be.matches(msg.code)) {
					LockedChestBlock.open(player, be);
				} else {
					player.displayClientMessage(Component.translatable("message.sped.locked_chest.wrong_code"), true);
				}
			});
			context.setPacketHandled(true);
		}
	}
}
