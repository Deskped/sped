package deskped.sped.gold;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.function.Consumer;

public class GoldenShieldItem extends ShieldItem {

	public GoldenShieldItem() {
		super(new Item.Properties().durability(1008));
	}

	@Override
	public String getDescriptionId(ItemStack stack) {
		return this.getDescriptionId();
	}

	@Override
	public boolean isValidRepairItem(ItemStack toRepair, ItemStack repair) {
		return repair.is(Items.GOLD_INGOT) || repair.is(GoldReg.GOLD_PLATE.get());
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> list, TooltipFlag flag) {
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("item.sped.golden_shield.description_" + i));
	}

	@Override
	public void initializeClient(Consumer<IClientItemExtensions> consumer) {
		consumer.accept(new IClientItemExtensions() {
			@Override
			public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
				return deskped.sped.gold.client.GoldenShieldRenderer.get();
			}
		});
	}
}
