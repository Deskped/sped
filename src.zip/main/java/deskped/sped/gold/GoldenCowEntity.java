package deskped.sped.gold;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

public class GoldenCowEntity extends Cow {

	public GoldenCowEntity(EntityType<? extends GoldenCowEntity> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createGoldenCowAttributes() {
		return Cow.createAttributes().add(Attributes.MAX_HEALTH, 12.0D);
	}

	@Nullable
	@Override
	public Cow getBreedOffspring(ServerLevel level, AgeableMob mate) {
		return null;
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return false;
	}

	@Override
	public boolean canFallInLove() {
		return false;
	}
}
