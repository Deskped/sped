package deskped.sped.gold;

import deskped.sped.init.SpedModBlocks;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public class SandQuarryFeature extends Feature<NoneFeatureConfiguration> {

	public SandQuarryFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		WorldGenLevel level = context.level();
		RandomSource random = context.random();
		BlockPos origin = context.origin();
		int radius = 6 + random.nextInt(5);
		int depth = 4 + random.nextInt(5);
		BlockState glowSand = SpedModBlocks.GLOW_SAND.get().defaultBlockState();
		BlockState glowSandstone = SpedModBlocks.GLOW_SANDSTONE.get().defaultBlockState();
		BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
		boolean placed = false;
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				double distance = Math.sqrt(dx * dx + dz * dz);
				if (distance > radius)
					continue;
				int x = origin.getX() + dx;
				int z = origin.getZ() + dz;
				int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
				if (level.isOutsideBuildHeight(surface))
					continue;
				int dig = (int) Math.round(depth * (1.0 - distance / radius));
				for (int y = surface; y > surface - dig; y--) {
					cursor.set(x, y, z);
					if (level.getBlockState(cursor).getFluidState().isEmpty())
						level.setBlock(cursor, Blocks.AIR.defaultBlockState(), 2);
				}
				int floor = surface - dig;
				for (int y = floor; y > floor - 3; y--) {
					cursor.set(x, y, z);
					if (level.isOutsideBuildHeight(y))
						break;
					if (level.getBlockState(cursor).isAir())
						continue;
					float roll = random.nextFloat();
					if (y == floor && roll < 0.72f)
						level.setBlock(cursor, glowSand, 2);
					else if (roll < 0.30f)
						level.setBlock(cursor, glowSandstone, 2);
					else if (roll < 0.36f)
						level.setBlock(cursor, Blocks.GOLD_ORE.defaultBlockState(), 2);
					else if (roll < 0.60f)
						level.setBlock(cursor, Blocks.SANDSTONE.defaultBlockState(), 2);
					placed = true;
				}
			}
		}
		return placed;
	}
}
