package deskped.sped.gold;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import net.minecraftforge.common.ForgeSpawnEggItem;

import java.util.List;

public class GoldenCowSpawnEggItem extends ForgeSpawnEggItem {

	public GoldenCowSpawnEggItem() {
		super(GoldReg.GOLDEN_COW, 0xE8C24A, 0xFFF3B0, new Item.Properties());
	}

	@Override
	public void appendHoverText(ItemStack stack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(stack, level, list, flag);
		for (int i = 0; i < 6; i++)
			list.add(Component.translatable("item.sped.golden_cow_spawn_egg.description_" + i));
	}
}
