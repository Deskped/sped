package deskped.sped.gold;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

import java.util.UUID;

public class LockedChestBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer {

	private static final int[] EMPTY_SLOTS = new int[0];

	private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);
	private String code = "";
	@Nullable
	private UUID owner;

	public LockedChestBlockEntity(BlockPos pos, BlockState state) {
		super(GoldReg.LOCKED_CHEST_BE.get(), pos, state);
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code == null ? "" : code.trim();
		this.setChanged();
	}

	public boolean hasCode() {
		return !code.isEmpty();
	}

	public boolean matches(String attempt) {
		return code.equals(attempt == null ? "" : attempt.trim());
	}

	@Nullable
	public UUID getOwner() {
		return owner;
	}

	public void setOwner(@Nullable UUID owner) {
		this.owner = owner;
		this.setChanged();
	}

	public boolean isOwner(Player player) {
		return owner == null || owner.equals(player.getUUID());
	}

	@Override
	public void load(CompoundTag tag) {
		super.load(tag);
		this.items = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
		ContainerHelper.loadAllItems(tag, this.items);
		this.code = tag.getString("LockCode");
		this.owner = tag.hasUUID("LockOwner") ? tag.getUUID("LockOwner") : null;
	}

	@Override
	protected void saveAdditional(CompoundTag tag) {
		super.saveAdditional(tag);
		ContainerHelper.saveAllItems(tag, this.items);
		tag.putString("LockCode", this.code);
		if (this.owner != null)
			tag.putUUID("LockOwner", this.owner);
	}

	@Override
	public int getContainerSize() {
		return 27;
	}

	@Override
	public boolean isEmpty() {
		for (ItemStack stack : this.items)
			if (!stack.isEmpty())
				return false;
		return true;
	}

	@Override
	public ItemStack getItem(int slot) {
		return this.items.get(slot);
	}

	@Override
	public ItemStack removeItem(int slot, int amount) {
		ItemStack stack = ContainerHelper.removeItem(this.items, slot, amount);
		if (!stack.isEmpty())
			this.setChanged();
		return stack;
	}

	@Override
	public ItemStack removeItemNoUpdate(int slot) {
		return ContainerHelper.takeItem(this.items, slot);
	}

	@Override
	public void setItem(int slot, ItemStack stack) {
		this.items.set(slot, stack);
		if (stack.getCount() > this.getMaxStackSize())
			stack.setCount(this.getMaxStackSize());
		this.setChanged();
	}

	@Override
	public boolean stillValid(Player player) {
		return this.level != null && this.level.getBlockEntity(this.worldPosition) == this && player.distanceToSqr(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5) <= 64.0;
	}

	@Override
	public void clearContent() {
		this.items.clear();
	}

	public NonNullList<ItemStack> getItems() {
		return this.items;
	}

	@Override
	protected Component getDefaultName() {
		return Component.translatable("block.sped.locked_chest");
	}

	@Override
	protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
		return ChestMenu.threeRows(id, inventory, this);
	}

	@Override
	public int[] getSlotsForFace(Direction side) {
		return EMPTY_SLOTS;
	}

	@Override
	public boolean canPlaceItemThroughFace(int slot, ItemStack stack, @Nullable Direction side) {
		return false;
	}

	@Override
	public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction side) {
		return false;
	}
}
