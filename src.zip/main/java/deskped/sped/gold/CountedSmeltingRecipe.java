package deskped.sped.gold;

import com.google.gson.JsonObject;

import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CookingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SmeltingRecipe;

public class CountedSmeltingRecipe extends SmeltingRecipe {

	public CountedSmeltingRecipe(ResourceLocation id, String group, CookingBookCategory category, Ingredient ingredient, ItemStack result, float experience, int cookingTime) {
		super(id, group, category, ingredient, result, experience, cookingTime);
	}

	@Override
	public RecipeSerializer<?> getSerializer() {
		return GoldReg.SMELTING_COUNTED.get();
	}

	public static class Serializer implements RecipeSerializer<CountedSmeltingRecipe> {

		@Override
		public CountedSmeltingRecipe fromJson(ResourceLocation id, JsonObject json) {
			String group = GsonHelper.getAsString(json, "group", "");
			Ingredient ingredient = Ingredient.fromJson(GsonHelper.isArrayNode(json, "ingredient") ? GsonHelper.getAsJsonArray(json, "ingredient") : GsonHelper.getAsJsonObject(json, "ingredient"));
			JsonObject resultJson = GsonHelper.getAsJsonObject(json, "result");
			ResourceLocation resultId = new ResourceLocation(GsonHelper.getAsString(resultJson, "item"));
			int count = GsonHelper.getAsInt(resultJson, "count", 1);
			ItemStack result = new ItemStack(BuiltInRegistries.ITEM.getOptional(resultId).orElseThrow(() -> new IllegalStateException("Item " + resultId + " does not exist")), count);
			float experience = GsonHelper.getAsFloat(json, "experience", 0.0F);
			int cookingTime = GsonHelper.getAsInt(json, "cookingtime", 200);
			return new CountedSmeltingRecipe(id, group, CookingBookCategory.MISC, ingredient, result, experience, cookingTime);
		}

		@Override
		public CountedSmeltingRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
			String group = buf.readUtf();
			CookingBookCategory category = buf.readEnum(CookingBookCategory.class);
			Ingredient ingredient = Ingredient.fromNetwork(buf);
			ItemStack result = buf.readItem();
			float experience = buf.readFloat();
			int cookingTime = buf.readVarInt();
			return new CountedSmeltingRecipe(id, group, category, ingredient, result, experience, cookingTime);
		}

		@Override
		public void toNetwork(FriendlyByteBuf buf, CountedSmeltingRecipe recipe) {
			buf.writeUtf(recipe.getGroup());
			buf.writeEnum(recipe.category());
			recipe.getIngredients().get(0).toNetwork(buf);
			buf.writeItem(recipe.getResultItem(RegistryAccess.EMPTY));
			buf.writeFloat(recipe.getExperience());
			buf.writeVarInt(recipe.getCookingTime());
		}
	}
}
