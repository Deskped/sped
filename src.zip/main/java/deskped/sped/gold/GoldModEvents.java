package deskped.sped.gold;

import deskped.sped.SpedMod;
import deskped.sped.init.SpedModTabs;

import net.minecraft.core.Position;
import net.minecraft.core.dispenser.AbstractProjectileDispenseBehavior;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.levelgen.Heightmap;

import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class GoldModEvents {

	@SubscribeEvent
	public static void attributes(EntityAttributeCreationEvent event) {
		event.put(GoldReg.GOLDEN_COW.get(), GoldenCowEntity.createGoldenCowAttributes().build());
	}

	@SubscribeEvent
	public static void spawnPlacement(SpawnPlacementRegisterEvent event) {
		event.register(GoldReg.GOLDEN_COW.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
	}

	@SubscribeEvent
	public static void commonSetup(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> DispenserBlock.registerBehavior(GoldReg.GOLDEN_ARROW.get(), new AbstractProjectileDispenseBehavior() {
			@Override
			protected Projectile getProjectile(Level level, Position position, ItemStack stack) {
				GoldenArrowEntity arrow = new GoldenArrowEntity(level, position.x(), position.y(), position.z());
				arrow.pickup = AbstractArrow.Pickup.ALLOWED;
				return arrow;
			}
		}));
	}

	@SubscribeEvent
	public static void tabContents(BuildCreativeModeTabContentsEvent event) {
		if (event.getTab() != SpedModTabs.RPED.get())
			return;
		event.accept(GoldReg.GOLD_PLATE.get());
		event.accept(GoldReg.SOUVENIR_COIN.get());
		event.accept(GoldReg.GOLDEN_GLASSES.get());
		event.accept(GoldReg.GOLDEN_STEAK.get());
		event.accept(GoldReg.GOLDEN_ARROW.get());
		event.accept(GoldReg.GOLDEN_SHIELD.get());
		event.accept(GoldReg.SWIFT_BOOTS_DIAMOND.get());
		event.accept(GoldReg.SWIFT_BOOTS_NETHERITE.get());
		event.accept(GoldReg.SLAG.get());
		event.accept(GoldReg.SLAG_BLOCK.get().asItem());
		event.accept(GoldReg.ENRICHER.get().asItem());
		event.accept(GoldReg.SIEVE.get().asItem());
		event.accept(GoldReg.LOCKED_CHEST.get().asItem());
		event.accept(GoldReg.GOLDEN_COW_SPAWN_EGG.get());
	}
}
