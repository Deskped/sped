package deskped.sped.gold;

import deskped.sped.SpedMod;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class GoldEvents {

	public static final String REINFORCE_TAG = "SpedGoldPlating";
	public static final int MAX_REINFORCE = 3;

	private static final UUID ARMOR_UUID = UUID.fromString("6f3b1c9a-1d21-4f5e-9a01-2c0d4b7e1a11");
	private static final UUID TOUGHNESS_UUID = UUID.fromString("6f3b1c9a-1d21-4f5e-9a01-2c0d4b7e1a12");
	private static final UUID KNOCKBACK_UUID = UUID.fromString("6f3b1c9a-1d21-4f5e-9a01-2c0d4b7e1a13");

	@SubscribeEvent
	public static void stripGoldFromMobDrops(LivingDropsEvent event) {
		if (event.getEntity() instanceof Player)
			return;
		if (event.getEntity() instanceof GoldenCowEntity)
			return;
		event.getDrops().removeIf(entity -> isGold(entity.getItem().getItem()));
	}

	private static boolean isGold(Item item) {
		return item == Items.GOLD_INGOT || item == Items.GOLD_NUGGET || item == Items.RAW_GOLD || item == Items.GOLD_BLOCK || item == Items.RAW_GOLD_BLOCK;
	}

	@SubscribeEvent
	public static void plateArmor(AnvilUpdateEvent event) {
		ItemStack left = event.getLeft();
		ItemStack right = event.getRight();
		if (!(left.getItem() instanceof ArmorItem armor))
			return;
		if (!right.is(GoldReg.GOLD_PLATE.get()) || right.getCount() < 4)
			return;
		if (armor.getMaterial() != ArmorMaterials.DIAMOND && armor.getMaterial() != ArmorMaterials.NETHERITE)
			return;
		int level = left.getTag() != null ? left.getTag().getInt(REINFORCE_TAG) : 0;
		if (level >= MAX_REINFORCE)
			return;
		ItemStack out = left.copy();
		applyReinforcement(out, armor, level + 1);
		if (event.getName() != null && !event.getName().isBlank())
			out.setHoverName(net.minecraft.network.chat.Component.literal(event.getName()));
		event.setOutput(out);
		event.setMaterialCost(4);
		event.setCost(5 + level * 4);
	}

	public static void applyReinforcement(ItemStack stack, ArmorItem armor, int level) {
		CompoundTag tag = stack.getOrCreateTag();
		tag.putInt(REINFORCE_TAG, level);
		EquipmentSlot slot = armor.getEquipmentSlot();
		ListTag modifiers = new ListTag();
		addModifier(modifiers, Attributes.ARMOR, "sped_armor", armor.getDefense() + level, ARMOR_UUID, slot);
		addModifier(modifiers, Attributes.ARMOR_TOUGHNESS, "sped_toughness", armor.getToughness() + level * 0.5D, TOUGHNESS_UUID, slot);
		double knockback = armor.getMaterial().getKnockbackResistance();
		if (knockback > 0)
			addModifier(modifiers, Attributes.KNOCKBACK_RESISTANCE, "sped_knockback", knockback, KNOCKBACK_UUID, slot);
		tag.put("AttributeModifiers", modifiers);
		Map<net.minecraft.world.item.enchantment.Enchantment, Integer> enchantments = EnchantmentHelper.getEnchantments(stack);
		enchantments.put(Enchantments.UNBREAKING, EnchantmentHelper.getItemEnchantmentLevel(Enchantments.UNBREAKING, stack) + 1);
		EnchantmentHelper.setEnchantments(enchantments, stack);
	}

	private static void addModifier(ListTag list, Attribute attribute, String name, double amount, UUID uuid, EquipmentSlot slot) {
		ResourceLocation id = BuiltInRegistries.ATTRIBUTE.getKey(attribute);
		if (id == null)
			return;
		CompoundTag entry = new CompoundTag();
		entry.putString("AttributeName", id.toString());
		entry.putString("Name", name);
		entry.putDouble("Amount", amount);
		entry.putInt("Operation", AttributeModifier.Operation.ADDITION.toValue());
		entry.putString("Slot", slot.getName());
		entry.putUUID("UUID", uuid);
		list.add(entry);
	}
}
