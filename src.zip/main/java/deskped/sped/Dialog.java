package deskped.sped;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.commands.Commands;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Dialog {
    public static final String MODID = "sped";

    public static final int TYPE_NARRATION = 0;
    public static final int TYPE_SAY = 1;
    public static final int TYPE_ACTION = 2;
    public static final int TYPE_WHISPER = 3;
    public static final int TYPE_SHOUT = 4;
    public static final int TYPE_OOC = 5;

    @SuppressWarnings("removal")
    private static final ResourceLocation PROTOCOL = new ResourceLocation(MODID + ":dialog_channel");

    public static SimpleChannel CHANNEL;
    private static final int PROTOCOL_VERSION = 2;
    private static final Map<UUID, String> playerNames = new ConcurrentHashMap<>();

    static Consumer<ServerToClientDialogMessage> serverToClientHandler = msg -> {};
    static Runnable openLoreHandler = () -> {};
    static Consumer<SyncLoreMessage> syncLoreHandler = msg -> {};

    public Dialog() {}

    @SubscribeEvent
    public static void init(FMLCommonSetupEvent event) {
        CHANNEL = NetworkRegistry.newSimpleChannel(
                PROTOCOL,
                () -> Integer.toString(PROTOCOL_VERSION),
                s -> true,
                s -> true
        );
        int id = 0;
        CHANNEL.registerMessage(id++, ClientToServerDialogMessage.class,
                ClientToServerDialogMessage::encode, ClientToServerDialogMessage::decode, ClientToServerDialogMessage::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, ServerToClientDialogMessage.class,
                ServerToClientDialogMessage::encode, ServerToClientDialogMessage::decode, ServerToClientDialogMessage::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, OpenLoreScreenMessage.class,
                OpenLoreScreenMessage::encode, OpenLoreScreenMessage::decode, OpenLoreScreenMessage::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, SyncLoreMessage.class,
                SyncLoreMessage::encode, SyncLoreMessage::decode, SyncLoreMessage::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, RpInputMessage.class,
                RpInputMessage::encode, RpInputMessage::decode, RpInputMessage::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    static String displayName(ServerPlayer sender) {
        String name = playerNames.get(sender.getUUID());
        if (name == null || name.trim().isEmpty()) name = sender.getName().getString();
        return name;
    }

    static void broadcast(ServerPlayer sender, String formatted, double radius, boolean named, boolean saveLore, int type) {
        MinecraftServer server = sender.getServer();
        if (server == null || CHANNEL == null) return;
        long start = System.currentTimeMillis();
        ServerToClientDialogMessage out = new ServerToClientDialogMessage(formatted, sender.getUUID(),
                sender.position().x, sender.position().y, sender.position().z, start, named, type);
        double r2 = radius * radius;
        for (ServerPlayer target : server.getPlayerList().getPlayers()) {
            if (target.distanceToSqr(sender) <= r2) {
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> target), out);
                if (saveLore) LoreStorage.append(target.getUUID(), formatted, start, server);
            }
        }
    }

    static void dispatch(ServerPlayer sender, String rest) {
        if (rest == null) return;
        if (rest.startsWith("%")) rest = rest.substring(1);
        if (rest.isEmpty()) return;
        String name = displayName(sender);
        char marker = rest.charAt(0);
        if (marker == '!') {
            String body = rest.substring(1).trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes(name + ": " + body), 20.0, true, true, TYPE_SAY);
        } else if (marker == '*') {
            String body = rest.substring(1).trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes("\u00A7o" + name + " " + body), 20.0, true, true, TYPE_ACTION);
        } else if (marker == '?') {
            String body = rest.substring(1).trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes("\u00A7o" + name + " \u0448\u0435\u043F\u0447\u0435\u0442: " + body), 8.0, false, false, TYPE_WHISPER);
        } else if (marker == '>') {
            String body = rest.substring(1).trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes("\u00A7l" + name + " \u043A\u0440\u0438\u0447\u0438\u0442: " + body), 45.0, true, true, TYPE_SHOUT);
        } else if (marker == '(') {
            String body = rest.substring(1).trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes("(( " + body + " ))"), 20.0, false, false, TYPE_OOC);
        } else {
            String body = rest.trim();
            if (body.isEmpty()) return;
            broadcast(sender, convertColorCodes("\u00A7o" + body), 20.0, false, false, TYPE_NARRATION);
        }
    }

    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {
        @SubscribeEvent
        public static void onRegisterCommands(RegisterCommandsEvent event) {
            event.getDispatcher().register(
                Commands.literal("sped")
                    .then(Commands.literal("setname")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String cur = playerNames.getOrDefault(player.getUUID(), "NPC");
                            ctx.getSource().sendSuccess(() -> Component.literal("Current name: " + cur + ". Usage: /sped setname <n>"), false);
                            return 1;
                        })
                        .then(Commands.argument("name", StringArgumentType.greedyString()).executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String name = StringArgumentType.getString(ctx, "name");
                            playerNames.put(player.getUUID(), name);
                            ctx.getSource().sendSuccess(() -> Component.literal("Name set to: " + name), false);
                            return 1;
                        })))
                    .then(Commands.literal("lore")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenLoreScreenMessage());
                            return 1;
                        }))
            );
        }

        @SubscribeEvent
        public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
            if (!(event.getEntity() instanceof ServerPlayer player)) return;
            MinecraftServer server = player.getServer();
            if (server == null || CHANNEL == null) return;
            LoreStorage.loadAndSend(player, server, CHANNEL);
        }

        @SubscribeEvent
        public static void onPlayerSave(PlayerEvent.SaveToFile event) {
            if (!(event.getEntity() instanceof ServerPlayer player)) return;
            MinecraftServer server = player.getServer();
            if (server == null) return;
            LoreStorage.save(player.getUUID(), server);
        }
    }

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class DialogClient {
        public static boolean rpMode = false;

        private static final long FADE = 1200L;
        private static final List<ActiveDialog> ACTIVE = new CopyOnWriteArrayList<>();

        private static Matrix4f projMatrix;
        private static Matrix4f viewMatrix;
        private static Vec3 camPos;
        private static float capturedPartial;

        private static final String[] RP_LINES = {
            "\u00A76\u00A7lSPED: \u0438\u0433\u0440\u0430 \u043F\u043E \u0440\u043E\u043B\u044F\u043C",
            "\u00A7e<\u0442\u0435\u043A\u0441\u0442> \u00A77\u0440\u0435\u043F\u043B\u0438\u043A\u0430",
            "\u00A7e!<\u0442\u0435\u043A\u0441\u0442> \u00A77\u0440\u0435\u043F\u043B\u0438\u043A\u0430 \u0441 \u0438\u043C\u0435\u043D\u0435\u043C",
            "\u00A7e*<\u0442\u0435\u043A\u0441\u0442> \u00A77\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
            "\u00A7e?<\u0442\u0435\u043A\u0441\u0442> \u00A77\u0448\u0451\u043F\u043E\u0442",
            "\u00A7e><\u0442\u0435\u043A\u0441\u0442> \u00A77\u043A\u0440\u0438\u043A",
            "\u00A7e(<\u0442\u0435\u043A\u0441\u0442> \u00A77\u0432\u043D\u0435 \u0440\u043F (\u041E\u041E\u0421)",
            "\u00A7e/sped setname <\u0438\u043C\u044F>",
            "\u00A78\u00BB Alt \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0435\u0442 \u0440\u0435\u0436\u0438\u043C: \u0441\u0435\u0440\u0432\u0435\u0440"
        };

        private static final String[] SERVER_LINES = {
            "\u00A76\u00A7lSPED: \u0441\u0435\u0440\u0432\u0435\u0440",
            "\u00A7e<\u0442\u0435\u043A\u0441\u0442> \u00A77\u043E\u0431\u044B\u0447\u043D\u044B\u0439 \u0447\u0430\u0442",
            "\u00A7e!<\u0442\u0435\u043A\u0441\u0442> \u00A77\u043E\u0431\u0449\u0438\u0439 \u0447\u0430\u0442",
            "\u00A78\u00BB Alt \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u0435\u0442 \u0440\u0435\u0436\u0438\u043C: \u0438\u0433\u0440\u0430 \u043F\u043E \u0440\u043E\u043B\u044F\u043C"
        };

        public static void onDialogReceived(ServerToClientDialogMessage msg) {
            ACTIVE.removeIf(a -> a.sender.equals(msg.senderUuid));
            ACTIVE.add(new ActiveDialog(msg.message, msg.senderUuid, msg.x, msg.y, msg.z, msg.startMillis, msg.type));
        }

        @SubscribeEvent
        public static void onClientChat(ClientChatEvent event) {
            String msg = event.getMessage();
            if (msg.startsWith("/")) return;
            if (rpMode) {
                event.setCanceled(true);
                if (CHANNEL != null && !msg.trim().isEmpty()) CHANNEL.sendToServer(new RpInputMessage(msg));
            }
        }

        @SubscribeEvent
        public static void onScreenKey(ScreenEvent.KeyPressed.Pre event) {
            if (!(event.getScreen() instanceof ChatScreen)) return;
            int k = event.getKeyCode();
            if (k == GLFW.GLFW_KEY_LEFT_ALT || k == GLFW.GLFW_KEY_RIGHT_ALT) {
                rpMode = !rpMode;
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onInputKey(InputEvent.Key event) {
            if (event.getAction() != GLFW.GLFW_PRESS) return;
            if (event.getKey() != GLFW.GLFW_KEY_LEFT_ALT && event.getKey() != GLFW.GLFW_KEY_RIGHT_ALT) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen != null) return;
            rpMode = !rpMode;
            if (mc.player != null) mc.player.displayClientMessage(
                Component.literal(rpMode
                    ? "\u00A76\u0420\u0435\u0436\u0438\u043C: \u00A7e\u0438\u0433\u0440\u0430 \u043F\u043E \u0440\u043E\u043B\u044F\u043C"
                    : "\u00A76\u0420\u0435\u0436\u0438\u043C: \u00A7e\u0441\u0435\u0440\u0432\u0435\u0440"), true);
        }

        @SubscribeEvent
        public static void onRenderLevel(RenderLevelStageEvent event) {
            if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
            projMatrix = new Matrix4f(event.getProjectionMatrix());
            viewMatrix = new Matrix4f(event.getPoseStack().last().pose());
            camPos = event.getCamera().getPosition();
            capturedPartial = event.getPartialTick();
        }

        @SubscribeEvent
        public static void onRenderGui(RenderGuiEvent.Post event) {
            renderDialogs(event.getGuiGraphics());
        }

        @SubscribeEvent
        public static void onScreenRender(ScreenEvent.Render.Post event) {
            GuiGraphics g = event.getGuiGraphics();
            renderDialogs(g);
            if (event.getScreen() instanceof ChatScreen) renderHint(g, event.getScreen().width, event.getScreen().height);
        }

        private static void renderHint(GuiGraphics g, int width, int height) {
            Font font = Minecraft.getInstance().font;
            String[] lines = rpMode ? RP_LINES : SERVER_LINES;
            int lineH = font.lineHeight + 1;
            int total = lines.length * lineH;
            int startY = height - 16 - total;
            int maxW = 0;
            for (String s : lines) maxW = Math.max(maxW, font.width(s));
            g.fill(width - maxW - 8, startY - 3, width - 2, height - 14, 0x90000000);
            for (int i = 0; i < lines.length; i++) {
                g.drawString(font, lines[i], width - font.width(lines[i]) - 6, startY + i * lineH, 0xFFFFFFFF, true);
            }
        }

        private static void renderDialogs(GuiGraphics g) {
            if (ACTIVE.isEmpty()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;
            Font font = mc.font;
            int sw = mc.getWindow().getGuiScaledWidth();
            int sh = mc.getWindow().getGuiScaledHeight();
            long now = System.currentTimeMillis();
            UUID selfId = mc.player != null ? mc.player.getUUID() : null;

            Matrix4f mvp = null;
            if (projMatrix != null && viewMatrix != null && camPos != null) {
                mvp = new Matrix4f(projMatrix);
                mvp.mul(viewMatrix);
            }

            for (ActiveDialog d : ACTIVE) {
                long age = now - d.start;
                if (age > d.lifetime) { ACTIVE.remove(d); continue; }

                float alpha;
                if (age < 200L) alpha = age / 200f;
                else if (age > d.lifetime - FADE) alpha = (d.lifetime - age) / (float) FADE;
                else alpha = 1f;
                alpha = Mth.clamp(alpha, 0.12f, 1f);

                float cx, cy;
                boolean isSelf = selfId != null && d.sender.equals(selfId);
                if (isSelf) {
                    cx = sw / 2f;
                    cy = sh - 52f;
                } else {
                    if (mvp == null) continue;
                    double wx = d.x, wy = d.y, wz = d.z;
                    Entity found = findEntity(mc, d.sender);
                    if (found != null) {
                        wx = Mth.lerp(capturedPartial, found.xo, found.getX());
                        wy = Mth.lerp(capturedPartial, found.yo, found.getY()) + found.getBbHeight();
                        wz = Mth.lerp(capturedPartial, found.zo, found.getZ());
                    }
                    wy += 0.6;
                    Vector4f p = new Vector4f((float) (wx - camPos.x), (float) (wy - camPos.y), (float) (wz - camPos.z), 1f);
                    p.mul(mvp);
                    float w = p.w();
                    if (w <= 0.05f) continue;
                    float ndcX = p.x() / w;
                    float ndcY = p.y() / w;
                    if (ndcX < -1.3f || ndcX > 1.3f || ndcY < -1.3f || ndcY > 1.3f) continue;
                    cx = (ndcX * 0.5f + 0.5f) * sw;
                    cy = (1f - (ndcY * 0.5f + 0.5f)) * sh;
                }

                if (d.type == TYPE_NARRATION) {
                    cy += Mth.sin((now % 2400L) / 2400f * (float) (Math.PI * 2.0)) * 3f;
                }

                drawWindow(g, font, cx, cy, d, alpha);
            }
        }

        private static Entity findEntity(Minecraft mc, UUID id) {
            for (Entity ent : mc.level.entitiesForRendering()) {
                if (id.equals(ent.getUUID())) return ent;
            }
            return null;
        }

        private static void drawWindow(GuiGraphics g, Font font, float cx, float cy, ActiveDialog d, float alpha) {
            int textColor = fadeArgb(baseColor(d.type), alpha);
            int bg = fadeArgb(bgColor(d.type), alpha);
            int border = fadeArgb(borderColor(d.type), alpha);
            float scale = scaleFor(d.type);
            String text = d.text;
            int tw = font.width(text);
            int th = font.lineHeight;
            int padX = 5, padY = 3;
            int boxW = tw + padX * 2;
            int boxH = th + padY * 2;

            var pose = g.pose();
            pose.pushPose();
            pose.translate(cx, cy, 0f);
            pose.scale(scale, scale, 1f);

            int x0 = -boxW / 2;
            int y0 = -boxH - 2;
            if ((bg >>> 24) != 0) g.fill(x0, y0, x0 + boxW, y0 + boxH, bg);
            if ((border >>> 24) != 0) {
                g.fill(x0, y0, x0 + boxW, y0 + 1, border);
                g.fill(x0, y0 + boxH - 1, x0 + boxW, y0 + boxH, border);
                g.fill(x0, y0, x0 + 1, y0 + boxH, border);
                g.fill(x0 + boxW - 1, y0, x0 + boxW, y0 + boxH, border);
            }
            g.drawString(font, text, x0 + padX, y0 + padY, textColor, true);

            pose.popPose();
        }

        private static int fadeArgb(int argb, float a) {
            int base = (argb >>> 24) & 0xFF;
            int na = Mth.clamp((int) (base * a), 0, 255);
            return (argb & 0x00FFFFFF) | (na << 24);
        }

        private static int baseColor(int type) {
            return switch (type) {
                case TYPE_SAY -> 0xFFFFFFFF;
                case TYPE_ACTION -> 0xFFE6B0FF;
                case TYPE_WHISPER -> 0xFFC2D2EC;
                case TYPE_SHOUT -> 0xFFFF7A60;
                case TYPE_OOC -> 0xFFA6B6C8;
                default -> 0xFFF4ECDA;
            };
        }

        private static int bgColor(int type) {
            return switch (type) {
                case TYPE_SAY -> 0xC0101010;
                case TYPE_ACTION -> 0xB0241038;
                case TYPE_WHISPER -> 0x90121C28;
                case TYPE_SHOUT -> 0xCC3A0806;
                case TYPE_OOC -> 0xA00E1218;
                default -> 0x00000000;
            };
        }

        private static int borderColor(int type) {
            return switch (type) {
                case TYPE_SAY -> 0xFF3A3A3A;
                case TYPE_ACTION -> 0xFF7A3CB0;
                case TYPE_WHISPER -> 0xFF2E4A66;
                case TYPE_SHOUT -> 0xFFB02010;
                case TYPE_OOC -> 0xFF2A3440;
                default -> 0x00000000;
            };
        }

        private static float scaleFor(int type) {
            return switch (type) {
                case TYPE_SHOUT -> 1.3f;
                case TYPE_WHISPER -> 0.85f;
                default -> 1.0f;
            };
        }

        static class ActiveDialog {
            final String text;
            final UUID sender;
            final double x, y, z;
            final long start;
            final int type;
            final long lifetime;

            ActiveDialog(String text, UUID sender, double x, double y, double z, long start, int type) {
                this.text = text; this.sender = sender;
                this.x = x; this.y = y; this.z = z;
                this.start = start; this.type = type;
                this.lifetime = Math.max(4000L, Math.min(12000L, 3000L + text.length() * 70L));
            }
        }
    }

    public static class OpenLoreScreenMessage {
        public static void encode(OpenLoreScreenMessage pkt, FriendlyByteBuf buf) {}
        public static OpenLoreScreenMessage decode(FriendlyByteBuf buf) { return new OpenLoreScreenMessage(); }
        public static void handle(OpenLoreScreenMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(openLoreHandler);
            ctx.get().setPacketHandled(true);
        }
    }

    public static class RpInputMessage {
        public final String text;

        public RpInputMessage(String text) { this.text = text; }

        public static void encode(RpInputMessage pkt, FriendlyByteBuf buf) {
            byte[] b = pkt.text.getBytes(StandardCharsets.UTF_8);
            buf.writeInt(b.length); buf.writeBytes(b);
        }

        public static RpInputMessage decode(FriendlyByteBuf buf) {
            int len = buf.readInt(); byte[] b = new byte[len]; buf.readBytes(b);
            return new RpInputMessage(new String(b, StandardCharsets.UTF_8));
        }

        public static void handle(RpInputMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> {
                ServerPlayer sender = c.getSender();
                if (sender == null) return;
                dispatch(sender, pkt.text);
            });
            c.setPacketHandled(true);
        }
    }

    public static class SyncLoreMessage {
        public final List<long[]> entries;
        public final List<String> raws;

        public SyncLoreMessage(List<long[]> entries, List<String> raws) {
            this.entries = entries; this.raws = raws;
        }

        public static void encode(SyncLoreMessage pkt, FriendlyByteBuf buf) {
            buf.writeInt(pkt.raws.size());
            for (int i = 0; i < pkt.raws.size(); i++) {
                buf.writeLong(pkt.entries.get(i)[0]);
                byte[] b = pkt.raws.get(i).getBytes(StandardCharsets.UTF_8);
                buf.writeInt(b.length); buf.writeBytes(b);
            }
        }

        public static SyncLoreMessage decode(FriendlyByteBuf buf) {
            int size = buf.readInt();
            List<long[]> entries = new ArrayList<>(size);
            List<String> raws = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                long ts = buf.readLong();
                int len = buf.readInt(); byte[] b = new byte[len]; buf.readBytes(b);
                entries.add(new long[]{ts});
                raws.add(new String(b, StandardCharsets.UTF_8));
            }
            return new SyncLoreMessage(entries, raws);
        }

        public static void handle(SyncLoreMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> syncLoreHandler.accept(pkt));
            ctx.get().setPacketHandled(true);
        }
    }

    public static class LoreStorage {
        private static java.io.File getFile(UUID uuid, MinecraftServer server) {
            java.io.File dir = new java.io.File(server.getWorldPath(
                    net.minecraft.world.level.storage.LevelResource.ROOT).toFile(), "sped_lore");
            dir.mkdirs();
            return new java.io.File(dir, uuid + ".dat");
        }

        public static void append(UUID uuid, String rawText, long timestamp, MinecraftServer server) {
            java.io.File f = getFile(uuid, server);
            try (java.io.BufferedWriter w = new java.io.BufferedWriter(
                    new java.io.OutputStreamWriter(new java.io.FileOutputStream(f, true), StandardCharsets.UTF_8))) {
                String escaped = rawText.replace("\\", "\\\\").replace("\n", "\\n");
                w.write(timestamp + "\t" + escaped + "\n");
            } catch (Exception ignored) {}
        }

        public static void save(UUID uuid, MinecraftServer server) {}

        public static void loadAndSend(ServerPlayer player, MinecraftServer server, SimpleChannel channel) {
            java.io.File f = getFile(player.getUUID(), server);
            List<long[]> entries = new ArrayList<>();
            List<String> raws = new ArrayList<>();
            if (f.exists()) {
                try (java.io.BufferedReader r = new java.io.BufferedReader(
                        new java.io.InputStreamReader(new java.io.FileInputStream(f), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        int tab = line.indexOf('\t');
                        if (tab < 0) continue;
                        try {
                            long ts = Long.parseLong(line.substring(0, tab));
                            String raw = line.substring(tab + 1).replace("\\n", "\n").replace("\\\\", "\\");
                            entries.add(new long[]{ts});
                            raws.add(raw);
                        } catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {}
            }
            if (entries.size() > 200) {
                entries = entries.subList(entries.size() - 200, entries.size());
                raws = raws.subList(raws.size() - 200, raws.size());
            }
            channel.send(PacketDistributor.PLAYER.with(() -> player), new SyncLoreMessage(entries, raws));
        }
    }

    public static class ClientToServerDialogMessage {
        public final String message;
        public final boolean named;

        public ClientToServerDialogMessage(String message, boolean named) {
            this.message = message; this.named = named;
        }

        public static void encode(ClientToServerDialogMessage pkt, FriendlyByteBuf buf) {
            byte[] bytes = pkt.message.getBytes(StandardCharsets.UTF_8);
            buf.writeInt(bytes.length); buf.writeBytes(bytes); buf.writeBoolean(pkt.named);
        }

        public static ClientToServerDialogMessage decode(FriendlyByteBuf buf) {
            int len = buf.readInt(); byte[] bytes = new byte[len]; buf.readBytes(bytes);
            return new ClientToServerDialogMessage(new String(bytes, StandardCharsets.UTF_8), buf.readBoolean());
        }

        public static void handle(ClientToServerDialogMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context context = ctx.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null) return;
                String outMsg = pkt.named ? displayName(sender) + ": " + pkt.message : pkt.message;
                outMsg = convertColorCodes(outMsg);
                broadcast(sender, outMsg, 20.0, pkt.named, pkt.named, pkt.named ? TYPE_SAY : TYPE_NARRATION);
            });
            context.setPacketHandled(true);
        }
    }

    public static class ServerToClientDialogMessage {
        public final String message;
        public final UUID senderUuid;
        public final double x, y, z;
        public final long startMillis;
        public final boolean named;
        public final int type;

        public ServerToClientDialogMessage(String message, UUID senderUuid, double x, double y, double z,
                                           long startMillis, boolean named, int type) {
            this.message = message; this.senderUuid = senderUuid;
            this.x = x; this.y = y; this.z = z;
            this.startMillis = startMillis; this.named = named; this.type = type;
        }

        public static void encode(ServerToClientDialogMessage pkt, FriendlyByteBuf buf) {
            byte[] bytes = pkt.message.getBytes(StandardCharsets.UTF_8);
            buf.writeInt(bytes.length); buf.writeBytes(bytes);
            buf.writeLong(pkt.senderUuid.getMostSignificantBits());
            buf.writeLong(pkt.senderUuid.getLeastSignificantBits());
            buf.writeDouble(pkt.x); buf.writeDouble(pkt.y); buf.writeDouble(pkt.z);
            buf.writeLong(pkt.startMillis); buf.writeBoolean(pkt.named); buf.writeInt(pkt.type);
        }

        public static ServerToClientDialogMessage decode(FriendlyByteBuf buf) {
            int len = buf.readInt(); byte[] bytes = new byte[len]; buf.readBytes(bytes);
            String msg = new String(bytes, StandardCharsets.UTF_8);
            UUID uuid = new UUID(buf.readLong(), buf.readLong());
            double x = buf.readDouble(), y = buf.readDouble(), z = buf.readDouble();
            long start = buf.readLong(); boolean named = buf.readBoolean(); int type = buf.readInt();
            return new ServerToClientDialogMessage(msg, uuid, x, y, z, start, named, type);
        }

        public static void handle(ServerToClientDialogMessage pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DialogClient.onDialogReceived(pkt)));
            ctx.get().setPacketHandled(true);
        }
    }

    @Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ServerChatInterceptor {
        @SubscribeEvent(priority = EventPriority.HIGH)
        public static void onServerChat(ServerChatEvent event) {
            Component comp = event.getMessage();
            String msg = comp == null ? "" : comp.getString();
            Player p = event.getPlayer();
            if (!(p instanceof ServerPlayer sender)) return;
            if (msg.startsWith("%")) {
                event.setCanceled(true);
                dispatch(sender, msg.substring(1));
            }
        }
    }

    static int colorFromCode(char c) {
        return switch (c) {
            case '0' -> 0x000000; case '1' -> 0x0000AA; case '2' -> 0x00AA00; case '3' -> 0x00AAAA;
            case '4' -> 0xAA0000; case '5' -> 0xAA00AA; case '6' -> 0xFFAA00; case '7' -> 0xAAAAAA;
            case '8' -> 0x555555; case '9' -> 0x5555FF; case 'a' -> 0x55FF55; case 'b' -> 0x55FFFF;
            case 'c' -> 0xFF5555; case 'd' -> 0xFF55FF; case 'e' -> 0xFFFF55; case 'f' -> 0xFFFFFF;
            default  -> 0xCCCCCC;
        };
    }

    private static String convertColorCodes(String s) {
        if (s == null) return null;
        return s.replace('&', '\u00A7');
    }
}
