package deskped.sped.voice.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.player.Player;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;

import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import deskped.sped.SpedMod;
import deskped.sped.voice.VoiceNet;
import deskped.sped.voice.client.ui.VoiceSettingsScreen;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT)
public class VoiceClient {

	public static final int MODE_PTT = 0;
	public static final int MODE_VOICE = 1;

	public static volatile int mode = MODE_VOICE;
	public static volatile double thresholdDb = -50.0D;
	public static volatile float micVolume = 1.0F;
	public static volatile float mainVolume = 1.0F;
	public static volatile int pitch = VoiceNet.PITCH_DEFAULT;
	public static volatile String micDevice = "";
	public static volatile boolean muted = false;
	public static volatile boolean deafened = false;
	public static volatile boolean serverMuted = false;

	public static volatile boolean ready = false;
	public static volatile boolean serverEnabled = true;
	public static volatile float serverDistance = 48.0F;
	public static volatile float serverWhisper = 12.0F;

	public static volatile boolean pttDown = false;
	public static volatile boolean whisperDown = false;
	public static volatile boolean testMic = false;

	public static volatile UUID myId = null;
	public static volatile String group = "";
	public static volatile boolean groupsDirty = false;
	public static final List<String> groupNames = new ArrayList<>();
	public static final List<Integer> groupCounts = new ArrayList<>();

	public static final Map<UUID, Float> playerVolumes = new ConcurrentHashMap<>();
	public static final Map<UUID, Long> talking = new ConcurrentHashMap<>();
	public static final Map<UUID, Byte> talkingFlags = new ConcurrentHashMap<>();

	private static MicThread mic;
	private static VoiceOutput output;
	private static boolean configLoaded = false;

	@SubscribeEvent
	public static void onLogin(ClientPlayerNetworkEvent.LoggingIn event) {
		loadConfig();
		myId = event.getPlayer().getUUID();
		ready = false;
		serverMuted = false;
		group = "";
		talking.clear();
		talkingFlags.clear();
		startAudio();
	}

	@SubscribeEvent
	public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
		stopAudio();
		ready = false;
		serverMuted = false;
		testMic = false;
		group = "";
		talking.clear();
		talkingFlags.clear();
	}

	@SubscribeEvent
	public static void onClientTick(TickEvent.ClientTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || VoiceKeys.PTT == null)
			return;
		long window = mc.getWindow().getWindow();
		pttDown = rawDown(VoiceKeys.PTT, window);
		whisperDown = rawDown(VoiceKeys.WHISPER, window);
		while (VoiceKeys.MUTE.consumeClick()) {
			muted = !muted;
			saveConfig();
		}
		while (VoiceKeys.DEAFEN.consumeClick()) {
			deafened = !deafened;
			saveConfig();
		}
		while (VoiceKeys.MENU.consumeClick()) {
			if (mc.screen == null)
				mc.setScreen(new VoiceSettingsScreen(null));
		}
		long now = System.currentTimeMillis();
		talking.entrySet().removeIf(e -> now - e.getValue() > 2000L);
	}

	@SubscribeEvent
	public static void onNameTag(RenderNameTagEvent event) {
		if (!(event.getEntity() instanceof Player pl))
			return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || pl == mc.player)
			return;
		Long t = talking.get(pl.getUUID());
		if (t == null || System.currentTimeMillis() - t > 300L)
			return;
		Byte fl = talkingFlags.get(pl.getUUID());
		boolean whisper = fl != null && (fl & VoiceNet.FLAG_WHISPER) != 0;
		int r = whisper ? 190 : 90;
		int g = whisper ? 130 : 255;
		int b = whisper ? 255 : 190;
		PoseStack ps = event.getPoseStack();
		ps.pushPose();
		ps.translate(0.0D, pl.getBbHeight() + 0.5F, 0.0D);
		ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
		ps.scale(-0.025F, -0.025F, 0.025F);
		Matrix4f m = ps.last().pose();
		VertexConsumer vc = event.getMultiBufferSource().getBuffer(RenderType.debugQuads());
		quad(vc, m, -2, -13, 2, -6, r, g, b);
		quad(vc, m, -4, -9, -3, -4, r, g, b);
		quad(vc, m, 3, -9, 4, -4, r, g, b);
		quad(vc, m, -3, -5, 3, -4, r, g, b);
		quad(vc, m, -1, -4, 1, -2, r, g, b);
		ps.popPose();
	}

	private static void quad(VertexConsumer vc, Matrix4f m, float x1, float y1, float x2, float y2, int r, int g, int b) {
		vc.vertex(m, x1, y1, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x1, y2, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x2, y2, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x2, y1, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x2, y1, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x2, y2, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x1, y2, 0.0F).color(r, g, b, 255).endVertex();
		vc.vertex(m, x1, y1, 0.0F).color(r, g, b, 255).endVertex();
	}

	private static boolean rawDown(KeyMapping key, long window) {
		if (key == null || key.isUnbound())
			return false;
		InputConstants.Key k = key.getKey();
		if (k.getType() == InputConstants.Type.KEYSYM)
			return InputConstants.isKeyDown(window, k.getValue());
		if (k.getType() == InputConstants.Type.MOUSE)
			return GLFW.glfwGetMouseButton(window, k.getValue()) == GLFW.GLFW_PRESS;
		return false;
	}

	public static void onVoice(VoiceNet.VoiceS2C msg) {
		talking.put(msg.id, System.currentTimeMillis());
		talkingFlags.put(msg.id, msg.flags);
		if (deafened)
			return;
		VoiceOutput out = output;
		if (out != null)
			out.enqueue(msg.id, msg.x, msg.y, msg.z, msg.flags, msg.pitch, msg.data);
	}

	public static void onConfig(VoiceNet.ConfigS2C msg) {
		serverEnabled = msg.enabled;
		serverDistance = msg.distance;
		serverWhisper = msg.whisper;
		ready = true;
	}

	public static void onMute(VoiceNet.MuteS2C msg) {
		serverMuted = msg.muted;
	}

	public static void onGroups(VoiceNet.GroupsS2C msg) {
		synchronized (groupNames) {
			group = msg.own;
			groupNames.clear();
			groupNames.addAll(msg.names);
			groupCounts.clear();
			groupCounts.addAll(msg.counts);
		}
		groupsDirty = true;
	}

	public static boolean consumeGroupsDirty() {
		if (!groupsDirty)
			return false;
		groupsDirty = false;
		return true;
	}

	public static void markSelfTalking(byte flags) {
		UUID id = myId;
		if (id != null) {
			talking.put(id, System.currentTimeMillis());
			talkingFlags.put(id, flags);
		}
	}

	public static boolean selfTalking() {
		UUID id = myId;
		if (id == null)
			return false;
		Long t = talking.get(id);
		return t != null && System.currentTimeMillis() - t < 300L;
	}

	public static double micLevelDb() {
		MicThread m = mic;
		return m == null ? -127.0D : m.levelDb;
	}

	public static boolean micOk() {
		MicThread m = mic;
		return m != null && m.ok;
	}

	public static float volumeFor(UUID id) {
		Float v = playerVolumes.get(id);
		return v == null ? 1.0F : v;
	}

	public static void sendVoiceFrame(byte flags, byte[] data) {
		VoiceNet.sendToServer(new VoiceNet.VoiceC2S(flags, pitch, data));
	}

	public static void feedSelf(short[] pcm) {
		VoiceOutput out = output;
		if (out != null)
			out.enqueueSelf(pcm);
	}

	public static void restartMic() {
		MicThread m = mic;
		if (m != null)
			m.shutdown();
		mic = new MicThread();
		mic.start();
	}

	private static void startAudio() {
		stopAudio();
		output = new VoiceOutput();
		output.start();
		mic = new MicThread();
		mic.start();
	}

	private static void stopAudio() {
		MicThread m = mic;
		mic = null;
		if (m != null)
			m.shutdown();
		VoiceOutput o = output;
		output = null;
		if (o != null)
			o.shutdown();
	}

	private static Path configPath() {
		return FMLPaths.CONFIGDIR.get().resolve("sped_voice_client.properties");
	}

	public static void loadConfig() {
		if (configLoaded)
			return;
		configLoaded = true;
		Path path = configPath();
		if (!Files.exists(path))
			return;
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
		} catch (IOException e) {
			return;
		}
		mode = "0".equals(props.getProperty("mode")) ? MODE_PTT : MODE_VOICE;
		thresholdDb = parse(props.getProperty("threshold_db"), -50.0D, -80.0D, 0.0D);
		micVolume = (float) parse(props.getProperty("mic_volume"), 1.0D, 0.0D, 2.0D);
		mainVolume = (float) parse(props.getProperty("main_volume"), 1.0D, 0.0D, 2.0D);
		pitch = (int) parse(props.getProperty("pitch"), VoiceNet.PITCH_DEFAULT, VoiceNet.PITCH_MIN, VoiceNet.PITCH_MAX);
		micDevice = props.getProperty("mic_device", "");
		muted = Boolean.parseBoolean(props.getProperty("muted", "false"));
		deafened = Boolean.parseBoolean(props.getProperty("deafened", "false"));
		for (String key : props.stringPropertyNames()) {
			if (key.startsWith("volume.")) {
				try {
					UUID id = UUID.fromString(key.substring(7));
					playerVolumes.put(id, (float) parse(props.getProperty(key), 1.0D, 0.0D, 2.0D));
				} catch (IllegalArgumentException ignored) {
				}
			}
		}
	}

	public static void saveConfig() {
		Properties props = new Properties();
		props.setProperty("mode", String.valueOf(mode));
		props.setProperty("threshold_db", String.valueOf(thresholdDb));
		props.setProperty("mic_volume", String.valueOf(micVolume));
		props.setProperty("main_volume", String.valueOf(mainVolume));
		props.setProperty("pitch", String.valueOf(pitch));
		props.setProperty("mic_device", micDevice);
		props.setProperty("muted", String.valueOf(muted));
		props.setProperty("deafened", String.valueOf(deafened));
		for (Map.Entry<UUID, Float> e : playerVolumes.entrySet())
			props.setProperty("volume." + e.getKey(), String.valueOf(e.getValue()));
		try (OutputStream out = Files.newOutputStream(configPath())) {
			props.store(out, "SPED voice client config");
		} catch (IOException ignored) {
		}
	}

	private static double parse(String s, double def, double min, double max) {
		if (s == null)
			return def;
		try {
			return Math.max(min, Math.min(max, Double.parseDouble(s.trim())));
		} catch (NumberFormatException e) {
			return def;
		}
	}
}
