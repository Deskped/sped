package deskped.sped.voice.client;

import net.minecraft.client.Minecraft;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

import java.util.ArrayList;
import java.util.List;

import deskped.sped.voice.Adpcm;
import deskped.sped.voice.VoiceNet;

@OnlyIn(Dist.CLIENT)
public class MicThread extends Thread {

	public static final int SAMPLE_RATE = 48000;
	public static final int FRAME_SAMPLES = 960;
	public static final AudioFormat FORMAT = new AudioFormat(SAMPLE_RATE, 16, 1, true, false);

	public volatile double levelDb = -127.0D;
	public volatile boolean ok = false;

	private volatile boolean running = true;
	private TargetDataLine line;
	private final int[] codecState = new int[1];
	private long lastLoud = 0L;
	private boolean wasActive = false;

	public MicThread() {
		super("sped-voice-mic");
		setDaemon(true);
	}

	public void shutdown() {
		running = false;
		TargetDataLine l = line;
		if (l != null) {
			try {
				l.stop();
				l.close();
			} catch (Exception ignored) {
			}
		}
		interrupt();
	}

	@Override
	public void run() {
		try {
			line = openLine();
			line.start();
			ok = true;
		} catch (Exception e) {
			ok = false;
			levelDb = -127.0D;
			return;
		}
		byte[] raw = new byte[FRAME_SAMPLES * 2];
		short[] pcm = new short[FRAME_SAMPLES];
		while (running) {
			int read = 0;
			try {
				while (read < raw.length && running) {
					int n = line.read(raw, read, raw.length - read);
					if (n <= 0)
						break;
					read += n;
				}
			} catch (Exception e) {
				break;
			}
			if (read < raw.length)
				continue;
			float gain = VoiceClient.micVolume;
			long sumSq = 0L;
			for (int i = 0; i < FRAME_SAMPLES; i++) {
				int s = (short) ((raw[i * 2] & 0xFF) | (raw[i * 2 + 1] << 8));
				s = Math.round(s * gain);
				if (s > 32767)
					s = 32767;
				else if (s < -32768)
					s = -32768;
				pcm[i] = (short) s;
				sumSq += (long) s * s;
			}
			double rms = Math.sqrt(sumSq / (double) FRAME_SAMPLES);
			levelDb = rms < 1.0D ? -127.0D : 20.0D * Math.log10(rms / 32767.0D);
			long now = System.currentTimeMillis();
			if (levelDb > VoiceClient.thresholdDb)
				lastLoud = now;
			boolean whisper = VoiceClient.whisperDown;
			boolean talkKey = VoiceClient.mode == VoiceClient.MODE_PTT ? VoiceClient.pttDown : now - lastLoud < 250L;
			boolean active = (talkKey || whisper) && !VoiceClient.muted && !VoiceClient.deafened && !VoiceClient.serverMuted && VoiceClient.ready && VoiceClient.serverEnabled && connected();
			if (VoiceClient.testMic)
				VoiceClient.feedSelf(pcm.clone());
			if (active) {
				if (!wasActive)
					codecState[0] = 0;
				byte flags = whisper ? VoiceNet.FLAG_WHISPER : 0;
				byte[] data = Adpcm.encode(pcm, codecState);
				VoiceClient.sendVoiceFrame(flags, data);
				VoiceClient.markSelfTalking(flags);
			}
			wasActive = active;
		}
		TargetDataLine l = line;
		if (l != null) {
			try {
				l.stop();
				l.close();
			} catch (Exception ignored) {
			}
		}
	}

	private boolean connected() {
		return Minecraft.getInstance().getConnection() != null;
	}

	private TargetDataLine openLine() throws Exception {
		DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
		String wanted = VoiceClient.micDevice;
		if (wanted != null && !wanted.isEmpty()) {
			for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
				if (wanted.equals(mi.getName())) {
					Mixer mixer = AudioSystem.getMixer(mi);
					if (mixer.isLineSupported(info)) {
						TargetDataLine l = (TargetDataLine) mixer.getLine(info);
						l.open(FORMAT, FRAME_SAMPLES * 8);
						return l;
					}
				}
			}
		}
		TargetDataLine l = (TargetDataLine) AudioSystem.getLine(info);
		l.open(FORMAT, FRAME_SAMPLES * 8);
		return l;
	}

	public static List<String> listDevices() {
		List<String> out = new ArrayList<>();
		DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
		for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
			try {
				if (AudioSystem.getMixer(mi).isLineSupported(info))
					out.add(mi.getName());
			} catch (Exception ignored) {
			}
		}
		return out;
	}
}
