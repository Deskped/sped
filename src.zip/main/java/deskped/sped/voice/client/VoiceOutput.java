package deskped.sped.voice.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import deskped.sped.voice.Adpcm;
import deskped.sped.voice.VoiceNet;

@OnlyIn(Dist.CLIENT)
public class VoiceOutput extends Thread {

	private static final UUID SELF = new UUID(0L, 0L);
	private static final int POOL = 24;
	private static final int MAX_QUEUED = 10;

	private static class Frame {
		final UUID id;
		final float x;
		final float y;
		final float z;
		final byte flags;
		final int pitch;
		final byte[] data;
		final short[] pcm;

		Frame(UUID id, float x, float y, float z, byte flags, int pitch, byte[] data, short[] pcm) {
			this.id = id;
			this.x = x;
			this.y = y;
			this.z = z;
			this.flags = flags;
			this.pitch = pitch;
			this.data = data;
			this.pcm = pcm;
		}
	}

	private static class Src {
		int source = -1;
		int[] buffers;
		final ArrayDeque<Integer> free = new ArrayDeque<>();
		long lastUse = System.currentTimeMillis();
	}

	private final LinkedBlockingQueue<Frame> queue = new LinkedBlockingQueue<>(256);
	private final Map<UUID, Src> sources = new HashMap<>();
	private final ByteBuffer scratch = BufferUtils.createByteBuffer(MicThread.FRAME_SAMPLES * 2);
	private volatile boolean running = true;
	private long lastSweep = 0L;

	public VoiceOutput() {
		super("sped-voice-out");
		setDaemon(true);
	}

	public void enqueue(UUID id, float x, float y, float z, byte flags, int pitch, byte[] data) {
		Frame f = new Frame(id, x, y, z, flags, pitch, data, null);
		if (!queue.offer(f)) {
			queue.poll();
			queue.offer(f);
		}
	}

	public void enqueueSelf(short[] pcm) {
		Frame f = new Frame(SELF, 0.0F, 0.0F, 0.0F, VoiceNet.FLAG_GROUP_FAR, VoiceClient.pitch, null, pcm);
		if (!queue.offer(f)) {
			queue.poll();
			queue.offer(f);
		}
	}

	public void shutdown() {
		running = false;
		interrupt();
	}

	@Override
	public void run() {
		while (running) {
			Frame f;
			try {
				f = queue.poll(50L, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				break;
			}
			try {
				if (f != null)
					feed(f);
				long now = System.currentTimeMillis();
				if (now - lastSweep > 1000L) {
					lastSweep = now;
					sweep(now);
				}
			} catch (Exception ignored) {
			}
		}
		try {
			for (Src s : sources.values())
				destroy(s);
		} catch (Exception ignored) {
		}
		sources.clear();
	}

	private void feed(Frame f) {
		Src s = sources.get(f.id);
		if (s == null) {
			s = create();
			if (s == null)
				return;
			sources.put(f.id, s);
		}
		s.lastUse = System.currentTimeMillis();
		reclaim(s);
		if (AL10.alGetSourcei(s.source, AL10.AL_BUFFERS_QUEUED) > MAX_QUEUED)
			return;
		Integer buf = s.free.poll();
		if (buf == null)
			return;
		short[] pcm = f.pcm != null ? f.pcm : Adpcm.decode(f.data, MicThread.FRAME_SAMPLES);
		scratch.clear();
		for (short v : pcm)
			scratch.putShort(v);
		scratch.flip();
		AL10.alBufferData(buf, AL10.AL_FORMAT_MONO16, scratch, MicThread.SAMPLE_RATE);
		applySpatial(s, f);
		AL10.alSourceQueueBuffers(s.source, buf);
		int state = AL10.alGetSourcei(s.source, AL10.AL_SOURCE_STATE);
		int queued = AL10.alGetSourcei(s.source, AL10.AL_BUFFERS_QUEUED);
		if (state != AL10.AL_PLAYING && queued >= 3)
			AL10.alSourcePlay(s.source);
		AL10.alGetError();
	}

	private void applySpatial(Src s, Frame f) {
		boolean relative = (f.flags & VoiceNet.FLAG_GROUP_FAR) != 0;
		float base = VoiceClient.mainVolume * (f.id.equals(SELF) ? 1.0F : VoiceClient.volumeFor(f.id));
		float gain;
		if (relative) {
			AL10.alSourcei(s.source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
			AL10.alSource3f(s.source, AL10.AL_POSITION, 0.0F, 0.0F, 0.0F);
			gain = base;
		} else {
			AL10.alSourcei(s.source, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
			AL10.alSource3f(s.source, AL10.AL_POSITION, f.x, f.y, f.z);
			float maxD = (f.flags & VoiceNet.FLAG_WHISPER) != 0 ? VoiceClient.serverWhisper : VoiceClient.serverDistance;
			Vec3 cam = cameraPos();
			float d = (float) Math.sqrt((cam.x - f.x) * (cam.x - f.x) + (cam.y - f.y) * (cam.y - f.y) + (cam.z - f.z) * (cam.z - f.z));
			float fall = maxD <= 0.0F ? 0.0F : 1.0F - d / maxD;
			if (fall < 0.0F)
				fall = 0.0F;
			gain = base * fall;
		}
		if (gain > 4.0F)
			gain = 4.0F;
		AL10.alSourcef(s.source, AL10.AL_GAIN, gain);
		AL10.alSourcef(s.source, AL10.AL_PITCH, VoiceNet.clampPitch(f.pitch) / 100.0F);
	}

	private Vec3 cameraPos() {
		try {
			return Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
		} catch (Exception e) {
			return Vec3.ZERO;
		}
	}

	private Src create() {
		int src = AL10.alGenSources();
		if (AL10.alGetError() != AL10.AL_NO_ERROR)
			return null;
		Src s = new Src();
		s.source = src;
		s.buffers = new int[POOL];
		AL10.alGenBuffers(s.buffers);
		for (int b : s.buffers)
			s.free.add(b);
		AL10.alSourcef(src, AL10.AL_ROLLOFF_FACTOR, 0.0F);
		AL10.alSourcef(src, AL10.AL_PITCH, 1.0F);
		AL10.alGetError();
		return s;
	}

	private void reclaim(Src s) {
		int processed = AL10.alGetSourcei(s.source, AL10.AL_BUFFERS_PROCESSED);
		while (processed-- > 0) {
			int b = AL10.alSourceUnqueueBuffers(s.source);
			if (AL10.alGetError() != AL10.AL_NO_ERROR)
				break;
			s.free.add(b);
		}
	}

	private void sweep(long now) {
		Iterator<Map.Entry<UUID, Src>> it = sources.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Src> e = it.next();
			if (now - e.getValue().lastUse > 30000L) {
				destroy(e.getValue());
				it.remove();
			}
		}
	}

	private void destroy(Src s) {
		try {
			AL10.alSourceStop(s.source);
			int processed = AL10.alGetSourcei(s.source, AL10.AL_BUFFERS_PROCESSED);
			while (processed-- > 0)
				AL10.alSourceUnqueueBuffers(s.source);
			AL10.alDeleteSources(s.source);
			if (s.buffers != null)
				AL10.alDeleteBuffers(s.buffers);
			AL10.alGetError();
		} catch (Exception ignored) {
		}
	}
}
