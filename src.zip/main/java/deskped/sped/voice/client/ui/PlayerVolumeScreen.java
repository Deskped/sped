package deskped.sped.voice.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

import deskped.sped.voice.client.VoiceClient;

@OnlyIn(Dist.CLIENT)
public class PlayerVolumeScreen extends Screen {

	private final Screen parent;
	private final List<Entry> entries = new ArrayList<>();
	private int page = 0;
	private int perPage = 1;

	private record Entry(UUID id, String name) {
	}

	public PlayerVolumeScreen(Screen parent) {
		super(Component.literal("\u0413\u0440\u043E\u043C\u043A\u043E\u0441\u0442\u044C \u0438\u0433\u0440\u043E\u043A\u043E\u0432"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		collect();
		int x = width / 2 - 100;
		int listTop = 40;
		int listBottom = height - 56;
		perPage = Math.max(1, (listBottom - listTop) / 24);
		int pages = Math.max(1, (entries.size() + perPage - 1) / perPage);
		if (page >= pages)
			page = pages - 1;
		int from = page * perPage;
		int to = Math.min(entries.size(), from + perPage);
		int y = listTop;
		for (int i = from; i < to; i++) {
			Entry e = entries.get(i);
			double val = VoiceClient.volumeFor(e.id()) / 2.0D;
			addRenderableWidget(new Ui.VSlider(x, y, 200, 20, val,
					v -> Component.literal(e.name() + ": " + Math.round(v * 200.0D) + "%"), v -> {
						VoiceClient.playerVolumes.put(e.id(), (float) (v * 2.0D));
						VoiceClient.saveConfig();
					}));
			y += 24;
		}
		if (pages > 1) {
			Button prev = Button.builder(Component.literal("< \u041D\u0430\u0437\u0430\u0434"), b -> {
				if (page > 0) {
					page--;
					rebuild();
				}
			}).bounds(x, height - 52, 98, 20).build();
			prev.active = page > 0;
			addRenderableWidget(prev);
			Button next = Button.builder(Component.literal("\u0412\u043F\u0435\u0440\u0451\u0434 >"), b -> {
				if ((page + 1) * perPage < entries.size()) {
					page++;
					rebuild();
				}
			}).bounds(x + 102, height - 52, 98, 20).build();
			next.active = (page + 1) * perPage < entries.size();
			addRenderableWidget(next);
		}
		addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(x, height - 28, 200, 20).build());
	}

	private void collect() {
		entries.clear();
		if (minecraft == null || minecraft.getConnection() == null)
			return;
		for (PlayerInfo info : minecraft.getConnection().getOnlinePlayers()) {
			UUID id = info.getProfile().getId();
			if (id.equals(VoiceClient.myId))
				continue;
			entries.add(new Entry(id, info.getProfile().getName()));
		}
		entries.sort(Comparator.comparing(Entry::name, String.CASE_INSENSITIVE_ORDER));
	}

	private void rebuild() {
		clearWidgets();
		init();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
		if (entries.isEmpty())
			g.drawCenteredString(font, "\u041D\u0435\u0442 \u0434\u0440\u0443\u0433\u0438\u0445 \u0438\u0433\u0440\u043E\u043A\u043E\u0432", width / 2, height / 2 - 4, Ui.DIM);
		super.render(g, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
