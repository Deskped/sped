package deskped.sped.voice.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

import deskped.sped.voice.VoiceNet;
import deskped.sped.voice.client.VoiceClient;

@OnlyIn(Dist.CLIENT)
public class GroupScreen extends Screen {

	private final Screen parent;
	private EditBox nameBox;

	public GroupScreen(Screen parent) {
		super(Component.literal("\u0413\u0440\u0443\u043F\u043F\u044B"));
		this.parent = parent;
		requestList();
	}

	@Override
	protected void init() {
		int x = width / 2 - 100;
		String prev = nameBox == null ? "" : nameBox.getValue();
		nameBox = new EditBox(font, x, 44, 134, 20, Component.literal("\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0433\u0440\u0443\u043F\u043F\u044B"));
		nameBox.setMaxLength(24);
		nameBox.setValue(prev);
		nameBox.setHint(Component.literal("\u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435"));
		addRenderableWidget(nameBox);
		addRenderableWidget(Button.builder(Component.literal("\u0412\u043E\u0439\u0442\u0438"), b -> join(nameBox.getValue())).bounds(x + 138, 44, 62, 20).build());

		List<String> names;
		List<Integer> counts;
		synchronized (VoiceClient.groupNames) {
			names = new ArrayList<>(VoiceClient.groupNames);
			counts = new ArrayList<>(VoiceClient.groupCounts);
		}
		int listTop = 72;
		int listBottom = height - 56;
		int rows = Math.max(0, (listBottom - listTop) / 24);
		int y = listTop;
		for (int i = 0; i < names.size() && i < rows; i++) {
			String name = names.get(i);
			int count = i < counts.size() ? counts.get(i) : 0;
			boolean own = name.equals(VoiceClient.group);
			String label = (own ? "\u2713 " : "") + name + " (" + count + ")";
			Button row = Button.builder(Component.literal(label), b -> join(name)).bounds(x, y, 200, 20).build();
			row.active = !own;
			addRenderableWidget(row);
			y += 24;
		}

		Button leave = Button.builder(Component.literal("\u041F\u043E\u043A\u0438\u043D\u0443\u0442\u044C"), b -> VoiceNet.sendToServer(new VoiceNet.GroupC2S(VoiceNet.GroupC2S.LEAVE, ""))).bounds(x, height - 52, 98, 20).build();
		leave.active = !VoiceClient.group.isEmpty();
		addRenderableWidget(leave);
		addRenderableWidget(Button.builder(Component.literal("\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C"), b -> requestList()).bounds(x + 102, height - 52, 98, 20).build());
		addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(x, height - 28, 200, 20).build());
	}

	private void join(String name) {
		String n = name == null ? "" : name.trim();
		if (n.isEmpty())
			return;
		VoiceNet.sendToServer(new VoiceNet.GroupC2S(VoiceNet.GroupC2S.JOIN, n));
	}

	private void requestList() {
		VoiceNet.sendToServer(new VoiceNet.GroupC2S(VoiceNet.GroupC2S.LIST, ""));
	}

	@Override
	public void tick() {
		if (VoiceClient.consumeGroupsDirty())
			rebuild();
		if (nameBox != null)
			nameBox.tick();
	}

	private void rebuild() {
		clearWidgets();
		init();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
		String cur = VoiceClient.group.isEmpty()
				? "\u0412\u044B \u043D\u0435 \u0432 \u0433\u0440\u0443\u043F\u043F\u0435"
				: "\u0412\u0430\u0448\u0430 \u0433\u0440\u0443\u043F\u043F\u0430: " + VoiceClient.group;
		g.drawCenteredString(font, cur, width / 2, 30, VoiceClient.group.isEmpty() ? Ui.DIM : Ui.ACCENT);
		super.render(g, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
