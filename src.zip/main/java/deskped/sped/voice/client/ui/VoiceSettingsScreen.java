package deskped.sped.voice.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.List;

import deskped.sped.voice.VoiceNet;
import deskped.sped.voice.client.MicThread;
import deskped.sped.voice.client.VoiceClient;

@OnlyIn(Dist.CLIENT)
public class VoiceSettingsScreen extends Screen {

	private final Screen parent;
	private int meterY;

	public VoiceSettingsScreen(Screen parent) {
		super(Component.literal("\u0413\u043E\u043B\u043E\u0441\u043E\u0432\u043E\u0439 \u0447\u0430\u0442"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int col = 150;
		int left = width / 2 - col - 2;
		int right = width / 2 + 2;
		int y = 36;
		addRenderableWidget(Button.builder(modeText(), b -> {
			VoiceClient.mode = VoiceClient.mode == VoiceClient.MODE_PTT ? VoiceClient.MODE_VOICE : VoiceClient.MODE_PTT;
			VoiceClient.saveConfig();
			b.setMessage(modeText());
		}).bounds(left, y, col, 20).build());
		addRenderableWidget(Button.builder(deviceText(), b -> {
			cycleDevice();
			b.setMessage(deviceText());
		}).bounds(right, y, col, 20).build());
		y += 24;
		addRenderableWidget(new Ui.VSlider(left, y, col, 20, (VoiceClient.thresholdDb + 80.0D) / 80.0D,
				v -> Component.literal("\u041F\u043E\u0440\u043E\u0433: " + Math.round(v * 80.0D - 80.0D) + " \u0434\u0411"), v -> {
					VoiceClient.thresholdDb = v * 80.0D - 80.0D;
					VoiceClient.saveConfig();
				}));
		double span = VoiceNet.PITCH_MAX - VoiceNet.PITCH_MIN;
		addRenderableWidget(new Ui.VSlider(right, y, col, 20, (VoiceClient.pitch - VoiceNet.PITCH_MIN) / span,
				v -> Component.literal("\u0422\u043E\u043D \u0433\u043E\u043B\u043E\u0441\u0430: " + pitchLabel((int) Math.round(VoiceNet.PITCH_MIN + v * span))), v -> {
					VoiceClient.pitch = VoiceNet.clampPitch((int) Math.round(VoiceNet.PITCH_MIN + v * span));
					VoiceClient.saveConfig();
				}));
		y += 24;
		addRenderableWidget(new Ui.VSlider(left, y, col, 20, VoiceClient.micVolume / 2.0D,
				v -> Component.literal("\u041C\u0438\u043A\u0440\u043E\u0444\u043E\u043D: " + Math.round(v * 200.0D) + "%"), v -> {
					VoiceClient.micVolume = (float) (v * 2.0D);
					VoiceClient.saveConfig();
				}));
		addRenderableWidget(new Ui.VSlider(right, y, col, 20, VoiceClient.mainVolume / 2.0D,
				v -> Component.literal("\u0413\u0440\u043E\u043C\u043A\u043E\u0441\u0442\u044C: " + Math.round(v * 200.0D) + "%"), v -> {
					VoiceClient.mainVolume = (float) (v * 2.0D);
					VoiceClient.saveConfig();
				}));
		y += 24;
		addRenderableWidget(Button.builder(muteText(), b -> {
			VoiceClient.muted = !VoiceClient.muted;
			VoiceClient.saveConfig();
			b.setMessage(muteText());
		}).bounds(left, y, col, 20).build());
		addRenderableWidget(Button.builder(deafenText(), b -> {
			VoiceClient.deafened = !VoiceClient.deafened;
			VoiceClient.saveConfig();
			b.setMessage(deafenText());
		}).bounds(right, y, col, 20).build());
		y += 24;
		addRenderableWidget(Button.builder(testText(), b -> {
			VoiceClient.testMic = !VoiceClient.testMic;
			b.setMessage(testText());
		}).bounds(left, y, col, 20).build());
		addRenderableWidget(Button.builder(Component.literal("\u041F\u0435\u0440\u0435\u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043C\u0438\u043A\u0440\u043E\u0444\u043E\u043D"), b -> VoiceClient.restartMic()).bounds(right, y, col, 20).build());
		y += 24;
		addRenderableWidget(Button.builder(Component.literal("\u0413\u0440\u0443\u043F\u043F\u044B..."), b -> minecraft.setScreen(new GroupScreen(this))).bounds(left, y, col, 20).build());
		addRenderableWidget(Button.builder(Component.literal("\u0413\u0440\u043E\u043C\u043A\u043E\u0441\u0442\u044C \u0438\u0433\u0440\u043E\u043A\u043E\u0432..."), b -> minecraft.setScreen(new PlayerVolumeScreen(this))).bounds(right, y, col, 20).build());
		y += 26;
		meterY = y;
		addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(width / 2 - 100, height - 28, 200, 20).build());
	}

	private static String pitchLabel(int pitch) {
		if (pitch == VoiceNet.PITCH_DEFAULT)
			return "\u043E\u0431\u044B\u0447\u043D\u044B\u0439";
		return (pitch > VoiceNet.PITCH_DEFAULT ? "+" : "") + (pitch - VoiceNet.PITCH_DEFAULT) + "%";
	}

	private Component modeText() {
		return Component.literal("\u0420\u0435\u0436\u0438\u043C: " + (VoiceClient.mode == VoiceClient.MODE_PTT ? "\u0440\u0430\u0446\u0438\u044F" : "\u0433\u043E\u043B\u043E\u0441"));
	}

	private Component muteText() {
		return Component.literal("\u041C\u0438\u043A\u0440\u043E\u0444\u043E\u043D: " + (VoiceClient.muted ? "\u0432\u044B\u043A\u043B." : "\u0432\u043A\u043B."));
	}

	private Component deafenText() {
		return Component.literal("\u041E\u0433\u043B\u0443\u0448\u0435\u043D\u0438\u0435: " + (VoiceClient.deafened ? "\u0432\u043A\u043B." : "\u0432\u044B\u043A\u043B."));
	}

	private Component testText() {
		return Component.literal("\u0422\u0435\u0441\u0442 \u043C\u0438\u043A\u0440\u043E\u0444\u043E\u043D\u0430: " + (VoiceClient.testMic ? "\u0432\u043A\u043B." : "\u0432\u044B\u043A\u043B."));
	}

	private Component deviceText() {
		String d = VoiceClient.micDevice;
		String label = d == null || d.isEmpty() ? "\u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E" : d;
		if (label.length() > 16)
			label = label.substring(0, 16) + "...";
		return Component.literal("\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E: " + label);
	}

	private void cycleDevice() {
		List<String> devices = MicThread.listDevices();
		if (devices.isEmpty()) {
			VoiceClient.micDevice = "";
		} else {
			int idx = devices.indexOf(VoiceClient.micDevice);
			idx++;
			if (idx >= devices.size()) {
				VoiceClient.micDevice = "";
			} else {
				VoiceClient.micDevice = devices.get(Math.max(0, idx));
			}
		}
		VoiceClient.saveConfig();
		VoiceClient.restartMic();
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		renderBackground(g);
		g.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
		drawMeter(g);
		super.render(g, mouseX, mouseY, partialTick);
	}

	private void drawMeter(GuiGraphics g) {
		int x = width / 2 - 152;
		int w = 304;
		int y = meterY;
		double db = VoiceClient.micLevelDb();
		double norm = (db + 80.0D) / 80.0D;
		boolean loud = db > VoiceClient.thresholdDb;
		Ui.bar(g, x, y, w, 6, norm, loud ? Ui.GREEN : 0xFF3F7F3F);
		double tn = (VoiceClient.thresholdDb + 80.0D) / 80.0D;
		int tx = x + (int) (w * Math.max(0.0D, Math.min(1.0D, tn)));
		g.fill(tx - 1, y - 2, tx + 1, y + 8, Ui.ACCENT);
		if (!VoiceClient.micOk())
			g.drawCenteredString(font, "\u041C\u0438\u043A\u0440\u043E\u0444\u043E\u043D \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D", width / 2, y + 12, Ui.RED);
	}

	@Override
	public void onClose() {
		VoiceClient.testMic = false;
		VoiceClient.saveConfig();
		minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
