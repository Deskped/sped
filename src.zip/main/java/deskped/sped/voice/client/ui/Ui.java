package deskped.sped.voice.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Consumer;
import java.util.function.Function;

@OnlyIn(Dist.CLIENT)
public final class Ui {

	public static final int TEXT = 0xFFFFFFFF;
	public static final int DIM = 0xFFA0A0A0;
	public static final int RED = 0xFFFF5555;
	public static final int GREEN = 0xFF55FF55;
	public static final int ACCENT = 0xFFFFFF55;
	public static final int CYAN = 0xFFFFFFFF;

	public static final int SLOT_BG = 0xFF000000;
	public static final int SLOT_BORDER = 0xFF373737;
	public static final int ROW_BG = 0xFF1E1E1E;
	public static final int ROW_HOVER = 0xFF3C3C3C;

	private Ui() {
	}

	public static void slot(GuiGraphics g, int x, int y, int w, int h) {
		g.fill(x - 1, y - 1, x + w + 1, y + h + 1, SLOT_BORDER);
		g.fill(x, y, x + w, y + h, SLOT_BG);
	}

	public static void bar(GuiGraphics g, int x, int y, int w, int h, double fraction, int color) {
		slot(g, x, y, w, h);
		int filled = (int) (w * Math.max(0.0D, Math.min(1.0D, fraction)));
		if (filled > 0)
			g.fill(x, y, x + filled, y + h, color);
	}

	@OnlyIn(Dist.CLIENT)
	public static class VSlider extends AbstractSliderButton {

		private final Function<Double, Component> fmt;
		private final Consumer<Double> apply;

		public VSlider(int x, int y, int w, int h, double value, Function<Double, Component> fmt, Consumer<Double> apply) {
			super(x, y, w, h, fmt.apply(value), value);
			this.fmt = fmt;
			this.apply = apply;
		}

		@Override
		protected void updateMessage() {
			setMessage(fmt.apply(value));
		}

		@Override
		protected void applyValue() {
			apply.accept(value);
		}
	}

	public static final int BG = 0xE6080611;
	public static final int PANEL = 0xF00E0B1A;
	public static final int LINE = 0xFF55E0FF;
	public static final int LINE_DIM = 0x8033A0C0;

	public static void panel(GuiGraphics g, int x, int y, int w, int h) {
		g.fill(x, y, x + w, y + h, PANEL);
		g.fill(x, y, x + w, y + 1, LINE);
		g.fill(x, y + h - 1, x + w, y + h, LINE);
		g.fill(x, y, x + 1, y + h, LINE);
		g.fill(x + w - 1, y, x + w, y + h, LINE);
	}

	public static void stars(GuiGraphics g, int x, int y, int w, int h, long seed) {
		java.util.Random r = new java.util.Random(seed);
		int n = Math.max(8, w * h / 900);
		for (int i = 0; i < n; i++) {
			int sx = x + r.nextInt(Math.max(1, w));
			int sy = y + r.nextInt(Math.max(1, h));
			int a = 40 + r.nextInt(120);
			g.fill(sx, sy, sx + 1, sy + 1, (a << 24) | 0x00FFFFFF);
		}
	}

	@OnlyIn(Dist.CLIENT)
	public static class FlatButton extends net.minecraft.client.gui.components.Button {
		public FlatButton(int x, int y, int w, int h, Component msg, OnPress onPress) {
			super(x, y, w, h, msg, onPress, DEFAULT_NARRATION);
		}

		@Override
		public void renderWidget(GuiGraphics g, int mx, int my, float partial) {
			boolean hov = isHoveredOrFocused();
			g.fill(getX(), getY(), getX() + width, getY() + height, hov ? 0xFF1B2A3A : 0xFF12151C);
			int edge = active ? (hov ? LINE : LINE_DIM) : 0x60505050;
			g.fill(getX(), getY(), getX() + width, getY() + 1, edge);
			g.fill(getX(), getY() + height - 1, getX() + width, getY() + height, edge);
			g.fill(getX(), getY(), getX() + 1, getY() + height, edge);
			g.fill(getX() + width - 1, getY(), getX() + width, getY() + height, edge);
			net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
			String t = getMessage().getString();
			g.drawString(mc.font, t, getX() + width / 2 - mc.font.width(t) / 2, getY() + height / 2 - 4,
					active ? TEXT : DIM, false);
		}
	}

}
