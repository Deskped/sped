package deskped.sped.voice.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.lwjgl.glfw.GLFW;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class VoiceKeys {

	public static final String CATEGORY = "\u0413\u043E\u043B\u043E\u0441\u043E\u0432\u043E\u0439 \u0447\u0430\u0442 SPED";

	public static KeyMapping PTT;
	public static KeyMapping WHISPER;
	public static KeyMapping MUTE;
	public static KeyMapping DEAFEN;
	public static KeyMapping MENU;

	@SubscribeEvent
	public static void onRegister(RegisterKeyMappingsEvent event) {
		PTT = new KeyMapping("\u0413\u043E\u0432\u043E\u0440\u0438\u0442\u044C", KeyConflictContext.UNIVERSAL, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY);
		WHISPER = new KeyMapping("\u0428\u0435\u043F\u043E\u0442", KeyConflictContext.UNIVERSAL, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY);
		MUTE = new KeyMapping("\u041C\u0438\u043A\u0440\u043E\u0444\u043E\u043D \u0432\u043A\u043B/\u0432\u044B\u043A\u043B", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, CATEGORY);
		DEAFEN = new KeyMapping("\u0417\u0430\u0433\u043B\u0443\u0448\u0438\u0442\u044C\u0441\u044F", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, CATEGORY);
		MENU = new KeyMapping("\u041C\u0435\u043D\u044E", KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CATEGORY);
		event.register(PTT);
		event.register(WHISPER);
		event.register(MUTE);
		event.register(DEAFEN);
		event.register(MENU);
	}
}
