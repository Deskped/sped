package deskped.sped.voice.client;

import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;

import deskped.sped.SpedMod;
import deskped.sped.voice.VoiceNet;
import deskped.sped.voice.client.ui.Ui;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class VoiceHud implements IGuiOverlay {

	private static final ResourceLocation MIC_GREEN = new ResourceLocation("sped", "textures/gui/voice/mic_green.png");
	private static final ResourceLocation MIC_PURPLE = new ResourceLocation("sped", "textures/gui/voice/mic_purple.png");
	private static final ResourceLocation MIC_CYAN = new ResourceLocation("sped", "textures/gui/voice/mic_cyan.png");
	private static final ResourceLocation MIC_MUTED = new ResourceLocation("sped", "textures/gui/voice/mic_muted.png");
	private static final ResourceLocation MIC_BANNED = new ResourceLocation("sped", "textures/gui/voice/mic_banned.png");
	private static final ResourceLocation SOUND_MUTED = new ResourceLocation("sped", "textures/gui/voice/sound_muted.png");
	private static final ResourceLocation GROUP = new ResourceLocation("sped", "textures/gui/voice/group.png");

	@SubscribeEvent
	public static void onRegister(RegisterGuiOverlaysEvent event) {
		event.registerAboveAll("sped_voice", new VoiceHud());
	}

	private static void icon(GuiGraphics g, ResourceLocation tex, int x, int y) {
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		g.blit(tex, x, y, 0, 0, 16, 16, 16, 16);
		RenderSystem.disableBlend();
	}

	@Override
	public void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenWidth, int screenHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui)
			return;
		if (!VoiceClient.ready)
			return;
		int cx = screenWidth / 2 - 8;
		int cy = screenHeight - 56;
		if (VoiceClient.serverMuted) {
			icon(g, MIC_BANNED, cx, cy);
		} else if (!VoiceClient.serverEnabled) {
			icon(g, MIC_MUTED, cx, cy);
			return;
		} else if (VoiceClient.deafened) {
			icon(g, SOUND_MUTED, cx, cy);
		} else if (VoiceClient.muted || !VoiceClient.micOk()) {
			icon(g, MIC_MUTED, cx, cy);
		} else if (VoiceClient.selfTalking()) {
			Byte fl = VoiceClient.talkingFlags.get(VoiceClient.myId);
			boolean whisper = fl != null && (fl & VoiceNet.FLAG_WHISPER) != 0;
			icon(g, whisper ? MIC_PURPLE : MIC_GREEN, cx, cy);
		}
		if (!VoiceClient.group.isEmpty()) {
			icon(g, GROUP, 5, screenHeight - 21);
			g.drawString(mc.font, VoiceClient.group, 23, screenHeight - 17, Ui.ACCENT);
		}
		long now = System.currentTimeMillis();
		int line = 0;
		for (Map.Entry<UUID, Long> e : VoiceClient.talking.entrySet()) {
			if (now - e.getValue() > 300L)
				continue;
			UUID id = e.getKey();
			if (id.equals(VoiceClient.myId))
				continue;
			String name = resolveName(mc, id);
			if (name == null)
				continue;
			Byte fl = VoiceClient.talkingFlags.get(id);
			boolean whisper = fl != null && (fl & VoiceNet.FLAG_WHISPER) != 0;
			int ty = screenHeight - 44 - line * 18;
			icon(g, whisper ? MIC_PURPLE : MIC_CYAN, 4, ty);
			g.drawString(mc.font, name, 22, ty + 4, whisper ? Ui.ACCENT : Ui.CYAN);
			line++;
			if (line >= 6)
				break;
		}
	}

	private static String resolveName(Minecraft mc, UUID id) {
		if (mc.getConnection() == null)
			return null;
		PlayerInfo info = mc.getConnection().getPlayerInfo(id);
		if (info == null)
			return null;
		return info.getProfile().getName();
	}
}
