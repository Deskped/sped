package deskped.sped.voice;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class VoiceNet {

	public static final byte FLAG_WHISPER = 1;
	public static final byte FLAG_GROUP_FAR = 2;

	public static final int PITCH_MIN = 70;
	public static final int PITCH_MAX = 140;
	public static final int PITCH_DEFAULT = 100;

	public static int clampPitch(int pitch) {
		if (pitch < PITCH_MIN)
			return PITCH_MIN;
		if (pitch > PITCH_MAX)
			return PITCH_MAX;
		return pitch;
	}

	private static final String VERSION = "1";
	public static SimpleChannel CHANNEL;

	@SubscribeEvent
	public static void onCommonSetup(FMLCommonSetupEvent event) {
		if (CHANNEL != null)
			return;
		CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SpedMod.MODID, "voice"), () -> VERSION, VERSION::equals, VERSION::equals);
		int id = 0;
		CHANNEL.registerMessage(id++, VoiceC2S.class, VoiceC2S::encode, VoiceC2S::decode, VoiceC2S::handle);
		CHANNEL.registerMessage(id++, VoiceS2C.class, VoiceS2C::encode, VoiceS2C::decode, VoiceS2C::handle);
		CHANNEL.registerMessage(id++, ConfigS2C.class, ConfigS2C::encode, ConfigS2C::decode, ConfigS2C::handle);
		CHANNEL.registerMessage(id++, GroupC2S.class, GroupC2S::encode, GroupC2S::decode, GroupC2S::handle);
		CHANNEL.registerMessage(id++, GroupsS2C.class, GroupsS2C::encode, GroupsS2C::decode, GroupsS2C::handle);
		CHANNEL.registerMessage(id++, MuteS2C.class, MuteS2C::encode, MuteS2C::decode, MuteS2C::handle);
	}

	public static void sendToServer(Object msg) {
		if (CHANNEL != null)
			CHANNEL.sendToServer(msg);
	}

	public static void sendTo(ServerPlayer player, Object msg) {
		if (CHANNEL != null)
			CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
	}

	public static class VoiceC2S {
		public final byte flags;
		public final int pitch;
		public final byte[] data;

		public VoiceC2S(byte flags, int pitch, byte[] data) {
			this.flags = flags;
			this.pitch = clampPitch(pitch);
			this.data = data;
		}

		public static void encode(VoiceC2S msg, FriendlyByteBuf buf) {
			buf.writeByte(msg.flags);
			buf.writeByte(msg.pitch);
			buf.writeByteArray(msg.data);
		}

		public static VoiceC2S decode(FriendlyByteBuf buf) {
			return new VoiceC2S(buf.readByte(), buf.readUnsignedByte(), buf.readByteArray());
		}

		public static void handle(VoiceC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					VoiceServer.relay(sender, msg.flags, msg.pitch, msg.data);
			});
			c.setPacketHandled(true);
		}
	}

	public static class VoiceS2C {
		public final UUID id;
		public final float x;
		public final float y;
		public final float z;
		public final byte flags;
		public final int pitch;
		public final byte[] data;

		public VoiceS2C(UUID id, float x, float y, float z, byte flags, int pitch, byte[] data) {
			this.id = id;
			this.x = x;
			this.y = y;
			this.z = z;
			this.flags = flags;
			this.pitch = clampPitch(pitch);
			this.data = data;
		}

		public static void encode(VoiceS2C msg, FriendlyByteBuf buf) {
			buf.writeUUID(msg.id);
			buf.writeFloat(msg.x);
			buf.writeFloat(msg.y);
			buf.writeFloat(msg.z);
			buf.writeByte(msg.flags);
			buf.writeByte(msg.pitch);
			buf.writeByteArray(msg.data);
		}

		public static VoiceS2C decode(FriendlyByteBuf buf) {
			return new VoiceS2C(buf.readUUID(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readByte(), buf.readUnsignedByte(), buf.readByteArray());
		}

		public static void handle(VoiceS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.voice.client.VoiceClient.onVoice(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class ConfigS2C {
		public final boolean enabled;
		public final float distance;
		public final float whisper;

		public ConfigS2C(boolean enabled, float distance, float whisper) {
			this.enabled = enabled;
			this.distance = distance;
			this.whisper = whisper;
		}

		public static void encode(ConfigS2C msg, FriendlyByteBuf buf) {
			buf.writeBoolean(msg.enabled);
			buf.writeFloat(msg.distance);
			buf.writeFloat(msg.whisper);
		}

		public static ConfigS2C decode(FriendlyByteBuf buf) {
			return new ConfigS2C(buf.readBoolean(), buf.readFloat(), buf.readFloat());
		}

		public static void handle(ConfigS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.voice.client.VoiceClient.onConfig(msg));
			ctx.get().setPacketHandled(true);
		}
	}

	public static class GroupC2S {
		public static final byte LIST = 0;
		public static final byte JOIN = 1;
		public static final byte LEAVE = 2;

		public final byte action;
		public final String name;

		public GroupC2S(byte action, String name) {
			this.action = action;
			this.name = name;
		}

		public static void encode(GroupC2S msg, FriendlyByteBuf buf) {
			buf.writeByte(msg.action);
			buf.writeUtf(msg.name, 32);
		}

		public static GroupC2S decode(FriendlyByteBuf buf) {
			return new GroupC2S(buf.readByte(), buf.readUtf(32));
		}

		public static void handle(GroupC2S msg, Supplier<NetworkEvent.Context> ctx) {
			NetworkEvent.Context c = ctx.get();
			c.enqueueWork(() -> {
				ServerPlayer sender = c.getSender();
				if (sender != null)
					VoiceServer.group(sender, msg.action, msg.name);
			});
			c.setPacketHandled(true);
		}
	}

	public static class GroupsS2C {
		public final String own;
		public final List<String> names;
		public final List<Integer> counts;

		public GroupsS2C(String own, List<String> names, List<Integer> counts) {
			this.own = own;
			this.names = names;
			this.counts = counts;
		}

		public static void encode(GroupsS2C msg, FriendlyByteBuf buf) {
			buf.writeUtf(msg.own, 32);
			buf.writeVarInt(msg.names.size());
			for (int i = 0; i < msg.names.size(); i++) {
				buf.writeUtf(msg.names.get(i), 32);
				buf.writeVarInt(msg.counts.get(i));
			}
		}

		public static GroupsS2C decode(FriendlyByteBuf buf) {
			String own = buf.readUtf(32);
			int n = buf.readVarInt();
			List<String> names = new ArrayList<>();
			List<Integer> counts = new ArrayList<>();
			for (int i = 0; i < n; i++) {
				names.add(buf.readUtf(32));
				counts.add(buf.readVarInt());
			}
			return new GroupsS2C(own, names, counts);
		}

		public static void handle(GroupsS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.voice.client.VoiceClient.onGroups(msg));
			ctx.get().setPacketHandled(true);
		}
	}
	public static class MuteS2C {
		public final boolean muted;

		public MuteS2C(boolean muted) {
			this.muted = muted;
		}

		public static void encode(MuteS2C msg, FriendlyByteBuf buf) {
			buf.writeBoolean(msg.muted);
		}

		public static MuteS2C decode(FriendlyByteBuf buf) {
			return new MuteS2C(buf.readBoolean());
		}

		public static void handle(MuteS2C msg, Supplier<NetworkEvent.Context> ctx) {
			DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> deskped.sped.voice.client.VoiceClient.onMute(msg));
			ctx.get().setPacketHandled(true);
		}
	}
}
