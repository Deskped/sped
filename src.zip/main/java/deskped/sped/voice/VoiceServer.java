package deskped.sped.voice;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import deskped.sped.SpedMod;

@Mod.EventBusSubscriber(modid = SpedMod.MODID)
public class VoiceServer {

	public static volatile boolean enabled = true;
	public static volatile double distance = 48.0D;
	public static volatile double whisperDistance = 12.0D;

	private static final Map<UUID, String> GROUPS = new ConcurrentHashMap<>();
	private static final int MAX_PACKET = 700;
	private static int tickCounter = 0;

	@SubscribeEvent
	public static void onServerStart(ServerAboutToStartEvent event) {
		GROUPS.clear();
		loadConfig();
	}

	@SubscribeEvent
	public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
		Player p = event.getEntity();
		if (p instanceof ServerPlayer sp) {
			VoiceNet.sendTo(sp, new VoiceNet.ConfigS2C(enabled, (float) distance, (float) whisperDistance));
			if (isMuted(sp))
				VoiceNet.sendTo(sp, new VoiceNet.MuteS2C(true));
		}
	}

	@SubscribeEvent
	public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
		GROUPS.remove(event.getEntity().getUUID());
	}

	@SubscribeEvent
	public static void onCommands(RegisterCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("mute").requires(s -> s.hasPermission(2))
				.then(Commands.argument("player", EntityArgument.player())
						.executes(ctx -> mute(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 0))
						.then(Commands.argument("minutes", IntegerArgumentType.integer(1, 525600))
								.executes(ctx -> mute(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), IntegerArgumentType.getInteger(ctx, "minutes"))))));
		event.getDispatcher().register(Commands.literal("unmute").requires(s -> s.hasPermission(2))
				.then(Commands.argument("player", EntityArgument.player())
						.executes(ctx -> unmute(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))));
	}

	private static int mute(CommandSourceStack src, ServerPlayer target, int minutes) {
		MuteData data = MuteData.get(src.getServer());
		long until = minutes <= 0 ? 0L : System.currentTimeMillis() + minutes * 60000L;
		data.mutes.put(target.getUUID(), until);
		data.setDirty();
		VoiceNet.sendTo(target, new VoiceNet.MuteS2C(true));
		String dur = minutes <= 0 ? "\u043D\u0430\u0432\u0441\u0435\u0433\u0434\u0430" : "\u043D\u0430 " + minutes + " \u043C\u0438\u043D";
		target.sendSystemMessage(Component.literal("\u0412\u0430\u043C \u0432\u044B\u0434\u0430\u043D \u043C\u0443\u0442 " + dur));
		src.sendSuccess(() -> Component.literal("\u0418\u0433\u0440\u043E\u043A " + target.getGameProfile().getName() + " \u0437\u0430\u043C\u044C\u044E\u0447\u0435\u043D " + dur), true);
		return 1;
	}

	private static int unmute(CommandSourceStack src, ServerPlayer target) {
		MuteData data = MuteData.get(src.getServer());
		Long removed = data.mutes.remove(target.getUUID());
		if (removed == null) {
			src.sendSuccess(() -> Component.literal("\u0418\u0433\u0440\u043E\u043A " + target.getGameProfile().getName() + " \u043D\u0435 \u0437\u0430\u043C\u044C\u044E\u0447\u0435\u043D"), false);
			return 0;
		}
		data.setDirty();
		VoiceNet.sendTo(target, new VoiceNet.MuteS2C(false));
		target.sendSystemMessage(Component.literal("\u041C\u0443\u0442 \u0441\u043D\u044F\u0442"));
		src.sendSuccess(() -> Component.literal("\u041C\u0443\u0442 \u0441\u043D\u044F\u0442 \u0441 \u0438\u0433\u0440\u043E\u043A\u0430 " + target.getGameProfile().getName()), true);
		return 1;
	}

	@SubscribeEvent
	public static void onChat(ServerChatEvent event) {
		ServerPlayer p = event.getPlayer();
		if (isMuted(p)) {
			event.setCanceled(true);
			p.sendSystemMessage(Component.literal("\u0412\u044B \u0437\u0430\u043C\u044C\u044E\u0447\u0435\u043D\u044B" + remain(p)));
		}
	}

	@SubscribeEvent
	public static void onServerTick(TickEvent.ServerTickEvent event) {
		if (event.phase != TickEvent.Phase.END)
			return;
		if (++tickCounter % 200 != 0)
			return;
		MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
		if (server == null)
			return;
		for (ServerPlayer p : server.getPlayerList().getPlayers())
			isMuted(p);
	}

	public static boolean isMuted(ServerPlayer p) {
		MinecraftServer server = p.getServer();
		if (server == null)
			return false;
		MuteData data = MuteData.get(server);
		Long until = data.mutes.get(p.getUUID());
		if (until == null)
			return false;
		if (until != 0L && System.currentTimeMillis() > until) {
			data.mutes.remove(p.getUUID());
			data.setDirty();
			VoiceNet.sendTo(p, new VoiceNet.MuteS2C(false));
			return false;
		}
		return true;
	}

	private static String remain(ServerPlayer p) {
		MinecraftServer server = p.getServer();
		if (server == null)
			return "";
		Long until = MuteData.get(server).mutes.get(p.getUUID());
		if (until == null || until == 0L)
			return "";
		long mins = (until - System.currentTimeMillis() + 59999L) / 60000L;
		if (mins < 1L)
			mins = 1L;
		return ", \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C " + mins + " \u043C\u0438\u043D";
	}

	public static void relay(ServerPlayer sender, byte flags, int pitch, byte[] data) {
		if (!enabled || data == null || data.length < 4 || data.length > MAX_PACKET)
			return;
		if (sender.getServer() == null)
			return;
		if (isMuted(sender))
			return;
		boolean whisper = (flags & VoiceNet.FLAG_WHISPER) != 0;
		double maxD = whisper ? whisperDistance : distance;
		double max2 = maxD * maxD;
		String own = GROUPS.get(sender.getUUID());
		Vec3 pos = sender.position();
		float sx = (float) pos.x;
		float sy = (float) (pos.y + sender.getEyeHeight());
		float sz = (float) pos.z;
		UUID id = sender.getUUID();
		for (ServerPlayer target : sender.getServer().getPlayerList().getPlayers()) {
			if (target == sender)
				continue;
			byte outFlags = flags;
			boolean sameLevel = target.level() == sender.level();
			boolean near = sameLevel && target.distanceToSqr(sender) <= max2;
			if (!near) {
				boolean sameGroup = own != null && !own.isEmpty() && own.equals(GROUPS.get(target.getUUID()));
				if (!sameGroup)
					continue;
				outFlags |= VoiceNet.FLAG_GROUP_FAR;
			}
			VoiceNet.sendTo(target, new VoiceNet.VoiceS2C(id, sx, sy, sz, outFlags, pitch, data));
		}
	}

	public static void group(ServerPlayer player, byte action, String rawName) {
		if (action == VoiceNet.GroupC2S.JOIN) {
			String name = rawName == null ? "" : rawName.trim();
			if (name.length() > 24)
				name = name.substring(0, 24);
			if (!name.isEmpty())
				GROUPS.put(player.getUUID(), name);
		} else if (action == VoiceNet.GroupC2S.LEAVE) {
			GROUPS.remove(player.getUUID());
		}
		sendGroups(player);
	}

	private static void sendGroups(ServerPlayer player) {
		Map<String, Integer> tally = new LinkedHashMap<>();
		for (String g : GROUPS.values())
			tally.merge(g, 1, Integer::sum);
		List<String> names = new ArrayList<>(tally.keySet());
		List<Integer> counts = new ArrayList<>();
		for (String n : names)
			counts.add(tally.get(n));
		String own = GROUPS.getOrDefault(player.getUUID(), "");
		VoiceNet.sendTo(player, new VoiceNet.GroupsS2C(own, names, counts));
	}

	private static void loadConfig() {
		Path path = FMLPaths.CONFIGDIR.get().resolve("sped_voice_server.properties");
		Properties props = new Properties();
		if (Files.exists(path)) {
			try (InputStream in = Files.newInputStream(path)) {
				props.load(in);
			} catch (IOException ignored) {
			}
		}
		enabled = Boolean.parseBoolean(props.getProperty("enabled", "true"));
		distance = parse(props.getProperty("distance"), 48.0D, 4.0D, 512.0D);
		whisperDistance = parse(props.getProperty("whisper_distance"), 12.0D, 2.0D, 256.0D);
		props.setProperty("enabled", String.valueOf(enabled));
		props.setProperty("distance", String.valueOf(distance));
		props.setProperty("whisper_distance", String.valueOf(whisperDistance));
		try (OutputStream out = Files.newOutputStream(path)) {
			props.store(out, "SPED voice server config");
		} catch (IOException ignored) {
		}
	}

	private static double parse(String s, double def, double min, double max) {
		if (s == null)
			return def;
		try {
			double v = Double.parseDouble(s.trim());
			return Math.max(min, Math.min(max, v));
		} catch (NumberFormatException e) {
			return def;
		}
	}

	public static class MuteData extends SavedData {

		public final Map<UUID, Long> mutes = new HashMap<>();

		public static MuteData get(MinecraftServer server) {
			return server.overworld().getDataStorage().computeIfAbsent(MuteData::load, MuteData::new, "sped_voice_mutes");
		}

		public static MuteData load(CompoundTag tag) {
			MuteData d = new MuteData();
			ListTag list = tag.getList("mutes", Tag.TAG_COMPOUND);
			for (int i = 0; i < list.size(); i++) {
				CompoundTag e = list.getCompound(i);
				d.mutes.put(e.getUUID("id"), e.getLong("until"));
			}
			return d;
		}

		@Override
		public CompoundTag save(CompoundTag tag) {
			ListTag list = new ListTag();
			for (Map.Entry<UUID, Long> e : mutes.entrySet()) {
				CompoundTag t = new CompoundTag();
				t.putUUID("id", e.getKey());
				t.putLong("until", e.getValue());
				list.add(t);
			}
			tag.put("mutes", list);
			return tag;
		}
	}
}
