package deskped.sped.voice;

public final class Adpcm {

	private static final int[] STEP = {7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767};
	private static final int[] INDEX = {-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8};

	private Adpcm() {
	}

	public static byte[] encode(short[] pcm, int[] indexState) {
		int index = clampIndex(indexState[0]);
		int predictor = pcm[0];
		int nibbles = pcm.length - 1;
		byte[] out = new byte[3 + (nibbles + 1) / 2];
		out[0] = (byte) (predictor & 0xFF);
		out[1] = (byte) ((predictor >> 8) & 0xFF);
		out[2] = (byte) index;
		int op = 3;
		int pending = 0;
		boolean half = false;
		for (int i = 1; i < pcm.length; i++) {
			int step = STEP[index];
			int diff = pcm[i] - predictor;
			int sign = diff < 0 ? 8 : 0;
			if (sign != 0)
				diff = -diff;
			int delta = 0;
			int vp = step >> 3;
			if (diff >= step) {
				delta = 4;
				diff -= step;
				vp += step;
			}
			step >>= 1;
			if (diff >= step) {
				delta |= 2;
				diff -= step;
				vp += step;
			}
			step >>= 1;
			if (diff >= step) {
				delta |= 1;
				vp += step;
			}
			if (sign != 0)
				predictor -= vp;
			else
				predictor += vp;
			if (predictor > 32767)
				predictor = 32767;
			else if (predictor < -32768)
				predictor = -32768;
			delta |= sign;
			index = clampIndex(index + INDEX[delta]);
			if (!half) {
				pending = delta & 0xF;
				half = true;
			} else {
				out[op++] = (byte) (pending | ((delta & 0xF) << 4));
				half = false;
			}
		}
		if (half)
			out[op] = (byte) pending;
		indexState[0] = index;
		return out;
	}

	public static short[] decode(byte[] in, int samples) {
		short[] out = new short[samples];
		if (in.length < 3)
			return out;
		int predictor = (short) ((in[0] & 0xFF) | ((in[1] & 0xFF) << 8));
		int index = clampIndex(in[2] & 0xFF);
		out[0] = (short) predictor;
		int ip = 3;
		int cur = 0;
		boolean half = false;
		for (int i = 1; i < samples; i++) {
			int delta;
			if (!half) {
				if (ip >= in.length)
					break;
				cur = in[ip++] & 0xFF;
				delta = cur & 0xF;
				half = true;
			} else {
				delta = (cur >> 4) & 0xF;
				half = false;
			}
			int step = STEP[index];
			int vp = step >> 3;
			if ((delta & 4) != 0)
				vp += step;
			if ((delta & 2) != 0)
				vp += step >> 1;
			if ((delta & 1) != 0)
				vp += step >> 2;
			if ((delta & 8) != 0)
				predictor -= vp;
			else
				predictor += vp;
			if (predictor > 32767)
				predictor = 32767;
			else if (predictor < -32768)
				predictor = -32768;
			index = clampIndex(index + INDEX[delta]);
			out[i] = (short) predictor;
		}
		return out;
	}

	private static int clampIndex(int i) {
		if (i < 0)
			return 0;
		if (i > 88)
			return 88;
		return i;
	}
}
