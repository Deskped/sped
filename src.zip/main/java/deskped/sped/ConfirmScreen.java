package deskped.sped;

import deskped.sped.client.ClientMenuState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ConfirmScreen extends Screen {

    private final Screen  parent;
    private final Minecraft mc;
    private final boolean ru;

    public ConfirmScreen(Screen parent, Minecraft mc, boolean ru) {
        super(Component.empty());
        this.parent = parent;
        this.mc     = mc;
        this.ru     = ru;
    }

    @Override
    protected void init() {
        int bh  = 18;
        int gap = 5;
        int bw1 = 55;
        int bw2 = 170;
        int bw3 = 65;
        int total = bw1 + gap + bw2 + gap + bw3;
        int sx = this.width / 2 - total / 2;
        int by = this.height / 2 + 12;

        this.addRenderableWidget(Button.builder(
            Component.literal(ru ? "Да" : "Yes"),
            b -> { ClientMenuState.confirmed = true; Menu.connect(parent, mc); }
        ).bounds(sx, by, bw1, bh).build());

        this.addRenderableWidget(Button.builder(
            Component.literal(ru ? "Не показывать больше" : "Don't show again"),
            b -> { ClientMenuState.confirmed = true; Menu.connect(parent, mc); }
        ).bounds(sx + bw1 + gap, by, bw2, bh).build());

        this.addRenderableWidget(Button.builder(
            Component.literal(ru ? "Отмена" : "Cancel"),
            b -> mc.setScreen(parent)
        ).bounds(sx + bw1 + gap + bw2 + gap, by, bw3, bh).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = System.currentTimeMillis();
        Menu.drawSpaceBg(g, this.width, this.height, now, 0f, 0f);

        String line = ru
            ? "Играть переводит вас на игровой сервер. Вы согласны?"
            : "Play will connect you to the game server. Do you agree?";

        int cx = this.width / 2;
        int ty = this.height / 2 - 14;
        var lines = this.font.split(Component.literal(line), 340);
        for (var seq : lines) {
            g.drawCenteredString(this.font, seq, cx, ty, 0xFFFFFF);
            ty += 11;
        }

        super.render(g, mx, my, partial);
    }

    @Override public boolean isPauseScreen() { return false; }
}